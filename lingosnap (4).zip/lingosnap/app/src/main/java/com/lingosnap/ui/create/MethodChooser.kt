package com.lingosnap.ui.create

import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.lingosnap.ui.theme.bold

/**
 * "How do you want to add cards?" – three big, calm cards (photo/file first, because that is what the app is for).
 * Used when a deck is created and when cards are added to an existing deck. Result: 1 = scan, 2 = AI, 0 = type.
 */
@Composable
fun MethodChooser(enabled: Boolean = true, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        MethodCard(Icons.Rounded.CameraAlt, tr("Foto oder Datei scannen"), tr("Kamera, Bild, PDF, Word oder PowerPoint"), highlighted = true, enabled = enabled) { onPick(1) }
        MethodCard(Icons.Rounded.AutoAwesome, tr("Mit KI erzeugen"), tr("Thema eingeben, Karten generieren lassen"), highlighted = false, enabled = enabled) { onPick(2) }
        MethodCard(Icons.Rounded.Edit, tr("Selbst eintippen"), tr("Einzeln oder als Liste einfügen"), highlighted = false, enabled = enabled) { onPick(0) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MethodCard(icon: ImageVector, title: String, desc: String, highlighted: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick, enabled = enabled, shape = RoundedCornerShape(30.dp),
        color = if (highlighted) cs.primaryContainer else cs.surfaceContainerHigh,
        contentColor = if (highlighted) cs.onPrimaryContainer else cs.onSurface,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = if (highlighted) cs.primary else cs.secondaryContainer, modifier = Modifier.size(56.dp)) {
                androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = if (highlighted) cs.onPrimary else cs.onSecondaryContainer, modifier = Modifier.size(28.dp))
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium.bold())
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = if (highlighted) cs.onPrimaryContainer.copy(alpha = 0.8f) else cs.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = if (highlighted) cs.onPrimaryContainer else cs.onSurfaceVariant)
        }
    }
}
