package com.lingosnap.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Expressive look: big, soft, rounded shapes. */
private val LingoShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(30.dp),
    extraLarge = RoundedCornerShape(40.dp),
)

/** Expressive-style emphasis: bolder weight for headlines and labels. */
fun TextStyle.bold(): TextStyle = copy(fontWeight = FontWeight.Bold)

/**
 * Material 3 + Material You.
 * [accent] 0 = colours from the phone's wallpaper (Android 12+), 1.. = [AccentOptions] built with Android's own theme styles ([style]).
 * [darkMode] 0 = follow system, 1 = dark, 2 = light.
 */
@Composable
fun LingoSnapTheme(
    darkMode: Int = 0,
    accent: Int = 0,
    style: Int = 0,
    content: @Composable () -> Unit,
) {
    val dark = when (darkMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val context = LocalContext.current
    val colorScheme = when {
        accent == 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            (if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)).richer(dark)
        else -> {
            // wallpaper colours need Android 12; older phones fall back to the first (blue) accent
            val option = AccentOptions.getOrNull(accent - 1) ?: AccentOptions.first()
            remember(option.seed, style, dark) { seedScheme(option.seed, style, dark) }
        }
    }
    MaterialTheme(colorScheme = colorScheme, shapes = LingoShapes, content = content)
}

/** Pulls the pastel container colours a bit towards their accent so the UI looks vivid instead of washed out. */
private fun ColorScheme.richer(dark: Boolean): ColorScheme {
    val t = if (dark) 0.14f else 0.22f
    return copy(
        primaryContainer = lerp(primaryContainer, primary, t),
        secondaryContainer = lerp(secondaryContainer, secondary, t),
        tertiaryContainer = lerp(tertiaryContainer, tertiary, t),
    )
}
