package com.lingosnap.ui.create

import com.lingosnap.util.tr

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.components.OptionSheet
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/**
 * New deck as a short, calm wizard: one question per page with a big headline.
 * 0 what to learn · 1 languages (or subject) · 2 name · 3 how to fill it. The last choice creates the deck and jumps
 * straight into that way (photo, AI, typing). No name: the AI picks one once the first cards are there.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NewDeckScreen(onCreated: (id: Long, method: Int) -> Unit, onBack: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var step by rememberSaveable { mutableIntStateOf(0) }
    var languageDeck by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "en")
    }
    var busy by remember { mutableStateOf(false) }
    val lastStep = 3

    fun back() { if (step > 0 && !busy) step-- else if (!busy) onBack() }
    BackHandler(enabled = step > 0 && !busy) { step-- }

    fun create(method: Int) {
        if (busy) return
        busy = true
        scope.launch {
            val finalName = name.trim().ifBlank { DEFAULT_DECK_NAME }
            val id = if (languageDeck) repo.createDeck(finalName, null, source, target, "")
            else repo.createDeck(finalName, null, "", "", subject, kind = "cards")
            onCreated(id, method)
        }
    }

    Column(Modifier.fillMaxSize().background(cs.surface).statusBarsPadding().navigationBarsPadding().imePadding()) {
        // top: back/close and a thin progress line
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { back() }) {
                Icon(if (step == 0) Icons.Rounded.Close else Icons.AutoMirrored.Rounded.ArrowBack, tr("Zurück"))
            }
            LinearProgressIndicator(
                progress = { (step + 1f) / (lastStep + 1f) },
                modifier = Modifier.weight(1f).height(6.dp).padding(end = 20.dp),
                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
                trackColor = cs.surfaceContainerHighest,
            )
        }
        AnimatedContent(
            targetState = step,
            modifier = Modifier.weight(1f),
            transitionSpec = {
                val forward = targetState > initialState
                (slideInHorizontally { if (forward) it / 5 else -it / 5 } + fadeIn()) togetherWith
                    (slideOutHorizontally { if (forward) -it / 5 else it / 5 } + fadeOut())
            },
            label = "newDeckStep",
        ) { current ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                when (current) {
                    0 -> {
                        Headline(tr("Was möchtest du lernen?"), null)
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            KindCard(Icons.Rounded.Translate, tr("Vokabeln"), tr("Vokabeln mit Wort, Übersetzung, Beispielsatz und Vorlesen"), Modifier.weight(1f)) { languageDeck = true; step = 1 }
                            KindCard(Icons.Rounded.Style, tr("Karteikarten"), tr("Frage und Antwort zu jedem anderen Thema, auch mit Bildern"), Modifier.weight(1f)) { languageDeck = false; step = 1 }
                        }
                    }
                    1 -> if (languageDeck) {
                        Headline(tr("Welche Sprache lernst du?"), null)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(selected = source == "auto", onClick = { source = "auto" }, label = { Text(tr("Automatisch")) })
                            SupportedLanguages.forEach { l ->
                                FilterChip(selected = source == l.tag, onClick = { source = l.tag }, label = { Text(l.label) })
                            }
                        }
                        if (source == "auto") {
                            Text(
                                tr("Bei „Automatisch“ erkennt die KI die Sprache jedes Worts selbst und übersetzt fehlende Übersetzungen in deine Zielsprache."),
                                style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
                            )
                        }
                        LanguageField(tr("Meine Sprache"), target, Modifier.fillMaxWidth()) { target = it }
                    } else {
                        Headline(tr("Worum geht es? (hilft der KI)"), null)
                        AppTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            placeholder = { Text(tr("z. B. Biologie Klasse 9, Zellaufbau")) },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    2 -> {
                        Headline(tr("Wie soll das Deck heißen?"), tr("Leer lassen: die KI findet einen Namen"))
                        val focus = remember { FocusRequester() }
                        AppTextField(
                            value = name,
                            onValueChange = { name = it },
                            placeholder = { Text(tr("Name des Decks (optional)")) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        )
                        LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
                    }
                    else -> {
                        Headline(tr("Womit möchtest du starten?"), null)
                        MethodChooser(enabled = !busy) { create(it) }
                        TextButton(onClick = { create(-2) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(tr("Leeres Deck erstellen")) }
                    }
                }
            }
        }
        if (step in 1..2) {
            Button(
                onClick = { step++ },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp).heightIn(min = 56.dp),
            ) { Text(tr("Weiter"), style = MaterialTheme.typography.titleMedium.bold()) }
        }
    }
}

@Composable
private fun Headline(title: String, subtitle: String?) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
        Text(title, style = MaterialTheme.typography.displaySmall.bold())
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** One of the two big "what to learn" cards: tap = chosen, on to the next page. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KindCard(icon: ImageVector, title: String, desc: String, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, shape = RoundedCornerShape(32.dp), color = cs.surfaceContainerHigh, modifier = modifier) {
        Column(Modifier.padding(20.dp).heightIn(min = 200.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Surface(shape = CircleShape, color = cs.primaryContainer, modifier = Modifier.size(60.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(30.dp)) }
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge.bold())
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
internal fun LanguageField(label: String, value: String, modifier: Modifier = Modifier, allowAuto: Boolean = false, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        AppTextField(
            value = if (value == "auto") tr("Automatisch") else languageName(value),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable { open = true })
    }
    if (open) {
        OptionSheet(
            title = label,
            options = (if (allowAuto) listOf("auto" to tr("Automatisch")) else emptyList()) + SupportedLanguages.map { it.tag to it.label },
            selected = value,
            onPick = { onPick(it); open = false },
            onDismiss = { open = false },
        )
    }
}
