package com.lingosnap.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cbrt
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Material You colour generation, written out here so the app needs no extra library: a seed colour is turned into hue
 * and chroma with the CAM16 colour model (the same one Android uses), and tonal palettes are built from it with the
 * recipes of Android's own theme styles (Tonal Spot, Vibrant, Expressive, Spritz, Rainbow, Fruit Salad, Monochrome).
 */
private object Cam16 {
    private const val WHITE_X = 95.047
    private const val WHITE_Y = 100.0
    private const val WHITE_Z = 108.883
    private val adaptingLuminance = (200.0 / PI) * yFromLstar(50.0) / 100.0
    private val n = yFromLstar(50.0) / WHITE_Y
    private val rgbW = doubleArrayOf(
        0.401288 * WHITE_X + 0.650173 * WHITE_Y - 0.051461 * WHITE_Z,
        -0.250268 * WHITE_X + 1.204414 * WHITE_Y + 0.045854 * WHITE_Z,
        -0.002079 * WHITE_X + 0.048952 * WHITE_Y + 0.953127 * WHITE_Z,
    )
    const val F = 1.0
    val c = 0.59 + (0.69 - 0.59) * ((F - 0.9) * 10.0)
    val nc = F
    private val d = (F * (1.0 - (1.0 / 3.6) * exp((-adaptingLuminance - 42.0) / 92.0))).coerceIn(0.0, 1.0)
    val rgbD = doubleArrayOf(d * (100.0 / rgbW[0]) + 1.0 - d, d * (100.0 / rgbW[1]) + 1.0 - d, d * (100.0 / rgbW[2]) + 1.0 - d)
    private val k = 1.0 / (5.0 * adaptingLuminance + 1.0)
    private val k4 = k * k * k * k
    private val k4F = 1.0 - k4
    val fl = k4 * adaptingLuminance + 0.1 * k4F * k4F * cbrt(5.0 * adaptingLuminance)
    val z = 1.48 + sqrt(n)
    val nbb = 0.725 / n.pow(0.2)
    val ncb = nbb
    val aw: Double
    init {
        val a = DoubleArray(3) { i ->
            val af = (fl * rgbD[i] * rgbW[i] / 100.0).pow(0.42)
            400.0 * af / (af + 27.13)
        }
        aw = (40.0 * a[0] + 20.0 * a[1] + a[2]) / 20.0 * nbb
    }
    val alphaPow = (1.64 - 0.29.pow(n)).pow(0.73)

    fun yFromLstar(l: Double): Double =
        100.0 * (if (l > 8.0) ((l + 16.0) / 116.0).pow(3) else l / (24389.0 / 27.0))

    fun lstarFromY(y: Double): Double {
        val yn = y / 100.0
        return if (yn <= 216.0 / 24389.0) (24389.0 / 27.0) * yn else 116.0 * cbrt(yn) - 16.0
    }

    private fun linear(v: Int): Double {
        val x = v / 255.0
        return (if (x <= 0.040449936) x / 12.92 else ((x + 0.055) / 1.055).pow(2.4)) * 100.0
    }

    private fun delinear(v: Double): Int {
        val x = v / 100.0
        val out = if (x <= 0.0031308) x * 12.92 else 1.055 * x.pow(1.0 / 2.4) - 0.055
        return Math.round(out * 255.0).toInt().coerceIn(0, 255)
    }

    /** Hue and chroma of an ARGB colour. */
    fun hueChroma(argb: Int): Pair<Double, Double> {
        val r = linear((argb shr 16) and 255)
        val g = linear((argb shr 8) and 255)
        val b = linear(argb and 255)
        val x = 0.41233895 * r + 0.35762064 * g + 0.18051042 * b
        val y = 0.2126 * r + 0.7152 * g + 0.0722 * b
        val zz = 0.01932141 * r + 0.11916382 * g + 0.95034478 * b
        val rD = rgbD[0] * (0.401288 * x + 0.650173 * y - 0.051461 * zz)
        val gD = rgbD[1] * (-0.250268 * x + 1.204414 * y + 0.045854 * zz)
        val bD = rgbD[2] * (-0.002079 * x + 0.048952 * y + 0.953127 * zz)
        fun adapt(v: Double): Double {
            val af = (fl * abs(v) / 100.0).pow(0.42)
            return sign(v) * 400.0 * af / (af + 27.13)
        }
        val rA = adapt(rD); val gA = adapt(gD); val bA = adapt(bD)
        val a = (11.0 * rA - 12.0 * gA + bA) / 11.0
        val bb = (rA + gA - 2.0 * bA) / 9.0
        val u = (20.0 * rA + 20.0 * gA + 21.0 * bA) / 20.0
        val p2 = (40.0 * rA + 20.0 * gA + bA) / 20.0
        var hue = Math.toDegrees(atan2(bb, a))
        if (hue < 0) hue += 360.0
        val ac = p2 * nbb
        val j = 100.0 * (ac / aw).pow(c * z)
        val huePrime = if (hue < 20.14) hue + 360.0 else hue
        val eHue = 0.25 * (cos(Math.toRadians(huePrime) + 2.0) + 3.8)
        val p1 = 50000.0 / 13.0 * eHue * nc * ncb
        val t = p1 * sqrt(a * a + bb * bb) / (u + 0.305)
        val alpha = t.pow(0.9) * alphaPow
        return hue to alpha * sqrt(j / 100.0)
    }

    /** Linear RGB (0..100) for hue, chroma and CAM16 lightness J, or null when it lies outside the sRGB gamut. */
    private fun linearRgb(hue: Double, chroma: Double, j: Double): DoubleArray? {
        val alpha = if (chroma == 0.0 || j == 0.0) 0.0 else chroma / sqrt(j / 100.0)
        val t = (alpha / alphaPow).pow(1.0 / 0.9)
        val hRad = Math.toRadians(hue)
        val eHue = 0.25 * (cos(hRad + 2.0) + 3.8)
        val ac = aw * (j / 100.0).pow(1.0 / c / z)
        val p1 = eHue * (50000.0 / 13.0) * nc * ncb
        val p2 = ac / nbb
        val hSin = sin(hRad); val hCos = cos(hRad)
        val gamma = 23.0 * (p2 + 0.305) * t / (23.0 * p1 + 11.0 * t * hCos + 108.0 * t * hSin)
        val a = gamma * hCos
        val b = gamma * hSin
        val rA = (460.0 * p2 + 451.0 * a + 288.0 * b) / 1403.0
        val gA = (460.0 * p2 - 891.0 * a - 261.0 * b) / 1403.0
        val bA = (460.0 * p2 - 220.0 * a - 6300.0 * b) / 1403.0
        fun unadapt(v: Double, i: Int): Double {
            val base = max(0.0, 27.13 * abs(v) / (400.0 - abs(v)))
            return sign(v) * (100.0 / fl) * base.pow(1.0 / 0.42) / rgbD[i]
        }
        val rF = unadapt(rA, 0); val gF = unadapt(gA, 1); val bF = unadapt(bA, 2)
        val x = 1.86206786 * rF - 1.01125463 * gF + 0.14918677 * bF
        val y = 0.38752654 * rF + 0.62144744 * gF - 0.00897398 * bF
        val zz = -0.01584150 * rF - 0.03412294 * gF + 1.04996444 * bF
        val r = 3.2413774792 * x - 1.5376652403 * y - 0.4988536685 * zz
        val g = -0.9691452513 * x + 1.8758853451 * y + 0.0415658562 * zz
        val bl = 0.0556209369 * x - 0.2039552456 * y + 1.0571799111 * zz
        val lo = -0.5; val hi = 100.5
        if (r < lo || g < lo || bl < lo || r > hi || g > hi || bl > hi) return null
        return doubleArrayOf(r.coerceIn(0.0, 100.0), g.coerceIn(0.0, 100.0), bl.coerceIn(0.0, 100.0))
    }

    private fun argb(lin: DoubleArray): Int =
        (0xFF shl 24) or (delinear(lin[0]) shl 16) or (delinear(lin[1]) shl 8) or delinear(lin[2])

    fun gray(tone: Double): Int {
        val v = delinear(yFromLstar(tone))
        return (0xFF shl 24) or (v shl 16) or (v shl 8) or v
    }

    /** The colour with this hue and lightness (L*) and as much chroma as fits, up to [chroma]. */
    fun solve(hue: Double, chroma: Double, tone: Double): Int {
        if (chroma < 0.5 || tone <= 0.0 || tone >= 100.0) return gray(tone.coerceIn(0.0, 100.0))
        var ch = chroma
        repeat(80) {
            var j = tone
            var outside = false
            for (step in 0 until 14) {
                val lin = linearRgb(hue, ch, j)
                if (lin == null) { outside = true; break }
                val y = 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]
                val l = lstarFromY(y)
                if (abs(l - tone) < 0.08) return argb(lin)
                j = (j * (tone / max(l, 0.5))).coerceIn(0.1, 100.0)
            }
            if (!outside) {
                // not converged but inside the gamut: good enough
                val lin = linearRgb(hue, ch, j)
                if (lin != null) return argb(lin)
            }
            ch *= 0.92
            if (ch < 0.5) return gray(tone)
        }
        return gray(tone)
    }
}

/** A hue/chroma pair that yields any tone (0..100) of one colour. */
private class Tonal(hue: Double, val chroma: Double) {
    val hue = ((hue % 360.0) + 360.0) % 360.0
    private val cache = HashMap<Int, Color>()
    fun tone(t: Int): Color = cache.getOrPut(t) { Color(Cam16.solve(hue, chroma, t.toDouble())) }
}

/** Android's theme styles. */
object AccentStyle {
    const val TonalSpot = 0
    const val Vibrant = 1
    const val Expressive = 2
    const val Spritz = 3
    const val Rainbow = 4
    const val FruitSalad = 5
    const val Monochrome = 6
    val count = 7
}

private fun rotated(hue: Double, hues: DoubleArray, rotations: DoubleArray): Double {
    for (i in 0 until hues.size - 1) {
        if (hues[i] < hue && hue < hues[i + 1]) return ((hue + rotations[i]) % 360.0 + 360.0) % 360.0
    }
    return hue
}

/** Builds a complete Material 3 colour scheme from a seed colour and one of Android's theme styles. */
fun seedScheme(seed: Int, style: Int, dark: Boolean): ColorScheme {
    val (hue, _) = Cam16.hueChroma(seed)
    val primary: Tonal; val secondary: Tonal; val tertiary: Tonal; val neutral: Tonal; val neutralVariant: Tonal
    when (style) {
        AccentStyle.Vibrant -> {
            primary = Tonal(hue, 200.0)
            secondary = Tonal(rotated(hue, doubleArrayOf(0.0, 41.0, 61.0, 101.0, 131.0, 181.0, 251.0, 301.0, 360.0), doubleArrayOf(18.0, 15.0, 10.0, 12.0, 15.0, 18.0, 15.0, 12.0, 12.0)), 24.0)
            tertiary = Tonal(rotated(hue, doubleArrayOf(0.0, 41.0, 61.0, 101.0, 131.0, 181.0, 251.0, 301.0, 360.0), doubleArrayOf(35.0, 30.0, 20.0, 25.0, 30.0, 35.0, 30.0, 25.0, 25.0)), 32.0)
            neutral = Tonal(hue, 10.0); neutralVariant = Tonal(hue, 12.0)
        }
        AccentStyle.Expressive -> {
            primary = Tonal(hue + 240.0, 40.0)
            secondary = Tonal(rotated(hue, doubleArrayOf(0.0, 21.0, 51.0, 121.0, 151.0, 191.0, 271.0, 321.0, 360.0), doubleArrayOf(45.0, 95.0, 45.0, 20.0, 45.0, 90.0, 45.0, 45.0, 45.0)), 24.0)
            tertiary = Tonal(rotated(hue, doubleArrayOf(0.0, 21.0, 51.0, 121.0, 151.0, 191.0, 271.0, 321.0, 360.0), doubleArrayOf(120.0, 120.0, 20.0, 45.0, 20.0, 15.0, 20.0, 120.0, 120.0)), 32.0)
            neutral = Tonal(hue + 15.0, 8.0); neutralVariant = Tonal(hue + 15.0, 12.0)
        }
        AccentStyle.Spritz -> {
            primary = Tonal(hue, 12.0); secondary = Tonal(hue, 8.0); tertiary = Tonal(hue, 16.0)
            neutral = Tonal(hue, 2.0); neutralVariant = Tonal(hue, 2.0)
        }
        AccentStyle.Rainbow -> {
            primary = Tonal(hue, 48.0); secondary = Tonal(hue, 16.0); tertiary = Tonal(hue + 60.0, 24.0)
            neutral = Tonal(hue, 0.0); neutralVariant = Tonal(hue, 0.0)
        }
        AccentStyle.FruitSalad -> {
            primary = Tonal(hue - 50.0, 48.0); secondary = Tonal(hue - 50.0, 36.0); tertiary = Tonal(hue, 36.0)
            neutral = Tonal(hue, 10.0); neutralVariant = Tonal(hue, 16.0)
        }
        AccentStyle.Monochrome -> {
            primary = Tonal(hue, 0.0); secondary = Tonal(hue, 0.0); tertiary = Tonal(hue, 0.0)
            neutral = Tonal(hue, 0.0); neutralVariant = Tonal(hue, 0.0)
        }
        else -> {
            primary = Tonal(hue, 36.0); secondary = Tonal(hue, 16.0); tertiary = Tonal(hue + 60.0, 24.0)
            neutral = Tonal(hue, 6.0); neutralVariant = Tonal(hue, 8.0)
        }
    }
    val base = if (dark) darkColorScheme() else lightColorScheme()
    return if (dark) base.copy(
        primary = primary.tone(80), onPrimary = primary.tone(20), primaryContainer = primary.tone(30), onPrimaryContainer = primary.tone(90),
        inversePrimary = primary.tone(40),
        secondary = secondary.tone(80), onSecondary = secondary.tone(20), secondaryContainer = secondary.tone(30), onSecondaryContainer = secondary.tone(90),
        tertiary = tertiary.tone(80), onTertiary = tertiary.tone(20), tertiaryContainer = tertiary.tone(30), onTertiaryContainer = tertiary.tone(90),
        background = neutral.tone(6), onBackground = neutral.tone(90),
        surface = neutral.tone(6), onSurface = neutral.tone(90),
        surfaceVariant = neutralVariant.tone(30), onSurfaceVariant = neutralVariant.tone(80),
        surfaceTint = primary.tone(80),
        inverseSurface = neutral.tone(90), inverseOnSurface = neutral.tone(20),
        outline = neutralVariant.tone(60), outlineVariant = neutralVariant.tone(30),
        surfaceDim = neutral.tone(6), surfaceBright = neutral.tone(24),
        surfaceContainerLowest = neutral.tone(4), surfaceContainerLow = neutral.tone(10), surfaceContainer = neutral.tone(12),
        surfaceContainerHigh = neutral.tone(17), surfaceContainerHighest = neutral.tone(22),
    ) else base.copy(
        primary = primary.tone(40), onPrimary = primary.tone(100), primaryContainer = primary.tone(90), onPrimaryContainer = primary.tone(10),
        inversePrimary = primary.tone(80),
        secondary = secondary.tone(40), onSecondary = secondary.tone(100), secondaryContainer = secondary.tone(90), onSecondaryContainer = secondary.tone(10),
        tertiary = tertiary.tone(40), onTertiary = tertiary.tone(100), tertiaryContainer = tertiary.tone(90), onTertiaryContainer = tertiary.tone(10),
        background = neutral.tone(98), onBackground = neutral.tone(10),
        surface = neutral.tone(98), onSurface = neutral.tone(10),
        surfaceVariant = neutralVariant.tone(90), onSurfaceVariant = neutralVariant.tone(30),
        surfaceTint = primary.tone(40),
        inverseSurface = neutral.tone(20), inverseOnSurface = neutral.tone(95),
        outline = neutralVariant.tone(50), outlineVariant = neutralVariant.tone(80),
        surfaceDim = neutral.tone(87), surfaceBright = neutral.tone(98),
        surfaceContainerLowest = neutral.tone(100), surfaceContainerLow = neutral.tone(96), surfaceContainer = neutral.tone(94),
        surfaceContainerHigh = neutral.tone(92), surfaceContainerHighest = neutral.tone(90),
    )
}

/** One entry of the colour picker. [seed] is the colour Android's theme engine starts from. */
class AccentOption(val name: String, val seed: Int)

/** Everything the colour picker offers besides "Material You" (the wallpaper colours of the phone). */
val AccentOptions: List<AccentOption>
    get() = listOf(
        AccentOption(com.lingosnap.util.tr("Blau"), 0xFF1B6EF3.toInt()),
        AccentOption(com.lingosnap.util.tr("Türkis"), 0xFF00A5A8.toInt()),
        AccentOption(com.lingosnap.util.tr("Grün"), 0xFF2E9E5B.toInt()),
        AccentOption(com.lingosnap.util.tr("Limette"), 0xFF8CB82E.toInt()),
        AccentOption(com.lingosnap.util.tr("Gelb"), 0xFFF2C21B.toInt()),
        AccentOption(com.lingosnap.util.tr("Orange"), 0xFFF08A1C.toInt()),
        AccentOption(com.lingosnap.util.tr("Rot"), 0xFFD93A3A.toInt()),
        AccentOption(com.lingosnap.util.tr("Rosa"), 0xFFE0568F.toInt()),
        AccentOption(com.lingosnap.util.tr("Lila"), 0xFF8E4FD6.toInt()),
        AccentOption(com.lingosnap.util.tr("Flieder"), 0xFF9A8CF0.toInt()),
        AccentOption(com.lingosnap.util.tr("Braun"), 0xFF8C6A55.toInt()),
        AccentOption(com.lingosnap.util.tr("Graphit"), 0xFF607A8B.toInt()),
    )

val AccentStyleNames: List<String>
    get() = listOf(
        com.lingosnap.util.tr("Tonal Spot"), com.lingosnap.util.tr("Lebhaft"), com.lingosnap.util.tr("Ausdrucksstark"),
        com.lingosnap.util.tr("Dezent"), com.lingosnap.util.tr("Regenbogen"), com.lingosnap.util.tr("Fruchtsalat"), com.lingosnap.util.tr("Monochrom"),
    )
