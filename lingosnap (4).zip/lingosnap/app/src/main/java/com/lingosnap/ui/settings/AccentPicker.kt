package com.lingosnap.ui.settings

import com.lingosnap.util.tr

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lingosnap.ui.components.AppChip
import com.lingosnap.ui.theme.AccentOptions
import com.lingosnap.ui.theme.AccentStyleNames
import com.lingosnap.ui.theme.bold
import com.lingosnap.ui.theme.seedScheme

/**
 * Colour picker with every accent Android offers: the wallpaper colours ("Material You") and the fixed colours, each with
 * Android's theme styles. Each swatch shows the three colours the app will use (primary, secondary, tertiary).
 */
@Composable
fun AccentPicker(accent: Int, style: Int, dark: Boolean, onAccent: (Int) -> Unit, onStyle: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val options = AccentOptions
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(tr("Akzentfarbe"), style = MaterialTheme.typography.bodyLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            val system = remember(dark) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val s = if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                    Triple(s.primary, s.secondary, s.tertiary)
                } else seedScheme(options.first().seed, 0, dark).let { Triple(it.primary, it.secondary, it.tertiary) }
            }
            Swatch(tr("Material You"), system.first, system.second, system.third, accent == 0) { onAccent(0) }
            options.forEachIndexed { i, o ->
                val colors = remember(o.seed, style, dark) { seedScheme(o.seed, style, dark).let { Triple(it.primary, it.secondary, it.tertiary) } }
                Swatch(o.name, colors.first, colors.second, colors.third, accent == i + 1) { onAccent(i + 1) }
            }
        }
        if (accent == 0) {
            Text(
                tr("Bei „Material You“ bestimmt dein Handy Farben und Stil. Wähle eine feste Farbe, um den Stil zu ändern."),
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
        } else {
            Text(tr("Stil"), style = MaterialTheme.typography.titleSmall.bold(), color = cs.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AccentStyleNames.forEachIndexed { i, name -> AppChip(style == i, { onStyle(i) }, name) }
            }
        }
    }
}

@Composable
private fun Swatch(label: String, a: Color, b: Color, c: Color, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Surface(
            shape = CircleShape, color = cs.surfaceContainerHighest,
            border = if (selected) BorderStroke(3.dp, cs.primary) else null,
            modifier = Modifier.size(60.dp),
        ) {
            Box(Modifier.padding(5.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(50.dp)) {
                    val s = Size(size.width, size.height)
                    drawArc(a, 180f, 180f, true, Offset.Zero, s)
                    drawArc(b, 90f, 90f, true, Offset.Zero, s)
                    drawArc(c, 0f, 90f, true, Offset.Zero, s)
                }
                if (selected) {
                    Surface(shape = CircleShape, color = cs.primary, modifier = Modifier.size(22.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Check, null, tint = cs.onPrimary, modifier = Modifier.size(14.dp)) }
                    }
                }
            }
        }
        Text(label, style = MaterialTheme.typography.labelMedium, color = if (selected) cs.onSurface else cs.onSurfaceVariant, textAlign = TextAlign.Center, maxLines = 1)
    }
}
