package com.lingosnap.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.lingosnap.MainActivity
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale

/** One entry of the podcast: the foreign word, then a pause to think, then the translation. */
data class PodcastItem(val source: String, val target: String, val sourceLang: String, val targetLang: String)

data class PodcastState(
    val active: Boolean = false,
    val playing: Boolean = false,
    val key: String = "",
    val title: String = "",
    val index: Int = 0,
    val total: Int = 0,
    /** 0 = reading the word, 1 = thinking pause, 2 = reading the translation, 3 = short gap */
    val phase: Int = 0,
    val source: String = "",
    val target: String = "",
    val pauseSec: Int = 4,
    val loop: Boolean = true,
)

/**
 * Reads a deck aloud like a podcast: word in the learned language → pause to translate in your head → translation.
 * Runs in a foreground service, so it keeps playing with the screen off or while another app is open.
 */
object PodcastPlayer {
    val state = MutableStateFlow(PodcastState())

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var appContext: Context? = null
    private var tts: TextToSpeech? = null
    private var ttsReady: CompletableDeferred<Boolean>? = null
    private val waiting = java.util.concurrent.ConcurrentHashMap<String, CompletableDeferred<Unit>>()
    private var items: List<PodcastItem> = emptyList()
    private var job: Job? = null
    private var focusRequest: AudioFocusRequest? = null

    fun isActiveFor(key: String) = state.value.active && state.value.key == key

    fun start(context: Context, key: String, title: String, list: List<PodcastItem>, pauseSec: Int, loop: Boolean, shuffle: Boolean) {
        if (list.isEmpty()) return
        appContext = context.applicationContext
        items = if (shuffle) list.shuffled() else list
        state.value = PodcastState(active = true, playing = true, key = key, title = title, total = items.size, pauseSec = pauseSec, loop = loop)
        publish(0)
        runCatching { ContextCompat.startForegroundService(context.applicationContext, Intent(context.applicationContext, PodcastService::class.java)) }
        launchLoop()
    }

    fun toggle() { if (state.value.playing) pause() else resume() }

    fun pause() {
        if (!state.value.active) return
        job?.cancel(); tts?.stop()
        abandonFocus()
        state.value = state.value.copy(playing = false)
    }

    fun resume() {
        if (!state.value.active || state.value.playing) return
        state.value = state.value.copy(playing = true)
        launchLoop()
    }

    fun next() = jump(state.value.index + 1)
    fun previous() = jump(state.value.index - 1)

    private fun jump(to: Int) {
        if (!state.value.active || items.isEmpty()) return
        val i = ((to % items.size) + items.size) % items.size
        val playing = state.value.playing
        job?.cancel(); tts?.stop()
        publish(i)
        if (playing) launchLoop()
    }

    fun setPause(sec: Int) { state.value = state.value.copy(pauseSec = sec) }
    fun setLoop(loop: Boolean) { state.value = state.value.copy(loop = loop) }

    fun stop() {
        job?.cancel(); tts?.stop()
        abandonFocus()
        state.value = PodcastState()
    }

    private fun publish(i: Int, phase: Int = 0) {
        val it = items.getOrNull(i) ?: return
        state.value = state.value.copy(index = i, phase = phase, source = it.source, target = it.target)
    }

    private fun launchLoop() {
        job?.cancel()
        job = scope.launch {
            if (!requestFocus()) { state.value = state.value.copy(playing = false); return@launch }
            var i = state.value.index
            while (isActive) {
                if (i >= items.size) {
                    if (state.value.loop) i = 0 else { stop(); return@launch }
                }
                val item = items[i]
                publish(i, 0)
                speak(item.source, item.sourceLang)
                publish(i, 1)
                // thinking pause: a little longer for long words
                val ms = state.value.pauseSec * 1000L + (item.source.length.coerceAtMost(40) * 40L)
                delay(ms)
                publish(i, 2)
                speak(item.target, item.targetLang)
                publish(i, 3)
                delay(1100)
                i++
            }
        }
    }

    private suspend fun engine(): TextToSpeech? {
        val ctx = appContext ?: return null
        tts?.let { if (ttsReady?.isCompleted == true) return it }
        val ready = CompletableDeferred<Boolean>()
        ttsReady = ready
        val engine = TextToSpeech(ctx) { status -> ready.complete(status == TextToSpeech.SUCCESS) }
        tts = engine
        engine.setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
        )
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { waiting.remove(utteranceId)?.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { waiting.remove(utteranceId)?.complete(Unit) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { waiting.remove(utteranceId)?.complete(Unit) }
        })
        return if (withTimeoutOrNull(8000) { ready.await() } == true) engine else null
    }

    /** Speaks one text and waits until it is finished. Missing voices are skipped instead of blocking the podcast. */
    private suspend fun speak(text: String, lang: String) {
        val engine = engine() ?: return
        if (text.isBlank()) return
        val tag = lang.ifBlank { Lang.code }
        val r = engine.setLanguage(Locale.forLanguageTag(tag))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return
        engine.setSpeechRate(0.88f)
        val id = "pod-${System.nanoTime()}"
        val done = CompletableDeferred<Unit>()
        waiting[id] = done
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        withTimeoutOrNull(30_000) { done.await() }
        waiting.remove(id)
    }

    private fun requestFocus(): Boolean {
        val am = appContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return true
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener { change ->
                // a call or another player takes over: stop politely, the user restarts with one tap
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause()
            }
            .build()
        focusRequest = req
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val am = appContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        focusRequest?.let { am.abandonAudioFocusRequest(it) }
        focusRequest = null
    }
}

/** Foreground service with a media-style notification: play/pause, previous, next, stop. */
class PodcastService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> PodcastPlayer.toggle()
            ACTION_NEXT -> PodcastPlayer.next()
            ACTION_PREV -> PodcastPlayer.previous()
            ACTION_STOP -> PodcastPlayer.stop()
        }
        ensureChannel()
        val s = PodcastPlayer.state.value
        val n = build(s)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTIFICATION_ID, n)
        if (!s.active) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        if (!started) {
            started = true
            scope.launch {
                PodcastPlayer.state.collect { st ->
                    if (!st.active) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                    else getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, build(st))
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, tr("Podcast"), NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun action(icon: Int, label: String, act: String, code: Int): NotificationCompat.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, PodcastService::class.java).setAction(act),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Action(icon, label, pi)
    }

    private fun build(s: PodcastState): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val text = if (s.phase >= 2) "${s.source} – ${s.target}" else s.source
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(s.title.ifBlank { tr("Podcast") })
            .setContentText(text)
            .setSubText("${s.index + 1} / ${s.total}")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(action(android.R.drawable.ic_media_previous, tr("Zurück"), ACTION_PREV, 1))
            .addAction(
                if (s.playing) action(android.R.drawable.ic_media_pause, tr("Pause"), ACTION_TOGGLE, 2)
                else action(android.R.drawable.ic_media_play, tr("Abspielen"), ACTION_TOGGLE, 2),
            )
            .addAction(action(android.R.drawable.ic_media_next, tr("Weiter"), ACTION_NEXT, 3))
            .addAction(action(android.R.drawable.ic_menu_close_clear_cancel, tr("Beenden"), ACTION_STOP, 4))
            .build()
    }

    companion object {
        const val CHANNEL = "podcast"
        const val NOTIFICATION_ID = 77
        const val ACTION_TOGGLE = "com.lingosnap.podcast.TOGGLE"
        const val ACTION_NEXT = "com.lingosnap.podcast.NEXT"
        const val ACTION_PREV = "com.lingosnap.podcast.PREV"
        const val ACTION_STOP = "com.lingosnap.podcast.STOP"
    }
}
