package com.lingosnap.ui.practice

import com.lingosnap.util.tr

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.StrokeCap
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.StudyDir
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Scaffold
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Button
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.ConfettiBurst
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.MorphLoader
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.FeedbackManager
import kotlinx.coroutines.launch

/** Shared by Multiple-Choice, Schreibtrainer and Speed-Match. */
class PracticeViewModel(
    private val repo: CardRepository,
    private val scope: StudyScope,
    private val id: Long,
    private val take: Int,
    val feedback: FeedbackManager,
    private val from: Int = 0,
    private val to: Int = 0,
) : ViewModel() {

    var loading by mutableStateOf(true)
        private set
    var cards by mutableStateOf<List<Flashcard>>(emptyList())
        private set
    var pool by mutableStateOf<List<Flashcard>>(emptyList())
        private set

    init {
        viewModelScope.launch {
            val all = repo.selectRange(repo.cardsFor(scope, id), from, to)
            pool = all
            // weakest cards first, with a little shuffle
            cards = all.shuffled().sortedBy { it.level / 2 }.take(take).shuffled()
            loading = false
        }
    }

    fun review(card: Flashcard, correct: Boolean, sound: Boolean = true) {
        if (sound) { if (correct) feedback.correct() else feedback.wrong() }
        viewModelScope.launch { repo.review(card, if (correct) Rating.Good else Rating.Hard) }
    }

    fun finish(perfect: Boolean, bonusXp: Int) {
        if (bonusXp > 0) repo.stats.addXp(bonusXp)
        if (perfect) repo.stats.recordPerfectSession()
    }
}

@Composable
fun rememberPractice(scope: StudyScope, id: Long, kind: String, take: Int, from: Int = 0, to: Int = 0): PracticeViewModel =
    viewModel(
        key = "practice-${kind}-${scope}-${id}-${from}-${to}",
        factory = viewModelFactory { initializer { PracticeViewModel(app().container.repository, scope, id, take, app().container.feedback, from, to) } },
    )

/** Whether this card is asked "backwards" (answer → question) in the chosen direction. */
fun isReversed(dir: String, card: Flashcard, index: Int): Boolean = when (dir) {
    StudyDir.Reverse -> true
    StudyDir.Mixed -> (card.id + index) % 2L == 0L
    else -> false
}

fun Flashcard.front(reversed: Boolean) = if (reversed) target else source
fun Flashcard.back(reversed: Boolean) = if (reversed) source else target

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PracticeScaffold(
    title: String,
    progress: Float,
    loading: Boolean,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p by animateFloatAsState(progress, spring(0.8f, 300f), label = "practiceProgress")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        topBar = {
            SessionTopBar(title, p, null, confirm = !loading && progress < 1f, onExit = onBack)
        },
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).navigationBarsPadding().padding(horizontal = 20.dp).padding(top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (loading) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                content()
            }
        }
    }
}

@Composable
fun ColumnScope.ResultPane(
    emoji: String,
    headline: String,
    detail: String,
    xp: Int,
    confetti: Boolean,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(headline, style = MaterialTheme.typography.headlineMedium.bold(), textAlign = TextAlign.Center)
            Text(detail, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
    Button(onClick = onBack, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text(tr("Fertig")) }
}

/** Shared top of every learning mode: close (with confirmation), title, counter and a rounded progress bar. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionTopBar(title: String, progress: Float, counter: String?, confirm: Boolean, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var ask by remember { mutableStateOf(false) }
    BackHandler(enabled = confirm) { ask = true }
    Column(Modifier.statusBarsPadding().padding(horizontal = 12.dp).padding(top = 4.dp, bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (confirm) ask = true else onExit() }) { Icon(Icons.Rounded.Close, tr("Beenden")) }
            Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, modifier = Modifier.weight(1f).padding(start = 4.dp))
            if (counter != null) {
                Surface(shape = CircleShape, color = cs.surfaceContainerHigh, modifier = Modifier.padding(end = 8.dp)) {
                    Text(counter, style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp).height(8.dp),
            strokeCap = StrokeCap.Round,
            gapSize = 0.dp,
            drawStopIndicator = {},
        )
    }
    if (ask) ConfirmDialog(
        title = tr("Lernen beenden?"),
        text = tr("Bereits bewertete Karten bleiben gespeichert. Den Rest dieser Runde machst du beim nächsten Mal."),
        confirmLabel = tr("Beenden"),
        onConfirm = { ask = false; onExit() },
        onDismiss = { ask = false },
    )
}
