package com.lingosnap.ui.settings

import com.lingosnap.util.tr

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.material3.Switch
import androidx.compose.material3.Icon
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.Icons
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.languageName
import com.lingosnap.data.model.typeLabelFor
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.OptionSheet
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.components.segmentShape
import androidx.compose.material3.Surface
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenAi: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val gemini = context.container.gemini
    val provider by gemini.provider.collectAsStateWithLifecycle()
    val hasKey = context.container.keyStore.hasKey

    val feedback = context.container.feedback
    var haptics by remember { mutableStateOf(feedback.haptics) }
    var sounds by remember { mutableStateOf(feedback.sounds) }
    var confirmReset by remember { mutableStateOf(false) }
    val autoBackup = context.container.autoBackup
    var backupFolder by remember { mutableStateOf(autoBackup.folder) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val folderPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            autoBackup.setFolder(uri)
            backupFolder = autoBackup.folder
            scope.launch {
                val ok = autoBackup.run(force = true)
                android.widget.Toast.makeText(context, if (ok) tr("Backup geschrieben") else tr("Ordner gespeichert"), android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    LargeScreen(title = tr("Optionen"), onBack = onBack) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item { GroupHeader(tr("Darstellung")) }
            item {
                Surface(Modifier.fillMaxWidth(), shape = segmentShape(0, 1), color = cs.surfaceContainer) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("Farbschema"), style = MaterialTheme.typography.bodyLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(tr("System"), tr("Hell"), tr("Dunkel")).forEachIndexed { i, label ->
                                // internal values: 0 = system, 2 = light, 1 = dark
                                val mode = when (i) { 0 -> 0; 1 -> 2; else -> 1 }
                                com.lingosnap.ui.components.AppChip(stats.darkMode == mode, { vm.setDarkMode(mode) }, label)
                            }
                        }
                    }
                }
            }

            item { GroupHeader(tr("Rückmeldung")) }
            item {
                SegmentedItem(
                    index = 0, count = 2, headline = tr("Haptik"),
                    supporting = tr("Ganz leichtes Vibrieren beim Lernen"),
                    trailing = { Switch(checked = haptics, onCheckedChange = { haptics = it; feedback.haptics = it; if (it) feedback.tap() }) },
                    onClick = { haptics = !haptics; feedback.haptics = haptics; if (haptics) feedback.tap() },
                )
            }
            item {
                SegmentedItem(
                    index = 1, count = 2, headline = tr("Töne"),
                    supporting = tr("Kurzer Klang bei richtig und falsch"),
                    trailing = { Switch(checked = sounds, onCheckedChange = { sounds = it; feedback.sounds = it; if (it) feedback.correct() }) },
                    onClick = { sounds = !sounds; feedback.sounds = sounds; if (sounds) feedback.correct() },
                )
            }

            item { GroupHeader("KI") }
            item {
                SegmentedItem(
                    index = 0,
                    count = 1,
                    headline = "KI",
                    supporting = if (hasKey) tr("{0} • Details und Status", provider?.label ?: tr("Schlüssel")) else tr("Nicht eingerichtet"),
                    onClick = onOpenAi,
                    trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
                )
            }

            item { GroupHeader(tr("Daten")) }
            item {
                SegmentedItem(
                    index = 0,
                    count = 5,
                    headline = tr("Backup sichern (Datei)"),
                    supporting = tr("Alle Decks mit Lernstand. Zum Wiederherstellen über das Import-Symbol laden."),
                    enabled = state.decks.isNotEmpty(),
                    onClick = { shareBackup(context, state.decks, state.cards, "lingosnap-backup") },
                )
            }
            item {
                SegmentedItem(
                    index = 1,
                    count = 5,
                    headline = tr("Vokabeln als Text exportieren"),
                    supporting = tr("{0} Karten in {1} Decks", state.cards.size, state.decks.size),
                    enabled = state.cards.isNotEmpty(),
                    onClick = {
                        val text = buildString {
                            state.decks.forEach { d ->
                                appendLine("# ${d.name} (${d.typeLabelFor(state.cardsOf(d.id))})")
                                state.cardsOf(d.id).forEach { appendLine("${it.source};${it.target}") }
                                appendLine()
                            }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, tr("Vokabeln exportieren")))
                    },
                )
            }
            item {
                SegmentedItem(
                    index = 2,
                    count = 5,
                    headline = tr("Automatisches Backup"),
                    supporting = if (backupFolder == null) tr("Aus. Wähle einen Ordner, z. B. in Google Drive – die App sichert dort höchstens einmal am Tag.")
                    else tr("An") + (autoBackup.lastRun.takeIf { it > 0 }?.let { tr(" · zuletzt ") + java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(it)) } ?: ""),
                    onClick = { folderPicker.launch(null) },
                    trailing = if (backupFolder != null) { {
                        androidx.compose.material3.TextButton(onClick = { autoBackup.setFolder(null); backupFolder = null }) { Text(tr("Aus")) }
                    } } else null,
                )
            }
            item {
                SegmentedItem(
                    index = 3,
                    count = 5,
                    headline = tr("Fehlerbericht kopieren"),
                    supporting = tr("Letzter Absturz und Gerätedaten – zum Einfügen in eine Nachricht"),
                    onClick = {
                        val cm = context.getSystemService(android.content.ClipboardManager::class.java)
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("LingoSnap", com.lingosnap.util.CrashLog.report(context)))
                        android.widget.Toast.makeText(context, tr("Kopiert"), android.widget.Toast.LENGTH_SHORT).show()
                    },
                )
            }
            item {
                SegmentedItem(
                    index = 4,
                    count = 5,
                    headline = tr("Alle Daten löschen"),
                    headlineColor = cs.error,
                    onClick = { confirmReset = true },
                )
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            title = tr("Alles löschen?"),
            text = tr("Alle Decks, Karten, XP und Serien werden unwiderruflich gelöscht."),
            confirmLabel = tr("Alles löschen"),
            onConfirm = { vm.clearEverything() },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
internal fun ModelDialog(onDismiss: () -> Unit, models: List<String>, active: String?) {
    val context = LocalContext.current
    val gemini = context.container.gemini
    val keys = context.container.keyStore
    val scope = rememberCoroutineScope()
    var chosen by remember { mutableStateOf(keys.chosenModel) }
    var refreshing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    OptionSheet(
        title = tr("Modell wählen"),
        options = listOf("" to tr("Automatisch (empfohlen)")) + models.take(15).map { it to it },
        selected = chosen ?: "",
        onPick = { key ->
            val model = key.ifEmpty { null }
            chosen = model
            gemini.chooseModel(model)
        },
        onDismiss = onDismiss,
        footer = {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(message.orEmpty(), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(
                    enabled = !refreshing,
                    onClick = {
                        refreshing = true
                        scope.launch {
                            gemini.refreshModels()
                                .onSuccess { gemini.apply(it); message = tr("{0} Modelle gefunden", it.models.size) }
                                .onFailure { message = it.message }
                            refreshing = false
                        }
                    },
                ) { Text(if (refreshing) tr("Suche …") else tr("Aktualisieren")) }
            }
        },
    )
}

/** Shares decks as one JSON file (lossless, can be imported again). */
fun shareBackup(
    context: android.content.Context,
    decks: List<com.lingosnap.data.model.Deck>,
    cards: List<com.lingosnap.data.model.Flashcard>,
    fileName: String,
) {
    val uri = com.lingosnap.data.Backup.writeFile(context, fileName, com.lingosnap.data.Backup.toJson(decks, cards))
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/json"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, tr("Datei sichern")))
}
