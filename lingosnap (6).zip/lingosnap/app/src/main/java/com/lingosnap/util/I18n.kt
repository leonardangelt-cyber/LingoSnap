package com.lingosnap.util

import android.content.Context
import kotlinx.serialization.json.Json
import java.util.Locale

/**
 * Translations of all texts in the app. The German text itself is the key; {0}, {1} … are the values that get filled in.
 * German (and any language without a file) uses the key / English as it is written in code and in assets/i18n/en.json.
 */
object Lang {
    private var app: Context? = null
    private val cache = HashMap<String, Map<String, String>>()

    fun init(context: Context) {
        app = context.applicationContext
    }

    val locale: Locale get() = Locale.getDefault()

    /** Language code of the phone, e.g. "de", "en", "es". */
    val code: String get() = locale.language.lowercase()

    /** English name of the phone's language, used inside AI prompts ("German", "Spanish" …). */
    val aiName: String get() = locale.getDisplayLanguage(Locale.ENGLISH).ifBlank { "English" }

    /** Name of a language in the phone's language ("Spanisch", "Spanish", "Español"). */
    fun displayName(tag: String): String =
        Locale.forLanguageTag(tag).getDisplayLanguage(locale).replaceFirstChar { it.uppercase(locale) }.ifBlank { tag }

    @Synchronized
    fun table(): Map<String, String> {
        val c = code
        if (c == "de") return emptyMap()
        return cache.getOrPut(c) { load(c) }
    }

    private fun load(c: String): Map<String, String> {
        val ctx = app ?: return emptyMap()
        fun read(name: String): Map<String, String> = runCatching {
            ctx.assets.open("i18n/$name.json").use { Json.decodeFromString<Map<String, String>>(it.readBytes().decodeToString()) }
        }.getOrDefault(emptyMap())
        val english = read("en")
        return if (c == "en") english else english + read(c)
    }
}

/** Translates a German UI text into the phone's language; [args] fill the {0}, {1} … gaps. */
fun tr(key: String, vararg args: Any?): String {
    var text = Lang.table()[key] ?: key
    for (i in args.indices) text = text.replace("{$i}", args[i].toString())
    return text
}
