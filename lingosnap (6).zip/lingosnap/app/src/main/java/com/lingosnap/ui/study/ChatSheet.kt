package com.lingosnap.ui.study

import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.languageNameEn
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/** Ask the AI anything about one card: differences to similar words, more examples, usage. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatSheet(card: Flashcard, onDismiss: () -> Unit) {
    val gemini = LocalContext.current.container.gemini
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val language = card.sourceLang.isNotBlank()
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun ask(q: String) {
        if (loading || q.isBlank()) return
        val history = messages.toList()
        messages += true to q.trim()
        input = ""; loading = true; error = null
        scope.launch {
            gemini.chatAbout(card.source, card.target, if (language) languageNameEn(card.sourceLang) else "", history, q.trim())
                .onSuccess { messages += false to it }
                .onFailure { error = it.message ?: tr("Die KI hat nicht geantwortet") }
            loading = false
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding().imePadding().padding(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(card.source, style = MaterialTheme.typography.headlineSmall.bold())
            Text(card.target, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (messages.isEmpty()) {
                    val ideas = if (language) listOf(tr("Wie unterscheidet es sich von ähnlichen Wörtern?"), tr("Gib mir drei weitere Beispiele"), tr("Wann benutze ich es nicht?"))
                    else listOf(tr("Erkläre es mir einfacher"), tr("Gib mir ein Beispiel aus dem Alltag"), tr("Was verwechselt man damit oft?"))
                    ideas.forEach { AssistChip(onClick = { ask(it) }, label = { Text(it) }) }
                }
                messages.forEach { (user, text) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = if (user) cs.primaryContainer else cs.surfaceContainerHigh,
                            contentColor = if (user) cs.onPrimaryContainer else cs.onSurface,
                            modifier = Modifier.fillMaxWidth(0.88f),
                        ) { Text(text, Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyLarge) }
                    }
                }
                if (loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text(tr("Frage zu dieser Karte")) })
                FilledIconButton(onClick = { ask(input) }, enabled = input.isNotBlank() && !loading) { Icon(Icons.AutoMirrored.Rounded.Send, tr("Senden")) }
            }
        }
    }
}
