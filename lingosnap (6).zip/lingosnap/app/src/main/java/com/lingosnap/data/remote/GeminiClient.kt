package com.lingosnap.data.remote

import android.util.Base64
import com.lingosnap.data.SecureKeyStore
import com.lingosnap.util.Lang
import com.lingosnap.util.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
data class VocabResponse(val pairs: List<VocabPair> = emptyList())

@Serializable
data class VocabPair(
    val source: String,
    val target: String,
    val example: String? = null,
    val lang: String? = null,
    /** From the AI: [image number (1-based), x, y, width, height] of a picture belonging to this card, as fractions of that image. */
    val figure: List<Float>? = null,
    /** Local path of a picture cut out of the scan (set by the app, never by the AI). */
    val image: String? = null,
)

sealed class GeminiException(message: String) : Exception(message) {
    data object MissingKey : GeminiException(tr("Kein API-Schlüssel hinterlegt. Trage ihn unter Optionen ein."))
    data object EmptyAnswer : GeminiException(tr("Die KI hat keine Antwort geliefert. Versuche es noch einmal."))
    class NoResult(raw: String) : GeminiException(
        tr("Es wurden keine Einträge erkannt.") + if (raw.isBlank()) "" else tr(" Antwort der KI: {0}", raw.trim().take(160)),
    )
    class Http(val code: Int, val detail: String) : GeminiException(
        when (code) {
            401, 403 -> tr("Der API-Schlüssel wurde abgelehnt. ({0})", detail)
            429 -> when {
                Regex("PerDay|per day|daily", RegexOption.IGNORE_CASE).containsMatchIn(detail) ->
                    tr("Das Tageslimit deines Schlüssels ist aufgebraucht. Es wird im Lauf des Tages zurückgesetzt, oder du hinterlegst unter KI-Einstellungen einen Reserve-Schlüssel. ({0})", detail)
                Regex("PerMinute|per minute", RegexOption.IGNORE_CASE).containsMatchIn(detail) ->
                    tr("Das Minutenlimit wurde erreicht. Warte eine Minute und versuche es noch einmal. ({0})", detail)
                else -> tr("Zu viele Anfragen oder Limit erreicht. Warte kurz oder nimm weniger Seiten auf einmal. ({0})", detail)
            }
            else -> tr("Fehler {0}: {1}", code, detail)
        },
    )
}

/** Which service a key belongs to – detected automatically from the key itself. */
enum class AiProvider(val label: String) {
    Gemini("Google Gemini"),
    OpenAi("OpenAI"),
    Anthropic("Anthropic Claude"),
    OpenRouter("OpenRouter"),
    Groq("Groq"),
    XAi("xAI Grok");

    companion object {
        /** Best guess from the key prefix; null = unknown (all providers are tried). */
        fun guess(key: String): AiProvider? = when {
            key.startsWith("AIza") -> Gemini
            key.startsWith("sk-ant-") -> Anthropic
            key.startsWith("sk-or-") -> OpenRouter
            key.startsWith("gsk_") -> Groq
            key.startsWith("xai-") -> XAi
            key.startsWith("sk-") -> OpenAi
            else -> null
        }
    }
}

/** Live callbacks while the AI answers (all optional). */
class Progress(
    val onModel: (String) -> Unit = {},
    val onFirstText: () -> Unit = {},
    val onPair: (VocabPair) -> Unit = {},
    /** Called when the provider's rate limit was hit and we wait [seconds] before trying again. */
    val onWait: (Int) -> Unit = {},
)

/** Result of a successful key check. */
data class Verified(val provider: AiProvider, val models: List<String>)

/**
 * Talks to Gemini, OpenAI, Claude, OpenRouter, Groq or Grok – whichever the pasted key belongs to.
 * The key is only ever sent as a header, never inside a URL.
 */
class GeminiClient(
    private val keyStore: SecureKeyStore,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .callTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build(),
) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val _provider = MutableStateFlow(keyStore.provider?.let { n -> AiProvider.entries.firstOrNull { it.name == n } })
    val provider: StateFlow<AiProvider?> = _provider

    private val _models = MutableStateFlow(keyStore.models)
    val models: StateFlow<List<String>> = _models

    private val _activeModel = MutableStateFlow(keyStore.chosenModel ?: keyStore.models.firstOrNull())
    val activeModel: StateFlow<String?> = _activeModel

    fun chooseModel(model: String?) {
        keyStore.chosenModel = model
        _activeModel.value = model ?: keyStore.models.firstOrNull()
    }

    /** Detects the provider and lists usable models. Works with any supported key. */
    suspend fun refreshModels(keyOverride: String? = null): Result<Verified> = runCatching {
        val key = keyOverride ?: keyStore.apiKey ?: throw GeminiException.MissingKey
        val guessed = AiProvider.guess(key)
        val candidates = if (guessed != null) listOf(guessed) else AiProvider.entries.toList()
        var rejected: GeminiException.Http? = null
        var found: Verified? = null
        for (p in candidates) {
            try {
                val list = listModels(p, key)
                if (list.isNotEmpty()) { found = Verified(p, list); break }
            } catch (e: GeminiException.Http) {
                if (guessed != null) throw e
                rejected = e
            } catch (e: java.io.IOException) {
                if (guessed != null) throw e
            } catch (e: IllegalArgumentException) {
                if (guessed != null) throw e
            }
        }
        val verified = found ?: throw (rejected ?: GeminiException.Http(404, "Für diesen Schlüssel wurden keine Modelle gefunden."))
        if (keyOverride == null) apply(verified)
        verified
    }

    fun apply(v: Verified) {
        keyStore.provider = v.provider.name
        keyStore.models = v.models
        _provider.value = v.provider
        _models.value = v.models
        val chosen = keyStore.chosenModel
        if (chosen != null && chosen !in v.models) keyStore.chosenModel = null
        _activeModel.value = keyStore.chosenModel ?: v.models.firstOrNull()
    }

    /** Saves (or, with null, removes) the reserve key after checking it. */
    suspend fun setBackupKey(key: String?): Result<Verified?> = runCatching {
        if (key.isNullOrBlank()) {
            keyStore.backupKey = null; keyStore.backupProvider = null; keyStore.backupModels = emptyList()
            return@runCatching null
        }
        val v = refreshModels(key.trim()).getOrThrow()
        keyStore.backupKey = key.trim(); keyStore.backupProvider = v.provider.name; keyStore.backupModels = v.models
        v
    }

    var qualityCheck: Boolean
        get() = keyStore.qualityCheck
        set(v) { keyStore.qualityCheck = v }

    /** Asks the AI to find wrong translations in a fresh list. Returns index (0-based) -> corrected pair. */
    suspend fun reviewPairs(pairs: List<VocabPair>, sourceLangName: String, targetLangName: String): Result<Map<Int, Pair<String, String>>> = runCatching {
        val list = pairs.mapIndexed { i, p -> "${i + 1}. ${p.source} = ${p.target}" }.joinToString("\n")
        val what = if (sourceLangName.isBlank()) "flashcards (question = answer)" else "vocabulary cards ($sourceLangName = $targetLangName)"
        val prompt = """
            Check these $what for real mistakes: wrong or misleading translations/answers, typos, wrong articles or wrong spelling.
            Do NOT change correct entries, do not rephrase, do not add anything.
            For every entry that needs a fix, output exactly one line: <number>: <corrected front> | <corrected back>
            If everything is correct, output only: OK
            $list
        """.trimIndent()
        val answer = execute(Task(prompt, emptyList(), 0.0, json = false), Progress())
        val regex = Regex("^\\s*(\\d+)\\s*[:.]\\s*(.+?)\\s*\\|\\s*(.+?)\\s*$")
        answer.lines().mapNotNull { line ->
            val m = regex.find(line) ?: return@mapNotNull null
            val i = m.groupValues[1].toIntOrNull()?.minus(1) ?: return@mapNotNull null
            if (i !in pairs.indices) return@mapNotNull null
            i to (m.groupValues[2] to m.groupValues[3])
        }.toMap()
    }

    suspend fun validateKey(key: String): Result<Verified> = refreshModels(key)

    /* ───────────────────────── tasks ───────────────────────── */

    suspend fun extractVocabulary(
        images: List<ByteArray>,
        sourceLangName: String,
        targetLangName: String,
        context: String,
        progress: Progress = Progress(),
        material: String = "",
        bulk: Boolean = false,
    ): Result<List<VocabPair>> = runCatching {
        val general = sourceLangName.isBlank()
        val auto = sourceLangName == "AUTO"
        // big documents: no invented sentences, keeps the answers short and the job fast
        val exampleRule = if (bulk) """- "example" = only if the material contains a sentence that uses the word: copy it (shortened if long). Never invent sentences; leave the field out otherwise."""
        else """- "example" = one short sentence in the source language that shows the word in use. If the word occurs in a sentence in the
              material, copy that sentence (shortened if it is long). Otherwise write one natural, simple sentence (max. 12 words) yourself."""
        val cardExampleRule = if (bulk) "- \"example\" = leave it out unless the material has a fitting sentence."
        else "- \"example\" = ONE short sentence that explains why the answer is true or gives a concrete example (helps understanding and memory). Leave it out if it would only repeat the answer."
        val job = if (general) """
            The material (image(s) and/or the text at the end) contains learning material: notes, a textbook or slide page, a printed text or a list.
            Turn ALL of the content into flashcards. "source" = the question, "target" = the short correct answer.
            - If the page already contains questions with answers, copy every one of them.
            - If it is running text or notes, write questions for every important fact, definition and term. Answers must be short and precise.
            Card design (based on learning research):
            - One fact or idea per card (minimum information principle). Split lists and long explanations into several cards.
            - The question must be specific and understandable on its own, without the page: name the topic in the question.
              No "which of the above", no yes/no questions, no vague questions like "What is important about X?".
            - Prefer questions that force real recall: definitions, "why" and "how" questions, causes and effects, differences,
              steps of a process, and a concrete case where the material gives one. Do not only ask for bare terms.
            - Answers are short and precise (ideally under 15 words), never a copied paragraph.
            - No duplicates. Use the language of the material unless told otherwise.
            - "figure" (optional, ONLY when the card is about a picture, diagram, map, chart or photo on an attached image):
              [image number starting at 1, x, y, width, height], all four numbers as fractions 0..1 of that image (origin top-left),
              a tight box around just that figure. Leave "figure" out for every card without a picture, and never guess.
            $cardExampleRule
        """ else """
            The material (image(s) and/or the text at the end) contains vocabulary: a word list, a textbook page, notes, a dialogue or a running text.
            Your job: capture EVERY vocabulary item. Do not stop early, do not skip entries, go through the whole page from top to bottom
            (and through every image).
            - ${if (auto) "Detect the language being learned yourself." else "The language being learned is $sourceLangName."}
              "source" = the word or phrase in that language (nouns with article, verbs in infinitive).
            - "target" = its meaning in $targetLangName. If the page already shows a translation in $targetLangName, use it.
              If the translation is missing or in another language, translate it into $targetLangName yourself.
            - "lang" = ISO 639-1 code of the source language (e.g. "es", "en", "fr").
            - Vocabulary list: one card per entry. Running text or dialogue: one card for every meaningful word and expression
              (nouns, verbs, adjectives, adverbs, phrases); leave out only trivial function words (articles, pronouns, "and") and names.
            - Dictionary or word list with definitions and example sentences: one card per headword. "target" is a short translation of the
              headword (not the definition); use the definition only to pick the right meaning. Example sentences are not cards of their own.
            $exampleRule
            - Fixed expressions, collocations, phrasal verbs and idioms stay ONE card as a whole chunk (e.g. "make a decision",
              "look forward to") – never split them into single words. Learning words in chunks and context is far more effective.
            - "target" = the most common meaning for this context, at most two short alternatives separated by ", " – no long definitions.
            - Skip headings, abbreviations tables, legends and page numbers. Fix obvious OCR typos.
        """
        val rule = if (general) JSON_RULE else JSON_RULE_LANG
        val prompt = """
            ${job.trimIndent()}
            ${context}
            ${if (material.isNotBlank()) "MATERIAL TEXT:\n" + material.take(40000) else ""}
            $rule
        """.trimIndent()
        finishPairs(execute(Task(prompt, images, 0.2, json = true), progress), progress)
    }

    /** Short search terms for an encyclopedia picture that fits a card. */
    suspend fun imageQueries(question: String, answer: String): Result<List<String>> = runCatching {
        val prompt = """
            Flashcard. Question: "$question" Answer: "$answer"
            Give 3 short search terms in ${Lang.aiName} (1-3 words each, the most specific first) that would find a fitting, clear encyclopedia picture
            (a photo, diagram or map that shows what this card is about). Answer with ONLY a JSON array of strings.
        """.trimIndent()
        val raw = execute(Task(prompt, emptyList(), 0.2, json = false), Progress())
        val start = raw.indexOf('[')
        val end = raw.lastIndexOf(']')
        if (start < 0 || end <= start) emptyList()
        else json.parseToJsonElement(raw.substring(start, end + 1)).jsonArray
            .mapNotNull { it.jsonPrimitive.contentOrNull?.trim()?.takeIf { t -> t.isNotEmpty() } }.take(3)
    }

    /** A short deck title for the given cards. */
    suspend fun suggestDeckName(samples: List<String>, languageDeck: Boolean): Result<String> = runCatching {
        val prompt = """
            These are entries of a new flashcard deck:
            ${samples.take(25).joinToString("\n") { "- $it" }}
            Give the deck a short, clear title in ${Lang.aiName} (2 to 4 words, no quotes, no trailing period) that names the ${if (languageDeck) "topic or situation" else "subject and topic"}.
            Return only the title.
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.3, json = false), Progress()).trim().trim('"', '.', ' ', '\n').take(40)
    }

    suspend fun generateVocabulary(
        topic: String,
        sourceLangName: String,
        targetLangName: String,
        count: Int,
        level: String,
        context: String,
        progress: Progress = Progress(),
    ): Result<List<VocabPair>> = runCatching {
        val general = sourceLangName.isBlank()
        val prompt = if (general) """
            Create exactly $count flashcards about: "$topic".${if (level.isBlank()) "" else " Difficulty: $level."}
            "source" = a clear question, "target" = the short, correct answer (a few words or one sentence).
            One fact per card (minimum information principle), no duplicates, no trick questions, answers must be factually correct.
            Each question is specific and understandable on its own, no yes/no questions. Mix definitions with "why"/"how" questions,
            causes and effects and short applications, so that learning needs real recall. Answers under 15 words.
            "example" = ONE short sentence that explains why the answer is true or gives a concrete example.
            $context
            $JSON_RULE
        """.trimIndent() else """
            Vocabulary list for a language learner. Topic: "$topic".${if (level.isBlank()) "" else " Level: $level."} Exactly $count entries.
            "source" = word or phrase in ${if (sourceLangName == "AUTO") "the language named in the topic or instructions (default: English)" else sourceLangName},
            "target" = translation in $targetLangName. "lang" = ISO 639-1 code of the source language.
            Nouns with article. Prefer the most frequent, most useful words for this topic (frequency matters more than rarity).
            Where natural, use common collocations and fixed phrases as one entry (e.g. "make a decision") besides single words. No duplicates.
            "example" = one short, natural sentence (max. 12 words) in the source language that uses the word in a typical context.
            $context
            $JSON_RULE_LANG
        """.trimIndent()
        finishPairs(execute(Task(prompt, emptyList(), 0.5, json = true), progress), progress)
    }

    suspend fun generateMnemonic(
        source: String, sourceLangName: String,
        target: String, targetLangName: String,
        explanationLang: String = Lang.aiName,
    ): Result<String> = runCatching {
        val prompt = if (sourceLangName.isBlank()) """
            You are a witty memory coach. Invent ONE vivid mnemonic (a short memory aid) that helps remember
            the answer "$target" to the flashcard question "$source". Max. 2 short sentences.
            Write in $explanationLang. Return only the mnemonic text.
        """.trimIndent() else """
            You are a witty memory coach. Invent ONE vivid, funny mnemonic (an "Eselsbrücke")
            that links the $sourceLangName word "$source" with its $targetLangName translation "$target".
            Use sound-alikes, an absurd mental image or a mini story. Max. 2 short sentences.
            Write the explanation in $explanationLang, but keep both vocabulary words in their original language.
            Return only the mnemonic text.
        """.trimIndent()
        execute(Task(prompt, emptyList(), 1.0, json = false), Progress()).trim()
    }

    /**
     * Finds entries that are the same or very similar. [existing] are cards already in the deck, [fresh] are new ones;
     * returns groups of ids like ["N3","E12"] (every group contains at least one new entry).
     */
    suspend fun findDuplicates(existing: List<String>, fresh: List<String>): Result<List<List<String>>> = runCatching {
        val list = buildString {
            existing.forEachIndexed { i, s -> appendLine("E${i + 1}: $s") }
            fresh.forEachIndexed { i, s -> appendLine("N${i + 1}: $s") }
        }
        val prompt = """
            You compare vocabulary entries ("word = translation"). Entries starting with E are already in the deck, entries starting with N are new.
            Find groups of entries that are the same or very similar: the same word, spelling variants, different forms of the same word,
            or near-synonyms with the same translation. Every group must contain at least one N entry.
            Do not group entries that merely belong to the same topic.
            $list
            Answer with ONLY JSON, no markdown: {"groups":[["N1","E3"],["N2","N7"]]}. If there are none: {"groups":[]}
        """.trimIndent()
        val raw = execute(Task(prompt, emptyList(), 0.0, json = false), Progress())
        val start = raw.indexOf('{'); val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return@runCatching emptyList()
        val groups = json.parseToJsonElement(raw.substring(start, end + 1)).jsonObject["groups"] as? kotlinx.serialization.json.JsonArray
            ?: return@runCatching emptyList()
        groups.mapNotNull { g ->
            (g as? kotlinx.serialization.json.JsonArray)?.mapNotNull { (it as? kotlinx.serialization.json.JsonPrimitive)?.content?.trim() }
                ?.takeIf { it.size >= 2 }
        }
    }

    /** One short example sentence (in the source language) for a card that has none yet. */
    suspend fun generateExample(
        source: String, sourceLangName: String, target: String, targetLangName: String,
    ): Result<String> = runCatching {
        val prompt = if (sourceLangName.isBlank()) """
            Flashcard question: "$source" – answer: "$target".
            Explain in ${Lang.aiName}, in at most 2 short sentences, why this answer is correct or what is behind it,
            so that it is easier to understand and remember. Do not repeat the question. Return only the explanation.
        """.trimIndent() else """
            Write ONE short, natural example sentence (max. 12 words) in $sourceLangName that uses "$source" (meaning: "$target" in $targetLangName).
            Return only the sentence, no translation, no quotes.
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.7, json = false), Progress()).trim().trim('"')
    }

    /** Answers a learner's question about one card; [history] = earlier turns (true = learner). */
    suspend fun chatAbout(
        source: String, target: String, languageName: String,
        history: List<Pair<Boolean, String>>, question: String,
    ): Result<String> = runCatching {
        val topic = if (languageName.isBlank()) "Flashcard: question \"$source\" – answer \"$target\"."
        else "Vocabulary card ($languageName): \"$source\" = \"$target\"."
        val talk = history.joinToString("\n") { (user, text) -> (if (user) "Learner: " else "Tutor: ") + text }
        val prompt = """
            You are a friendly, precise tutor. $topic
            Answer the learner's question in ${Lang.aiName}, concrete and short (max. 120 words). Use $languageName examples where useful.
            ${if (talk.isNotBlank()) "Conversation so far:\n$talk" else ""}
            Learner: $question
            Tutor:
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.5, json = false), Progress()).trim()
    }

    /** Short feedback for a sentence the learner wrote with [word]. */
    suspend fun checkSentence(word: String, meaning: String, languageName: String, sentence: String): Result<String> = runCatching {
        val prompt = """
            A learner of $languageName wrote ONE sentence using the word "$word" (meaning: "$meaning"):
            "$sentence"
            Answer in ${Lang.aiName}, max. 60 words, in exactly three lines. Each line starts with its label, translated into ${Lang.aiName}:
            Verdict: <correct / almost correct / has mistakes> – <one short reason>
            Better: <the corrected or improved sentence in $languageName>
            Tip: <one short tip on usage of "$word">
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.3, json = false), Progress()).trim()
    }

    /* ───────────────────────── core ───────────────────────── */

    /** At most three requests at the same time and at least ~0.7 s between two request starts: keeps free-tier keys from running dry. */
    private val gate = Semaphore(2)
    private val spacing = Mutex()
    private var lastStart = 0L
    /** Pause before each request start. Grows after a rate limit, shrinks again while all goes well. */
    @Volatile private var gap = 1500L

    private suspend fun <T> throttled(block: suspend () -> T): T = gate.withPermit {
        spacing.withLock {
            val wait = lastStart + gap - System.currentTimeMillis()
            if (wait > 0) delay(wait)
            lastStart = System.currentTimeMillis()
        }
        block()
    }

    private class Task(val prompt: String, val images: List<ByteArray>, val temperature: Double, val json: Boolean)

    private suspend fun execute(task: Task, progress: Progress): String {
        val key = keyStore.apiKey ?: throw GeminiException.MissingKey
        var found = _provider.value
        var available = keyStore.models
        if (found == null || available.isEmpty()) {
            val v = refreshModels().getOrThrow()
            found = v.provider
            available = v.models
        }
        val provider: AiProvider = found ?: throw GeminiException.MissingKey
        val wantImages = task.images.isNotEmpty()
        var emitted = 0
        var first = true
        val onText: (String) -> Unit = { text ->
            if (first) { first = false; progress.onFirstText() }
            if (task.json) {
                val pairs = extractPairs(text)
                while (emitted < pairs.size) progress.onPair(pairs[emitted++])
            }
        }
        val (text, err) = tryModels(provider, key, modelOrder(provider, available, keyStore.chosenModel, wantImages), task, progress, onText, failOnAuth = true)
        if (text != null) return text
        // the main key is out of quota (or its models are down): the reserve key, if there is one, takes over
        val spareKey = keyStore.backupKey
        val spareProvider = keyStore.backupProvider?.let { n -> AiProvider.entries.firstOrNull { it.name == n } }
        if (spareKey != null && spareProvider != null && emitted == 0) {
            val (spareText, spareErr) = tryModels(
                spareProvider, spareKey, modelOrder(spareProvider, keyStore.backupModels, null, wantImages).take(3),
                task, progress, onText, failOnAuth = false,
            )
            if (spareText != null) return spareText
            throw spareErr ?: err ?: GeminiException.EmptyAnswer
        }
        throw err ?: GeminiException.EmptyAnswer
    }

    private fun modelOrder(provider: AiProvider, available: List<String>, chosen: String?, wantImages: Boolean): List<String> {
        var order = (listOfNotNull(chosen) + available).distinct()
        if (wantImages) {
            val capable = order.filter { supportsVision(provider, it) }
            if (capable.isNotEmpty()) order = capable
            // lite models read text from photos less reliably – try them last
            order = order.sortedBy { "lite" in it || "nano" in it }
        }
        return order.take(4)
    }

    /** Pacing happens before every request (see throttled); a rate limit slows the following requests and tries the next model at once. */
    private suspend fun tryModels(
        provider: AiProvider, key: String, order: List<String>, task: Task, progress: Progress,
        onText: (String) -> Unit, failOnAuth: Boolean,
    ): Pair<String?, GeminiException?> {
        var last: GeminiException? = null
        for (m in order) {
            try {
                progress.onModel(m)
                val text = throttled {
                    when (provider) {
                        AiProvider.Gemini -> callGemini(m, key, task, onText)
                        AiProvider.Anthropic -> callAnthropic(m, key, task, onText)
                        else -> callOpenAiCompatible(provider, m, key, task, onText)
                    }
                }
                _activeModel.value = m
                gap = maxOf(1500L, gap - 250L)
                return text to null
            } catch (e: GeminiException.Http) {
                if (failOnAuth && (e.code == 401 || e.code == 403)) throw e
                if (e.code == 429) gap = minOf(gap * 2, 8000L)
                last = e
            }
        }
        return null to last
    }

    private fun supportsVision(p: AiProvider, m: String): Boolean = when (p) {
        AiProvider.Gemini, AiProvider.Anthropic, AiProvider.OpenRouter -> true
        AiProvider.OpenAi -> listOf("gpt-4o", "gpt-4.1", "gpt-4.5", "gpt-5", "gpt-4-turbo", "o1", "o3", "o4").any { m.startsWith(it) }
        AiProvider.Groq -> "llama-4" in m || "vision" in m
        AiProvider.XAi -> "vision" in m || Regex("grok-[4-9]").containsMatchIn(m)
    }

    /* ── Gemini ── */

    private val vocabSchema: JsonElement = Json.parseToJsonElement(
        """{"type":"OBJECT","properties":{"pairs":{"type":"ARRAY","items":{"type":"OBJECT",
        "properties":{"source":{"type":"STRING"},"target":{"type":"STRING"},"example":{"type":"STRING"},"lang":{"type":"STRING"},"figure":{"type":"ARRAY","items":{"type":"NUMBER"}}},
        "required":["source","target"]}}},"required":["pairs"]}""",
    )

    private suspend fun callGemini(model: String, key: String, task: Task, onText: (String) -> Unit): String {
        fun body(noThinking: Boolean) = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject {
                    putJsonArray("parts") {
                        task.images.forEach { img ->
                            addJsonObject {
                                putJsonObject("inline_data") {
                                    put("mime_type", "image/jpeg")
                                    put("data", Base64.encodeToString(img, Base64.NO_WRAP))
                                }
                            }
                        }
                        addJsonObject { put("text", task.prompt) }
                    }
                }
            }
            putJsonObject("generationConfig") {
                put("temperature", task.temperature)
                if (task.json) {
                    put("responseMimeType", "application/json")
                    put("responseSchema", vocabSchema)
                }
                if (noThinking) putJsonObject("thinkingConfig") {
                    if ("gemini-3" in model) put("thinkingLevel", "low") else put("thinkingBudget", 0)
                }
            }
        }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
        val headers = mapOf("x-goog-api-key" to key)
        val fast = ("2.5" in model && "pro" !in model) || "gemini-3" in model
        val pick: (JsonObject) -> String? = { o ->
            o["candidates"]?.jsonArray?.firstOrNull()?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray
                ?.filter { it.jsonObject["thought"]?.jsonPrimitive?.contentOrNull != "true" }
                ?.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }
                ?.joinToString("")
        }
        return try {
            stream(url, headers, body(fast), pick, onText)
        } catch (e: GeminiException.Http) {
            if (fast && e.code == 400) stream(url, headers, body(false), pick, onText) else throw e
        }
    }

    /* ── OpenAI, OpenRouter, Groq, xAI (same chat format) ── */

    private fun baseUrl(p: AiProvider) = when (p) {
        AiProvider.OpenAi -> "https://api.openai.com/v1"
        AiProvider.OpenRouter -> "https://openrouter.ai/api/v1"
        AiProvider.Groq -> "https://api.groq.com/openai/v1"
        AiProvider.XAi -> "https://api.x.ai/v1"
        else -> error("not openai compatible")
    }

    private suspend fun callOpenAiCompatible(p: AiProvider, model: String, key: String, task: Task, onText: (String) -> Unit): String {
        val body = buildJsonObject {
            put("model", model)
            put("stream", true)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    if (task.images.isEmpty()) {
                        put("content", task.prompt)
                    } else {
                        putJsonArray("content") {
                            addJsonObject { put("type", "text"); put("text", task.prompt) }
                            task.images.forEach { img ->
                                addJsonObject {
                                    put("type", "image_url")
                                    putJsonObject("image_url") {
                                        put("url", "data:image/jpeg;base64," + Base64.encodeToString(img, Base64.NO_WRAP))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return stream(
            baseUrl(p) + "/chat/completions",
            mapOf("Authorization" to "Bearer $key"),
            body,
            { o -> o["choices"]?.jsonArray?.firstOrNull()?.jsonObject?.get("delta")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull },
            onText,
        )
    }

    /* ── Anthropic ── */

    private suspend fun callAnthropic(model: String, key: String, task: Task, onText: (String) -> Unit): String {
        val body = buildJsonObject {
            put("model", model)
            put("max_tokens", 16000)
            put("stream", true)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    putJsonArray("content") {
                        task.images.forEach { img ->
                            addJsonObject {
                                put("type", "image")
                                putJsonObject("source") {
                                    put("type", "base64")
                                    put("media_type", "image/jpeg")
                                    put("data", Base64.encodeToString(img, Base64.NO_WRAP))
                                }
                            }
                        }
                        addJsonObject { put("type", "text"); put("text", task.prompt) }
                    }
                }
            }
        }
        return stream(
            "https://api.anthropic.com/v1/messages",
            anthropicHeaders(key),
            body,
            { o -> o["delta"]?.jsonObject?.get("text")?.jsonPrimitive?.contentOrNull },
            onText,
        )
    }

    private fun anthropicHeaders(key: String) = mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")

    /* ── model lists ── */

    private suspend fun listModels(p: AiProvider, key: String): List<String> = when (p) {
        AiProvider.Gemini -> {
            val root = get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000", mapOf("x-goog-api-key" to key))
            val names = root.obj("models")?.jsonArray.orEmpty().filter { m ->
                m.jsonObject["supportedGenerationMethods"]?.jsonArray?.any { it.jsonPrimitive.contentOrNull == "generateContent" } == true
            }.mapNotNull { it.jsonObject["name"]?.jsonPrimitive?.contentOrNull?.removePrefix("models/") }
            rankGemini(names)
        }
        AiProvider.Anthropic -> {
            val root = get("https://api.anthropic.com/v1/models?limit=100", anthropicHeaders(key))
            rankClaude(root.ids())
        }
        AiProvider.OpenRouter -> {
            // /key checks the key itself; /models is public
            get("https://openrouter.ai/api/v1/key", mapOf("Authorization" to "Bearer $key"))
            rankOpenRouter(get("https://openrouter.ai/api/v1/models", emptyMap()).ids())
        }
        AiProvider.OpenAi -> rankOpenAi(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
        AiProvider.Groq -> rankGroq(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
        AiProvider.XAi -> rankXai(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
    }

    private fun JsonElement.ids(): List<String> =
        obj("data")?.jsonArray.orEmpty().mapNotNull { it.jsonObject["id"]?.jsonPrimitive?.contentOrNull }

    /* ── http ── */

    /** Runs the blocking OkHttp call but aborts it as soon as the coroutine is cancelled (so "Abbrechen" works at once). */
    private suspend fun okhttp3.Call.executeCancellable(): okhttp3.Response {
        val handle = currentCoroutineContext()[kotlinx.coroutines.Job]?.invokeOnCompletion { if (it != null) cancel() }
        try { return execute() } finally { handle?.dispose() }
    }

    private suspend fun get(url: String, headers: Map<String, String>): JsonElement = send(url, headers, null)
    private suspend fun post(url: String, headers: Map<String, String>, body: JsonObject): JsonElement = send(url, headers, body)

    private suspend fun send(url: String, headers: Map<String, String>, body: JsonObject?): JsonElement =
        withContext(Dispatchers.IO) {
            val builder = Request.Builder().url(url)
            headers.forEach { (k, v) -> builder.header(k, v) }
            if (body != null) builder.post(body.toString().toRequestBody("application/json".toMediaType())) else builder.get()
            http.newCall(builder.build()).executeCancellable().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    val detail = runCatching {
                        val e = json.parseToJsonElement(raw).jsonObject["error"]
                        (e as? JsonObject)?.get("message")?.jsonPrimitive?.contentOrNull ?: (e as? JsonPrimitive)?.contentOrNull
                    }.getOrNull()
                    throw GeminiException.Http(res.code, (detail ?: res.message).take(300))
                }
                json.parseToJsonElement(raw)
            }
        }

    private suspend fun stream(
        url: String,
        headers: Map<String, String>,
        body: JsonObject,
        pick: (JsonObject) -> String?,
        onText: (String) -> Unit,
    ): String = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        builder.post(body.toString().toRequestBody("application/json".toMediaType()))
        http.newCall(builder.build()).executeCancellable().use { res ->
            if (!res.isSuccessful) {
                val raw = res.body?.string().orEmpty()
                val detail = runCatching {
                    val e = json.parseToJsonElement(raw).jsonObject["error"]
                    (e as? JsonObject)?.get("message")?.jsonPrimitive?.contentOrNull ?: (e as? JsonPrimitive)?.contentOrNull
                }.getOrNull()
                throw GeminiException.Http(res.code, (detail ?: res.message).take(300))
            }
            val source = res.body?.source() ?: throw GeminiException.EmptyAnswer
            val sb = StringBuilder()
            while (true) {
                currentCoroutineContext().ensureActive()
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val payload = line.removePrefix("data:").trim()
                if (payload.isEmpty() || payload == "[DONE]") continue
                val obj = runCatching { json.parseToJsonElement(payload).jsonObject }.getOrNull() ?: continue
                val piece = pick(obj)
                if (!piece.isNullOrEmpty()) {
                    sb.append(piece)
                    onText(sb.toString())
                }
            }
            sb.toString().takeIf { it.isNotBlank() } ?: throw GeminiException.EmptyAnswer
        }
    }

    /** Complete {"source":..,"target":..} objects found so far in a partial JSON answer. */
    private fun extractPairs(text: String): List<VocabPair> =
        Regex("\\{[^{}]*\\}").findAll(text).mapNotNull { m ->
            runCatching { json.decodeFromString<VocabPair>(m.value) }.getOrNull()
        }.filter { it.source.isNotBlank() && it.target.isNotBlank() }.toList()

    private fun finishPairs(raw: String, progress: Progress): List<VocabPair> =
        parsePairs(raw).ifEmpty { throw GeminiException.NoResult(raw) }

    private fun JsonElement.obj(name: String): JsonElement? = (this as? JsonObject)?.get(name)

    private fun parsePairs(raw: String): List<VocabPair> {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) throw GeminiException.NoResult(raw)
        val parsed = runCatching { json.decodeFromString<VocabResponse>(raw.substring(start, end + 1)).pairs }
            .getOrElse { extractPairs(raw) }
        return parsed
            .map {
                it.copy(
                    source = it.source.trim(), target = it.target.trim(),
                    example = it.example?.trim()?.takeIf { e -> e.isNotEmpty() },
                    lang = it.lang?.trim()?.takeIf { l -> l.length in 2..5 },
                    figure = it.figure?.takeIf { f -> f.size == 5 && f.drop(1).all { v -> v in 0f..1f } },
                    image = null,
                )
            }
            .filter { it.source.isNotEmpty() && it.target.isNotEmpty() }
            .distinctBy { it.source.lowercase() to it.target.lowercase() }
    }

    private companion object {
        const val JSON_RULE_LANG = """Answer with ONLY a JSON object, no markdown: {"pairs":[{"source":"...","target":"...","lang":"xx","example":"..."}]}"""
        const val JSON_RULE = """Answer with ONLY a JSON object, no markdown: {"pairs":[{"source":"...","target":"...","example":"...","figure":[1,0.1,0.2,0.5,0.3]}]} ("figure" is optional, see the rules)"""
    }
}

/* ───────────────────────── ranking: newest generation first, fast tiers first ───────────────────────── */

private fun num(regex: String, s: String): Double =
    Regex(regex).find(s)?.groupValues?.drop(1)?.filter { it.isNotEmpty() }?.joinToString(".")?.toDoubleOrNull() ?: 0.0

private fun String.isSnapshot() = Regex("-\\d{4}-\\d{2}-\\d{2}$|-\\d{8}$|-\\d{3,4}$").containsMatchIn(this)

private fun rankGemini(names: List<String>): List<String> {
    val bad = listOf("tts", "image", "embedding", "live", "audio", "robotics", "computer", "learnlm", "aqa", "gemma", "imagen", "veo", "native")
    fun tier(n: String) = when { "flash-lite" in n -> 4; "flash" in n -> 3; "pro" in n -> 1; else -> 0 }
    return names.filter { it.startsWith("gemini") && bad.none { b -> b in it } }.distinct()
        .sortedWith(
            compareByDescending<String> { num("gemini-(\\d+)(?:\\.(\\d+))?", it) }
                .thenByDescending { tier(it) }
                .thenByDescending { if (listOf("preview", "exp").any { b -> b in it }) 0 else 1 }
                .thenBy { it },
        )
}

private fun rankClaude(ids: List<String>): List<String> {
    fun tier(n: String) = when { "haiku" in n -> 3; "sonnet" in n -> 2; else -> 1 }
    fun ver(n: String): Double {
        val m = Regex("claude-(?:haiku|sonnet|opus)-(\\d+)(?:-(\\d{1,2}))?(?!\\d)").find(n)
        if (m != null) return "${m.groupValues[1]}.${m.groupValues[2].ifEmpty { "0" }}".toDouble()
        val old = Regex("claude-(\\d+)(?:-(\\d+))?").find(n)
        return if (old != null) "${old.groupValues[1]}.${old.groupValues[2].ifEmpty { "0" }}".toDouble() else 0.0
    }
    return ids.filter { it.startsWith("claude") }.distinct()
        .sortedWith(compareByDescending<String> { ver(it) }.thenByDescending { tier(it) }.thenBy { it.isSnapshot() }.thenBy { it })
}

private fun rankOpenAi(ids: List<String>): List<String> {
    val bad = listOf("embedding", "tts", "whisper", "audio", "realtime", "image", "transcribe", "moderation", "dall", "search", "instruct", "codex", "davinci", "babbage", "pro", "deep-research", "computer", "omni", "sora", "chat-latest")
    val chat = ids.filter { (it.startsWith("gpt-") || Regex("^o\\d").containsMatchIn(it)) && bad.none { b -> b in it } }.distinct()
    val clean = chat.filterNot { it.isSnapshot() }.ifEmpty { chat }
    fun tier(n: String) = when { "nano" in n -> 1; "mini" in n -> 3; else -> 2 }
    return clean.sortedWith(
        compareByDescending<String> { if (it.startsWith("gpt-")) num("gpt-(\\d+)(?:\\.(\\d+))?", it) else 0.0 }
            .thenByDescending { tier(it) }
            .thenBy { it },
    )
}

private fun rankGroq(ids: List<String>): List<String> {
    val bad = listOf("whisper", "tts", "guard", "playai", "orpheus", "embed")
    val ok = ids.filter { m -> bad.none { it in m } }.distinct()
    return ok.sortedWith(
        compareByDescending<String> { "llama-4" in it }
            .thenByDescending { "llama-3.3" in it }
            .thenByDescending { "versatile" in it }
            .thenBy { it },
    )
}

private fun rankXai(ids: List<String>): List<String> {
    val ok = ids.filter { "grok" in it && "image" !in it && "imagine" !in it }.distinct()
    return ok.sortedWith(
        compareByDescending<String> { num("grok-(\\d+)(?:\\.(\\d+))?", it) }
            .thenByDescending { "fast" in it || "mini" in it }
            .thenBy { it },
    )
}

private fun rankOpenRouter(ids: List<String>): List<String> {
    val prefer = listOf(
        "google/gemini-2.5-flash", "google/gemini-flash", "openai/gpt-4o-mini", "openai/gpt-5-mini",
        "anthropic/claude-haiku", "anthropic/claude-3.5-haiku", "meta-llama/llama-4", "google/gemini-2.0-flash",
    )
    val picked = prefer.flatMap { p -> ids.filter { it.startsWith(p) && !it.endsWith(":free") }.sorted().take(2) }.distinct()
    return picked.ifEmpty { ids.take(12) }
}
