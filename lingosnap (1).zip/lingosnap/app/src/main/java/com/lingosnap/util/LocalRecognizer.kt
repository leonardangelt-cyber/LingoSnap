package com.lingosnap.util

import android.graphics.BitmapFactory
import android.graphics.Rect
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.lingosnap.data.remote.VocabPair
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** What the recognition without AI found: the pairs, and how many lines had no translation next to them. */
class LocalResult(val pairs: List<VocabPair>, val skipped: Int)

/**
 * Reads vocabulary without any AI, on the phone: text blocks are split at their separators, photos and scanned pages go through the
 * text recognition of ML Kit (Latin letters) and are paired by their rows: left part = word, right part = translation.
 * Handwriting and unusual layouts are much weaker than with the AI – this is the fallback and the offline way.
 */
object LocalRecognizer {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { c.resume(it) }
        addOnFailureListener { c.resumeWithException(it) }
        addOnCanceledListener { c.cancel() }
    }

    private class Piece(val text: String, val box: Rect) {
        val midY get() = (box.top + box.bottom) / 2f
        val height get() = (box.bottom - box.top).coerceAtLeast(1)
    }

    suspend fun read(batch: Batch, source: String, target: String, orient: Boolean = true): LocalResult {
        val pairs = ArrayList<VocabPair>()
        var skipped = 0
        fun addEntries(text: String) {
            ManualLines.parse(text).forEach { e -> if (e.second != null) pairs += VocabPair(e.first, e.second, e.example) else skipped++ }
        }
        if (batch.text.isNotBlank()) addEntries(batch.text)
        batch.images?.invoke()?.forEach { jpg ->
            val bmp = BitmapFactory.decodeByteArray(jpg, 0, jpg.size) ?: return@forEach
            val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
            val pieces = result.textBlocks.flatMap { b -> b.lines }.mapNotNull { l -> l.boundingBox?.let { Piece(l.text, it) } }
            val width = bmp.width
            bmp.recycle()
            val (rows, loose) = rows(pieces, width)
            rows.forEach { (a, b) -> if (a.isNotBlank() && b.isNotBlank()) pairs += VocabPair(a.trim(), b.trim()) }
            loose.forEach { addEntries(it) }
        }
        val clean = pairs.distinctBy { it.source.lowercase() + "|" + it.target.lowercase() }
        return LocalResult(if (orient && source != target) TextAi.orient(clean, source, target) else clean, skipped)
    }

    /**
     * Groups the recognised lines into rows by their height on the page. A row with two or more parts is split at its widest gap
     * (left = word, right = translation); a row with one part is returned as a loose line (it may contain a separator).
     */
    private fun rows(pieces: List<Piece>, pageWidth: Int): Pair<List<Pair<String, String>>, List<String>> {
        val sorted = pieces.sortedBy { it.midY }
        val groups = ArrayList<MutableList<Piece>>()
        for (p in sorted) {
            val g = groups.lastOrNull()
            val avgH = g?.map { it.height }?.average() ?: 0.0
            if (g != null && kotlin.math.abs(p.midY - g.map { it.midY }.average()) <= avgH * 0.6) g.add(p) else groups.add(mutableListOf(p))
        }
        val pairs = ArrayList<Pair<String, String>>()
        val loose = ArrayList<String>()
        for (g in groups) {
            val row = g.sortedBy { it.box.left }
            if (row.size < 2) { loose += row[0].text; continue }
            var cut = 1; var widest = -1
            for (i in 1 until row.size) { val gap = row[i].box.left - row[i - 1].box.right; if (gap > widest) { widest = gap; cut = i } }
            // two columns only when the gap is a real gap, not just a space between words
            if (widest < pageWidth * 0.03) { loose += row.joinToString(" ") { it.text }; continue }
            pairs += row.subList(0, cut).joinToString(" ") { it.text } to row.subList(cut, row.size).joinToString(" ") { it.text }
        }
        return pairs to loose
    }
}
