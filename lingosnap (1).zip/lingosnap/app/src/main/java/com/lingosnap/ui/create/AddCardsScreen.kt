package com.lingosnap.ui.create

import com.lingosnap.util.tr
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.rounded.*

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.material3.IconButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.container
import com.lingosnap.ui.components.AppChip
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold
import java.io.File
import kotlinx.coroutines.launch

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun AddCardsScreen(deckId: Long, initialMethod: Int, onFinished: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val repository = context.container.repository
    val vm: AddCardsViewModel = viewModel(
        key = "add-${deckId}",
        factory = viewModelFactory { initializer { AddCardsViewModel(repository, deckId, context.container.appScope, context.container.notifier) } },
    )
    val cs = MaterialTheme.colorScheme
    // -1 = first show the "how do you want to add cards?" menu
    var method by rememberSaveable { mutableIntStateOf(initialMethod) }
    val isLang = vm.deck?.isLanguage != false

    var showCamera by remember { mutableStateOf(false) }
    if (showCamera) {
        CameraDialog(
            onDone = { uris ->
                showCamera = false
                vm.addFiles(uris)
            },
            onClose = { showCamera = false },
        )
    }
    // one file per pick; more can be added afterwards ("Noch eine Datei hinzufügen")
    val files = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri))
    }
    // asks once for the right to show the "fertig" notification, then continues in the background either way
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.moveToBackground() }
    // inside a method: back returns to the "how do you want to add cards" menu
    androidx.activity.compose.BackHandler(enabled = method >= 0 && initialMethod < 0 && !vm.busy) { method = -1 }

    LargeScreen(
        title = tr("Karten hinzufügen"),
        onBack = { if (method >= 0 && initialMethod < 0) method = -1 else onBack() },
        bottomBar = {
            if (method >= 0) {
                Surface(color = cs.surfaceContainer, tonalElevation = 0.dp) {
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(16.dp)) {
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !vm.busy,
                            // files waiting in the list: "Fertig" = all files are added, start the recognition
                            onClick = { if (method >= 1 && vm.files.isNotEmpty()) vm.startScan(context, local = method == 2) else vm.save(onFinished) },
                        ) {
                            Text(if (method >= 1 && vm.files.isNotEmpty()) tr("Fertig") else if (vm.selectedCount > 0) tr("{0} Karten speichern", vm.selectedCount) else tr("Fertig"))
                        }
                    }
                }
            }
        },
    ) { inner ->
        if (method < 0) {
            Column(Modifier.padding(inner).padding(horizontal = 16.dp)) {
                vm.deck?.let {
                    Text(
                        it.name,
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                    )
                }
                GroupHeader(tr("Wie möchtest du Karten hinzufügen?"))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    SegmentedItem(
                        0, 3, tr("Foto oder Datei mit KI scannen"),
                        supporting = tr("Kamera, Bild, PDF, Word oder PowerPoint"),
                        onClick = { method = 1 },
                        leading = { Icon(Icons.Rounded.CameraAlt, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        1, 3, tr("Ohne KI scannen"),
                        supporting = tr("Text direkt auf dem Handy erkennen, auch offline"),
                        onClick = { method = 2 },
                        leading = { Icon(Icons.Rounded.DocumentScanner, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        2, 3, tr("Selbst eintippen"),
                        supporting = tr("Einzeln oder als Liste, mit automatischer Übersetzung"),
                        onClick = { method = 0 },
                        leading = { Icon(Icons.Rounded.Edit, null, tint = cs.primary) },
                    )
                }
                TextButton(onClick = onFinished, modifier = Modifier.padding(top = 16.dp)) { Text(tr("Später hinzufügen")) }
            }
        } else {
            LazyColumn(Modifier.padding(inner), contentPadding = PaddingValues(bottom = 16.dp)) {
                item {
                    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        vm.deck?.let {
                            Text(it.name, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        when (method) {
                            0 -> ManualInput(vm, isLang)
                            else -> {
                                Text(
                                    if (method == 2) tr("Ohne KI: Der Text wird auf dem Handy erkannt, auch ohne Internet. Das klappt gut bei gedruckten Listen mit Trennzeichen (casa - Haus) oder in zwei Spalten, bei Handschrift deutlich schlechter. Wähle Bilder, PDF, Word oder PowerPoint oder fotografiere die Seite.")
                                    else if (isLang) tr("Fotografiere eine Vokabelliste oder Buchseite, oder wähle Bilder, PDF, Word oder PowerPoint. Beliebig viele Dateien und Seiten.")
                                    else tr("Fotografiere Notizen oder Folien, oder wähle Bilder, PDF, Word oder PowerPoint. Beliebig viele Dateien und Seiten."),
                                    color = cs.onSurfaceVariant,
                                )
                                // preview of everything chosen so far
                                vm.files.forEach { uri ->
                                    androidx.compose.runtime.key(uri) { FilePreviewRow(uri, onRemove = { vm.removeFile(uri) }) }
                                }
                                // file symbol with text, and next to it the camera symbol; "Fertig" at the bottom starts the recognition
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    FilledTonalButton(
                                        enabled = !vm.busy,
                                        onClick = { files.launch(com.lingosnap.util.DocumentReader.MIME_TYPES) },
                                        modifier = Modifier.weight(1f),
                                    ) {
                                        Icon(Icons.Rounded.NoteAdd, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            if (vm.files.isEmpty()) tr("Dokument hinzufügen") else tr("Weiteres Dokument hinzufügen"),
                                            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                        )
                                    }
                                    androidx.compose.material3.FilledTonalIconButton(
                                        enabled = !vm.busy,
                                        onClick = { showCamera = true },
                                        modifier = Modifier.size(width = 56.dp, height = 40.dp),
                                    ) { Icon(Icons.Rounded.CameraAlt, tr("Kamera")) }
                                }
                                if (method == 1) ModelLine()
                            }
                        }
                        }
                    }
                }
                vm.notice?.let { n ->
                    item {
                        Surface(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            shape = MaterialTheme.shapes.large, color = cs.errorContainer, contentColor = cs.onErrorContainer,
                        ) { Text(n, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium) }
                    }
                }
                if (vm.drafts.isNotEmpty()) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            GroupHeader(tr("Neu ({0} von {1})", vm.selectedCount, vm.drafts.size), Modifier.weight(1f))
                            val allOn = vm.selectedCount == vm.drafts.size
                            TextButton(onClick = { vm.drafts.forEach { it.selected = !allOn } }) {
                                Text(if (allOn) tr("Keine") else tr("Alle"))
                            }
                        }
                    }
                    items(vm.drafts.size) { i ->
                        val d = vm.drafts[i]
                        Column(Modifier.padding(horizontal = 16.dp).padding(vertical = 1.dp)) {
                            SegmentedItem(
                                index = i,
                                count = vm.drafts.size,
                                headline = d.pair.source,
                                supporting = d.pair.target + (d.pair.example?.let { "\n${it}" } ?: ""),
                                onClick = { d.selected = !d.selected },
                                leading = d.pair.image?.let { img ->
                                    { com.lingosnap.util.CardImage(img, Modifier.size(48.dp), maxHeight = 48.dp, maxPx = 160, crop = true) }
                                },
                                trailing = {
                                    var edit by remember { mutableStateOf(false) }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { edit = true }) { Icon(Icons.Rounded.Edit, tr("Eintrag bearbeiten")) }
                                        Checkbox(checked = d.selected, onCheckedChange = { d.selected = it })
                                    }
                                    if (edit) {
                                        var src by remember { mutableStateOf(d.pair.source) }
                                        var tgt by remember { mutableStateOf(d.pair.target) }
                                        var pic by remember { mutableStateOf(d.pair.image) }
                                        var finder by remember { mutableStateOf(false) }
                                        if (finder) {
                                            ImageFinderDialog(
                                                question = src, answer = tgt,
                                                onPicked = { pic = it; finder = false },
                                                onDismiss = { finder = false },
                                            )
                                        }
                                        com.lingosnap.ui.components.FormSheet(
                                            title = tr("Eintrag bearbeiten"),
        icon = Icons.Rounded.Edit,
                                            onDismiss = { edit = false },
                                            confirmLabel = tr("Speichern"),
                                            confirmEnabled = src.isNotBlank() && tgt.isNotBlank(),
                                            onConfirm = {
                                                d.pair = d.pair.copy(source = src.trim(), target = tgt.trim(), image = pic); edit = false
                                            },
                                        ) {
                                            AppTextField(src, { src = it }, Modifier.fillMaxWidth(), label = { Text(tr("Vorderseite")) })
                                            AppTextField(tgt, { tgt = it }, Modifier.fillMaxWidth(), label = { Text(tr("Rückseite")) })
                                            if (!isLang) {
                                                com.lingosnap.util.CardImage(pic, Modifier.fillMaxWidth(), maxHeight = 140.dp)
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    androidx.compose.material3.OutlinedButton(enabled = src.isNotBlank(), onClick = { finder = true }) {
                                                        Text(if (pic == null) tr("Bild suchen") else tr("Anderes Bild"))
                                                    }
                                                    if (pic != null) TextButton(onClick = { pic = null }) { Text(tr("Entfernen")) }
                                                }
                                            }
                                        }
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }

    if (vm.showProgress) AiProgressDialog(vm, onBackground = {
        val needsPermission = android.os.Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (needsPermission) notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS) else vm.moveToBackground()
    })
}

/** Loading sheet: shows every step the AI goes through, the model and the percentage. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun AiProgressDialog(vm: AddCardsViewModel, onBackground: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val labels = if (vm.scanning)
        listOf(tr("Dateien vorbereiten"), tr("An die KI senden"), tr("Text lesen und Einträge erkennen"), tr("Liste zusammenstellen"))
    else
        listOf(tr("Anfrage vorbereiten"), tr("An die KI senden"), tr("Einträge erzeugen"), tr("Liste zusammenstellen"))
    val finished = !vm.busy
    val failed = vm.error != null
    val animated by androidx.compose.animation.core.animateFloatAsState(vm.progress, label = "aiProgress")

    val model = vm.currentModel
    val latest = vm.drafts.firstOrNull()?.pair
    val heroColor = if (failed) cs.errorContainer else cs.surfaceContainerHigh
    val onHero = if (failed) cs.onErrorContainer else cs.onSurface

    androidx.compose.material3.ModalBottomSheet(
        onDismissRequest = { if (finished) vm.dismissProgress() },
        sheetState = androidx.compose.material3.rememberModalBottomSheetState(
            skipPartiallyExpanded = true,
            confirmValueChange = { finished || it != androidx.compose.material3.SheetValue.Hidden },
        ),
        sheetGesturesEnabled = finished,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
        containerColor = cs.surfaceContainerLow,
        dragHandle = { com.lingosnap.ui.components.SheetHandle() },
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 16.dp)
                .verticalScroll(androidx.compose.foundation.rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // hero: big ring with percentage, headline and status
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp), color = heroColor, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(124.dp)) {
                        if (failed) {
                            Icon(Icons.Rounded.ErrorOutline, null, tint = onHero, modifier = Modifier.size(64.dp))
                        } else {
                            CircularProgressIndicator(
                                progress = { if (finished) 1f else animated },
                                modifier = Modifier.size(124.dp),
                                strokeWidth = 11.dp,
                                color = cs.primary,
                                trackColor = cs.surfaceContainerHighest,
                                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
                            )
                            if (finished) Icon(Icons.Rounded.Check, null, tint = cs.primary, modifier = Modifier.size(52.dp))
                            else Text(
                                "${(animated * 100).toInt()}%",
                                // exactly centered in the ring: equal digit width (no jumping), no extra space above/below the text line
                                style = MaterialTheme.typography.headlineMedium.bold().copy(
                                    fontFeatureSettings = "tnum",
                                    lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                                        androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                                        androidx.compose.ui.text.style.LineHeightStyle.Trim.Both,
                                    ),
                                ),
                                color = onHero,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            when {
                                failed -> tr("Das hat nicht geklappt")
                                finished -> if (vm.resultCount > 0) tr("{0} Einträge gefunden", vm.resultCount) else tr("Keine neuen Einträge")
                                else -> tr("KI arbeitet")
                            },
                            style = MaterialTheme.typography.headlineSmall.bold(), color = onHero,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        if (!failed && !finished && !vm.status.isNullOrBlank()) {
                            Text(vm.status.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = onHero.copy(alpha = 0.8f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                        if (failed) {
                            Text(vm.error.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = onHero, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                    if (!failed && (model != null || (vm.totalFound > 0 && !finished))) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            model?.let { m ->
                                Surface(shape = androidx.compose.foundation.shape.CircleShape, color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer) {
                                    Text(m, Modifier.padding(horizontal = 14.dp, vertical = 7.dp), style = MaterialTheme.typography.labelLarge)
                                }
                            }
                            if (vm.totalFound > 0 && !finished) {
                                Surface(shape = androidx.compose.foundation.shape.CircleShape, color = cs.surfaceContainerHighest, contentColor = cs.onSurface) {
                                    Text(tr("{0} gefunden", vm.totalFound), Modifier.padding(horizontal = 14.dp, vertical = 7.dp), style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
            }

            if (!failed) {
                // steps
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp), color = cs.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        labels.forEachIndexed { i, label ->
                            val state = when {
                                vm.step > i || finished -> 2
                                vm.step == i -> 1
                                else -> 0
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
                                    when (state) {
                                        2 -> Surface(shape = androidx.compose.foundation.shape.CircleShape, color = cs.primary, modifier = Modifier.size(26.dp)) {
                                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Check, null, tint = cs.onPrimary, modifier = Modifier.size(16.dp)) }
                                        }
                                        1 -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.5.dp, color = cs.primary)
                                        else -> Surface(shape = androidx.compose.foundation.shape.CircleShape, color = cs.surfaceContainerHighest, modifier = Modifier.size(22.dp)) {}
                                    }
                                }
                                Spacer(Modifier.width(14.dp))
                                Text(
                                    label,
                                    style = if (state == 1) MaterialTheme.typography.bodyLarge.bold() else MaterialTheme.typography.bodyLarge,
                                    color = when (state) { 0 -> cs.outline; 1 -> cs.onSurface; else -> cs.onSurfaceVariant },
                                )
                            }
                        }
                    }
                }

                // newest entry, so you can see it working
                if (latest != null && !finished) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp), color = cs.surfaceContainerHighest, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                            Text(tr("Zuletzt erkannt"), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                            Text(latest.source, style = MaterialTheme.typography.titleMedium.bold(), color = cs.onSurface, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(latest.target, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!finished) {
                    FilledTonalButton(onClick = { vm.cancelAi() }, shape = androidx.compose.foundation.shape.CircleShape, modifier = Modifier.weight(1f).heightIn(min = 52.dp)) { Text(tr("Abbrechen")) }
                    Button(onClick = onBackground, shape = androidx.compose.foundation.shape.CircleShape, modifier = Modifier.weight(1.3f).heightIn(min = 52.dp)) { Text(tr("Im Hintergrund"), style = MaterialTheme.typography.titleSmall.bold()) }
                } else {
                    Button(onClick = { vm.dismissProgress() }, shape = androidx.compose.foundation.shape.CircleShape, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
                        Text(if (failed) tr("Schließen") else tr("Weiter"), style = MaterialTheme.typography.titleSmall.bold())
                    }
                }
            }
        }
    }
}

@Composable
private fun ManualInput(vm: AddCardsViewModel, isLang: Boolean) {
    var list by rememberSaveable { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        com.lingosnap.ui.components.PillChoice(
            listOf(tr("Einzeln"), tr("Liste")), if (list) tr("Liste") else tr("Einzeln"), { list = it == tr("Liste") },
        )
        if (list) ListInput(vm, isLang) else SingleInput(vm, isLang)
    }
}

/** One word and its translation; the small button next to the second field translates whichever field is filled. */
@Composable
private fun SingleInput(vm: AddCardsViewModel, isLang: Boolean) {
    var word by rememberSaveable { mutableStateOf("") }
    var translation by rememberSaveable { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var problem by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    fun add() {
        vm.addManual(word, translation)
        word = ""; translation = ""; problem = null
        runCatching { focus.requestFocus() }
    }

    fun translate() {
        val typed = if (word.isNotBlank()) word else translation
        if (typed.isBlank() || working) return
        working = true; problem = null
        scope.launch {
            val r = vm.translate(typed)
            r.onSuccess { t ->
                // the foreign word always goes into the first field, the translation into the second – whichever one was typed
                if (t.foreign) { word = t.text; translation = typed } else { word = typed; translation = t.text }
            }.onFailure { problem = it.message }
            working = false
        }
    }

    AppTextField(
        value = word, onValueChange = { word = it }, label = { Text(if (isLang) tr("Wort") else tr("Frage")) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().focusRequester(focus),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
    )
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AppTextField(
            value = translation, onValueChange = { translation = it }, label = { Text(if (isLang) tr("Übersetzung") else tr("Antwort")) }, singleLine = true,
            modifier = Modifier.weight(1f),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { add() }),
        )
        if (isLang) {
            androidx.compose.material3.FilledTonalIconButton(
                // translates the field that is filled; with both filled there is nothing to translate
                enabled = !working && (word.isNotBlank() xor translation.isNotBlank()),
                onClick = { translate() },
                modifier = Modifier.size(48.dp),
            ) {
                if (working) androidx.compose.material3.CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                else Icon(Icons.Rounded.Translate, tr("Automatisch übersetzen"))
            }
        }
    }
    problem?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
    if (isLang) Text(
        tr("Schreibe das Wort in einer der beiden Sprachen. Mit dem Knopf wird es übersetzt, und das Fremdwort steht in der Liste immer vorn."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    FilledTonalButton(enabled = word.isNotBlank() && translation.isNotBlank(), onClick = { add() }) { Text(tr("Hinzufügen")) }
}

/** Many entries at once: one per line, the two sides separated by a hyphen, semicolon, equals sign, colon or comma. */
@Composable
private fun ListInput(vm: AddCardsViewModel, isLang: Boolean) {
    var text by rememberSaveable { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(tr("Liste"), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        if (isLang) androidx.compose.material3.FilledTonalButton(
            enabled = text.isNotBlank() && !working,
            onClick = {
                working = true; info = null
                scope.launch {
                    val (clean, failed) = vm.normalizeList(text)
                    text = clean
                    info = if (failed > 0) tr("{0} Zeilen konnten nicht übersetzt werden. Beim ersten Mal wird das Sprachpaket geladen – dafür braucht das Handy Internet.", failed)
                    else tr("Fertig: Fremdwort vorn, Übersetzung dahinter, fehlende Übersetzungen ergänzt.")
                    working = false
                }
            },
            contentPadding = PaddingValues(horizontal = 14.dp),
            modifier = Modifier.heightIn(min = 40.dp),
        ) {
            if (working) androidx.compose.material3.CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            else Icon(Icons.Rounded.Translate, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(tr("Übersetzen"))
        }
    }
    AppTextField(
        value = text, onValueChange = { text = it; info = null }, minLines = 12,
        placeholder = {
            Text(
                if (isLang) tr("Ein Eintrag pro Zeile, zum Beispiel:\n\ncasa - Haus\nperro ; Hund\ngato = Katze\nla mesa : der Tisch\nel libro, das Buch\nla ventana\n\nSteht nur ein Wort in der Zeile (wie „la ventana“), übersetzt der Knopf „Übersetzen“ es.")
                else tr("Eine Karte pro Zeile, zum Beispiel:\n\nHauptstadt von Frankreich ; Paris\nWer schrieb Faust ? = Goethe\nH2O - Wasser"),
                style = MaterialTheme.typography.bodyMedium,
            )
        },
        modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp),
    )
    info?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
    Text(
        tr("Trennzeichen zwischen den beiden Seiten: Strich ( - ), Semikolon, Gleichheitszeichen, Doppelpunkt, Komma oder Tabulator. Die App nimmt das Zeichen, das in den meisten Zeilen vorkommt."),
        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
    )
    FilledTonalButton(
        enabled = text.isNotBlank() && !working,
        onClick = {
            working = true; info = null
            scope.launch {
                val (added, left) = vm.addList(text)
                text = ""
                info = if (left > 0) tr("{0} Einträge hinzugefügt, {1} Zeilen ohne Übersetzung ausgelassen.", added, left) else tr("{0} Einträge hinzugefügt.", added)
                working = false
            }
        },
    ) { Text(tr("Übernehmen")) }
}

@Composable
private fun ModelLine() {
    val gemini = LocalContext.current.container.gemini
    val provider by gemini.provider.collectAsState()
    if (provider != null) return
    val text = tr("Kein API-Schlüssel hinterlegt – unter Optionen eintragen.")
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
