@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.lingosnap.ui.mascot

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.tr
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Axi swims around on top of the app: wanders on its own, can be dragged anywhere, tapped to chat, says tips in speech
 * bubbles and – on the very first start – walks the user through the app ([tour]).
 */
@Composable
fun MascotOverlay(
    tour: Boolean,
    onTourDone: () -> Unit,
    onChat: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    BoxWithConstraints(modifier.fillMaxSize()) {
        val sizePx = with(density) { 76.dp.toPx() }
        val bubbleW = with(density) { 236.dp.toPx() }
        val maxX = with(density) { maxWidth.toPx() } - sizePx
        val maxY = with(density) { maxHeight.toPx() } - sizePx
        val pos = remember { Animatable(Offset(maxX * 0.78f, maxY * 0.62f), Offset.VectorConverter) }
        var dragging by remember { mutableStateOf(false) }
        var look by remember { mutableStateOf(Offset.Zero) }
        var mood by remember { mutableStateOf(Mood.Idle) }
        var bubble by remember { mutableStateOf<String?>(null) }
        var step by remember { mutableIntStateOf(0) }
        var tourOn by remember { mutableStateOf(tour) }

        val steps = listOf(
            tr("Hallo, ich bin Axi, ein Axolotl! Ich zeige dir kurz, wie die App funktioniert."),
            tr("Mit „Neues Deck“ legst du Vokabeln oder Karteikarten an. Du kannst sie tippen, scannen oder von der KI erzeugen lassen."),
            tr("Oben findest du die Suche, den Import und die Lernmethode."),
            tr("Die Tabs trennen Vokabeln und Lernkarten. Karteikarten sind nach Fächern sortiert."),
            tr("Tippe ein Deck an, dann kannst du lernen: Karteikarten, Multiple Choice, Schreiben und mehr."),
            tr("Tippe mich an, wenn du Fragen hast. Ich bin immer in der Nähe!"),
        )
        val tips = listOf(
            tr("Tipp: Kurze Lerneinheiten jeden Tag helfen mehr als eine lange pro Woche."),
            tr("Wusstest du? Axolotl leben nur in Seen bei Mexiko-Stadt und sind stark gefährdet."),
            tr("Tipp: Sprich neue Wörter laut aus, dann merkst du sie dir besser."),
            tr("Tipp: Falsche Karten wiederholst du am Ende jeder Runde noch einmal."),
            tr("Tipp: Mit „Mit KI erzeugen“ entstehen Karten zu jedem Thema."),
            tr("Tippe mich an und frag mich etwas!"),
        )

        fun moveTo(target: Offset, ms: Int = 2600) {
            scope.launch {
                look = Offset((target.x - pos.value.x).coerceIn(-1f, 1f), 0f)
                pos.animateTo(target, tween(ms, easing = FastOutSlowInEasing))
                look = Offset.Zero
            }
        }

        // wandering
        LaunchedEffect(tourOn) {
            while (true) {
                delay(Random.nextLong(5000, 11000))
                if (!dragging && !tourOn) {
                    val t = Offset(Random.nextFloat() * maxX, maxY * (0.25f + Random.nextFloat() * 0.7f))
                    look = Offset((t.x - pos.value.x).coerceIn(-1f, 1f), 0f)
                    pos.animateTo(t, tween(Random.nextInt(2400, 4200), easing = FastOutSlowInEasing))
                    look = Offset.Zero
                }
            }
        }
        // tips
        LaunchedEffect(tourOn) {
            if (tourOn) return@LaunchedEffect
            var i = Random.nextInt(tips.size)
            delay(14000)
            while (true) {
                if (!dragging) {
                    bubble = tips[i % tips.size]; mood = Mood.Talking
                    delay(2600); mood = Mood.Idle
                    delay(4400); bubble = null
                    i++
                }
                delay(Random.nextLong(28000, 50000))
            }
        }
        // tour
        LaunchedEffect(tourOn, step) {
            if (!tourOn) return@LaunchedEffect
            bubble = steps[step]
            mood = if (step == steps.lastIndex) Mood.Happy else Mood.Talking
            val side = if (step % 2 == 0) 0.12f else 0.82f
            val y = when (step) { 1 -> 0.78f; 2 -> 0.18f; 3 -> 0.3f; else -> 0.55f }
            moveTo(Offset(maxX * side, maxY * y), 1500)
            delay(2200)
            if (mood == Mood.Talking) mood = Mood.Idle
        }

        val bubbleBelow = pos.value.y < maxY * 0.5f
        val bx = (pos.value.x + sizePx / 2 - bubbleW / 2).coerceIn(with(density) { 8.dp.toPx() }, (maxX + sizePx - bubbleW - with(density) { 8.dp.toPx() }).coerceAtLeast(0f))
        val bubbleH = with(density) { (if (tourOn) 168.dp else 96.dp).toPx() }
        val by = if (bubbleBelow) pos.value.y + sizePx + with(density) { 4.dp.toPx() } else pos.value.y - bubbleH - with(density) { 4.dp.toPx() }

        AnimatedVisibility(
            visible = bubble != null,
            modifier = Modifier.offset { IntOffset(bx.roundToInt(), by.roundToInt().coerceAtLeast(0)) },
            enter = fadeIn(tween(160)) + scaleIn(tween(220), initialScale = 0.85f),
            exit = fadeOut(tween(160)) + scaleOut(tween(160), targetScale = 0.9f),
        ) {
            Surface(
                Modifier.width(236.dp),
                shape = RoundedCornerShape(24.dp), color = cs.inverseSurface, contentColor = cs.inverseOnSurface,
                shadowElevation = 6.dp,
                onClick = { if (!tourOn) bubble = null },
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(bubble.orEmpty(), style = MaterialTheme.typography.bodyMedium)
                    if (tourOn) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { tourOn = false; bubble = null; mood = Mood.Idle; onTourDone() }) {
                            Text(tr("Überspringen"), color = cs.inverseOnSurface)
                        }
                        Button(onClick = {
                            if (step < steps.lastIndex) step++ else { tourOn = false; bubble = null; mood = Mood.Happy; onTourDone() }
                        }) { Text(if (step < steps.lastIndex) tr("Weiter") else tr("Los geht’s")) }
                    }
                }
            }
        }

        Axolotl(
            Modifier
                .offset { IntOffset(pos.value.x.roundToInt(), pos.value.y.roundToInt()) }
                .size(76.dp)
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { if (!tourOn) { mood = Mood.Happy; onChat() } })
                }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { dragging = true; mood = Mood.Happy },
                        onDragEnd = { dragging = false; mood = Mood.Idle },
                        onDragCancel = { dragging = false; mood = Mood.Idle },
                    ) { change, drag ->
                        change.consume()
                        val n = Offset((pos.value.x + drag.x).coerceIn(0f, maxX), (pos.value.y + drag.y).coerceIn(0f, maxY))
                        look = Offset(drag.x.coerceIn(-1f, 1f), drag.y.coerceIn(-1f, 1f))
                        scope.launch { pos.snapTo(n) }
                    }
                },
            mood = mood, look = look,
        )
    }
}

private fun Modifier.fillMaxWidth(): Modifier = this.then(Modifier.width(204.dp))
