package com.lingosnap

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.room.Room
import com.lingosnap.data.CardRepository
import com.lingosnap.data.SecureKeyStore
import com.lingosnap.data.StatsStore
import com.lingosnap.data.local.AppDatabase
import com.lingosnap.data.local.MIGRATION_1_2
import com.lingosnap.data.local.MIGRATION_2_3
import com.lingosnap.data.local.MIGRATION_3_4
import com.lingosnap.data.local.MIGRATION_4_5
import com.lingosnap.data.local.MIGRATION_5_6
import com.lingosnap.util.FeedbackManager
import com.lingosnap.data.remote.GeminiClient
import com.lingosnap.util.TtsManager

/** Hand-rolled DI container – swap for Hilt/Koin once the app grows. */
class AppContainer(context: Context) {
    val keyStore = SecureKeyStore(context)
    val gemini = GeminiClient(keyStore)
    val stats = StatsStore(context)
    private val db = Room.databaseBuilder(context, AppDatabase::class.java, "lingosnap_v2.db")
        .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
        .build()
    val repository = CardRepository(db.dao(), gemini, stats)
    val tts = TtsManager(context)
    val feedback = FeedbackManager(context)
    val notifier = com.lingosnap.util.Notifier(context)
    val autoBackup = com.lingosnap.util.AutoBackup(context, repository)
    /** Lives as long as the app process: AI jobs keep running when the user leaves a screen. */
    val appScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Main.immediate)
}

class LingoSnapApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        com.lingosnap.util.Lang.init(this)
        com.lingosnap.util.CardImages.init(this)
        com.lingosnap.util.CrashLog.install(this)
        container = AppContainer(this)
        container.autoBackup.startWatching(container.appScope)
        com.lingosnap.util.Reminders.apply(this)
    }
}

val Context.container: AppContainer get() = (applicationContext as LingoSnapApp).container
fun CreationExtras.app(): LingoSnapApp = this[APPLICATION_KEY] as LingoSnapApp
