package com.lingosnap.ui.create

import com.lingosnap.util.tr

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.remote.GeminiException
import com.lingosnap.data.remote.Progress
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.AiJobs
import com.lingosnap.util.Batch
import com.lingosnap.util.DocumentReader
import com.lingosnap.util.JobInfo
import com.lingosnap.util.Notifier
import com.lingosnap.util.PendingStore
import com.lingosnap.util.normalize
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.max

class Draft(pair: VocabPair, selected: Boolean = true) {
    var pair by mutableStateOf(pair)
    var selected by mutableStateOf(selected)
}

/**
 * Collects new cards for an existing deck (typed, from files or from the AI) and saves them at once.
 * AI jobs run in [appScope], so they keep going when the user leaves the screen.
 */
val DEFAULT_DECK_NAME: String get() = tr("Neues Deck")

class AddCardsViewModel(
    private val repo: CardRepository,
    private val deckId: Long,
    private val appScope: CoroutineScope,
    private val notifier: Notifier,
) : ViewModel() {

    var deck by mutableStateOf<Deck?>(null)
        private set

    val drafts = mutableStateListOf<Draft>()
    private val seen = HashSet<String>()

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** 0..1 while the AI works; status text says what it is doing right now. */
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf<String?>(null)
        private set

    /** Loading dialog: visible while the AI works and until the user confirms the result. */
    var showProgress by mutableStateOf(false)
        private set
    /** 0 prepare, 1 send, 2 read, 3 assemble, 4 check duplicates, 5 done */
    var step by mutableIntStateOf(0)
        private set
    var found by mutableIntStateOf(0)
        private set
    /** Number of cards this run really added to the list (kept until the next run, whatever happens to the list afterwards). */
    var resultCount by mutableIntStateOf(0)
        private set
    /** Number of entries in the answer of the AI, known as soon as the answer is there (the list below fills up afterwards). */
    var totalFound by mutableIntStateOf(0)
        private set
    /** The model that is being asked right now (and, at the end, the one that answered). */
    var currentModel by mutableStateOf<String?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    private var aiJob: Job? = null
    private var waitingSince = 0L
    private var waitingModel: String? = null
    private var lastFailure: String? = null
    private var detached = false
    private var inBackground = false

    /** Files chosen for the scan: they only show as a preview until the learner starts the recognition. */
    val files = mutableStateListOf<Uri>()

    fun addFiles(uris: List<Uri>) { uris.forEach { if (it !in files) files.add(it) } }
    fun removeFile(uri: Uri) { files.remove(uri) }

    fun startScan(context: Context, local: Boolean = false) {
        if (busy || files.isEmpty()) return
        val list = files.toList()
        files.clear()
        if (local) scanLocal(context, list) else scan(context, list)
    }


    init {
        viewModelScope.launch {
            deck = repo.deck(deckId)
            // results of a job that finished while the screen was closed
            PendingStore.take(deckId)?.forEach { addDraft(it) }
        }
    }

    override fun onCleared() { detached = true }

    fun dismissProgress() { if (!busy) showProgress = false }

    private var userCancelled = false

    /** Stops the AI job at once (the running request is aborted) and closes the progress sheet. */
    fun cancelAi() {
        userCancelled = true
        showProgress = false
        aiJob?.cancel()
    }

    /** "Im Hintergrund fortsetzen": hides the dialog, keeps working and notifies when done. */
    fun moveToBackground() {
        if (!busy) return
        inBackground = true
        showProgress = false
        notifier.startKeepAlive()
    }

    private fun addDraft(pair: VocabPair): Boolean {
        val key = pair.source.lowercase() + "|" + pair.target.lowercase()
        if (!seen.add(key)) return false
        drafts.add(0, Draft(pair))
        return true
    }

    private val isLangDeck get() = deck?.isLanguage != false

    /** Adds one typed card; for a vocabulary deck the foreign word always becomes the front, whichever field it was typed into. */
    fun addManual(first: String, second: String) {
        if (first.isBlank() || second.isBlank()) return
        val pair = VocabPair(first.trim(), second.trim())
        val d = deck
        if (d == null || !isLangDeck) { addDraft(pair); return }
        viewModelScope.launch {
            val fixed = runCatching { com.lingosnap.util.TextAi.orient(listOf(pair), d.sourceLang, d.targetLang).first() }.getOrDefault(pair)
            addDraft(fixed)
        }
    }

    /** Translates a typed word into the other language of the deck (see [com.lingosnap.util.TextAi.translateFor]). */
    suspend fun translate(text: String): Result<com.lingosnap.util.Translated> {
        val d = deck ?: return Result.failure(IllegalStateException(tr("Das Deck wird noch geladen.")))
        return com.lingosnap.util.TextAi.translateFor(text, d.sourceLang, d.targetLang)
    }

    /**
     * Cleans the typed list: the foreign word first, the translation second, missing translations filled in by the phone.
     * Returns the new text (one entry per line, "word - translation") and how many lines could not be completed.
     */
    suspend fun normalizeList(text: String): Pair<String, Int> {
        val d = deck
        val entries = com.lingosnap.util.ManualLines.parse(text)
        if (d == null || !isLangDeck) return text to 0
        var failed = 0
        // 1. lines that have both sides: right way round?
        val both = entries.filter { it.second != null }
        val fixed = com.lingosnap.util.TextAi.orient(both.map { VocabPair(it.first, it.second!!, it.example) }, d.sourceLang, d.targetLang)
        var k = 0
        val lines = ArrayList<String>()
        for (e in entries) {
            if (e.second != null) {
                val p = fixed[k++]
                lines += if (p.example.isNullOrBlank()) "${p.source} - ${p.target}" else "${p.source} ; ${p.target} ; ${p.example}"
            } else {
                // 2. a single word: translated into the other language of the deck
                val t = com.lingosnap.util.TextAi.translateFor(e.first, d.sourceLang, d.targetLang).getOrNull()
                if (t == null) { failed++; lines += e.first }
                else lines += if (t.foreign) "${t.text} - ${e.first}" else "${e.first} - ${t.text}"
            }
        }
        return lines.joinToString("\n") to failed
    }

    /** Adds the typed list as cards. Lines that still have no translation are left out; returns (added, left out). */
    suspend fun addList(text: String): Pair<Int, Int> {
        val (clean, failed) = normalizeList(text)
        val entries = com.lingosnap.util.ManualLines.parse(clean)
        val added = entries.count { e -> e.second != null && addDraft(VocabPair(e.first, e.second!!, e.example)) }
        return added to failed
    }

    /* ── AI jobs ── */

    private var batchCount = 1
    private var completedBatches = 0
    private var receivedTotal = 0
    private var receivedAtComplete = 0

    private fun part() = if (batchCount > 1) tr(" (Teil {0} von {1} fertig)", completedBatches, batchCount) else ""

    /** Runs an AI job with live progress. [expected] = known number of entries, or 0 if unknown. */
    private fun runAi(expected: Int, scan: Boolean, prepare: suspend () -> Unit = {}, local: Boolean = false, job: suspend (Progress) -> Result<List<VocabPair>>) {
        if (busy) return
        userCancelled = false
        busy = true; error = null; notice = null; showProgress = true; scanning = scan; inBackground = false
        step = 0; found = 0; resultCount = 0; totalFound = 0; currentModel = null; progress = 0.1f
        batchCount = 1; completedBatches = 0; receivedTotal = 0; receivedAtComplete = 0
        windowLo = 0.12f; windowHi = 0.85f; waitingForAi = false
        status = if (scan) tr("Dateien werden vorbereitet") else tr("Anfrage wird vorbereitet")
        aiJob = appScope.launch {
            var ticker: Job? = null
            var failed: String? = null
            var cancelled = false
            // publishes percent + status for the deck list and the notification
            val reporter = launch {
                while (true) {
                    val pct = (progress * 100).toInt().coerceIn(0, 100)
                    val text = status ?: ""
                    AiJobs.set(deckId, JobInfo(pct, text))
                    if (inBackground || detached) notifier.progress(deckId, deck?.name ?: tr("Deck"), pct, text)
                    delay(400)
                }
            }
            try {
                prepare()
                step = 1; progress = max(progress, 0.12f)
                if (local) {
                    // no AI: the text is read on the phone
                    step = 2
                    status = tr("Text wird auf dem Gerät erkannt (ohne KI)")
                    waitingForAi = false
                } else {
                    status = tr("Anfrage wird an die KI gesendet") + part()
                    waitingSince = System.currentTimeMillis(); waitingModel = null; lastFailure = null; waitingForAi = true
                }
                // Like the web app: while we wait, the bar counts up slowly (every 0.4 s) towards the end of its window (85 % for one request,
                // for several requests each one has its own part of the way). It never passes the end of its window.
                // The status line says honestly which model we wait for and why the previous one was given up.
                ticker = launch {
                    while (true) {
                        delay(400)
                        val cap = windowHi - 0.02f
                        if (progress < cap) progress += (cap - progress) * 0.02f
                        if (waitingForAi) {
                            val sec = ((System.currentTimeMillis() - waitingSince) / 1000).toInt()
                            val who = waitingModel
                            status = (if (who == null) tr("Anfrage wird an die KI gesendet") else tr("Warte auf {0} … {1} s", who, sec)) +
                                (lastFailure?.let { "\n" + it } ?: "") + part()
                        }
                    }
                }
                val p = Progress(
                    onModel = { m -> launch(Dispatchers.Main) { currentModel = m.removePrefix("models/"); waitingModel = currentModel; waitingSince = System.currentTimeMillis(); waitingForAi = true } },
                    onFailed = { m, why -> launch(Dispatchers.Main) { lastFailure = tr("{0}: {1} – das nächste Modell wird versucht", m, why) } },
                    onFirstText = {
                        launch(Dispatchers.Main) {
                            step = 2
                            waitingForAi = false
                            lastFailure = null
                            status = (if (scan) tr("KI liest den Text und erkennt Einträge") else tr("KI erzeugt Einträge")) + part()
                            if (!scan && progress < 0.35f) progress = 0.35f
                        }
                    },
                    onPair = { pair ->
                        launch(Dispatchers.Main) {
                            if (addDraft(pair)) receivedTotal++
                            found = receivedTotal
                            val f = if (expected > 0) (receivedTotal / expected.toFloat()).coerceAtMost(1f)
                            else (completedBatches + (1f - exp(-(receivedTotal - receivedAtComplete) / 12f))) / batchCount
                            progress = max(progress, 0.35f + 0.45f * f.coerceAtMost(1f))
                        }
                    },
                )
                job(p).onSuccess { list ->
                    waitingForAi = false
                    ticker?.cancel()
                    // the answer is here: say so, then create the cards one after another so that the learner sees them appear
                    step = 3; progress = max(progress, 0.85f)
                    totalFound = list.size
                    status = if (local) tr("Text erkannt – {0} Einträge werden erstellt", list.size) else tr("Antwort erhalten – {0} Einträge werden erstellt", list.size)
                    delay(500) // long enough to read how many entries the AI found
                    val pause = (1500L / list.size.coerceAtLeast(1)).coerceIn(4L, 40L)
                    var added = 0
                    list.forEachIndexed { i, pair ->
                        if (addDraft(pair)) added++
                        found = drafts.size
                        progress = max(progress, 0.85f + 0.14f * (i + 1) / list.size)
                        status = tr("{0} Einträge erkannt – Eintrag {1} wird erstellt", list.size, i + 1)
                        delay(pause)
                    }
                    resultCount = added
                    if (drafts.isEmpty()) {
                        failed = tr("Es wurden keine Einträge erkannt.")
                        error = failed
                        status = null
                    } else {
                        progress = 1f
                        step = 4
                        status = tr("Fertig")
                    }
                }.onFailure {
                    if (userCancelled || it is kotlinx.coroutines.CancellationException) {
                        cancelled = true; status = null; showProgress = false
                    } else {
                        failed = it.message ?: tr("Unbekannter Fehler")
                        error = failed
                        status = null
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                cancelled = true
                status = null
                showProgress = false
                throw e
            } catch (e: Exception) {
                if (userCancelled) { cancelled = true; status = null; showProgress = false }
                else {
                    failed = e.message ?: tr("Unbekannter Fehler")
                    error = failed
                    status = null
                }
            } finally {
                ticker?.cancel()
                reporter.cancel()
                AiJobs.clear(deckId)
                waitingForAi = false
                busy = false
                if (cancelled) {
                    notifier.stopKeepAlive()
                    notifier.cancelProgress()
                } else if (inBackground || detached) {
                    notifier.stopKeepAlive()
                    // finished while the learner was elsewhere: the cards go straight into the deck, so the deck is full when it is opened
                    val saved = if (failed == null) runCatching { autoSave() }.getOrDefault(0) else 0
                    val title = if (failed == null) tr("LingoSnap: Fertig") else tr("LingoSnap: Das hat nicht geklappt")
                    val text = if (failed == null) tr("{0} Karten wurden zu „{1}“ hinzugefügt.", saved, deck?.name ?: tr("deinem Deck")) else failed.orEmpty()
                    notifier.done(deckId, title, text)
                }
            }
        }
        aiJob?.let { AiJobs.register(deckId, it) }
    }

    private var windowLo = 0.12f
    private var windowHi = 0.85f
    private var waitingForAi = false

    /** Saves every selected draft that is not already in the deck. Returns how many cards were added. */
    private suspend fun autoSave(): Int {
        val d = deck ?: return 0
        val existing = runCatching { repo.cardsOf(deckId) }.getOrDefault(emptyList())
        val known = existing.map { normalize(it.source) + "|" + normalize(it.target) }.toSet()
        val add = drafts.filter { it.selected && (normalize(it.pair.source) + "|" + normalize(it.pair.target)) !in known }
        if (add.isEmpty()) return 0
        repo.addCards(d, add.map { it.pair })
        drafts.clear()
        seen.clear()
        found = 0
        return add.size
    }

    /** As in the web app: a deck that still has no name takes the name of the first file (without the ending). */
    private fun nameFromFile(fileName: String) {
        val d = deck ?: return
        val name = fileName.trim().take(40)
        if (d.name != DEFAULT_DECK_NAME || name.length < 2) return
        // photos taken with the camera have no meaningful name
        if (Regex("^(scan_|img[_-]|pxl_|dsc|photo|image|\\d{4,})", RegexOption.IGNORE_CASE).containsMatchIn(name)) return
        appScope.launch {
            runCatching { repo.renameDeck(d, name) }.onSuccess { deck = d.copy(name = name) }
        }
    }

    /**
     * The file recognition of the web app: the files are read, every block of text / every photo / every scan is one request, one after
     * another. A block that fails does not stop the others; equal cards are kept once.
     */
    fun scan(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (uris.isEmpty()) return
        var batches: List<Batch> = emptyList()
        runAi(
            expected = 0,
            scan = true,
            prepare = {
                status = if (uris.size > 1) tr("{0} Dateien werden vorbereitet …", uris.size) else tr("Datei wird vorbereitet …")
                val material = DocumentReader.read(context, uris)
                batches = material.batches
                batchCount = batches.size.coerceAtLeast(1)
                nameFromFile(material.firstFileName)
            },
        ) { p ->
            val all = ArrayList<VocabPair>()
            var firstError: Throwable? = null
            var failedParts = 0
            batches.forEachIndexed { i, batch ->
                windowLo = 0.12f + 0.73f * i / batches.size
                windowHi = 0.12f + 0.73f * (i + 1) / batches.size
                progress = max(progress, windowLo)
                val r = repo.recognize(batch, d, p)
                val e = r.exceptionOrNull()
                if (e is kotlinx.coroutines.CancellationException) throw e
                r.getOrNull()?.let { all += it }
                // a block without vocabulary (blank page, cover) is fine; real errors are counted
                if (e != null && e !is GeminiException.NoResult) { failedParts++; if (firstError == null) firstError = e }
                completedBatches++
                progress = max(progress, windowHi)
            }
            if (failedParts > 0 && all.isNotEmpty()) {
                notice = tr("{0} von {1} Teilen der Datei konnten nicht gelesen werden, die Einträge daraus fehlen. Starte den Import später noch einmal, um sie nachzuholen.", failedParts, batches.size)
            }
            // the AI could not be reached at all: read the text on the phone instead (the list below is the check before saving)
            if (all.isEmpty() && firstError != null && !userCancelled) {
                waitingForAi = false
                status = tr("Die KI ist nicht erreichbar – der Text wird stattdessen auf dem Gerät erkannt")
                var skipped = 0
                val localFound = ArrayList<VocabPair>()
                batches.forEach { b ->
                    val r = runCatching { com.lingosnap.util.LocalRecognizer.read(b, d.sourceLang, d.targetLang, orient = d.isLanguage) }.getOrNull()
                    if (r != null) { localFound += r.pairs; skipped += r.skipped }
                }
                if (localFound.isNotEmpty()) {
                    notice = tr("Die KI war nicht erreichbar. Der Text wurde auf dem Gerät erkannt – das ist ungenauer. Bitte prüfe die Einträge, bevor du speicherst.")
                    all += localFound
                }
            }
            when {
                all.isNotEmpty() -> Result.success(all)
                firstError != null -> Result.failure(firstError!!)
                else -> Result.failure(GeminiException.NoResult(""))
            }
        }
    }

    /** Reads the files without AI, on the phone: separators in text, rows of two columns in photos and scans. */
    fun scanLocal(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (uris.isEmpty()) return
        var batches: List<Batch> = emptyList()
        runAi(
            expected = 0, scan = true, local = true,
            prepare = {
                status = if (uris.size > 1) tr("{0} Dateien werden vorbereitet …", uris.size) else tr("Datei wird vorbereitet …")
                val material = DocumentReader.read(context, uris)
                batches = material.batches
                batchCount = batches.size.coerceAtLeast(1)
                nameFromFile(material.firstFileName)
            },
        ) { _ ->
            val all = ArrayList<VocabPair>()
            var skipped = 0
            var firstError: Throwable? = null
            batches.forEachIndexed { i, batch ->
                windowLo = 0.12f + 0.73f * i / batches.size
                windowHi = 0.12f + 0.73f * (i + 1) / batches.size
                progress = max(progress, windowLo)
                status = tr("Text wird auf dem Gerät erkannt (ohne KI)") + part()
                val r = runCatching { com.lingosnap.util.LocalRecognizer.read(batch, d.sourceLang, d.targetLang, orient = d.isLanguage) }
                val e = r.exceptionOrNull()
                if (e is kotlinx.coroutines.CancellationException) throw e
                r.getOrNull()?.let { all += it.pairs; skipped += it.skipped }
                if (e != null && firstError == null) firstError = e
                completedBatches++
                progress = max(progress, windowHi)
            }
            if (skipped > 0 && all.isNotEmpty()) notice = tr("{0} Zeilen ohne Übersetzung wurden übersprungen. Mit der KI-Erkennung oder dem Übersetzen-Knopf beim Eintippen lassen sie sich ergänzen.", skipped)
            when {
                all.isNotEmpty() -> Result.success(all.distinctBy { it.source.lowercase() + "|" + it.target.lowercase() })
                firstError != null -> Result.failure(firstError!!)
                else -> Result.failure(GeminiException.NoResult(""))
            }
        }
    }

    /** Shown above the list when part of a big file could not be read. */
    var notice by mutableStateOf<String?>(null)
        private set

    val selectedCount: Int get() = drafts.count { it.selected }

    /** Saves the selected cards (a card that is exactly the same as one in the deck is skipped). */
    fun save(onDone: () -> Unit) {
        val d = deck ?: return
        if (busy) return
        viewModelScope.launch {
            busy = true
            val known = repo.cardsOf(deckId).map { normalize(it.source) + "|" + normalize(it.target) }.toSet()
            val add = drafts.filter { it.selected && (normalize(it.pair.source) + "|" + normalize(it.pair.target)) !in known }
            if (add.isNotEmpty()) repo.addCards(d, add.map { it.pair })
            busy = false
            onDone()
        }
    }
}
