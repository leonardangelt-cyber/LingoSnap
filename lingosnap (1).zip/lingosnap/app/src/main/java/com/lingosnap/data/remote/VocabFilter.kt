package com.lingosnap.data.remote

/**
 * Cleans the answer of the file recognition so that only real vocabulary entries count:
 * headings, lesson titles, page numbers and column titles are removed, equal entries are kept once.
 */
object VocabFilter {
    private val heading = Regex(
        "^(unit|lektion|lesson|kapitel|chapter|seite|page|p\\.|s\\.|übung|exercise|vocabulary|vokabeln|vokabelliste|wortschatz|word ?list|" +
            "teil|part|thema|topic|modul|module|leçon|lección|lezione|lição|unidade|tema|vocabulaire|vocabulario|vocabolario|vocabulário)" +
            "(\\s*[\\p{L}]?\\s*\\d+\\s*[:.)-]?\\s*\\d*|\\s*:)$",
        RegexOption.IGNORE_CASE,
    )
    private val onlyNumber = Regex("^[\\d\\s.,:;()/\\-–—]+$")

    private fun key(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim().trimEnd('.', '!', '?', ';', ',')

    fun isHeading(front: String): Boolean {
        val f = front.trim()
        return f.isEmpty() || onlyNumber.matches(f) || heading.matches(f)
    }

    fun clean(pairs: List<VocabPair>): List<VocabPair> {
        val seen = HashSet<String>()
        val out = ArrayList<VocabPair>(pairs.size)
        for (p in pairs) {
            val s = p.source.trim(); val t = p.target.trim()
            if (s.isEmpty() || t.isEmpty() || isHeading(s) || onlyNumber.matches(t)) continue
            if (!seen.add(key(s) + "|" + key(t))) continue
            out += if (s == p.source && t == p.target) p else p.copy(source = s, target = t)
        }
        return out
    }
}
