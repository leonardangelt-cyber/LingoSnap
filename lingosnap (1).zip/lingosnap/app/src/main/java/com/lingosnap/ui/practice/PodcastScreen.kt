package com.lingosnap.ui.practice

import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.components.PillChoice
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.Lang
import com.lingosnap.util.PodcastItem
import com.lingosnap.util.PodcastPlayer

/**
 * Podcast mode: the word is read in the learned language, then there is a pause to translate it in your head,
 * then the translation is read. Keeps playing in the background (foreground service with notification controls).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PodcastScreen(scope: StudyScope, id: Long, onBack: () -> Unit, from: Int = 0, to: Int = 0) {
    val vm = rememberPractice(scope, id, "podcast", 100000, from, to)
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val key = "$scope-$id-$from-$to"
    val st by PodcastPlayer.state.collectAsState()
    val mine = st.active && st.key == key

    LaunchedEffect(vm.loading, key) {
        if (!vm.loading && !PodcastPlayer.isActiveFor(key)) {
            val list = vm.pool
                .filter { it.source.isNotBlank() && it.target.isNotBlank() }
                .map { PodcastItem(it.source, it.target, it.sourceLang.ifBlank { Lang.code }, it.targetLang.ifBlank { Lang.code }) }
            PodcastPlayer.start(context, key, tr("Podcast"), list, pauseSec = 4, loop = true, shuffle = false)
        }
    }

    Scaffold(
        containerColor = cs.surface,
        topBar = {
            TopAppBar(
                title = { Text(tr("Podcast"), style = MaterialTheme.typography.titleLarge.bold()) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, tr("Zurück")) } },
            )
        },
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (vm.loading || !mine) {
                Column(Modifier.fillMaxWidth().height(240.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            } else {
                // now playing
                Surface(shape = RoundedCornerShape(36.dp), color = cs.primaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 24.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Surface(shape = CircleShape, color = cs.primary, contentColor = cs.onPrimary) {
                            Text("${st.index + 1} / ${st.total}", Modifier.padding(horizontal = 14.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
                        }
                        Text(
                            st.source, style = MaterialTheme.typography.displaySmall.bold(), color = cs.onPrimaryContainer,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                        )
                        Surface(shape = RoundedCornerShape(24.dp), color = cs.surface.copy(alpha = if (st.phase >= 2) 0.9f else 0.35f), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                if (st.phase >= 2) {
                                    Text(st.target, style = MaterialTheme.typography.headlineSmall.bold(), color = cs.onSurface, textAlign = TextAlign.Center)
                                } else {
                                    Text(
                                        if (st.phase == 1) tr("Übersetze im Kopf …") else tr("Hör zu …"),
                                        style = MaterialTheme.typography.titleMedium, color = cs.onPrimaryContainer, textAlign = TextAlign.Center,
                                    )
                                }
                            }
                        }
                        LinearProgressIndicator(
                            progress = { if (st.total == 0) 0f else (st.index + 1f) / st.total },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = cs.primary, trackColor = cs.onPrimaryContainer.copy(alpha = 0.15f),
                            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
                        )
                    }
                }

                // controls
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(onClick = { PodcastPlayer.previous() }, modifier = Modifier.size(60.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, tr("Zurück"), modifier = Modifier.size(30.dp))
                    }
                    FilledIconButton(onClick = { PodcastPlayer.toggle() }, modifier = Modifier.size(88.dp)) {
                        Icon(if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (st.playing) tr("Pause") else tr("Abspielen"), modifier = Modifier.size(44.dp))
                    }
                    FilledTonalIconButton(onClick = { PodcastPlayer.next() }, modifier = Modifier.size(60.dp)) {
                        Icon(Icons.Rounded.SkipNext, tr("Weiter"), modifier = Modifier.size(30.dp))
                    }
                }

                // settings
                Surface(shape = RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(tr("Denkpause"), style = MaterialTheme.typography.titleMedium.bold())
                        val options = listOf(2, 4, 6, 8).map { "$it s" }
                        PillChoice(options = options, selected = "${st.pauseSec} s", onSelect = { PodcastPlayer.setPause(it.removeSuffix(" s").toInt()) })
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Endlos wiederholen"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                            Switch(checked = st.loop, onCheckedChange = { PodcastPlayer.setLoop(it) })
                        }
                    }
                }
                Text(
                    tr("Läuft auch bei ausgeschaltetem Bildschirm weiter. Steuern kannst du es in der Benachrichtigung."),
                    style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                )
                TextButton(onClick = { PodcastPlayer.stop(); onBack() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Stop, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.size(8.dp))
                    Text(tr("Beenden"))
                }
            }
        }
    }
}
