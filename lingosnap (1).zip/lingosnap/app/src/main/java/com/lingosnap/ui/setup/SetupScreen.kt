@file:OptIn(ExperimentalMaterial3Api::class)

package com.lingosnap.ui.setup

import com.lingosnap.util.tr
import com.lingosnap.ui.icons.AppIcon

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Button
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.MorphLoader
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.floating
import com.lingosnap.ui.theme.bold

@Composable
fun SetupScreen(onDone: () -> Unit, vm: SetupViewModel = viewModel(factory = SetupViewModel.Factory)) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val uriHandler = LocalUriHandler.current
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(ui.saved) { if (ui.saved) onDone() }

    AppBackground {
        Column(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(Modifier, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "LingoSnap",
                    style = MaterialTheme.typography.headlineLarge.bold(),
                    color = cs.onSurface,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("Foto machen. Jedes Wort lernen."),
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }

            // Key card
            Surface(
                Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                color = cs.surfaceContainer,
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(AppIcon.Lock, null, tint = cs.primary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(tr("Dein API-Schlüssel"), style = MaterialTheme.typography.titleMedium.bold())
                    }
                    Text(
                        tr("Funktioniert mit Schlüsseln von Google Gemini, OpenAI, Claude, OpenRouter, Groq und xAI. Anbieter und Modell werden automatisch erkannt. Der Schlüssel bleibt verschlüsselt auf diesem Gerät."),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                    AppTextField(
                        value = ui.key,
                        onValueChange = vm::onKeyChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(tr("API-Schlüssel")) },
                        singleLine = true,
                        isError = ui.error != null,
                        visualTransformation = if (ui.visible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = vm::toggleVisible) {
                                Icon(
                                    if (ui.visible) AppIcon.VisibilityOff else AppIcon.Visibility,
                                    tr("Anzeigen/Verbergen"),
                                )
                            }
                        },
                    )
                    AnimatedVisibility(
                        visible = ui.error != null,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically(),
                    ) {
                        Surface(shape = MaterialTheme.shapes.medium, color = cs.errorContainer, contentColor = cs.onErrorContainer) {
                            Text(
                                ui.error.orEmpty(),
                                Modifier.padding(14.dp),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            }

            Button(
                onClick = vm::saveAndVerify,
                enabled = ui.key.isNotBlank() && !ui.validating,
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) {
                if (ui.validating) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp, color = cs.onPrimary)
                    Spacer(Modifier.width(12.dp))
                    Text(tr("Prüfe …"), style = MaterialTheme.typography.titleMedium.bold())
                } else {
                    Text(tr("Prüfen & speichern"), style = MaterialTheme.typography.titleMedium.bold())
                }
            }

            if (ui.canForce && ui.error != null) {
                androidx.compose.material3.FilledTonalButton(onClick = vm::saveAnyway, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text(tr("Trotzdem speichern"))
                }
            }
            TextButton(
                onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") },
            ) {
                Text(tr("Kostenlosen Gemini-Schlüssel holen"))
            }
            TextButton(onClick = vm::skip) { Text(tr("Überspringen")) }
        }
    }
}
