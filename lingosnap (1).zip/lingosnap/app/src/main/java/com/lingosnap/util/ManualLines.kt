package com.lingosnap.util

/** One line of a typed list: [first] is always there, [second] is null when the line has only a word (it will be translated). */
class ListEntry(val first: String, val second: String?, val example: String? = null)

/**
 * Reads the list input: one entry per line, the two sides separated by a semicolon, tab, " - ", "=", ":", "|", "->" or a comma.
 * The separator that most lines use is taken for all lines; a line without it tries the others, and a line with no separator at all
 * is a single word that only needs a translation. Pure Kotlin (no Android), tested on the JVM.
 */
object ManualLines {
    /** In the order they win a tie. The bare hyphen and the comma are the weakest: they also occur inside words and translations. */
    private val strong = listOf("\t", ";", "|", " -> ", "->", " => ", "=>", " - ", " – ", " — ", " = ", "=", ": ", ":")
    private val weak = listOf("-", ",")
    private val numbering = Regex("""^(?:\d{1,3}[.)]|[•*·-])\s+""")

    fun parse(text: String): List<ListEntry> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("//") }
            .map { numbering.replaceFirst(it, "").trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()
        fun best(list: List<String>): String? = list.maxByOrNull { c -> lines.count { it.contains(c) } }?.takeIf { c -> lines.any { it.contains(c) } }
        val global = best(strong) ?: best(weak)
        val out = ArrayList<ListEntry>()
        for (line in lines) {
            val sep = if (global != null && line.contains(global)) global else (strong + weak).firstOrNull { line.contains(it) }
            if (sep == null) { out += ListEntry(line, null); continue }
            val parts = if (sep == ";" || sep == "\t") line.split(sep).map { it.trim() } else line.split(sep, limit = 2).map { it.trim() }
            val a = parts.getOrNull(0).orEmpty(); val b = parts.getOrNull(1).orEmpty()
            when {
                a.isNotEmpty() && b.isNotEmpty() -> out += ListEntry(a, b, parts.getOrNull(2)?.takeIf { it.isNotEmpty() })
                a.isNotEmpty() -> out += ListEntry(a, null)
                b.isNotEmpty() -> out += ListEntry(b, null)
            }
        }
        return out
    }
}

/** Decides which side of a pair is the foreign word and which the translation, from how likely each text is in which language. */
object Orient {
    /** Language tag of "zh-Latn" / "de" / "pt-BR" as plain "zh" / "de" / "pt". */
    fun base(tag: String) = tag.lowercase().substringBefore('-').substringBefore('_')

    private fun p(m: Map<String, Float>, tag: String): Float = m.entries.filter { base(it.key) == base(tag) }.sumOf { it.value.toDouble() }.toFloat()

    /**
     * Positive = the sides are the wrong way round (the first text looks like the translation language).
     * [source] = language of the cards' front (foreign), [target] = the translation language; source "auto" / blank = unknown foreign language.
     */
    fun diff(a: Map<String, Float>, b: Map<String, Float>, source: String, target: String): Float {
        val knownSource = source.isNotBlank() && source != "auto"
        return if (knownSource) (p(a, target) + p(b, source)) - (p(a, source) + p(b, target))
        else p(a, target) - p(b, target)
    }

    /**
     * For a whole list: a line with a clear result is decided on its own; an unclear line follows the trend of the whole list
     * (the lists are written one way round, nearly always).
     */
    fun decide(diffs: List<Float>, clear: Float = 0.35f): List<Boolean> {
        if (diffs.isEmpty()) return emptyList()
        val trend = diffs.sum() / diffs.size
        return diffs.map { d -> if (d > clear) true else if (d < -clear) false else trend > 0.1f }
    }
}
