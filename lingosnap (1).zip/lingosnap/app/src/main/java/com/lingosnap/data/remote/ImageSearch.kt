package com.lingosnap.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class WebImage(val title: String, val url: String, val source: String)

/** Free encyclopedia pictures (Wikipedia, Wikimedia Commons) – no key needed. */
object ImageSearch {
    private val http = OkHttpClient.Builder()
        .callTimeout(20, TimeUnit.SECONDS)
        .build()
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private const val AGENT = "LingoSnap/1.0 (Android flashcard app)"

    private fun api(host: String, params: Map<String, String>): JsonObject {
        val url = "https://$host/w/api.php".toHttpUrl().newBuilder().apply {
            addQueryParameter("action", "query")
            addQueryParameter("format", "json")
            params.forEach { (k, v) -> addQueryParameter(k, v) }
        }.build()
        http.newCall(Request.Builder().url(url).header("User-Agent", AGENT).build()).execute().use { res ->
            if (!res.isSuccessful) error("HTTP ${res.code}")
            return json.parseToJsonElement(res.body?.string().orEmpty()).jsonObject
        }
    }

    /** Pictures for [query]: Wikipedia article pictures first (best match), then Commons files. */
    suspend fun search(query: String): List<WebImage> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext emptyList()
        val out = mutableListOf<WebImage>()
        runCatching {
            val pages = api(
                "de.wikipedia.org",
                mapOf(
                    "generator" to "search", "gsrsearch" to q, "gsrlimit" to "10",
                    "prop" to "pageimages", "piprop" to "thumbnail", "pithumbsize" to "800", "pilimit" to "10",
                ),
            )["query"]?.jsonObject?.get("pages")?.jsonObject.orEmpty()
            pages.values.map { it.jsonObject }
                .sortedBy { it["index"]?.jsonPrimitive?.intOrNull ?: 99 }
                .forEach { p ->
                    val src = p["thumbnail"]?.jsonObject?.get("source")?.jsonPrimitive?.contentOrNull ?: return@forEach
                    out += WebImage(p["title"]?.jsonPrimitive?.contentOrNull.orEmpty(), src, "Wikipedia")
                }
        }
        runCatching {
            val pages = api(
                "commons.wikimedia.org",
                mapOf(
                    "generator" to "search", "gsrnamespace" to "6", "gsrsearch" to q, "gsrlimit" to "12",
                    "prop" to "imageinfo", "iiprop" to "url|mime", "iiurlwidth" to "800",
                ),
            )["query"]?.jsonObject?.get("pages")?.jsonObject.orEmpty()
            pages.values.map { it.jsonObject }
                .sortedBy { it["index"]?.jsonPrimitive?.intOrNull ?: 99 }
                .forEach { p ->
                    val info = p["imageinfo"]?.jsonArray?.firstOrNull()?.jsonObject ?: return@forEach
                    val mime = info["mime"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    if (mime !in setOf("image/jpeg", "image/png", "image/svg+xml", "image/webp")) return@forEach
                    val src = info["thumburl"]?.jsonPrimitive?.contentOrNull ?: return@forEach
                    out += WebImage(p["title"]?.jsonPrimitive?.contentOrNull.orEmpty().removePrefix("File:"), src, "Wikimedia Commons")
                }
        }
        out.distinctBy { it.url }
    }

    suspend fun bytes(url: String): ByteArray? = withContext(Dispatchers.IO) {
        runCatching {
            http.newCall(Request.Builder().url(url).header("User-Agent", AGENT).build()).execute().use { res ->
                if (res.isSuccessful) res.body?.bytes() else null
            }
        }.getOrNull()
    }
}
