package com.lingosnap.ui.create

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.lingosnap.container
import com.lingosnap.data.remote.FrameBox
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import androidx.compose.material.icons.rounded.FlashAuto
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Full-screen in-app camera: live preview, tap to focus, pinch to zoom, flash modes and
 * several shots in one go. The photos are handed back as content URIs.
 */
@Composable
fun CameraDialog(hint: String = "", onDone: (List<Uri>) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    val shots = remember { mutableStateListOf<Uri>() }
    var confirmDiscard by remember { mutableStateOf(false) }

    fun close() {
        if (shots.isEmpty()) onClose() else confirmDiscard = true
    }

    Dialog(
        onDismissRequest = { close() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnClickOutside = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            var granted by remember {
                mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            }
            var asked by remember { mutableStateOf(false) }
            val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
                granted = it
                asked = true
            }
            LaunchedEffect(Unit) { if (!granted) permission.launch(Manifest.permission.CAMERA) }

            if (granted) {
                CameraContent(shots = shots, hint = hint, onClose = { close() }, onDone = { onDone(shots.toList()) })
            } else {
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Kamera-Zugriff nötig", color = Color.White, style = MaterialTheme.typography.titleLarge.bold())
                    Text(
                        "LingoSnap braucht die Kamera, um Seiten und Notizen zu fotografieren. Die Bilder bleiben auf deinem Gerät, bis du sie auswertest.",
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
                    )
                    Button(onClick = {
                        if (asked) {
                            context.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        } else permission.launch(Manifest.permission.CAMERA)
                    }) { Text(if (asked) "Einstellungen öffnen" else "Zugriff erlauben") }
                    TextButton(onClick = onClose) { Text("Abbrechen", color = Color.White) }
                }
            }

            if (confirmDiscard) {
                AlertDialog(
                    onDismissRequest = { confirmDiscard = false },
                    title = { Text("Aufnahmen verwerfen?") },
                    text = { Text("${shots.size} Aufnahmen wurden noch nicht ausgewertet.") },
                    confirmButton = {
                        TextButton(onClick = {
                            shots.forEach { deleteShot(context, it) }
                            shots.clear()
                            confirmDiscard = false
                            onClose()
                        }) { Text("Verwerfen") }
                    },
                    dismissButton = { TextButton(onClick = { confirmDiscard = false }) { Text("Weiter fotografieren") } },
                )
            }
        }
    }
}

@Composable
private fun CameraContent(shots: MutableList<Uri>, hint: String, onClose: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(ImageCapture.FLASH_MODE_AUTO)
            .build()
    }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var capturing by remember { mutableStateOf(false) }
    var focusAt by remember { mutableStateOf<androidx.compose.ui.geometry.Offset?>(null) }
    val focusAlpha = remember { Animatable(0f) }
    val shutterFlash = remember { Animatable(0f) }
    val gemini = context.container.gemini
    var aiOn by rememberSaveable { mutableStateOf(context.container.keyStore.apiKey != null) }
    var boxes by remember { mutableStateOf<List<FrameBox>>(emptyList()) }
    var aiTip by remember { mutableStateOf<String?>(null) }
    var aiNote by remember { mutableStateOf<String?>(null) }
    var localTip by remember { mutableStateOf<LocalTip?>(null) }
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    val boxAlpha = remember { Animatable(0f) }

    fun adjustExposure(delta: Int) {
        val cam = camera ?: return
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported) return
        val r = st.exposureCompensationRange
        cam.cameraControl.setExposureCompensationIndex((st.exposureCompensationIndex + delta).coerceIn(r.lower, r.upper))
        localTip = null
    }

    // free, instant exposure check on the preview itself
    LaunchedEffect(camera) {
        if (camera == null) return@LaunchedEffect
        while (true) {
            delay(900)
            val bmp = previewView.bitmap ?: continue
            val a = withContext(Dispatchers.Default) { analyse(bmp) }
            localTip = when {
                a.mean < 75f -> LocalTip("Zu dunkel. Mehr Licht oder Blitz an.", "Heller", 2)
                a.blown > 0.22f -> LocalTip("Überbelichtet oder Spiegelung. Winkel ändern oder abdunkeln.", "Dunkler", -2)
                else -> null
            }
        }
    }

    // the AI looks at the preview now and then: frames around useful material plus a tip
    LaunchedEffect(camera, aiOn) {
        boxes = emptyList(); aiTip = null; aiNote = null
        if (!aiOn || camera == null) return@LaunchedEffect
        var last: FloatArray? = null
        var fails = 0
        var runs = 0
        delay(1200)
        while (runs < 40 && fails < 3) {
            ensureActive()
            val bmp = previewView.bitmap
            if (bmp == null || capturing) { delay(700); continue }
            val a = withContext(Dispatchers.Default) { analyse(bmp) }
            val diff = last?.let { l -> a.sig.indices.sumOf { i -> kotlin.math.abs(a.sig[i] - l[i]).toDouble() }.toFloat() / a.sig.size } ?: 99f
            if (diff > 12f) boxes = emptyList()
            if (diff < 6f) { delay(1000); continue }
            last = a.sig
            val jpeg = withContext(Dispatchers.Default) { toJpeg(bmp, 640) }
            val r = gemini.analyzeFrame(jpeg, hint)
            ensureActive()
            val info = r.getOrNull()
            if (info != null) {
                boxes = info.boxes
                aiTip = info.tip
                fails = 0; runs++
                boxAlpha.snapTo(0f)
                boxAlpha.animateTo(1f, tween(250))
            } else fails++
            delay(3500)
        }
        if (fails >= 3) aiNote = "KI-Rahmen gerade nicht verfügbar"
        else if (runs >= 40) aiNote = "KI-Rahmen pausiert, um Anfragen zu sparen"
        boxes = emptyList()
    }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                p.unbindAll()
                camera = p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            } catch (e: Exception) {
                error = "Die Kamera konnte nicht gestartet werden."
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose { runCatching { provider?.unbindAll() } }
    }

    LaunchedEffect(flashMode) { imageCapture.flashMode = flashMode }

    fun capture() {
        if (capturing) return
        capturing = true
        val dir = File(context.cacheDir, "images").apply { mkdirs() }
        val file = File.createTempFile("scan_", ".jpg", dir)
        imageCapture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    shots.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                    capturing = false
                }

                override fun onError(exception: ImageCaptureException) {
                    file.delete()
                    capturing = false
                    error = "Das Foto konnte nicht gespeichert werden."
                }
            },
        )
    }

    LaunchedEffect(focusAt) {
        if (focusAt != null) {
            focusAlpha.snapTo(1f)
            focusAlpha.animateTo(0f, tween(900))
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        // top bar
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onClose,
                colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White),
            ) { Icon(Icons.Rounded.Close, "Schließen") }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Text(
                    if (shots.isEmpty()) "Seite fotografieren" else "${shots.size} ${if (shots.size == 1) "Aufnahme" else "Aufnahmen"}",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            IconButton(
                onClick = { aiOn = !aiOn },
                colors = IconButtonDefaults.iconButtonColors(contentColor = if (aiOn) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.55f)),
            ) { Icon(Icons.Rounded.AutoAwesome, "KI-Rahmen") }
            IconButton(
                onClick = {
                    flashMode = when (flashMode) {
                        ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                        ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                        else -> ImageCapture.FLASH_MODE_AUTO
                    }
                },
                colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White),
            ) {
                Icon(
                    when (flashMode) {
                        ImageCapture.FLASH_MODE_ON -> Icons.Rounded.FlashOn
                        ImageCapture.FLASH_MODE_OFF -> Icons.Rounded.FlashOff
                        else -> Icons.Rounded.FlashAuto
                    },
                    "Blitz",
                )
            }
        }

        // viewfinder
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .aspectRatio(3f / 4f, matchHeightConstraintsFirst = true)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF111111))
                    .onSizeChanged { viewSize = it }
                    .pointerInput(camera) {
                        detectTapGestures { offset ->
                            val cam = camera ?: return@detectTapGestures
                            focusAt = offset
                            val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                            cam.cameraControl.startFocusAndMetering(
                                FocusMeteringAction.Builder(point)
                                    .setAutoCancelDuration(3, TimeUnit.SECONDS)
                                    .build(),
                            )
                        }
                    }
                    .pointerInput(camera) {
                        detectTransformGestures { _, _, zoom, _ ->
                            val cam = camera ?: return@detectTransformGestures
                            val state = cam.cameraInfo.zoomState.value ?: return@detectTransformGestures
                            cam.cameraControl.setZoomRatio((state.zoomRatio * zoom).coerceIn(state.minZoomRatio, state.maxZoomRatio))
                        }
                    },
            ) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                focusAt?.let { p ->
                    Box(
                        Modifier
                            .offset { IntOffset((p.x - with(density) { 28.dp.toPx() }).roundToInt(), (p.y - with(density) { 28.dp.toPx() }).roundToInt()) }
                            .size(56.dp)
                            .scale(0.8f + 0.2f * focusAlpha.value)
                            .border(2.dp, Color.White.copy(alpha = focusAlpha.value), CircleShape),
                    )
                }
                val frameColor = MaterialTheme.colorScheme.primary
                if (viewSize.width > 0) boxes.forEach { b ->
                    Box(
                        Modifier
                            .offset { IntOffset((b.x * viewSize.width).roundToInt(), (b.y * viewSize.height).roundToInt()) }
                            .size(
                                with(density) { (b.w * viewSize.width).toDp() },
                                with(density) { (b.h * viewSize.height).toDp() },
                            )
                            .graphicsLayer { alpha = boxAlpha.value }
                            .background(frameColor.copy(alpha = 0.10f), RoundedCornerShape(10.dp))
                            .border(2.dp, frameColor, RoundedCornerShape(10.dp)),
                    ) {
                        if (b.label.isNotBlank()) {
                            Text(
                                b.label,
                                color = MaterialTheme.colorScheme.onPrimary,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.align(Alignment.TopStart).background(frameColor, RoundedCornerShape(bottomEnd = 8.dp, topStart = 8.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        }
                    }
                }
                Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = shutterFlash.value)))
                val tipText = localTip?.text ?: aiTip ?: aiNote
                if (tipText != null) {
                    Row(
                        Modifier.align(Alignment.BottomCenter).padding(12.dp)
                            .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(20.dp))
                            .padding(start = 14.dp, end = if (localTip != null) 4.dp else 14.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(tipText, color = Color.White, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f, fill = false))
                        localTip?.let { t -> TextButton(onClick = { adjustExposure(t.delta) }) { Text(t.action) } }
                    }
                }
                error?.let {
                    Text(
                        it,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    )
                }
            }
        }

        // thumbnails of what has been taken
        if (shots.isNotEmpty()) {
            LazyRow(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(shots.toList(), key = { it.toString() }) { uri ->
                    Thumb(uri) {
                        shots.remove(uri)
                        deleteShot(context, uri)
                    }
                }
            }
        }

        // shutter row
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f))
            val source = remember { MutableInteractionSource() }
            val pressed by source.collectIsPressedAsState()
            val inner by animateFloatAsState(if (pressed || capturing) 0.82f else 1f, tween(90), label = "shutter")
            Box(
                Modifier
                    .size(80.dp)
                    .border(4.dp, Color.White, CircleShape)
                    .padding(8.dp)
                    .scale(inner)
                    .clip(CircleShape)
                    .background(if (capturing) Color.White.copy(alpha = 0.6f) else Color.White)
                    .clickable(interactionSource = source, indication = null, enabled = camera != null && !capturing) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        capture()
                    },
            )
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                if (shots.isNotEmpty()) {
                    Button(onClick = onDone) { Text("Fertig (${shots.size})") }
                }
            }
        }
    }

    LaunchedEffect(capturing) {
        if (capturing) {
            shutterFlash.snapTo(0.7f)
            shutterFlash.animateTo(0f, tween(220))
        }
    }
}

@Composable
private fun Thumb(uri: Uri, onRemove: () -> Unit) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            }.getOrNull()
        }
    }
    Box(Modifier.size(width = 52.dp, height = 68.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF222222)).clickable(onClick = onRemove)) {
        bitmap?.let {
            Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(3.dp).size(18.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Close, "Entfernen", tint = Color.White, modifier = Modifier.size(12.dp)) }
    }
}

private fun deleteShot(context: android.content.Context, uri: Uri) {
    runCatching { uri.lastPathSegment?.let { File(File(context.cacheDir, "images"), it.substringAfterLast('/')).delete() } }
}

private class LocalTip(val text: String, val action: String, val delta: Int)

private class Analysis(val mean: Float, val blown: Float, val sig: FloatArray)

/** Brightness figures of a preview frame: mean, share of blown-out pixels, and an 8x8 brightness map to notice movement. */
private fun analyse(bmp: Bitmap): Analysis {
    val w = 32
    val h = 40
    val small = Bitmap.createScaledBitmap(bmp, w, h, true)
    val px = IntArray(w * h)
    small.getPixels(px, 0, w, 0, 0, w, h)
    var sum = 0.0
    var blown = 0
    val sig = FloatArray(64)
    val count = IntArray(64)
    for (i in px.indices) {
        val c = px[i]
        val l = 0.299 * ((c shr 16) and 255) + 0.587 * ((c shr 8) and 255) + 0.114 * (c and 255)
        sum += l
        if (l > 245) blown++
        val cell = ((i / w) * 8 / h) * 8 + (i % w) * 8 / w
        sig[cell] += l.toFloat()
        count[cell]++
    }
    for (i in sig.indices) if (count[i] > 0) sig[i] /= count[i]
    if (small !== bmp) small.recycle()
    return Analysis((sum / px.size).toFloat(), blown / px.size.toFloat(), sig)
}

private fun toJpeg(bmp: Bitmap, maxSide: Int): ByteArray {
    val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
    val src = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
    val out = java.io.ByteArrayOutputStream()
    src.compress(Bitmap.CompressFormat.JPEG, 70, out)
    return out.toByteArray()
}
