package com.lingosnap.ui.practice

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Flashcard
import com.lingosnap.ui.components.IconBadge
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.tr

/** A card in the lists below; [given] is what the learner answered (typing, multiple choice), [times] how often it went wrong. */
class ReportItem(val card: Flashcard, val given: String? = null, val times: Int = 1)

/**
 * What the "session over" screen shows besides the headline: right and wrong (as numbers), the time, the cards that went wrong
 * (with the answer given) and the cards that were known. Every learning mode fills what it knows; empty parts are not shown.
 */
class SessionReport(
    val total: Int,
    /** Cards that were right / wrong; -1 = the mode does not count that way. */
    val right: Int = -1,
    val wrong: Int = -1,
    val seconds: Int = 0,
    val missed: List<ReportItem> = emptyList(),
    val known: List<ReportItem> = emptyList(),
)

fun formatDuration(seconds: Int): String =
    if (seconds < 60) tr("{0} s", seconds) else tr("{0}:{1} min", seconds / 60, (seconds % 60).toString().padStart(2, '0'))

/** The statistic tiles under the ring that come from the report itself (time and pace). */
fun SessionReport.timeStats(unit: String = tr("Karte")): List<ResultStat> {
    if (seconds <= 0) return emptyList()
    val list = mutableListOf(ResultStat(Icons.Rounded.Timer, formatDuration(seconds)))
    if (total > 0) list += ResultStat(Icons.Rounded.Schedule, tr("Ø {0} s pro {1}", ((seconds.toFloat() / total) + 0.5f).toInt().coerceAtLeast(1), unit))
    return list
}

/** A list of cards, the first few open, the rest behind "show all". Missed cards show the answer that was given, if there is one. */
@Composable
fun CardListSection(title: String, items: List<ReportItem>, good: Boolean, startOpen: Boolean, modifier: Modifier = Modifier) {
    if (items.isEmpty()) return
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(startOpen) }
    var all by remember { mutableStateOf(false) }
    val list = if (all) items else items.take(10)
    Column(modifier.fillMaxWidth().animateContentSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("$title (${items.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, color = if (good) cs.primary else cs.error)
            Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = cs.onSurfaceVariant)
        }
        if (open) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                list.forEachIndexed { i, it ->
                    SegmentedItem(
                        index = i, count = list.size,
                        headline = it.card.source,
                        supporting = buildString {
                            append(it.card.target)
                            if (!it.given.isNullOrBlank() && !it.given.equals(it.card.target, true)) append("\n").append(tr("Deine Antwort: {0}", it.given))
                            else if (!good && it.times > 1) append("\n").append(tr("{0} mal falsch", it.times))
                        },
                        leading = {
                            if (good) IconBadge(Icons.Rounded.Check, 40, cs.primaryContainer, cs.onPrimaryContainer)
                            else IconBadge(Icons.Rounded.Close, 40, cs.errorContainer, cs.onErrorContainer)
                        },
                    )
                }
            }
            if (items.size > 10) Text(
                if (all) tr("Weniger anzeigen") else tr("Alle {0} anzeigen", items.size),
                Modifier.clickable { all = !all }.padding(horizontal = 8.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelLarge, color = cs.primary,
            )
        }
    }
}

/** Right/wrong report for the modes that only know that. */
fun simpleReport(total: Int, known: List<ReportItem>, missed: List<ReportItem>, seconds: Int): SessionReport =
    SessionReport(total = total, right = known.size, wrong = missed.size, seconds = seconds, missed = missed, known = known)

/** For the modes that only count. */
fun countReport(total: Int, correct: Int): SessionReport = SessionReport(total = total, right = correct, wrong = total - correct)
