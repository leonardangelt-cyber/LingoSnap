package com.lingosnap.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp

/** Pop-up menu in the app's look: big rounded corners, tonal surface, icons in front of every entry. */
@Composable
fun AppMenu(expanded: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 0.dp,
        shadowElevation = 8.dp,
        offset = DpOffset(0.dp, 4.dp),
        modifier = Modifier.padding(vertical = 2.dp),
        content = content,
    )
}

@Composable
fun AppMenuItem(text: String, icon: ImageVector, onClick: () -> Unit, supporting: String? = null, danger: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    DropdownMenuItem(
        text = {
            Column {
                Text(text, style = MaterialTheme.typography.bodyLarge)
                if (supporting != null) Text(supporting, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        },
        leadingIcon = { Icon(icon, null, tint = if (danger) cs.error else cs.primary) },
        onClick = onClick,
        colors = MenuDefaults.itemColors(textColor = if (danger) cs.error else cs.onSurface),
        modifier = Modifier.padding(horizontal = 6.dp).clip(RoundedCornerShape(16.dp)),
    )
}

@Composable
fun AppMenuDivider() {
    HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant)
}
