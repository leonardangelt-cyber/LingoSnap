package com.lingosnap.ui.practice

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Flashcard
import com.lingosnap.ui.mascot.Axolotl
import com.lingosnap.ui.mascot.Mood
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.tr

/** One small stat bubble: icon + text. */
class ResultStat(val icon: ImageVector, val text: String)

/**
 * The shared "session over" screen: the mascot, a ring with the share of right answers, stat chips with symbols,
 * the cards that went wrong, and the buttons. [ratio] < 0 hides the ring.
 */
@Composable
fun ColumnScope.ResultScreen(
    headline: String,
    detail: String,
    ratio: Float,
    stats: List<ResultStat>,
    wrong: List<Flashcard> = emptyList(),
    primaryLabel: String? = null,
    onPrimary: () -> Unit = {},
    doneLabel: String,
    onDone: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val shown by animateFloatAsState(if (go) ratio.coerceIn(0f, 1f) else 0f, tween(1100, easing = FastOutSlowInEasing), label = "ring")
    val mood = when {
        ratio < 0f -> Mood.Happy
        ratio >= 0.8f -> Mood.Happy
        ratio >= 0.4f -> Mood.Idle
        else -> Mood.Sad
    }
    Column(
        Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (ratio >= 0f) {
                val track = cs.secondaryContainer
                val bar = cs.primary
                Canvas(Modifier.size(200.dp)) {
                    val w = 16.dp.toPx()
                    val inset = w / 2
                    val s = Size(size.width - w, size.height - w)
                    drawArc(track, 0f, 360f, false, Offset(inset, inset), s, style = Stroke(w, cap = StrokeCap.Round))
                    if (shown > 0f) drawArc(bar, -90f, 360f * shown, false, Offset(inset, inset), s, style = Stroke(w, cap = StrokeCap.Round))
                }
            }
            Axolotl(Modifier.size(if (ratio >= 0f) 130.dp else 170.dp), mood = mood)
        }
        if (ratio >= 0f) Surface(shape = CircleShape, color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
            Text("${(shown * 100).toInt()} %", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.titleMedium.bold())
        }
        Text(headline, style = MaterialTheme.typography.headlineMedium.bold(), textAlign = TextAlign.Center)
        if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 12.dp))
        if (stats.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            stats.forEach { st ->
                Surface(shape = CircleShape, color = cs.surfaceContainerHigh) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(st.icon, null, Modifier.size(18.dp), tint = cs.primary)
                        Spacer(Modifier.width(6.dp))
                        Text(st.text, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
        if (wrong.isNotEmpty()) {
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = cs.errorContainer.copy(alpha = 0.45f)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Close, null, Modifier.size(18.dp), tint = cs.error)
                        Spacer(Modifier.width(6.dp))
                        Text(tr("Noch üben"), style = MaterialTheme.typography.titleSmall, color = cs.error)
                    }
                    wrong.take(8).forEach { c ->
                        Row {
                            Text(c.source, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium.bold(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(c.target, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End)
                        }
                    }
                    if (wrong.size > 8) Text(tr("… und {0} weitere", wrong.size - 8), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                }
            }
        }
    }
    if (primaryLabel != null) Button(onClick = onPrimary, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
        Icon(Icons.Rounded.Replay, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(primaryLabel)
    }
    if (primaryLabel != null) TextButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text(doneLabel) }
    else Button(onClick = onDone, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
        Icon(Icons.Rounded.Check, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(doneLabel)
    }
}

fun xpStat(xp: Int): ResultStat? = if (xp > 0) ResultStat(Icons.Rounded.Bolt, "+$xp XP") else null
fun streakStat(n: Int): ResultStat? = if (n >= 2) ResultStat(Icons.Rounded.LocalFireDepartment, tr("Serie {0}", n)) else null
