package com.lingosnap.data.remote

import com.lingosnap.util.VocabImport
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Reads the answer of the AI even if it is dirty. Three stages, as in the web app:
 *  1. clean + repair the JSON (code fences, cut-off end, trailing commas, control characters), map synonym field names
 *  2. regex: pick every single {...} object / "key": "value" pair that is still readable
 *  3. line and table parser (->, =>, -, :, =, ;, |, tab, markdown tables)
 */
object CardParser {
    private val json = Json { isLenient = true; ignoreUnknownKeys = true }

    fun parse(raw: String): List<VocabPair> {
        val text = stripFences(raw)
        if (text.isBlank()) return emptyList()
        stage1(text).let { if (it.isNotEmpty()) return finish(it) }
        stage2(text).let { if (it.isNotEmpty()) return finish(it) }
        // a single sentence ("Sorry, I cannot read this") is an answer, not a card
        if (text.lines().count { it.isNotBlank() } < 2) return emptyList()
        return finish(VocabImport.parse(text, "answer.txt"))
    }

    /** Cards that are already complete in a partial answer (used while the answer streams in). */
    fun objects(text: String): List<VocabPair> = stage2(text)

    /* ───── stage 1 ───── */

    internal fun stripFences(raw: String): String =
        raw.replace(Regex("```[a-zA-Z]*"), "").replace("```", "").trim()

    private fun repair(s: String): String =
        s.replace(Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F]"), "")
            .replace(Regex(",\\s*([}\\]])"), "$1")

    private fun stage1(text: String): List<VocabPair> {
        val a = text.indexOf('[')
        val o = text.indexOf('{')
        if (a < 0 && o < 0) return emptyList()
        val objectRoot = o >= 0 && (a < 0 || o < a)
        val start = if (objectRoot) o else a
        val close = if (objectRoot) '}' else ']'
        val end = text.lastIndexOf(close)
        val candidates = ArrayList<String>()
        if (end > start) candidates += text.substring(start, end + 1)
        // cut off at the end: keep everything up to the last complete object and close the brackets ourselves
        val lastObj = text.lastIndexOf('}')
        if (lastObj > start) {
            val head = text.substring(start, lastObj + 1)
            candidates += if (objectRoot) listOf("$head]}", "$head]", head) else listOf("$head]")
        }
        for (c in candidates) {
            val el = runCatching { json.parseToJsonElement(repair(c)) }.getOrNull() ?: continue
            val list = cards(el)
            if (list.isNotEmpty()) return list
        }
        return emptyList()
    }

    private fun cards(el: JsonElement): List<VocabPair> = when (el) {
        is JsonArray -> el.mapNotNull { VocabImport.pairOf(it) }
        is JsonObject -> {
            val arr = listOf("cards", "pairs", "vocabulary", "items", "data", "karten").firstNotNullOfOrNull { el[it] as? JsonArray }
                ?: (el.values.firstOrNull { it is JsonArray } as? JsonArray)
            if (arr != null) arr.mapNotNull { VocabImport.pairOf(it) } else listOfNotNull(VocabImport.pairOf(el))
        }
        else -> emptyList()
    }

    /* ───── stage 2 ───── */

    private val block = Regex("\\{[^{}]*\\}")
    private val kv = Regex("\"([A-Za-zäöüÄÖÜß_]+)\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")

    private fun stage2(text: String): List<VocabPair> = block.findAll(text).mapNotNull { m ->
        val strict = runCatching { VocabImport.pairOf(json.parseToJsonElement(repair(m.value))) }.getOrNull()
        strict ?: loose(m.value)
    }.toList()

    private fun loose(s: String): VocabPair? {
        val map = HashMap<String, String>()
        kv.findAll(s).forEach { map[it.groupValues[1].lowercase()] = unescape(it.groupValues[2]) }
        fun pick(names: List<String>) = names.firstNotNullOfOrNull { map[it]?.takeIf { v -> v.isNotBlank() } }
        val a = pick(VocabImport.frontKeys) ?: return null
        val b = pick(VocabImport.backKeys) ?: return null
        return VocabPair(a, b, pick(VocabImport.exampleKeys), lang = map["lang"]?.takeIf { it.length in 2..5 })
    }

    private fun unescape(s: String) = s.replace("\\\"", "\"").replace("\\n", " ").replace("\\t", " ").replace("\\\\", "\\")

    private fun finish(list: List<VocabPair>): List<VocabPair> = list
        .map { it.copy(source = it.source.trim(), target = it.target.trim(), example = it.example?.trim()?.takeIf { e -> e.isNotEmpty() }, image = null) }
        .filter { it.source.isNotEmpty() && it.target.isNotEmpty() }
        .distinctBy { it.source.lowercase() to it.target.lowercase() }
}
