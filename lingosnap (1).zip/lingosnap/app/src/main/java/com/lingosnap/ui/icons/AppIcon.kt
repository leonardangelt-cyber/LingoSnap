package com.lingosnap.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/**
 * LingoSnap's own symbol set. Every icon is drawn on a 24 grid with thick rounded strokes and a soft, see-through
 * fill ("duotone") in the spirit of Material 3 Expressive; they take the colour of the surrounding Icon tint.
 * kind 0 = outline only, 1 = solid, 2 = soft fill with outline.
 */
private fun icon(name: String, vararg layers: Pair<String, Int>): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
        for ((d, kind) in layers) {
            addPath(
                pathData = addPathNodes(d),
                fill = if (kind == 0) null else SolidColor(Color.Black),
                fillAlpha = if (kind == 2) 0.3f else 1f,
                stroke = if (kind == 1) null else SolidColor(Color.Black),
                strokeLineWidth = 2.4f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            )
        }
    }.build()

object AppIcon {
    val Add: ImageVector by lazy { icon("Add", "M12 5v14M5 12h14" to 0) }
    val Close: ImageVector by lazy { icon("Close", "M6 6l12 12M18 6L6 18" to 0) }
    val Check: ImageVector by lazy { icon("Check", "M5 12.5l4.5 4.5L19 7.5" to 0) }
    val Done: ImageVector by lazy { icon("Done", "M9.5 3.5h5a6 6 0 0 1 6 6v5a6 6 0 0 1 -6 6h-5a6 6 0 0 1 -6 -6v-5a6 6 0 0 1 6 -6Z" to 2, "M8 12.3l2.8 2.8L16.2 9" to 0) }
    val CheckCircle: ImageVector by lazy { icon("CheckCircle", "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0Z" to 2, "M8 12.5l3 3 5-6" to 0) }
    val ErrorOutline: ImageVector by lazy { icon("ErrorOutline", "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0Z" to 2, "M12 7.5v5.5" to 0, "M10.8 16.6a1.2 1.2 0 1 0 2.4 0a1.2 1.2 0 1 0 -2.4 0Z" to 1) }
    val WarningAmber: ImageVector by lazy { icon("WarningAmber", "M12 4l9 15.5H3Z" to 2, "M12 10v4.2" to 0, "M10.9 17a1.1 1.1 0 1 0 2.2 0a1.1 1.1 0 1 0 -2.2 0Z" to 1) }
    val ArrowBack: ImageVector by lazy { icon("ArrowBack", "M19 12H5M11 6l-6 6 6 6" to 0) }
    val ArrowForward: ImageVector by lazy { icon("ArrowForward", "M5 12h14M13 6l6 6-6 6" to 0) }
    val KeyboardArrowRight: ImageVector by lazy { icon("KeyboardArrowRight", "M9.5 6l6 6-6 6" to 0) }
    val KeyboardArrowDown: ImageVector by lazy { icon("KeyboardArrowDown", "M6 9.5l6 6 6-6" to 0) }
    val MoreVert: ImageVector by lazy { icon("MoreVert", "M10.1 5.5a1.9 1.9 0 1 0 3.8 0a1.9 1.9 0 1 0 -3.8 0Z" to 1, "M10.1 12a1.9 1.9 0 1 0 3.8 0a1.9 1.9 0 1 0 -3.8 0Z" to 1, "M10.1 18.5a1.9 1.9 0 1 0 3.8 0a1.9 1.9 0 1 0 -3.8 0Z" to 1) }
    val Search: ImageVector by lazy { icon("Search", "M4.0 10.5a6.5 6.5 0 1 0 13.0 0a6.5 6.5 0 1 0 -13.0 0Z" to 2, "M15.5 15.5L20 20" to 0) }
    val Edit: ImageVector by lazy { icon("Edit", "M4.5 19.5l1-4.2L16 4.8a2.1 2.1 0 013 3L8.7 18.5Z" to 2, "M13.8 7.2l3 3" to 0) }
    val EditNote: ImageVector by lazy { icon("EditNote", "M8.0 4h8.0a4.5 4.5 0 0 1 4.5 4.5v7.0a4.5 4.5 0 0 1 -4.5 4.5h-8.0a4.5 4.5 0 0 1 -4.5 -4.5v-7.0a4.5 4.5 0 0 1 4.5 -4.5Z" to 2, "M8 9.5h8M8 13.5h4" to 0) }
    val Delete: ImageVector by lazy { icon("Delete", "M6 8h12l-1 11.2a2 2 0 01-2 1.8H9a2 2 0 01-2-1.8Z" to 2, "M4.5 8h15M9.5 8V5.5A1.5 1.5 0 0111 4h2a1.5 1.5 0 011.5 1.5V8" to 0, "M10 12v5M14 12v5" to 0) }
    val DeleteForever: ImageVector by lazy { icon("DeleteForever", "M6 8h12l-1 11.2a2 2 0 01-2 1.8H9a2 2 0 01-2-1.8Z" to 2, "M4.5 8h15M9.5 8V5.5A1.5 1.5 0 0111 4h2a1.5 1.5 0 011.5 1.5V8" to 0, "M10 12.5l4 4M14 12.5l-4 4" to 0) }
    val Save: ImageVector by lazy { icon("Save", "M8.0 3.5h8.0a4.5 4.5 0 0 1 4.5 4.5v8.0a4.5 4.5 0 0 1 -4.5 4.5h-8.0a4.5 4.5 0 0 1 -4.5 -4.5v-8.0a4.5 4.5 0 0 1 4.5 -4.5Z" to 2, "M7.5 3.5v5h7v-5M7.5 20.5v-6h9v6" to 0) }
    val Share: ImageVector by lazy { icon("Share", "M3.4 12a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" to 1, "M14.9 6a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" to 1, "M14.9 18a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" to 1, "M8.3 10.8l7-3.6M8.3 13.2l7 3.6" to 0) }
    val FileDownload: ImageVector by lazy { icon("FileDownload", "M12 4v11M7.5 10.5L12 15l4.5-4.5M5 19.5h14" to 0) }
    val UploadFile: ImageVector by lazy { icon("UploadFile", "M6.5 3.5h7l5 5V19a1.5 1.5 0 01-1.5 1.5h-10.5A1.5 1.5 0 015 19V5a1.5 1.5 0 011.5-1.5Z" to 2, "M12 17v-6M9.2 13.4L12 10.6l2.8 2.8" to 0) }
    val CloudUpload: ImageVector by lazy { icon("CloudUpload", "M7 18.5a4.5 4.5 0 01-.6-8.96A6 6 0 0117.8 9.4 4.6 4.6 0 0117 18.5Z" to 2, "M12 16v-5M9.8 12.8L12 10.6l2.2 2.2" to 0) }
    val Sync: ImageVector by lazy { icon("Sync", "M19.5 12a7.5 7.5 0 00-13-5.1M4.5 12a7.5 7.5 0 0013 5.1M6.5 3.5v3.8h3.8M17.5 20.5v-3.8h-3.8" to 0) }
    val Replay: ImageVector by lazy { icon("Replay", "M5.5 12a6.5 6.5 0 106.5-6.5H8M10.5 2.8L7.8 5.5l2.7 2.7" to 0) }
    val Shuffle: ImageVector by lazy { icon("Shuffle", "M3.5 7h3c4.5 0 5 10 9.5 10h4.5M3.5 17h3c1.4 0 2.4-.8 3.2-2.1M13.8 9.1c.8-1.3 1.8-2.1 3-2.1h3.7M18 4.5l2.5 2.5-2.5 2.5M18 14.5l2.5 2.5-2.5 2.5" to 0) }
    val SwapHoriz: ImageVector by lazy { icon("SwapHoriz", "M4.5 8.5h14M15 5l3.5 3.5L15 12M19.5 15.5h-14M9 12l-3.5 3.5L9 19" to 0) }
    val Translate: ImageVector by lazy { icon("Translate", "M5.7 3h4.6a3.2 3.2 0 0 1 3.2 3.2v3.0999999999999996a3.2 3.2 0 0 1 -3.2 3.2h-4.6a3.2 3.2 0 0 1 -3.2 -3.2v-3.0999999999999996a3.2 3.2 0 0 1 3.2 -3.2Z" to 2, "M5.7 9.8l2.3-4.6 2.3 4.6M6.5 8.4h3" to 0, "M13.7 11.5h4.6a3.2 3.2 0 0 1 3.2 3.2v3.0999999999999996a3.2 3.2 0 0 1 -3.2 3.2h-4.6a3.2 3.2 0 0 1 -3.2 -3.2v-3.0999999999999996a3.2 3.2 0 0 1 3.2 -3.2Z" to 2, "M14 16.3h4M16 14.7v1.3c0 1.3-.7 2-1.6 2.4" to 0) }
    val Style: ImageVector by lazy { icon("Style", "M8.5 4.5h8.5A2.5 2.5 0 0119.5 7v8.5" to 0, "M7.5 7.5h5.5a3.5 3.5 0 0 1 3.5 3.5v6.0a3.5 3.5 0 0 1 -3.5 3.5h-5.5a3.5 3.5 0 0 1 -3.5 -3.5v-6.0a3.5 3.5 0 0 1 3.5 -3.5Z" to 2) }
    val School: ImageVector by lazy { icon("School", "M12 4L2.5 9l9.5 5 9.5-5Z" to 2, "M6.5 11.8V16c0 1.4 2.5 3 5.5 3s5.5-1.6 5.5-3v-4.2M21.5 9v5.5" to 0) }
    val Quiz: ImageVector by lazy { icon("Quiz", "M9.0 3.5h6.0a5.5 5.5 0 0 1 5.5 5.5v6.0a5.5 5.5 0 0 1 -5.5 5.5h-6.0a5.5 5.5 0 0 1 -5.5 -5.5v-6.0a5.5 5.5 0 0 1 5.5 -5.5Z" to 2, "M9.6 9.6a2.4 2.4 0 114 1.8c-.9.7-1.6 1.1-1.6 2.3" to 0, "M10.8 16.9a1.2 1.2 0 1 0 2.4 0a1.2 1.2 0 1 0 -2.4 0Z" to 1) }
    val Psychology: ImageVector by lazy { icon("Psychology", "M8 20v-3.2C5.7 15.5 4.5 13.4 4.5 11a7.5 7.5 0 0115 0c0 2-.9 3.4-2.5 4.4V20Z" to 2, "M12 8.2a2.5 2.5 0 11-2.4 3.2" to 0) }
    val Person: ImageVector by lazy { icon("Person", "M8.3 8.2a3.7 3.7 0 1 0 7.4 0a3.7 3.7 0 1 0 -7.4 0Z" to 2, "M4.5 20a7.5 6 0 0115 0Z" to 2) }
    val Mic: ImageVector by lazy { icon("Mic", "M12 3h0a3 3 0 0 1 3 3v5a3 3 0 0 1 -3 3h0a3 3 0 0 1 -3 -3v-5a3 3 0 0 1 3 -3Z" to 2, "M5.5 11.5a6.5 6.5 0 0013 0M12 18v3M9 21h6" to 0) }
    val Lightbulb: ImageVector by lazy { icon("Lightbulb", "M12 3.5a6 6 0 00-3.4 10.9c.6.5.9 1.1.9 1.8v.3h5v-.3c0-.7.3-1.3.9-1.8A6 6 0 0012 3.5Z" to 2, "M9.8 19h4.4M10.6 21h2.8" to 0) }
    val Keyboard: ImageVector by lazy { icon("Keyboard", "M6.0 6h12.0a3.5 3.5 0 0 1 3.5 3.5v5.0a3.5 3.5 0 0 1 -3.5 3.5h-12.0a3.5 3.5 0 0 1 -3.5 -3.5v-5.0a3.5 3.5 0 0 1 3.5 -3.5Z" to 2, "M6.1 10.3a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0Z" to 1, "M9.799999999999999 10.3a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0Z" to 1, "M13.4 10.3a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0Z" to 1, "M16.6 10.3a0.9 0.9 0 1 0 1.8 0a0.9 0.9 0 1 0 -1.8 0Z" to 1, "M8 14.5h8" to 0) }
    val Key: ImageVector by lazy { icon("Key", "M3.7 15.5a4.3 4.3 0 1 0 8.6 0a4.3 4.3 0 1 0 -8.6 0Z" to 2, "M11.2 12.3L20 3.5M16.5 7l3 3" to 0) }
    val Image: ImageVector by lazy { icon("Image", "M7 4.5h10a4 4 0 0 1 4 4v7a4 4 0 0 1 -4 4h-10a4 4 0 0 1 -4 -4v-7a4 4 0 0 1 4 -4Z" to 2, "M6.8 9.5a1.7 1.7 0 1 0 3.4 0a1.7 1.7 0 1 0 -3.4 0Z" to 1, "M3.5 17l5-4.8 4 3.6 3-2.6 5 4.3" to 0) }
    val Folder: ImageVector by lazy { icon("Folder", "M3.5 7.5a2.5 2.5 0 012.5-2.5h3.6l2.2 2.5H18a2.5 2.5 0 012.5 2.5v7.5a2.5 2.5 0 01-2.5 2.5H6a2.5 2.5 0 01-2.5-2.5Z" to 2) }
    val DriveFileMove: ImageVector by lazy { icon("DriveFileMove", "M3.5 7.5a2.5 2.5 0 012.5-2.5h3.6l2.2 2.5H18a2.5 2.5 0 012.5 2.5v7.5a2.5 2.5 0 01-2.5 2.5H6a2.5 2.5 0 01-2.5-2.5Z" to 2, "M9 13h6M12.5 10.5l2.5 2.5-2.5 2.5" to 0) }
    val CallMerge: ImageVector by lazy { icon("CallMerge", "M6 4v3.5c0 3 2.5 5 6 5M18 4v3.5c0 3-2.5 5-6 5M12 12.5V20M9 17l3 3 3-3" to 0) }
    val Visibility: ImageVector by lazy { icon("Visibility", "M2.8 12C4.7 8 8 6 12 6s7.3 2 9.2 6c-1.9 4-5.2 6-9.2 6s-7.3-2-9.2-6Z" to 2, "M9.4 12a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" to 1) }
    val VisibilityOff: ImageVector by lazy { icon("VisibilityOff", "M2.8 12C4.7 8 8 6 12 6s7.3 2 9.2 6c-1.9 4-5.2 6-9.2 6s-7.3-2-9.2-6Z" to 2, "M4 4l16 16" to 0) }
    val Settings: ImageVector by lazy { icon("Settings", "M12 3.5l1.6 2.2 2.7-.5.9 2.6 2.4 1.3-.8 2.7.8 2.7-2.4 1.3-.9 2.6-2.7-.5L12 20.5l-1.6-2.2-2.7.5-.9-2.6-2.4-1.3.8-2.7-.8-2.7 2.4-1.3.9-2.6 2.7.5Z" to 2, "M9.2 12a2.8 2.8 0 1 0 5.6 0a2.8 2.8 0 1 0 -5.6 0Z" to 0) }
    val Schedule: ImageVector by lazy { icon("Schedule", "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0Z" to 2, "M12 7.5V12l3 2" to 0) }
    val Palette: ImageVector by lazy { icon("Palette", "M12 3.5a8.5 8.5 0 100 17c1.4 0 2-1 1.5-2-.6-1.2.1-2.5 1.5-2.5h2a2.5 2.5 0 002.5-2.5C20 7 16.4 3.5 12 3.5Z" to 2, "M6.5 11.5a1.3 1.3 0 1 0 2.6 0a1.3 1.3 0 1 0 -2.6 0Z" to 1, "M9.2 7.6a1.3 1.3 0 1 0 2.6 0a1.3 1.3 0 1 0 -2.6 0Z" to 1, "M13.7 7.8a1.3 1.3 0 1 0 2.6 0a1.3 1.3 0 1 0 -2.6 0Z" to 1) }
    val Notifications: ImageVector by lazy { icon("Notifications", "M12 3.5a5.5 5.5 0 00-5.5 5.5v3.2L4.8 15.5c-.5.9.1 2 1.2 2h12c1.1 0 1.7-1.1 1.2-2l-1.7-3.3V9A5.5 5.5 0 0012 3.5Z" to 2, "M9.8 20.2a2.4 2.4 0 004.4 0" to 0) }
    val Lock: ImageVector by lazy { icon("Lock", "M8.0 10.5h8.0a3.5 3.5 0 0 1 3.5 3.5v3.0a3.5 3.5 0 0 1 -3.5 3.5h-8.0a3.5 3.5 0 0 1 -3.5 -3.5v-3.0a3.5 3.5 0 0 1 3.5 -3.5Z" to 2, "M8 10.5V8a4 4 0 018 0v2.5" to 0, "M10.6 15.5a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0Z" to 1) }
    val LocalFireDepartment: ImageVector by lazy { icon("LocalFireDepartment", "M12 3c.5 3 3.5 4.6 4.8 7.3 1.4 3 .4 7.2-2.8 9.2a5.6 5.6 0 01-6.9-.6C5.2 17.3 5 14.5 6.5 12c.3 1.4 1.2 2.3 2.2 2.6C8 10.5 9.5 5.5 12 3Z" to 2) }
    val Link: ImageVector by lazy { icon("Link", "M10 14a3.8 3.8 0 005.4 0l3-3a3.8 3.8 0 00-5.4-5.4l-1 1M14 10a3.8 3.8 0 00-5.4 0l-3 3a3.8 3.8 0 005.4 5.4l1-1" to 0) }
    val Layers: ImageVector by lazy { icon("Layers", "M12 3.5l9 5-9 5-9-5Z" to 2, "M3.5 12.5l8.5 4.7 8.5-4.7M3.5 16.5l8.5 4.7 8.5-4.7" to 0) }
    val Language: ImageVector by lazy { icon("Language", "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0Z" to 2, "M3 12h18M12 3c2.5 2.5 3.8 5.5 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.5-3.8-9S9.5 5.5 12 3Z" to 0) }
    val FormatQuote: ImageVector by lazy { icon("FormatQuote", "M4 11.5C4 8.5 5.8 6.7 8.5 6.2l.5 1.7c-1.3.4-2 1.2-2.1 2.2H9.2V16H4ZM13.5 11.5c0-3 1.8-4.8 4.5-5.3l.5 1.7c-1.3.4-2 1.2-2.1 2.2h2.3V16h-5.2Z" to 1) }
    val FlashOn: ImageVector by lazy { icon("FlashOn", "M13 3L6 13.5h5l-1 7.5 8-10.5h-5.2Z" to 2) }
    val Bolt: ImageVector by lazy { icon("Bolt", "M13.5 2.8L5.5 13.5h5.2L9.5 21.2l9-11.2h-5.5Z" to 2) }
    val FlashOff: ImageVector by lazy { icon("FlashOff", "M13 3L6 13.5h5l-1 7.5 8-10.5h-5.2Z" to 2, "M4 4l16 16" to 0) }
    val FlashAuto: ImageVector by lazy { icon("FlashAuto", "M10 3L4 12.5h4l-.8 6.5 6.8-8.5H9.8Z" to 2, "M16.5 15.5l2-5 2 5M17.2 14h2.6" to 0) }
    val Flag: ImageVector by lazy { icon("Flag", "M5.5 4v17" to 0, "M5.5 5h12l-2.5 3.8 2.5 3.7h-12Z" to 2) }
    val EmojiEvents: ImageVector by lazy { icon("EmojiEvents", "M7.5 4h9v5.5a4.5 4.5 0 01-9 0Z" to 2, "M7.5 6H4.5v1.5A3.5 3.5 0 007.8 11M16.5 6h3v1.5a3.5 3.5 0 01-3.3 3.5M12 14v4M8.5 20.5h7M10 18h4" to 0) }
    val AutoAwesome: ImageVector by lazy { icon("AutoAwesome", "M10 3.5l1.9 5.1 5.1 1.9-5.1 1.9L10 17.5l-1.9-5.1L3 10.5l5.1-1.9Z" to 2, "M18 13.5l.9 2.2 2.2.9-2.2.9-.9 2.2-.9-2.2-2.2-.9 2.2-.9Z" to 1) }
    val VolumeUp: ImageVector by lazy { icon("VolumeUp", "M4 9.5h3.2L11.5 5.5v13L7.2 14.5H4Z" to 2, "M15 9.2a4 4 0 010 5.6M17.6 6.6a7.5 7.5 0 010 10.8" to 0) }
    val CameraAlt: ImageVector by lazy { icon("CameraAlt", "M3.5 8.5A2.5 2.5 0 016 6h1.6l1.2-2h5.4l1.2 2H18a2.5 2.5 0 012.5 2.5v9A2.5 2.5 0 0118 20H6a2.5 2.5 0 01-2.5-2.5Z" to 2, "M8.7 13a3.3 3.3 0 1 0 6.6 0a3.3 3.3 0 1 0 -6.6 0Z" to 0) }
    val ContentPaste: ImageVector by lazy { icon("ContentPaste", "M8.5 4.5h7.0a3.5 3.5 0 0 1 3.5 3.5v9.0a3.5 3.5 0 0 1 -3.5 3.5h-7.0a3.5 3.5 0 0 1 -3.5 -3.5v-9.0a3.5 3.5 0 0 1 3.5 -3.5Z" to 2, "M10.6 2.8h2.8a1.6 1.6 0 0 1 1.6 1.6v0.3999999999999999a1.6 1.6 0 0 1 -1.6 1.6h-2.8a1.6 1.6 0 0 1 -1.6 -1.6v-0.3999999999999999a1.6 1.6 0 0 1 1.6 -1.6Z" to 1, "M8.5 11h7M8.5 14.5h5" to 0) }
}
