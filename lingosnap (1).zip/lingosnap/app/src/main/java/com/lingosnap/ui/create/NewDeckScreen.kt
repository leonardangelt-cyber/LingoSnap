package com.lingosnap.ui.create

import com.lingosnap.util.tr

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.lingosnap.ui.components.OptionSheet
import androidx.compose.material.icons.rounded.ExpandMore
import com.lingosnap.ui.components.SegmentedItem
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.Surface
import androidx.compose.material3.RadioButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Style
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/**
 * One page: kind of deck, optional name, languages – and the way to fill it. Every start button creates the deck and
 * jumps straight into that way (photo, AI, typing), so there is no extra menu in between. No name: the AI picks one
 * once the first cards are there.
 */
@Composable
fun NewDeckScreen(onCreated: (id: Long, method: Int) -> Unit, onBack: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    var languageDeck by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "en")
    }
    var busy by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    fun create(method: Int) {
        if (busy) return
        busy = true
        scope.launch {
            val finalName = name.trim().ifBlank { DEFAULT_DECK_NAME }
            val id = if (languageDeck) repo.createDeck(finalName, null, source, target, "")
            else repo.createDeck(finalName, null, "", "", subject, kind = "cards")
            onCreated(id, method)
        }
    }

    LargeScreen(
        title = tr("Neues Deck"),
        onBack = onBack,
    ) { inner ->
        Column(
            Modifier.padding(inner).verticalScroll(rememberScrollState()).navigationBarsPadding().imePadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // 1) what kind of deck: two big choice cards
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                KindCard(
                    selected = languageDeck, icon = Icons.Rounded.Translate, title = tr("Sprache lernen"),
                    desc = tr("Vokabeln mit Wort, Übersetzung, Beispielsatz und Vorlesen"),
                    modifier = Modifier.weight(1f),
                ) { languageDeck = true }
                KindCard(
                    selected = !languageDeck, icon = Icons.Rounded.Style, title = tr("Karteikarten"),
                    desc = tr("Frage und Antwort zu jedem anderen Thema, auch mit Bildern"),
                    modifier = Modifier.weight(1f),
                ) { languageDeck = false }
            }

            // 2) languages or subject, in one soft card
            Surface(shape = RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (languageDeck) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LanguageField(tr("Ich lerne"), source, Modifier.weight(1f), allowAuto = true) { source = it }
                            FilledTonalIconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                                Icon(Icons.Rounded.SwapHoriz, tr("Tauschen"))
                            }
                            LanguageField(tr("Meine Sprache"), target, Modifier.weight(1f)) { target = it }
                        }
                        if (source == "auto") {
                            Text(
                                tr("Bei „Automatisch“ erkennt die KI die Sprache jedes Worts selbst und übersetzt fehlende Übersetzungen in deine Zielsprache."),
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                            )
                        }
                    } else {
                        AppTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text(tr("Worum geht es? (hilft der KI)")) },
                            placeholder = { Text(tr("z. B. Biologie Klasse 9, Zellaufbau")) },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    AppTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(tr("Name des Decks (optional)")) },
                        placeholder = { Text(tr("Leer lassen: die KI findet einen Namen")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            // 3) how to fill it: the tiles are the buttons, one tap creates the deck and starts
            Text(tr("Womit möchtest du starten?"), style = MaterialTheme.typography.titleMedium.bold(), modifier = Modifier.padding(start = 4.dp, top = 4.dp))
            MethodTile(
                icon = Icons.Rounded.CameraAlt, title = tr("Foto oder Datei scannen"), desc = tr("Kamera, Bild, PDF, Word oder PowerPoint"),
                container = cs.primary, onContainer = cs.onPrimary, badge = cs.onPrimary.copy(alpha = 0.18f), enabled = !busy, big = true,
            ) { create(1) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MethodTile(
                    icon = Icons.Rounded.AutoAwesome, title = tr("Mit KI erzeugen"), desc = tr("Thema eingeben, Karten generieren lassen"),
                    container = cs.tertiaryContainer, onContainer = cs.onTertiaryContainer, badge = cs.tertiary, badgeOn = cs.onTertiary,
                    enabled = !busy, modifier = Modifier.weight(1f),
                ) { create(2) }
                MethodTile(
                    icon = Icons.Rounded.Edit, title = tr("Selbst eintippen"), desc = tr("Einzeln oder als Liste einfügen"),
                    container = cs.secondaryContainer, onContainer = cs.onSecondaryContainer, badge = cs.secondary, badgeOn = cs.onSecondary,
                    enabled = !busy, modifier = Modifier.weight(1f),
                ) { create(0) }
            }
            androidx.compose.material3.TextButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = !busy,
                onClick = { create(-2) },
            ) { Text(tr("Leeres Deck erstellen")) }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
/** One of the two big "what do you want to learn" cards. */
@Composable
private fun KindCard(selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val container = if (selected) cs.primaryContainer else cs.surfaceContainerHigh
    val onContainer = if (selected) cs.onPrimaryContainer else cs.onSurface
    Surface(
        onClick = onClick, shape = RoundedCornerShape(28.dp), color = container, contentColor = onContainer,
        border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, cs.primary) else null,
        modifier = modifier,
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                com.lingosnap.ui.components.IconBadge(icon, size = 44, container = if (selected) cs.primary else cs.secondaryContainer, content = if (selected) cs.onPrimary else cs.onSecondaryContainer)
                Spacer(Modifier.weight(1f))
                if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = cs.primary)
            }
            Text(title, style = MaterialTheme.typography.titleMedium.bold())
            Text(desc, style = MaterialTheme.typography.bodySmall, color = if (selected) onContainer.copy(alpha = 0.8f) else cs.onSurfaceVariant)
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
/** A big, colourful tile: tapping it creates the deck and jumps into that way of filling it. */
@Composable
private fun MethodTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String,
    container: androidx.compose.ui.graphics.Color, onContainer: androidx.compose.ui.graphics.Color,
    badge: androidx.compose.ui.graphics.Color, badgeOn: androidx.compose.ui.graphics.Color = onContainer,
    enabled: Boolean, modifier: Modifier = Modifier.fillMaxWidth(), big: Boolean = false, onClick: () -> Unit,
) {
    Surface(
        onClick = onClick, enabled = enabled, shape = RoundedCornerShape(32.dp), color = container, contentColor = onContainer,
        modifier = modifier,
    ) {
        if (big) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                com.lingosnap.ui.components.IconBadge(icon, size = 56, container = badge, content = badgeOn)
                Spacer(Modifier.size(16.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge.bold())
                    Text(desc, style = MaterialTheme.typography.bodyMedium, color = onContainer.copy(alpha = 0.85f))
                }
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, null)
            }
        } else {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                com.lingosnap.ui.components.IconBadge(icon, size = 48, container = badge, content = badgeOn)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium.bold())
                    Text(desc, style = MaterialTheme.typography.bodySmall, color = onContainer.copy(alpha = 0.8f))
                }
            }
        }
    }
}

@Composable
internal fun LanguageField(label: String, value: String, modifier: Modifier = Modifier, allowAuto: Boolean = false, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        AppTextField(
            value = if (value == "auto") tr("Automatisch") else languageName(value),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable { open = true })
    }
    if (open) {
        OptionSheet(
            title = label,
            options = (if (allowAuto) listOf("auto" to tr("Automatisch")) else emptyList()) + SupportedLanguages.map { it.tag to it.label },
            selected = value,
            onPick = { onPick(it); open = false },
            onDismiss = { open = false },
        )
    }
}
