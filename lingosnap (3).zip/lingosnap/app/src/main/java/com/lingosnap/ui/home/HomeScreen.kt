package com.lingosnap.ui.home

import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.rounded.FileDownload
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import androidx.compose.ui.Alignment
import androidx.compose.material3.Surface
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import com.lingosnap.ui.components.LearnMethodSheet
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.data.model.languageName
import com.lingosnap.data.model.typeLabelFor
import com.lingosnap.container
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.rounded.School
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenDeck: (Long) -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onCreate: (language: Boolean) -> Unit,
    onSettings: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    var deckToDelete by remember { mutableStateOf<Deck?>(null) }
    var deckToFolder by remember { mutableStateOf<Deck?>(null) }
    var method by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var parsed by remember { mutableStateOf<com.lingosnap.util.ParsedImport?>(null) }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { com.lingosnap.util.ImportParsers.parse(ctx, uri) }
                .onSuccess { parsed = it }
                .onFailure { Toast.makeText(ctx, it.message ?: tr("Datei konnte nicht gelesen werden"), Toast.LENGTH_LONG).show() }
        }
    }
    val feedback = LocalContext.current.container.feedback
    var learnMode by remember { mutableStateOf(feedback.learnMode) }

    var importMenu by remember { mutableStateOf(false) }
    val incoming by com.lingosnap.util.PendingImport.state.collectAsStateWithLifecycle()
    androidx.compose.runtime.LaunchedEffect(incoming) {
        incoming?.let { parsed = it; com.lingosnap.util.PendingImport.state.value = null }
    }
    var searching by remember { mutableStateOf(false) }
    var addMenu by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val pager = androidx.compose.foundation.pager.rememberPagerState { 2 }
    val tab = pager.currentPage
    val jobs by com.lingosnap.util.AiJobs.state.collectAsStateWithLifecycle()

    LargeScreen(
        title = tr("Decks"),
        actions = {
            IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, if (searching) tr("Suche schließen") else tr("Suchen"))
            }
            Box {
                IconButton(onClick = { importMenu = true }) { Icon(Icons.Rounded.FileDownload, tr("Importieren")) }
                com.lingosnap.ui.components.AppMenu(expanded = importMenu, onDismiss = { importMenu = false }) {
                    com.lingosnap.ui.components.AppMenuItem(tr("Datei wählen"), Icons.Rounded.UploadFile, supporting = tr("Backup, CSV, Anki, Quizlet"), onClick = { importMenu = false; importPicker.launch(com.lingosnap.util.ImportParsers.MIME_TYPES) })
                    com.lingosnap.ui.components.AppMenuItem(tr("Link aus Zwischenablage"), Icons.Rounded.ContentPaste, onClick = {
                        importMenu = false
                        val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                        val found = com.lingosnap.util.DeckLink.decode(text)
                        if (found != null) parsed = found
                        else Toast.makeText(ctx, tr("In der Zwischenablage ist kein LingoSnap-Link."), Toast.LENGTH_LONG).show()
                    })
                }
            }
            IconButton(onClick = { method = true }) { Icon(Icons.Rounded.School, tr("Lernmethode")) }
            IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, tr("Optionen")) }
        },
        floatingActionButton = {
            androidx.compose.material3.FloatingActionButton(onClick = { addMenu = true }) {
                Icon(Icons.Rounded.Add, tr("Neues Deck"))
            }
        },
    ) { inner ->
        Column(Modifier.padding(inner)) {
            if (searching) com.lingosnap.ui.components.AppTextField(
                query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text(tr("Deck, Wort oder Übersetzung suchen")) }, singleLine = true,
            )
            HomeTabs(
                labels = listOf(tr("Vokabeln"), tr("Lernkarten")),
                counts = listOf(state.decks.count { it.isLanguage }, state.decks.count { !it.isLanguage }),
                icons = listOf(Icons.Rounded.Translate, Icons.Rounded.Style),
                position = pager.currentPage + pager.currentPageOffsetFraction,
                onSelect = { scope.launch { pager.animateScrollToPage(it) } },
            )
            androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.weight(1f)) { page ->
            val q = query.trim()
            val shownDecks = state.decks.filter { if (page == 0) it.isLanguage else !it.isLanguage }.filter { d ->
                q.isEmpty() || d.name.contains(q, true) || state.cardsOf(d.id).any { it.source.contains(q, true) || it.target.contains(q, true) }
            }
            // language decks grouped by the language they teach
    val groups = remember(shownDecks, state.cards) {
        val withLabel = shownDecks.map { d ->
            val label = when {
                !d.isLanguage -> state.groups.firstOrNull { it.id == d.groupId }?.name ?: NO_FOLDER
                d.sourceLang != "auto" -> languageName(d.sourceLang)
                else -> state.cardsOf(d.id).groupingBy { it.sourceLang }.eachCount()
                    .maxByOrNull { it.value }?.key?.let { languageName(it) } ?: tr("Sprache offen")
            }
            label to d
        }
        withLabel.groupBy({ it.first }, { it.second }).toList()
            .sortedWith(compareBy({ it.first == NO_FOLDER }, { it.first == tr("Sprache offen") }, { it.first }))
    }

            LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (shownDecks.isEmpty() && !state.loading) {
                item {
                    Text(
                        if (q.isNotEmpty()) tr("Nichts gefunden.")
                        else if (state.decks.isEmpty()) tr("Noch keine Decks. Tippe auf „Neues Deck“, um loszulegen.")
                        else if (page == 0) tr("Noch keine Vokabel-Decks.") else tr("Noch keine Lernkarten-Decks."),
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
            }
            groups.forEach { (label, decks) ->
                // language decks: one heading per language; plain card decks: headings only once folders exist
                if (page == 0 || groups.size > 1 || label != NO_FOLDER) item(key = "h-${label}") {
                    GroupHeader(
                        if (page == 1 && label == NO_FOLDER) tr("Ohne Ordner") else label,
                        icon = if (page == 1) Icons.Rounded.Folder else Icons.Rounded.Translate,
                    )
                }
                items(decks.size, key = { decks[it].id }) { i ->
                    val deck = decks[i]
                    val cards = state.cardsOf(deck.id)
                    val due = cards.count { it.dueAt <= System.currentTimeMillis() }
                    val job = jobs[deck.id]
                    SegmentedItem(
                        index = i,
                        count = decks.size,
                        headline = deck.name,
                        supporting = job?.let { "${it.percent} % • ${it.status}" } ?: tr("{0} • {1} Karten", deck.typeLabelFor(cards), cards.size),
                        progress = job?.let { it.percent / 100f },
                        onClick = { onOpenDeck(deck.id) },
                        trailing = {
                            if (job != null) IconButton(onClick = { com.lingosnap.util.AiJobs.cancel(deck.id) }) {
                                Icon(Icons.Rounded.Close, tr("KI-Vorgang abbrechen"))
                            } else Row(verticalAlignment = Alignment.CenterVertically) {
                                if (due > 0) {
                                    Surface(shape = RoundedCornerShape(50), color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
                                        Text(tr("{0} fällig", due), Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                                var menu by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, tr("Mehr")) }
                                    com.lingosnap.ui.components.AppMenu(expanded = menu, onDismiss = { menu = false }) {
                                        if (!deck.isLanguage) com.lingosnap.ui.components.AppMenuItem(tr("In Ordner legen"), Icons.Rounded.Folder, onClick = { menu = false; deckToFolder = deck })
                                        com.lingosnap.ui.components.AppMenuItem(tr("Deck löschen"), Icons.Rounded.Delete, danger = true, onClick = { menu = false; deckToDelete = deck })
                                    }
                                }
                            }
                        },
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }
            }
        }
    }

    parsed?.let { p ->
        ImportDialog(p, onDismiss = { parsed = null })
    }

    if (method) {
        LearnMethodSheet(
            current = learnMode,
            onPick = { learnMode = it; feedback.learnMode = it; method = false },
            onDismiss = { method = false },
        )
    }

    deckToFolder?.let { deck ->
        FolderDialog(
            folders = state.groups.map { it.id to it.name },
            current = deck.groupId,
            onPick = { vm.moveDeckToFolder(deck, it); deckToFolder = null },
            onCreate = { name -> vm.createFolderFor(deck, name); deckToFolder = null },
            onDismiss = { deckToFolder = null },
        )
    }

    if (addMenu) AddDeckMenu(onDismiss = { addMenu = false }, onPick = { addMenu = false; onCreate(it) })

    deckToDelete?.let { deck ->
        ConfirmDialog(
            title = tr("Deck löschen?"),
            text = tr("„{0}“ und alle {1} Karten werden gelöscht.", deck.name, state.cardsOf(deck.id).size),
            confirmLabel = tr("Löschen"),
            onConfirm = { vm.deleteDeck(deck.id) },
            onDismiss = { deckToDelete = null },
        )
    }
}

private const val NO_FOLDER = "\u0000ohne"

@Composable
private fun FolderDialog(
    folders: List<Pair<Long, String>>,
    current: Long?,
    onPick: (Long?) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    com.lingosnap.ui.components.FormSheet(
        title = tr("In Ordner legen"),
        icon = androidx.compose.material.icons.Icons.Rounded.Folder,
        onDismiss = onDismiss,
        confirmLabel = tr("Neu anlegen"),
        confirmEnabled = name.isNotBlank(),
        onConfirm = { onCreate(name.trim()) },
    ) {
        val all = listOf<Pair<Long?, String>>(null to tr("Ohne Ordner")) + folders
        androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            all.forEachIndexed { i, (id, label) ->
                SegmentedItem(
                    index = i, count = all.size, headline = label,
                    onClick = { onPick(id) },
                    trailing = if (id == current) { { Icon(Icons.Rounded.Check, tr("Aktuell")) } } else null,
                )
            }
        }
        com.lingosnap.ui.components.AppTextField(
            name, { name = it }, Modifier.fillMaxWidth(),
            label = { Text(tr("Neuer Ordner")) }, singleLine = true,
        )
    }
}

/** Pill-shaped tab switch: the coloured pill slides along while the pages are swiped. */
@Composable
private fun HomeTabs(
    labels: List<String>,
    counts: List<Int>,
    icons: List<androidx.compose.ui.graphics.vector.ImageVector>,
    position: Float,
    onSelect: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    androidx.compose.foundation.layout.BoxWithConstraints(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(56.dp)
            .clip(RoundedCornerShape(28.dp)).background(cs.surfaceContainerHigh).padding(4.dp),
    ) {
        val w = maxWidth / labels.size
        Box(
            Modifier.offset(x = w * position).width(w).fillMaxHeight()
                .clip(RoundedCornerShape(24.dp)).background(cs.primary),
        )
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, label ->
                val t = (1f - kotlin.math.abs(position - i)).coerceIn(0f, 1f)
                val color = androidx.compose.ui.graphics.lerp(cs.onSurfaceVariant, cs.onPrimary, t)
                Row(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(24.dp)).clickable { onSelect(i) },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(icons[i], null, tint = color, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(label, color = color, style = MaterialTheme.typography.titleSmall)
                    if (counts[i] > 0) {
                        Spacer(Modifier.width(8.dp))
                        Text(counts[i].toString(), color = color.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
