package com.lingosnap.ui.create

import com.lingosnap.util.tr

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.lingosnap.ui.components.OptionSheet
import androidx.compose.material.icons.rounded.ExpandMore
import com.lingosnap.ui.components.SegmentedItem
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.Surface
import androidx.compose.material3.RadioButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Style
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/**
 * Two calm steps, same look as the "new deck" menu: 1) name and languages (or subject), 2) how to fill the deck.
 * Every choice in step 2 creates the deck and jumps straight into that way (photo, AI, typing). No name: the AI picks
 * one once the first cards are there.
 */
@Composable
fun NewDeckScreen(languageDeck: Boolean, onCreated: (id: Long, method: Int) -> Unit, onBack: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    var step by rememberSaveable { mutableIntStateOf(0) }
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "en")
    }
    var busy by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    androidx.activity.compose.BackHandler(enabled = step == 1 && !busy) { step = 0 }

    fun create(method: Int) {
        if (busy) return
        busy = true
        scope.launch {
            val finalName = name.trim().ifBlank { DEFAULT_DECK_NAME }
            val id = if (languageDeck) repo.createDeck(finalName, null, source, target, "")
            else repo.createDeck(finalName, null, "", "", subject, kind = "cards")
            onCreated(id, method)
        }
    }

    LargeScreen(
        title = if (languageDeck) tr("Vokabeln") else tr("Karteikarten"),
        onBack = { if (step == 1 && !busy) step = 0 else onBack() },
        bottomBar = {
            if (step == 0) {
                Surface(color = cs.surface) {
                    Button(
                        onClick = { step = 1 },
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(16.dp).heightIn(min = 56.dp),
                    ) { Text(tr("Weiter"), style = MaterialTheme.typography.titleMedium.bold()) }
                }
            }
        },
    ) { inner ->
        Column(
            Modifier.padding(inner).verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (step == 0) {
                Text(tr("Neues Deck"), style = MaterialTheme.typography.headlineMedium.bold(), modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
                AppTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(tr("Name des Decks (optional)")) },
                    placeholder = { Text(tr("Leer lassen: die KI findet einen Namen")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (languageDeck) {
                    Text(tr("Sprachen"), style = MaterialTheme.typography.titleMedium.bold(), modifier = Modifier.padding(start = 4.dp, top = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LanguageField(tr("Ich lerne"), source, Modifier.weight(1f), allowAuto = true) { source = it }
                        IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                            Icon(Icons.Rounded.SwapHoriz, tr("Tauschen"))
                        }
                        LanguageField(tr("Meine Sprache"), target, Modifier.weight(1f)) { target = it }
                    }
                    if (source == "auto") {
                        Text(
                            tr("Bei „Automatisch“ erkennt die KI die Sprache jedes Worts selbst und übersetzt fehlende Übersetzungen in deine Zielsprache."),
                            style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp),
                        )
                    }
                } else {
                    AppTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text(tr("Worum geht es? (hilft der KI)")) },
                        placeholder = { Text(tr("z. B. Biologie Klasse 9, Zellaufbau")) },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            } else {
                Text(tr("Womit möchtest du starten?"), style = MaterialTheme.typography.headlineMedium.bold(), modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
                StartPill(Icons.Rounded.CameraAlt, tr("Foto oder Datei scannen"), tr("Kamera, Bild, PDF, Word oder PowerPoint"), busy) { create(1) }
                StartPill(Icons.Rounded.AutoAwesome, tr("Mit KI erzeugen"), tr("Thema eingeben, Karten generieren lassen"), busy) { create(2) }
                StartPill(Icons.Rounded.Edit, tr("Selbst eintippen"), tr("Einzeln oder als Liste einfügen"), busy) { create(0) }
                StartPill(Icons.Rounded.Style, tr("Leeres Deck erstellen"), tr("Später hinzufügen"), busy) { create(-2) }
            }
        }
    }
}

/** One calm choice: round icon, title, one line of help. The whole pill is the button. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun StartPill(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String, busy: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick, enabled = !busy, shape = RoundedCornerShape(36.dp),
        color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(28.dp))
            Spacer(Modifier.size(18.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium.bold())
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = cs.onSecondaryContainer.copy(alpha = 0.8f))
            }
        }
    }
}

@Composable
internal fun LanguageField(label: String, value: String, modifier: Modifier = Modifier, allowAuto: Boolean = false, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        AppTextField(
            value = if (value == "auto") tr("Automatisch") else languageName(value),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable { open = true })
    }
    if (open) {
        OptionSheet(
            title = label,
            options = (if (allowAuto) listOf("auto" to tr("Automatisch")) else emptyList()) + SupportedLanguages.map { it.tag to it.label },
            selected = value,
            onPick = { onPick(it); open = false },
            onDismiss = { open = false },
        )
    }
}
