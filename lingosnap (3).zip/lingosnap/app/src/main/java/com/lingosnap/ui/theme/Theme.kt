package com.lingosnap.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Expressive look: big, soft, rounded shapes. */
private val LingoShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(30.dp),
    extraLarge = RoundedCornerShape(40.dp),
)

/** Expressive-style emphasis: bolder weight for headlines and labels. */
fun TextStyle.bold(): TextStyle = copy(fontWeight = FontWeight.Bold)

/** Accent swatches shown in the settings (index 0 = Material You / wallpaper colours). */
val AccentHues = listOf(0f, 150f, 14f, 212f, 38f, 338f)
val AccentNames = listOf("Material You", "Grün", "Rot", "Blau", "Orange", "Pink")

private fun hsv(h: Float, s: Float, v: Float): Color {
    val hue = ((h % 360f) + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))))
}

/** Builds a full tonal colour scheme from a single hue. */
fun accentScheme(hue: Float, dark: Boolean): ColorScheme {
    val base = if (dark) darkColorScheme() else lightColorScheme()
    return if (dark) {
        base.copy(
            primary = hsv(hue, 0.45f, 1.0f),
            onPrimary = hsv(hue, 0.9f, 0.22f),
            primaryContainer = hsv(hue, 0.65f, 0.38f),
            onPrimaryContainer = hsv(hue, 0.2f, 1.0f),
            secondary = hsv(hue + 25f, 0.28f, 0.92f),
            onSecondary = hsv(hue + 25f, 0.6f, 0.2f),
            secondaryContainer = hsv(hue + 25f, 0.4f, 0.32f),
            onSecondaryContainer = hsv(hue + 25f, 0.15f, 1.0f),
            tertiary = hsv(hue + 70f, 0.4f, 1.0f),
            onTertiary = hsv(hue + 70f, 0.8f, 0.22f),
            tertiaryContainer = hsv(hue + 70f, 0.55f, 0.36f),
            onTertiaryContainer = hsv(hue + 70f, 0.2f, 1.0f),
            background = hsv(hue, 0.32f, 0.09f),
            onBackground = hsv(hue, 0.06f, 0.95f),
            surface = hsv(hue, 0.32f, 0.09f),
            onSurface = hsv(hue, 0.06f, 0.95f),
            surfaceVariant = hsv(hue, 0.25f, 0.24f),
            onSurfaceVariant = hsv(hue, 0.14f, 0.80f),
            surfaceContainerLowest = hsv(hue, 0.34f, 0.06f),
            surfaceContainerLow = hsv(hue, 0.32f, 0.11f),
            surfaceContainer = hsv(hue, 0.30f, 0.13f),
            surfaceContainerHigh = hsv(hue, 0.28f, 0.16f),
            surfaceContainerHighest = hsv(hue, 0.26f, 0.19f),
            outline = hsv(hue, 0.18f, 0.58f),
            outlineVariant = hsv(hue, 0.24f, 0.30f),
            surfaceTint = hsv(hue, 0.45f, 1.0f),
        )
    } else {
        base.copy(
            primary = hsv(hue, 0.78f, 0.58f),
            onPrimary = Color.White,
            primaryContainer = hsv(hue, 0.20f, 1.0f),
            onPrimaryContainer = hsv(hue, 0.9f, 0.26f),
            secondary = hsv(hue + 25f, 0.45f, 0.5f),
            onSecondary = Color.White,
            secondaryContainer = hsv(hue + 25f, 0.15f, 0.97f),
            onSecondaryContainer = hsv(hue + 25f, 0.7f, 0.24f),
            tertiary = hsv(hue + 70f, 0.6f, 0.55f),
            onTertiary = Color.White,
            tertiaryContainer = hsv(hue + 70f, 0.18f, 1.0f),
            onTertiaryContainer = hsv(hue + 70f, 0.8f, 0.25f),
            background = hsv(hue, 0.03f, 0.99f),
            onBackground = hsv(hue, 0.25f, 0.12f),
            surface = hsv(hue, 0.03f, 0.99f),
            onSurface = hsv(hue, 0.25f, 0.12f),
            surfaceVariant = hsv(hue, 0.10f, 0.92f),
            onSurfaceVariant = hsv(hue, 0.25f, 0.32f),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = hsv(hue, 0.04f, 0.97f),
            surfaceContainer = hsv(hue, 0.06f, 0.95f),
            surfaceContainerHigh = hsv(hue, 0.08f, 0.93f),
            surfaceContainerHighest = hsv(hue, 0.10f, 0.91f),
            outline = hsv(hue, 0.15f, 0.50f),
            outlineVariant = hsv(hue, 0.12f, 0.80f),
            surfaceTint = hsv(hue, 0.78f, 0.58f),
        )
    }
}

/**
 * Material 3 + Material You.
 * [accent] 0 = colours from the user's wallpaper (Android 12+), 1..5 = fixed accent.
 * [darkMode] 0 = follow system, 1 = dark, 2 = light.
 */
@Composable
fun LingoSnapTheme(
    darkMode: Int = 0,
    accent: Int = 0,
    content: @Composable () -> Unit,
) {
    val dark = when (darkMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val context = LocalContext.current
    val colorScheme = when {
        accent == 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        else -> {
            // accent 0 on Android < 12 falls back to the blue accent
            val index = if (accent in 1..AccentHues.lastIndex) accent else 3
            accentScheme(AccentHues[index], dark)
        }
    }
    MaterialTheme(colorScheme = colorScheme.richer(dark), shapes = LingoShapes, content = content)
}

/** Pulls the pastel container colours a bit towards their accent so the UI looks vivid instead of washed out. */
private fun ColorScheme.richer(dark: Boolean): ColorScheme {
    val t = if (dark) 0.14f else 0.22f
    return copy(
        primaryContainer = lerp(primaryContainer, primary, t),
        secondaryContainer = lerp(secondaryContainer, secondary, t),
        tertiaryContainer = lerp(tertiaryContainer, tertiary, t),
    )
}
