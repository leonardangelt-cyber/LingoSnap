package com.lingosnap.ui.home

import com.lingosnap.util.tr

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lingosnap.ui.theme.bold

/**
 * "New deck" menu in the style of Google's own apps: the + button turns into a close button and the choices
 * float above it as pills over a dimmed screen. Tap outside or the close button to leave.
 */
@Composable
fun AddDeckMenu(onDismiss: () -> Unit, onPick: (language: Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
        ) {
            Column(
                Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                AnimatedVisibility(shown, enter = fadeIn(tween(160, 40)) + slideInVertically(tween(220, 40)) { it / 2 } + scaleIn(tween(220, 40), initialScale = 0.8f), exit = fadeOut()) {
                    MenuPill(Icons.Rounded.Style, tr("Karteikarten")) { onPick(false) }
                }
                AnimatedVisibility(shown, enter = fadeIn(tween(160, 0)) + slideInVertically(tween(220, 0)) { it / 2 } + scaleIn(tween(220, 0), initialScale = 0.8f), exit = fadeOut()) {
                    MenuPill(Icons.Rounded.Translate, tr("Vokabeln")) { onPick(true) }
                }
                FloatingActionButton(onClick = onDismiss, containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.Close, tr("Schließen"))
                }
            }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun MenuPill(icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, shape = CircleShape, color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer, shadowElevation = 3.dp) {
        Row(Modifier.padding(horizontal = 24.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Text(label, style = MaterialTheme.typography.titleMedium.bold())
        }
    }
}
