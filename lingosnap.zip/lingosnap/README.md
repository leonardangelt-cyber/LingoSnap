# LingoSnap – Gemini-powered vocabulary flashcards

Jetpack Compose · Material 3 Expressive · Material You dynamic colour (follows wallpaper + dark mode)

## Project structure

```
app/src/main/java/com/lingosnap/
├── LingoSnapApp.kt            Application + hand-rolled DI container (AppContainer)
├── MainActivity.kt            edge-to-edge, NavHost with spring transitions
├── data/
│   ├── SecureKeyStore.kt      EncryptedSharedPreferences (AES-256, Android Keystore)
│   ├── CardRepository.kt      single source of truth (Room + Gemini)
│   ├── local/Database.kt      Room entity DAO + database
│   ├── model/Flashcard.kt     entity, Mastery, Rating, Srs (5-level Leitner), languages
│   └── remote/GeminiClient.kt REST client: vision→JSON, mnemonic, key validation
├── util/
│   ├── TtsManager.kt          Android TextToSpeech wrapper
│   └── ImageUtils.kt          EXIF-safe downscale → JPEG
└── ui/
    ├── theme/Theme.kt         MaterialExpressiveTheme + MotionScheme.expressive + dynamic colour
    ├── components/            AppBackground (adaptive gradient), BouncyButton, MasteryIndicator
    ├── setup/                 API-key onboarding (verify → save)
    ├── home/                  stats hero, word list, FAB
    ├── scan/                  camera/gallery → Gemini → review & save
    └── study/                 swipe + 3D-flip card, TTS, mnemonic sheet, rating feedback
```

## State management best practices used here

1. **One immutable `UiState` data class per screen**, exposed as `StateFlow` – the UI is a pure function of it.
2. **Unidirectional data flow**: composables emit events (`vm::rate`), the ViewModel updates state, Compose re-renders.
3. **Collect with `collectAsStateWithLifecycle()`** so nothing runs in the background.
4. **ViewModels depend on the repository only** – no Room/OkHttp/Context in UI code; `stateIn(WhileSubscribed(5s))` for cold flows.
5. **Ephemeral UI state stays in the UI** (drag offset `Animatable`, flip angle, dropdown open) – domain state lives in the ViewModel.
6. **Keyed state resets**: `remember(cardKey)` gives each card fresh gesture state (also for re-queued "Hard" cards).
7. **Errors are values** (`Result`, sealed `MnemonicState`), never thrown into the UI.

## Setup

1. Open in Android Studio (Narwhal+), let Gradle sync (bump plugin versions if prompted).
2. Run on a device/emulator with Android 8+ (dynamic colour on Android 12+).
3. Paste your key from https://aistudio.google.com/apikey on the first screen.

## Notes

- Model is `gemini-2.5-flash` in `GeminiClient` – change to `gemini-2.5-pro` for messy handwriting.
- Mnemonics are written in German (`explanationLang` parameter) – make it a setting if you like.
- `security-crypto` is flagged deprecated by Google but still works; migrate to DataStore + Tink later if desired.
- The swipe gesture is only enabled after flipping, so ratings are always based on seeing the answer.
