package com.lingosnap.data.remote

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/** One card that needs an example sentence and/or a mnemonic. Empty language names mean a plain question/answer card. */
class HelpItem(
    val id: Long, val source: String, val target: String,
    val sourceLang: String, val targetLang: String,
    val needExample: Boolean, val needMnemonic: Boolean,
)

class HelpResult(val id: Long, val example: String?, val mnemonic: String?)

/**
 * Learning aids in bulk: ONE request writes the example sentence and the mnemonic for up to [BATCH] cards,
 * so a whole deck is ready long before the learner taps the symbols.
 */
object CardHelp {
    const val BATCH = 20

    fun prompt(items: List<HelpItem>, explanationLang: String): String {
        val lines = items.joinToString("\n") { i ->
            val needs = listOfNotNull(if (i.needExample) "example" else null, if (i.needMnemonic) "mnemonic" else null).joinToString("+")
            val lang = if (i.sourceLang.isBlank()) "question card" else "${i.sourceLang} -> ${i.targetLang}"
            "${i.id} | ${i.source.oneLine()} | ${i.target.oneLine()} | $lang | $needs"
        }
        return """
            You write learning aids for flashcards. Entries (id | front | back | languages | what is needed):
            $lines

            For every entry return one JSON object with the same id:
            - "example": language card: ONE short, natural sentence (max. 12 words) in the front language that uses the front word, without translation.
              Question card: 1-2 short sentences in $explanationLang that explain why the back is the answer.
            - "mnemonic": ONE vivid, funny memory aid (max. 2 short sentences). Language card: link the front word with its translation using a
              sound-alike, an absurd picture or a mini story; write it in $explanationLang but keep both vocabulary words in their language.
              Question card: a memory trick for the answer.
            Only include the fields that are needed. Keep it short.
            Return ONLY a JSON array, no other text: [{"id":1,"example":"...","mnemonic":"..."}]
        """.trimIndent()
    }

    private fun String.oneLine() = replace('\n', ' ').trim()

    private val json = Json { isLenient = true; ignoreUnknownKeys = true }
    private val block = Regex("\\{[^{}]*\\}")

    /** Reads the answer even if it is wrapped in code fences, cut off, or not strictly valid JSON. */
    fun parse(raw: String): List<HelpResult> {
        val text = raw.replace(Regex("```[a-zA-Z]*"), "").replace("```", "")
        return block.findAll(text).mapNotNull { m ->
            val obj = runCatching { json.parseToJsonElement(m.value.replace(Regex(",\\s*\\}"), "}")) as? JsonObject }.getOrNull()
                ?: return@mapNotNull null
            val id = (obj["id"] as? JsonPrimitive)?.content?.trim()?.toDoubleOrNull()?.toLong() ?: return@mapNotNull null
            fun field(n: String) = (obj[n] as? JsonPrimitive)?.content?.trim()?.trim('"')?.takeIf { it.isNotEmpty() }
            val ex = field("example"); val mn = field("mnemonic")
            if (ex == null && mn == null) null else HelpResult(id, ex, mn)
        }.distinctBy { it.id }.toList()
    }
}
