package com.lingosnap.ui.create

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.MorphLoader
import com.lingosnap.ui.components.ScreenTitle
import com.lingosnap.ui.components.SectionLabel
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.theme.bold
import java.io.File

@Composable
fun CreateScreen(
    deckId: Long,
    onFinished: (Long) -> Unit,
    onBack: () -> Unit,
) {
    val vm: CreateViewModel = viewModel(
        key = "create-$deckId",
        factory = viewModelFactory { initializer { CreateViewModel(app().container.repository, deckId) } },
    )
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val groups by vm.groups.collectAsState(initial = emptyList())
    val isNew = deckId == 0L

    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = cameraUri
        if (ok && uri != null) vm.scan(context, uri)
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.scan(context, uri)
    }

    AppBackground {
        LazyColumn(
            Modifier.statusBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Column {
                    Row(Modifier.entrance(0), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
                    }
                    ScreenTitle(
                        if (isNew) "Neues Deck" else "Karten hinzufügen",
                        Modifier.entrance(1),
                        if (isNew) "Name, Sprachen und Inhalt festlegen" else vm.existing?.name,
                    )
                }
            }

            if (isNew) {
                item {
                    Panel(Modifier.entrance(2)) {
                        OutlinedTextField(
                            vm.name, { vm.name = it }, label = { Text("Deckname") }, singleLine = true,
                            shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedTextField(
                            vm.description, { vm.description = it }, label = { Text("Beschreibung (optional)") },
                            shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth(),
                        )
                        SectionLabel("Gruppe")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = vm.groupId == null, onClick = { vm.groupId = null }, label = { Text("Keine") })
                            groups.forEach { g ->
                                FilterChip(
                                    selected = vm.groupId == g.id,
                                    onClick = { vm.groupId = g.id; vm.newGroupName = "" },
                                    label = { Text(g.name) },
                                )
                            }
                        }
                        if (vm.groupId == null) {
                            OutlinedTextField(
                                vm.newGroupName, { vm.newGroupName = it }, label = { Text("… oder neue Gruppe anlegen") },
                                singleLine = true, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
                item {
                    Panel(Modifier.entrance(3)) {
                        SectionLabel("Sprachen")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LangPicker("Lernsprache", vm.sourceLang, Modifier.weight(1f)) { vm.sourceLang = it }
                            IconButton(onClick = { vm.swapLanguages() }) { Icon(Icons.Rounded.SwapHoriz, "Tauschen") }
                            LangPicker("Muttersprache", vm.targetLang, Modifier.weight(1f)) { vm.targetLang = it }
                        }
                    }
                }
            }

            item {
                Panel(Modifier.entrance(4)) {
                    SectionLabel("Vokabeln hinzufügen")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Manuell", "KI-Assistent", "Foto").forEachIndexed { i, label ->
                            FilterChip(selected = vm.method == i, onClick = { vm.method = i }, label = { Text(label) })
                        }
                    }
                    when (vm.method) {
                        0 -> {
                            OutlinedTextField(
                                vm.manualText, { vm.manualText = it },
                                label = { Text("Ein Paar pro Zeile") },
                                placeholder = { Text("casa;Haus\nperro;Hund") },
                                supportingText = { Text("${vm.manualPairs.size} Paare erkannt • Trenner: ; - = :") },
                                shape = MaterialTheme.shapes.large,
                                minLines = 5,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        1 -> {
                            OutlinedTextField(
                                vm.topic, { vm.topic = it }, label = { Text("Thema, z. B. „Im Restaurant“") },
                                singleLine = true, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth(),
                            )
                            Text("Anzahl", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(10, 15, 25, 40).forEach { n ->
                                    FilterChip(selected = vm.count == n, onClick = { vm.count = n }, label = { Text("$n") })
                                }
                            }
                            Text("Niveau", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("A1", "A2", "B1", "B2", "C1").forEach { l ->
                                    FilterChip(selected = vm.level == l, onClick = { vm.level = l }, label = { Text(l) })
                                }
                            }
                            FilledTonalButton(onClick = { vm.generate() }, enabled = vm.topic.isNotBlank() && !vm.busy) {
                                Icon(Icons.Rounded.AutoAwesome, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Vokabeln generieren")
                            }
                        }
                        else -> {
                            Text(
                                "Fotografiere eine Buchseite oder Vokabelliste – die KI liest die Wörter aus.",
                                color = cs.onSurfaceVariant,
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                FilledTonalButton(
                                    enabled = !vm.busy,
                                    onClick = {
                                        val dir = File(context.cacheDir, "images").apply { mkdirs() }
                                        val file = File.createTempFile("scan_", ".jpg", dir)
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        cameraUri = uri
                                        camera.launch(uri)
                                    },
                                ) {
                                    Icon(Icons.Rounded.CameraAlt, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Kamera")
                                }
                                FilledTonalButton(
                                    enabled = !vm.busy,
                                    onClick = { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                ) {
                                    Icon(Icons.Rounded.PhotoLibrary, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Galerie")
                                }
                            }
                        }
                    }
                    AnimatedVisibility(vm.busy, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                            MorphLoader(size = 56.dp)
                        }
                    }
                    AnimatedVisibility(vm.error != null) {
                        Text(vm.error.orEmpty(), color = cs.error, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            if (vm.drafts.isNotEmpty()) {
                item {
                    SectionLabel("Vorschau", Modifier.padding(top = 4.dp), trailing = "${vm.drafts.count { it.selected }} / ${vm.drafts.size} gewählt")
                }
                items(vm.drafts.size) { i ->
                    val d = vm.drafts[i]
                    Surface(
                        Modifier.fillMaxWidth().clickable { d.selected = !d.selected },
                        shape = MaterialTheme.shapes.large,
                        color = if (d.selected) cs.secondaryContainer else cs.surfaceContainerHigh,
                    ) {
                        Row(Modifier.padding(start = 8.dp, end = 16.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = d.selected, onCheckedChange = { d.selected = it })
                            Column(Modifier.weight(1f)) {
                                Text(d.pair.source, style = MaterialTheme.typography.titleMedium.bold())
                                Text(d.pair.target, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            item {
                BouncyButton(
                    onClick = { vm.save(onFinished) },
                    enabled = vm.canSave,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                ) {
                    Icon(Icons.Rounded.Check, null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (isNew) "Deck erstellen (${vm.selectedCount})" else "${vm.selectedCount} Karten hinzufügen",
                        style = MaterialTheme.typography.titleMedium.bold(),
                    )
                }
                if (isNew && vm.name.isBlank()) {
                    Text("Gib dem Deck einen Namen.", Modifier.padding(top = 6.dp), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun Panel(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
    }
}

@Composable
private fun LangPicker(label: String, value: String, modifier: Modifier = Modifier, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Box(modifier) {
        Surface(
            Modifier.fillMaxWidth().clickable { open = true },
            shape = MaterialTheme.shapes.large,
            color = cs.surfaceContainerHigh,
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                Text(languageName(value), style = MaterialTheme.typography.titleMedium.bold())
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            SupportedLanguages.forEach { l ->
                DropdownMenuItem(text = { Text(l.label) }, onClick = { onPick(l.tag); open = false })
            }
        }
    }
}
