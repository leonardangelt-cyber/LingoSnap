package com.lingosnap.ui.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.ui.components.FormSheet
import com.lingosnap.util.tr
import kotlinx.coroutines.launch

/** Backup and synchronisation: pick a folder once, the app keeps a copy of everything in it. */
@Composable
fun BackupSheet(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val backup = context.container.autoBackup
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var enabled by remember { mutableStateOf(backup.enabled) }
    var folder by remember { mutableStateOf(backup.folderName) }
    var last by remember { mutableLongStateOf(backup.lastRun) }
    var error by remember { mutableStateOf(backup.lastError) }
    var working by remember { mutableStateOf(false) }
    var restore by remember { mutableStateOf<com.lingosnap.util.ParsedImport?>(null) }
    var note by remember { mutableStateOf<String?>(null) }

    fun runNow() {
        working = true
        scope.launch {
            backup.run(force = true)
            last = backup.lastRun; error = backup.lastError; working = false
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            backup.setFolder(uri)
            enabled = true; folder = backup.folderName
            runNow()
        }
    }

    FormSheet(
        title = tr("Backup und Synchronisierung"),
        icon = Icons.Rounded.Sync,
        onDismiss = onDismiss,
        confirmLabel = if (enabled) tr("Jetzt sichern") else tr("Ordner wählen"),
        onConfirm = { if (enabled) runNow() else picker.launch(null) },
        dismissLabel = tr("Schließen"),
        busy = working,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                tr("Wähle einmal einen Ordner auf dem Handy oder in der Cloud (z. B. Google Drive). Die App sichert dort automatisch, kurz nachdem sich etwas geändert hat."),
                style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
            )
            Text(
                tr("Im Ordner entsteht „LingoSnap“ mit zwei Teilen: „Komplett-Backup“ (alle Decks mit Lernstand, Gruppen und alle Einstellungen) und „Decks“ (eine Textdatei pro Deck, nach Sprachen in Ordnern sortiert). Die API-Schlüssel werden nicht gesichert."),
                style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
            )
            if (enabled) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Folder, null, Modifier.size(20.dp), tint = cs.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(folder ?: tr("Ordner gewählt"), style = MaterialTheme.typography.titleSmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.CloudDone, null, Modifier.size(20.dp), tint = if (error == null) cs.primary else cs.error)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        when {
                            working -> tr("Wird gesichert …")
                            error != null -> tr("Fehler: {0}", error.orEmpty())
                            last > 0 -> tr("Zuletzt gesichert: {0}", java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(last)))
                            else -> tr("Noch nicht gesichert")
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (error == null) cs.onSurface else cs.error,
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            working = true; note = null
                            scope.launch {
                                val found = backup.readBackup()
                                working = false
                                if (found == null) note = tr("Im Ordner liegt noch kein Backup.") else restore = found
                            }
                        },
                        enabled = !working,
                    ) { Text(tr("Decks wiederherstellen")) }
                    OutlinedButton(
                        onClick = {
                            working = true; note = null
                            scope.launch {
                                val n = backup.restoreSettings()
                                working = false
                                note = if (n == 0) tr("Im Ordner liegen keine gespeicherten Einstellungen.") else tr("{0} Einstellungen zurückgeholt. Starte die App neu, damit alles greift.", n)
                            }
                        },
                        enabled = !working,
                    ) { Text(tr("Einstellungen holen")) }
                }
                note?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = cs.primary) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { picker.launch(null) }, enabled = !working) { Text(tr("Anderer Ordner")) }
                    TextButton(
                        onClick = { backup.setFolder(null); enabled = false; folder = null; error = null },
                        enabled = !working,
                    ) { Text(tr("Ausschalten"), color = cs.error) }
                }
            }
        }
    }
    restore?.let { r -> ImportDialog(r, onDismiss = { restore = null }) }
}
