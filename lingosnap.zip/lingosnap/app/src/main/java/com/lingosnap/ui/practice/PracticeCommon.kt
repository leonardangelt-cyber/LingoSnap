package com.lingosnap.ui.practice

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.lingosnap.ui.StudyDir
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Scaffold
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Button
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.ConfettiBurst
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.MorphLoader
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.FeedbackManager
import kotlinx.coroutines.launch

/** Shared by Multiple-Choice, Schreibtrainer and Speed-Match. */
class PracticeViewModel(
    private val repo: CardRepository,
    private val scope: StudyScope,
    private val id: Long,
    private val take: Int,
    val feedback: FeedbackManager,
) : ViewModel() {

    var loading by mutableStateOf(true)
        private set
    var cards by mutableStateOf<List<Flashcard>>(emptyList())
        private set
    var pool by mutableStateOf<List<Flashcard>>(emptyList())
        private set

    init {
        viewModelScope.launch {
            val all = repo.cardsFor(scope, id)
            pool = all
            // weakest cards first, with a little shuffle
            cards = all.shuffled().sortedBy { it.level / 2 }.take(take).shuffled()
            loading = false
        }
    }

    fun review(card: Flashcard, correct: Boolean, sound: Boolean = true) {
        if (sound) { if (correct) feedback.correct() else feedback.wrong() }
        viewModelScope.launch { repo.review(card, if (correct) Rating.Good else Rating.Hard) }
    }

    fun finish(perfect: Boolean, bonusXp: Int) {
        if (bonusXp > 0) repo.stats.addXp(bonusXp)
        if (perfect) repo.stats.recordPerfectSession()
    }
}

@Composable
fun rememberPractice(scope: StudyScope, id: Long, kind: String, take: Int): PracticeViewModel =
    viewModel(
        key = "practice-$kind-$scope-$id",
        factory = viewModelFactory { initializer { PracticeViewModel(app().container.repository, scope, id, take, app().container.feedback) } },
    )

/** Whether this card is asked "backwards" (answer → question) in the chosen direction. */
fun isReversed(dir: String, card: Flashcard, index: Int): Boolean = when (dir) {
    StudyDir.Reverse -> true
    StudyDir.Mixed -> (card.id + index) % 2L == 0L
    else -> false
}

fun Flashcard.front(reversed: Boolean) = if (reversed) target else source
fun Flashcard.back(reversed: Boolean) = if (reversed) source else target

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PracticeScaffold(
    title: String,
    progress: Float,
    loading: Boolean,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p by animateFloatAsState(progress, spring(0.8f, 300f), label = "practiceProgress")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        topBar = {
            Column {
                TopAppBar(
                    title = { Text(title, maxLines = 1) },
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.Close, "Schließen") } },
                )
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
            }
        },
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (loading) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                content()
            }
        }
    }
}

@Composable
fun ColumnScope.ResultPane(
    emoji: String,
    headline: String,
    detail: String,
    xp: Int,
    confetti: Boolean,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(headline, style = MaterialTheme.typography.headlineMedium.bold(), textAlign = TextAlign.Center)
            Text(detail, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
    Button(onClick = onBack, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Fertig") }
}
