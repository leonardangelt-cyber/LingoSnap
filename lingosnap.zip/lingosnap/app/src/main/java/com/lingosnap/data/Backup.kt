package com.lingosnap.data

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.File

/** One card read from a file; learning state is optional (only backups carry it). */
class ImportedCard(
    val source: String,
    val target: String,
    val example: String? = null,
    val sourceLang: String? = null,
    val level: Int = 0,
    val dueAt: Long = 0L,
    val ease: Double = 2.5,
    val intervalDays: Int = 0,
    val mnemonic: String? = null,
)

/** A deck read from a file. [kind] / languages are null when the file does not say. */
class ImportedDeck(
    val name: String,
    val kind: String?,
    val sourceLang: String?,
    val targetLang: String?,
    val description: String,
    val cards: List<ImportedCard>,
)

/** Lossless backup of decks including the learning state, as one JSON file. */
object Backup {
    fun toJson(decks: List<Deck>, cards: List<Flashcard>): String {
        val root = buildJsonObject {
            put("app", "lingosnap")
            put("version", 1)
            put("decks", buildJsonArray {
                decks.forEach { d ->
                    add(buildJsonObject {
                        put("name", d.name)
                        put("kind", d.kind)
                        put("sourceLang", d.sourceLang)
                        put("targetLang", d.targetLang)
                        put("description", d.description)
                        put("cards", buildJsonArray {
                            cards.filter { it.deckId == d.id }.forEach { c ->
                                add(buildJsonObject {
                                    put("source", c.source)
                                    put("target", c.target)
                                    put("example", c.example)
                                    put("sourceLang", c.sourceLang)
                                    put("level", c.level)
                                    put("dueAt", c.dueAt)
                                    put("ease", c.ease)
                                    put("intervalDays", c.intervalDays)
                                    put("mnemonic", c.mnemonic)
                                })
                            }
                        })
                    })
                }
            })
        }
        return Json { prettyPrint = true }.encodeToString(JsonElement.serializer(), root)
    }

    /** Writes the JSON to the cache and returns a shareable uri. */
    fun writeFile(context: Context, fileName: String, json: String): Uri {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safe = fileName.replace(Regex("[^\\p{L}\\p{N}._-]+"), "_").ifBlank { "lingosnap" }
        val file = File(dir, "$safe.json")
        file.writeText(json)
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun parse(text: String): List<ImportedDeck>? {
        val root = runCatching { Json.parseToJsonElement(text) }.getOrNull() as? JsonObject ?: return null
        val decks = root["decks"] as? JsonArray ?: return null
        fun JsonObject.str(k: String) = (this[k] as? JsonPrimitive)?.takeIf { it !is JsonNull }?.content
        return decks.mapNotNull { e ->
            val d = e as? JsonObject ?: return@mapNotNull null
            val cards = (d["cards"] as? JsonArray).orEmpty().mapNotNull { ce ->
                val c = ce as? JsonObject ?: return@mapNotNull null
                val s = c.str("source") ?: return@mapNotNull null
                val t = c.str("target") ?: return@mapNotNull null
                ImportedCard(
                    s, t, c.str("example"), c.str("sourceLang"),
                    c.str("level")?.toIntOrNull() ?: 0, c.str("dueAt")?.toLongOrNull() ?: 0L,
                    c.str("ease")?.toDoubleOrNull() ?: 2.5, c.str("intervalDays")?.toIntOrNull() ?: 0, c.str("mnemonic"),
                )
            }
            ImportedDeck(
                d.str("name") ?: "Import", d.str("kind"), d.str("sourceLang"), d.str("targetLang"),
                d.str("description").orEmpty(), cards,
            )
        }
    }
}
