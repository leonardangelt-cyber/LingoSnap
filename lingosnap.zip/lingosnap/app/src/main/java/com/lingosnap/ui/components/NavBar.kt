package com.lingosnap.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class NavItemSpec(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val isCenter: Boolean = false,
)

/** Floating, pill-shaped bottom navigation with springy selection. */
@Composable
fun FloatingNavBar(
    items: List<NavItemSpec>,
    selectedRoute: String?,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    Surface(
        modifier.padding(horizontal = 16.dp, vertical = 12.dp).fillMaxWidth(),
        shape = RoundedCornerShape(38.dp),
        color = cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        tonalElevation = 6.dp,
        shadowElevation = 16.dp,
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { item ->
                NavButton(
                    item = item,
                    selected = selectedRoute?.startsWith(item.route) == true,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(item.route)
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun NavButton(item: NavItemSpec, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val pill by animateColorAsState(
        if (selected && !item.isCenter) cs.primaryContainer else Color.Transparent,
        label = "navPill",
    )
    val tint by animateColorAsState(
        if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant,
        label = "navTint",
    )
    val scale by animateFloatAsState(
        if (selected) 1.18f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "navScale",
    )
    val spin by animateFloatAsState(
        if (selected && item.isCenter) 135f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 200f),
        label = "navSpin",
    )
    val source = remember { MutableInteractionSource() }

    Column(
        modifier
            .pressScale(source, 0.9f)
            .clip(RoundedCornerShape(30.dp))
            .background(pill)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        if (item.isCenter) {
            Box(
                Modifier.size(42.dp).background(cs.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    item.icon, item.label,
                    Modifier.size(26.dp).graphicsLayer { rotationZ = spin },
                    tint = cs.onPrimary,
                )
            }
        } else {
            Icon(
                item.icon, item.label,
                Modifier.size(25.dp).graphicsLayer { scaleX = scale; scaleY = scale },
                tint = tint,
            )
        }
        Text(
            item.label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = tint,
        )
    }
}
