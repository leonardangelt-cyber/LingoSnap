package com.lingosnap.data.model

import com.lingosnap.util.tr

import com.lingosnap.data.Stats
import kotlin.math.sqrt

/* ───────── levels ───────── */

fun levelForXp(xp: Int): Int = sqrt(xp / 100.0).toInt() + 1
fun xpForLevel(level: Int): Int = 100 * (level - 1) * (level - 1)

data class Rank(val minLevel: Int, val emoji: String, val name: String)

val Ranks get() = listOf(
    Rank(1, "🌱", tr("Vokabel-Pionier")),
    Rank(2, "🧭", tr("Wort-Entdecker")),
    Rank(3, "📚", tr("Sprach-Sammler")),
    Rank(5, "🥷", tr("Grammatik-Ninja")),
    Rank(7, "🧙", tr("Wort-Zauberer")),
    Rank(10, "🏛️", tr("Sprach-Meister")),
    Rank(14, "👑", tr("Polyglott")),
)

fun rankFor(level: Int): Rank = Ranks.last { level >= it.minLevel }

/* ───────── badges ───────── */

data class LearnProgress(
    val stats: Stats,
    val cardCount: Int,
    val deckCount: Int,
    val mastered: Int,
)

data class Achievement(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val unlocked: (LearnProgress) -> Boolean,
)

val Achievements: List<Achievement> get() = listOf(
    Achievement("first_deck", "📦", tr("Erstes Deck"), tr("Erstelle dein erstes Deck")) { it.deckCount >= 1 },
    Achievement("words_25", "🌿", tr("Wortsammler"), tr("Sammle 25 Vokabeln")) { it.cardCount >= 25 },
    Achievement("words_100", "🌳", tr("Wortschatz"), tr("Sammle 100 Vokabeln")) { it.cardCount >= 100 },
    Achievement("words_500", "🏞️", tr("Bibliothekar"), tr("Sammle 500 Vokabeln")) { it.cardCount >= 500 },
    Achievement("review_1", "✨", tr("Erster Schritt"), tr("Bewerte deine erste Karte")) { it.stats.totalReviews >= 1 },
    Achievement("review_50", "🎯", tr("Im Flow"), tr("50 Karten gelernt")) { it.stats.totalReviews >= 50 },
    Achievement("review_250", "🚀", tr("Durchstarter"), tr("250 Karten gelernt")) { it.stats.totalReviews >= 250 },
    Achievement("review_1000", "🛸", tr("Lern-Maschine"), tr("1000 Karten gelernt")) { it.stats.totalReviews >= 1000 },
    Achievement("streak_3", "🔥", tr("Auf Kurs"), tr("3 Tage in Folge gelernt")) { it.stats.bestStreak >= 3 },
    Achievement("streak_7", "🌋", tr("Wochen-Held"), tr("7 Tage in Folge gelernt")) { it.stats.bestStreak >= 7 },
    Achievement("streak_30", "☄️", tr("Monats-Legende"), tr("30 Tage in Folge gelernt")) { it.stats.bestStreak >= 30 },
    Achievement("master_10", "🏅", tr("Meister-Schüler"), tr("10 Wörter gemeistert")) { it.mastered >= 10 },
    Achievement("master_50", "🥇", tr("Wort-Meister"), tr("50 Wörter gemeistert")) { it.mastered >= 50 },
    Achievement("goal_1", "✅", tr("Tagesziel"), tr("Erreiche dein Tagesziel")) { it.stats.goalHits >= 1 },
    Achievement("goal_7", "📅", tr("Zielstrebig"), tr("Tagesziel an 7 Tagen erreicht")) { it.stats.goalHits >= 7 },
    Achievement("perfect_1", "💎", tr("Perfekt!"), tr("Eine Runde ohne Fehler")) { it.stats.perfectSessions >= 1 },
    Achievement("level_3", "⭐", tr("Level 3"), tr("Erreiche Level 3")) { levelForXp(it.stats.xp) >= 3 },
    Achievement("level_5", "🌟", tr("Level 5"), tr("Erreiche Level 5")) { levelForXp(it.stats.xp) >= 5 },
    Achievement("level_10", "💫", tr("Level 10"), tr("Erreiche Level 10")) { levelForXp(it.stats.xp) >= 10 },
    Achievement("xp_1000", "⚡", tr("Power-User"), tr("Sammle 1000 XP")) { it.stats.xp >= 1000 },
)
