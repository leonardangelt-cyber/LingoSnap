package com.lingosnap.data.model

import com.lingosnap.data.Stats
import kotlin.math.sqrt

/* ───────── levels ───────── */

fun levelForXp(xp: Int): Int = sqrt(xp / 100.0).toInt() + 1
fun xpForLevel(level: Int): Int = 100 * (level - 1) * (level - 1)

data class Rank(val minLevel: Int, val emoji: String, val name: String)

val Ranks = listOf(
    Rank(1, "🌱", "Vokabel-Pionier"),
    Rank(2, "🧭", "Wort-Entdecker"),
    Rank(3, "📚", "Sprach-Sammler"),
    Rank(5, "🥷", "Grammatik-Ninja"),
    Rank(7, "🧙", "Wort-Zauberer"),
    Rank(10, "🏛️", "Sprach-Meister"),
    Rank(14, "👑", "Polyglott"),
)

fun rankFor(level: Int): Rank = Ranks.last { level >= it.minLevel }

/* ───────── badges ───────── */

data class LearnProgress(
    val stats: Stats,
    val cardCount: Int,
    val deckCount: Int,
    val mastered: Int,
)

data class Achievement(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val unlocked: (LearnProgress) -> Boolean,
)

val Achievements: List<Achievement> = listOf(
    Achievement("first_deck", "📦", "Erstes Deck", "Erstelle dein erstes Deck") { it.deckCount >= 1 },
    Achievement("words_25", "🌿", "Wortsammler", "Sammle 25 Vokabeln") { it.cardCount >= 25 },
    Achievement("words_100", "🌳", "Wortschatz", "Sammle 100 Vokabeln") { it.cardCount >= 100 },
    Achievement("words_500", "🏞️", "Bibliothekar", "Sammle 500 Vokabeln") { it.cardCount >= 500 },
    Achievement("review_1", "✨", "Erster Schritt", "Bewerte deine erste Karte") { it.stats.totalReviews >= 1 },
    Achievement("review_50", "🎯", "Im Flow", "50 Karten gelernt") { it.stats.totalReviews >= 50 },
    Achievement("review_250", "🚀", "Durchstarter", "250 Karten gelernt") { it.stats.totalReviews >= 250 },
    Achievement("review_1000", "🛸", "Lern-Maschine", "1000 Karten gelernt") { it.stats.totalReviews >= 1000 },
    Achievement("streak_3", "🔥", "Auf Kurs", "3 Tage in Folge gelernt") { it.stats.bestStreak >= 3 },
    Achievement("streak_7", "🌋", "Wochen-Held", "7 Tage in Folge gelernt") { it.stats.bestStreak >= 7 },
    Achievement("streak_30", "☄️", "Monats-Legende", "30 Tage in Folge gelernt") { it.stats.bestStreak >= 30 },
    Achievement("master_10", "🏅", "Meister-Schüler", "10 Wörter gemeistert") { it.mastered >= 10 },
    Achievement("master_50", "🥇", "Wort-Meister", "50 Wörter gemeistert") { it.mastered >= 50 },
    Achievement("goal_1", "✅", "Tagesziel", "Erreiche dein Tagesziel") { it.stats.goalHits >= 1 },
    Achievement("goal_7", "📅", "Zielstrebig", "Tagesziel an 7 Tagen erreicht") { it.stats.goalHits >= 7 },
    Achievement("perfect_1", "💎", "Perfekt!", "Eine Runde ohne Fehler") { it.stats.perfectSessions >= 1 },
    Achievement("level_3", "⭐", "Level 3", "Erreiche Level 3") { levelForXp(it.stats.xp) >= 3 },
    Achievement("level_5", "🌟", "Level 5", "Erreiche Level 5") { levelForXp(it.stats.xp) >= 5 },
    Achievement("level_10", "💫", "Level 10", "Erreiche Level 10") { levelForXp(it.stats.xp) >= 10 },
    Achievement("xp_1000", "⚡", "Power-User", "Sammle 1000 XP") { it.stats.xp >= 1000 },
)
