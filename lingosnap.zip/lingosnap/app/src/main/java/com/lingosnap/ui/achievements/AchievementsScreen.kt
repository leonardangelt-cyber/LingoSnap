package com.lingosnap.ui.achievements

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Achievements
import com.lingosnap.data.model.Ranks
import com.lingosnap.data.model.rankFor
import com.lingosnap.data.model.xpForLevel
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.ScreenTitle
import com.lingosnap.ui.components.SectionLabel
import com.lingosnap.ui.components.StatTile
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.theme.bold
import java.time.DayOfWeek
import java.time.LocalDate

private val Tabs = listOf("Übersicht", "Ränge", "Abzeichen")

@Composable
fun AchievementsScreen(vm: AppViewModel = viewModel(factory = AppViewModel.Factory)) {
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    AppBackground {
        Column(Modifier.statusBarsPadding().padding(horizontal = 20.dp).padding(top = 8.dp)) {
            ScreenTitle("Erfolge", Modifier.entrance(0), "Dein Fortschritt auf einen Blick")
            Spacer(Modifier.height(12.dp))
            Row(Modifier.entrance(1), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tabs.forEachIndexed { i, label ->
                    FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(12.dp))
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    (fadeIn(spring()) + slideInVertically(spring(0.8f, 300f)) { it / 10 }) togetherWith fadeOut()
                },
                label = "achTab",
            ) { t ->
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 150.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    when (t) {
                        0 -> overview(state)
                        1 -> ranks(state)
                        else -> badges(state)
                    }
                }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.overview(state: com.lingosnap.ui.AppState) {
    val stats = state.stats
    item {
        val level = stats.level
        val base = xpForLevel(level)
        val next = xpForLevel(level + 1)
        val ratio = ((stats.xp - base) / (next - base).toFloat()).coerceIn(0f, 1f)
        val progress by animateFloatAsState(ratio, spring(0.8f, 100f), label = "xp")
        val cs = MaterialTheme.colorScheme
        val rank = rankFor(level)
        Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CookieBadge(size = 72.dp, color = cs.primary, lobes = 10) {
                        Text("${level}", style = MaterialTheme.typography.headlineMedium.bold(), color = cs.onPrimary)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(rank.name, style = MaterialTheme.typography.titleLarge.bold())
                        Text("Level $level • ${stats.xp} XP", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                WavyProgressBar(progress, color = cs.primary, trackColor = cs.onPrimaryContainer.copy(alpha = 0.18f))
                Text("Noch ${next - stats.xp} XP bis Level ${level + 1}", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
    item {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("", "Serie", stats.activeStreak, Modifier.weight(1f), " Tage")
            StatTile("", "Rekord", stats.bestStreak, Modifier.weight(1f), " Tage")
        }
    }
    item {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("", "Tagesziel", stats.todayCount, Modifier.weight(1f), " / ${stats.dailyGoal}")
            StatTile("", "Gemeistert", state.mastered, Modifier.weight(1f))
        }
    }
    item {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("", "Wiederholungen", stats.totalReviews, Modifier.weight(1f))
            StatTile("", "Perfekte Runden", stats.perfectSessions, Modifier.weight(1f))
        }
    }
    item { WeekCard(state) }
}

@Composable
private fun WeekCard(state: com.lingosnap.ui.AppState) {
    val cs = MaterialTheme.colorScheme
    val today = LocalDate.now()
    val monday = today.with(DayOfWeek.MONDAY)
    val days = (0..6).map { monday.plusDays(it.toLong()) }
    val counts = days.map { state.stats.history[it.toString()] ?: 0 }
    val maxCount = (counts.maxOrNull() ?: 0).coerceAtLeast(state.stats.dailyGoal).coerceAtLeast(1)
    val names = listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
    Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainer) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionLabel("Diese Woche", trailing = "${counts.sum()} Karten")
            Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                days.forEachIndexed { i, d ->
                    val h by animateFloatAsState(counts[i] / maxCount.toFloat(), spring(0.6f, 140f), label = "bar")
                    val isToday = d == today
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Text("${counts[i]}", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        Box(
                            Modifier
                                .width(22.dp)
                                .height((6 + 70 * h).dp)
                                .background(if (isToday) cs.primary else cs.primary.copy(alpha = 0.45f), CircleShape),
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            names[i],
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isToday) cs.primary else cs.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.ranks(state: com.lingosnap.ui.AppState) {
    val level = state.stats.level
    item { Text("Steige im Level auf, um neue Ränge freizuschalten.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    Ranks.forEach { r ->
        item(key = r.name) {
            val cs = MaterialTheme.colorScheme
            val reached = level >= r.minLevel
            val bg by animateColorAsState(if (reached) cs.tertiaryContainer else cs.surfaceContainerHigh, label = "rank")
            Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, color = bg) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                        Text(r.name, style = MaterialTheme.typography.titleMedium.bold())
                        Text("ab Level ${r.minLevel}", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                    if (reached) Text("Erreicht", style = MaterialTheme.typography.titleLarge.bold(), color = cs.primary)
                }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.badges(state: com.lingosnap.ui.AppState) {
    val progress = state.progress
    val unlockedCount = Achievements.count { it.unlocked(progress) }
    item { Text("$unlockedCount von ${Achievements.size} freigeschaltet", style = MaterialTheme.typography.titleMedium.bold()) }
    Achievements.chunked(2).forEachIndexed { idx, pair ->
        item(key = "badge-row-$idx") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { a ->
                    val cs = MaterialTheme.colorScheme
                    val on = a.unlocked(progress)
                    val scale by animateFloatAsState(if (on) 1f else 0.96f, spring(0.4f, 200f), label = "b")
                    Surface(
                        Modifier.weight(1f).graphicsLayer { scaleX = scale; scaleY = scale },
                        shape = MaterialTheme.shapes.large,
                        color = if (on) cs.secondaryContainer else cs.surfaceContainerHigh,
                    ) {
                        Column(
                            Modifier.padding(14.dp).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Text(a.emoji, fontSize = 34.sp, modifier = Modifier.graphicsLayer { alpha = if (on) 1f else 0.3f })
                            Text(a.title, style = MaterialTheme.typography.titleSmall.bold(), textAlign = TextAlign.Center)
                            Text(
                                a.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
