package com.lingosnap.ui.components

import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Choose how the flashcard mode works: spaced repetition or right/wrong rounds. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LearnMethodSheet(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
            Text(tr("Wie möchtest du lernen?"), style = MaterialTheme.typography.headlineSmall)
            Text(
                tr("Gilt für den Modus „Karteikarten“."),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
            )
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                SegmentedItem(
                    0, 2, tr("Wiederholungssystem (SRS)"),
                    supporting = tr("Jede Karte kommt nach einem Zeitplan wieder. Je besser du sie kannst, desto später."),
                    onClick = { onPick("srs") },
                    trailing = { RadioButton(selected = current == "srs", onClick = { onPick("srs") }) },
                )
                SegmentedItem(
                    1, 2, tr("Richtig oder falsch"),
                    supporting = tr("Falsche Karten kommen in die nächste Runde, bis du alle richtig hattest."),
                    onClick = { onPick("rounds") },
                    trailing = { RadioButton(selected = current == "rounds", onClick = { onPick("rounds") }) },
                )
            }
        }
    }
}
