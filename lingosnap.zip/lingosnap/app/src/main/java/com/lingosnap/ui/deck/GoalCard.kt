package com.lingosnap.ui.deck

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EditCalendar
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.languageNameEn
import com.lingosnap.ui.components.IconBadge
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.DeckGoals
import com.lingosnap.util.Lang
import com.lingosnap.util.tr
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/**
 * Optional goal date ("I want to know all cards by …"): shows what to do today and lets the AI write the day's plan.
 */
@Composable
fun GoalCard(deck: Deck, cards: List<Flashcard>, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var goal by remember(deck.id) { mutableStateOf(DeckGoals.get(deck.id)) }
    var aiText by remember(deck.id) { mutableStateOf(DeckGoals.planText(deck.id).orEmpty()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val hasKey = context.container.keyStore.hasKey

    fun pickDate() {
        val start = goal ?: LocalDate.now().plusDays(14)
        android.app.DatePickerDialog(
            context, { _, y, m, d ->
                goal = LocalDate.of(y, m + 1, d); DeckGoals.set(deck.id, goal); aiText = ""
            }, start.year, start.monthValue - 1, start.dayOfMonth,
        ).apply {
            datePicker.minDate = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        }.show()
    }

    fun generate() {
        val g = goal ?: return
        if (loading) return
        val p = DeckGoals.plan(cards, g)
        loading = true; error = null; aiText = ""
        scope.launch {
            val lang = if (deck.isLanguage && deck.sourceLang.isNotBlank() && deck.sourceLang != "auto") languageNameEn(deck.sourceLang) else ""
            val r = withTimeoutOrNull(45_000) {
                context.container.gemini.dailyPlan(
                    deck.name, lang, cards.size, p.remaining, p.daysLeft, p.newToday, p.due,
                    p.words.map { it.source to it.target }, onPartial = { aiText = it },
                )
            } ?: Result.failure(Exception(tr("Die KI antwortet zu langsam. Versuche es noch einmal.")))
            r.onSuccess { aiText = it; DeckGoals.savePlanText(deck.id, it) }.onFailure { error = it.message; aiText = "" }
            loading = false
        }
    }

    // once per day (and after the goal changed): ask the AI automatically
    LaunchedEffect(goal, hasKey) {
        if (goal != null && hasKey && cards.isNotEmpty() && aiText.isBlank() && !loading) generate()
    }

    Surface(modifier.fillMaxWidth().animateContentSize(), shape = RoundedCornerShape(28.dp), color = cs.surfaceContainer) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val g = goal
            if (g == null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Flag, 44, cs.secondaryContainer, cs.onSecondaryContainer)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(tr("Lernziel (optional)"), style = MaterialTheme.typography.titleMedium)
                        Text(tr("Bis wann willst du alle Karten können? Die KI plant dir jeden Tag."), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }
                FilledTonalButton(onClick = { pickDate() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.EditCalendar, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(tr("Datum wählen"))
                }
            } else {
                val p = DeckGoals.plan(cards, g)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Flag, 44, cs.primaryContainer, cs.onPrimaryContainer)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(tr("Ziel: {0}", g.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(Lang.locale))), style = MaterialTheme.typography.titleMedium.bold())
                        Text(
                            if (p.overdue) tr("Das Datum ist vorbei") else tr("Noch {0} Tage", p.daysLeft),
                            style = MaterialTheme.typography.bodyMedium, color = if (p.overdue) cs.error else cs.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { goal = null; DeckGoals.set(deck.id, null); aiText = "" }) { Icon(Icons.Rounded.Close, tr("Ziel entfernen")) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip(tr("Heute neu: {0}", p.newToday))
                    Chip(tr("Wiederholen: {0}", p.due))
                    Chip(tr("Offen: {0}", p.remaining))
                }
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerHigh) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(20.dp).padding(top = 2.dp), tint = cs.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            when {
                                aiText.isNotBlank() -> Text(aiText, style = MaterialTheme.typography.bodyMedium)
                                loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text(tr("Die KI plant deinen Tag …"), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                                }
                                error != null -> Text(error.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = cs.error)
                                !hasKey -> Text(tr("Für den KI-Tagesplan fehlt ein Schlüssel unter Optionen."), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                                else -> Text(tr("Tagesplan der KI"), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                            }
                        }
                        if (hasKey) IconButton(onClick = { generate() }, enabled = !loading, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Rounded.Refresh, tr("Neuer Plan"), Modifier.size(20.dp))
                        }
                    }
                }
                TextButton(onClick = { pickDate() }) {
                    Icon(Icons.Rounded.EditCalendar, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(tr("Datum ändern"))
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer) {
        Text(text, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
    }
}
