package com.lingosnap.ui.practice

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.StudyDir
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.delay

private const val PAIRS = 6

@Composable
fun MatchScreen(scope: StudyScope, id: Long, dir: String, onBack: () -> Unit) {
    val vm = rememberPractice(scope, id, "match", PAIRS)
    val cards = vm.cards

    val left = remember(cards) { cards.shuffled() }
    val right = remember(cards) { cards.shuffled() }
    var matched by remember { mutableStateOf(setOf<Long>()) }
    var selLeft by remember { mutableStateOf<Long?>(null) }
    var selRight by remember { mutableStateOf<Long?>(null) }
    var wrongPair by remember { mutableStateOf<Pair<Long, Long>?>(null) }
    var mistakes by remember { mutableIntStateOf(0) }
    var seconds by remember { mutableIntStateOf(0) }
    var awarded by remember { mutableIntStateOf(0) }
    var handled by remember { mutableStateOf(false) }

    val done = !vm.loading && cards.isNotEmpty() && matched.size == cards.size

    LaunchedEffect(vm.loading, done) {
        if (!vm.loading && !done) while (true) { delay(1000); seconds++ }
    }

    LaunchedEffect(selLeft, selRight) {
        val l = selLeft
        val r = selRight
        if (l != null && r != null) {
            if (l == r) {
                matched = matched + l
                cards.firstOrNull { it.id == l }?.let { vm.review(it, mistakes == 0, sound = false) }
                vm.feedback.correct()
                selLeft = null; selRight = null
            } else {
                mistakes++
                vm.feedback.wrong()
                wrongPair = l to r
                delay(550)
                wrongPair = null
                selLeft = null; selRight = null
            }
        }
    }

    val stars = when {
        mistakes == 0 && seconds <= 25 -> 3
        mistakes <= 2 && seconds <= 50 -> 2
        else -> 1
    }
    LaunchedEffect(done) {
        if (done && !handled) {
            handled = true
            awarded = stars * 6 + 4
            vm.finish(perfect = mistakes == 0, bonusXp = awarded)
        }
    }

    PracticeScaffold(
        title = "Zuordnen  •  ${seconds} s",
        progress = if (cards.isEmpty()) 0f else matched.size / cards.size.toFloat(),
        loading = vm.loading,
        onBack = onBack,
    ) {
        if (cards.isEmpty()) {
            Text("Dieses Deck hat noch keine Karten.", style = MaterialTheme.typography.titleMedium)
        } else if (done) {
            ResultPane(
                emoji = "",
                headline = "Geschafft in ${seconds}s",
                detail = (if (mistakes == 0) "Fehlerfrei" else "$mistakes Fehlversuche") + " • " + "★".repeat(stars),
                xp = awarded,
                confetti = stars >= 2,
                onBack = onBack,
            )
        } else {
            Text("Verbinde links und rechts, was zusammengehört", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    left.forEach { c ->
                        Tile(
                            text = c.front((dir == StudyDir.Reverse)),
                            cardId = c.id,
                            matched = c.id in matched,
                            selected = selLeft == c.id,
                            wrong = wrongPair?.first == c.id,
                            onClick = { if (wrongPair == null) selLeft = c.id },
                        )
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    right.forEach { c ->
                        Tile(
                            text = c.back((dir == StudyDir.Reverse)),
                            cardId = c.id,
                            matched = c.id in matched,
                            selected = selRight == c.id,
                            wrong = wrongPair?.second == c.id,
                            onClick = { if (wrongPair == null) selRight = c.id },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Tile(
    text: String,
    cardId: Long,
    matched: Boolean,
    selected: Boolean,
    wrong: Boolean,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shake = remember { Animatable(0f) }
    LaunchedEffect(wrong) {
        if (wrong) {
            repeat(3) {
                shake.animateTo(10f, tween(50))
                shake.animateTo(-10f, tween(50))
            }
            shake.animateTo(0f, tween(50))
        }
    }
    val bg by animateColorAsState(
        when {
            matched -> cs.primary
            wrong -> cs.errorContainer
            selected -> cs.tertiaryContainer
            else -> cs.surfaceContainerHigh
        },
        label = "tile$cardId",
    )
    val scale by animateFloatAsState(
        if (matched) 0.9f else if (selected) 1.05f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "tileScale",
    )
    val tileAlpha by animateFloatAsState(if (matched) 0.35f else 1f, label = "tileAlpha")
    val src = remember { MutableInteractionSource() }
    Surface(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .graphicsLayer { translationX = shake.value; scaleX = scale; scaleY = scale; this.alpha = tileAlpha }
            .pressScale(src, 0.95f),
        shape = MaterialTheme.shapes.medium,
        color = bg,
        contentColor = if (matched) cs.onPrimary else cs.onSurface,
    ) {
        Column(
            Modifier
                .clickable(enabled = !matched, interactionSource = src, indication = null, onClick = onClick)
                .padding(12.dp)
                .fillMaxWidth()
                .heightIn(min = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(text, style = MaterialTheme.typography.titleMedium.bold(), textAlign = TextAlign.Center)
        }
    }
}
