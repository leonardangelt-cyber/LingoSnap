package com.lingosnap.util

import com.lingosnap.data.remote.VocabPair
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/** Fast local import of structured files (txt, csv, tsv, json, markdown tables, Anki exports): no AI needed. */
object VocabImport {
    private val json = Json { isLenient = true; ignoreUnknownKeys = true }

    fun isStructuredName(name: String): Boolean {
        val l = name.lowercase()
        return l.endsWith(".txt") || l.endsWith(".csv") || l.endsWith(".tsv") || l.endsWith(".json") || l.endsWith(".md")
    }

    /** Returns the cards, or an empty list if the text is not a list of pairs (then the AI reads it instead). */
    fun parse(raw: String, name: String): List<VocabPair> {
        val text = raw.removePrefix("\uFEFF").trim()
        if (text.isEmpty()) return emptyList()
        val result = if (text.startsWith("[") || text.startsWith("{")) fromJson(text) else fromLines(text)
        return result
            .map { it.copy(source = it.source.trim(), target = it.target.trim(), example = it.example?.trim()?.takeIf { e -> e.isNotEmpty() }) }
            .filter { it.source.isNotEmpty() && it.target.isNotEmpty() }
            .distinctBy { it.source.lowercase() to it.target.lowercase() }
    }

    /* ───── JSON ───── */

    internal val frontKeys = listOf("front", "source", "question", "word", "term", "vorderseite", "frage", "wort", "begriff")
    internal val backKeys = listOf("back", "target", "answer", "translation", "meaning", "rückseite", "antwort", "übersetzung", "bedeutung")
    internal val exampleKeys = listOf("example", "sentence", "beispiel")

    private fun fromJson(text: String): List<VocabPair> {
        val root = runCatching { json.parseToJsonElement(text) }.getOrNull() ?: return fromLines(text)
        val items: JsonArray = when (root) {
            is JsonArray -> root
            is JsonObject -> listOf("cards", "pairs", "vocabulary", "items", "data", "karten").firstNotNullOfOrNull { (root[it] as? JsonArray) }
                ?: (root.values.firstOrNull { it is JsonArray } as? JsonArray)
                ?: JsonArray(emptyList())
            else -> JsonArray(emptyList())
        }
        return items.mapNotNull { pairOf(it) }
    }

    private fun str(e: JsonElement?): String? = (e as? JsonPrimitive)?.content?.takeIf { it.isNotBlank() }

    /** One JSON entry (object with front/back or synonyms, or a [front, back, example] array) as a card. */
    internal fun pairOf(e: JsonElement): VocabPair? = when (e) {
        is JsonObject -> {
            val keys = e.keys.associateBy { it.lowercase() }
            fun pick(names: List<String>) = names.firstNotNullOfOrNull { n -> keys[n]?.let { str(e[it]) } }
            val a = pick(frontKeys); val b = pick(backKeys)
            if (a != null && b != null) VocabPair(
                a, b, pick(exampleKeys),
                lang = keys["lang"]?.let { str(e[it]) }?.takeIf { it.length in 2..5 },
                figure = (keys["figure"]?.let { e[it] } as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.content?.toFloatOrNull() }
                    ?.takeIf { f -> f.size == 5 && f.drop(1).all { v -> v in 0f..1f } },
            ) else null
        }
        is JsonArray -> {
            val a = str(e.getOrNull(0)); val b = str(e.getOrNull(1))
            if (a != null && b != null) VocabPair(a, b, str(e.getOrNull(2))) else null
        }
        else -> null
    }

    /* ───── text lines ───── */

    private val example = Regex("""\s*[\(\[]\s*(?:Beispiel|Example|Bsp\.?|z\. ?B\.?|e\.g\.)\s*:?\s*(.+?)\s*[\)\]]\s*$""", RegexOption.IGNORE_CASE)

    private fun fromLines(text: String): List<VocabPair> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("//") }
        if (lines.isEmpty()) return emptyList()
        // markdown table: | a | b |
        if (lines.count { it.startsWith("|") } >= 2) {
            return lines.filter { it.startsWith("|") && !it.matches(Regex("""\|[\s:\-|]+\|?""")) }.mapNotNull { l ->
                val c = l.trim('|').split("|").map { it.trim() }
                if (c.size >= 2) pair(c[0], c[1], c.getOrNull(2)) else null
            }.let { dropHeader(it) }
        }
        val delim = listOf("\t", ";", ",").firstOrNull { d -> lines.count { csvSplit(it, d[0]).size >= 2 } * 10 >= lines.size * 8 }
        val out = ArrayList<VocabPair>()
        var parsed = 0
        for (l in lines) {
            val cols = if (delim != null) csvSplit(l, delim[0]) else splitBySeparator(l)
            if (cols != null && cols.size >= 2) { pair(cols[0], cols[1], cols.getOrNull(2))?.let { out += it; parsed++ } }
        }
        // running text with only a few separators is not a vocabulary list: leave it to the AI
        if (parsed * 10 < lines.size * 6) return emptyList()
        return if (delim != null) dropHeader(out) else out
    }

    private fun dropHeader(list: List<VocabPair>): List<VocabPair> {
        val h = list.firstOrNull() ?: return list
        val names = (frontKeys + backKeys + listOf("german", "english", "deutsch", "englisch", "spanish", "spanisch", "language"))
        return if (h.source.lowercase() in names && h.target.lowercase() in names) list.drop(1) else list
    }

    private fun pair(a: String, b: String, c: String?): VocabPair? {
        var front = a.trim(); var back = b.trim(); var ex = c?.trim()?.takeIf { it.isNotEmpty() }
        if (ex == null) {
            example.find(back)?.let { ex = it.groupValues[1]; back = back.removeRange(it.range).trim() }
            if (ex == null) example.find(front)?.let { ex = it.groupValues[1]; front = front.removeRange(it.range).trim() }
        }
        if (front.isEmpty() || back.isEmpty()) return null
        return VocabPair(front, back, ex)
    }

    /** CSV split with "quoted, fields". Null if the line does not contain the delimiter. */
    private fun csvSplit(line: String, d: Char): List<String> {
        val out = ArrayList<String>(); val sb = StringBuilder(); var q = false; var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && q && line.getOrNull(i + 1) == '"' -> { sb.append('"'); i++ }
                c == '"' -> q = !q
                c == d && !q -> { out += sb.toString().trim(); sb.clear() }
                else -> sb.append(c)
            }
            i++
        }
        out += sb.toString().trim()
        return out
    }

    private val separators = listOf("\t", " -> ", "->", " => ", "=>", " - ", " – ", " — ", " = ", "=", ": ", ":", " | ", "|")

    private fun splitBySeparator(line: String): List<String>? {
        val sep = separators.firstOrNull { line.contains(it) } ?: return null
        return line.split(sep, limit = 3).map { it.trim() }
    }
}
