package com.lingosnap.util

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.provider.OpenableColumns
import com.lingosnap.data.Backup
import com.lingosnap.data.ImportedCard
import com.lingosnap.data.ImportedDeck
import com.lingosnap.data.model.SupportedLanguages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.util.zip.ZipInputStream

/** [hasMeta] = the file itself says deck type and languages, otherwise the user has to choose. */
class ParsedImport(val decks: List<ImportedDeck>, val hasMeta: Boolean)

/** Reads decks from: LingoSnap backups (.json), text/CSV/TSV (Quizlet, Anki, spreadsheets), our text export and Anki packages (.apkg). */
object ImportParsers {
    val MIME_TYPES = arrayOf("*/*")

    suspend fun parse(context: Context, uri: Uri): ParsedImport = withContext(Dispatchers.IO) {
        val name = displayName(context, uri)
        val lower = name.lowercase()
        val baseName = name.substringBeforeLast('.').ifBlank { "Import" }
        val result: ParsedImport = when {
            lower.endsWith(".apkg") || lower.endsWith(".colpkg") -> ParsedImport(readAnki(context, uri), false)
            else -> {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    .removePrefix("﻿")
                val backup = if (lower.endsWith(".json") || text.trimStart().startsWith("{")) Backup.parse(text) else null
                if (backup != null) ParsedImport(backup, true) else parseText(text, baseName)
            }
        }
        val decks = result.decks.filter { it.cards.isNotEmpty() }
        if (decks.isEmpty()) throw IllegalArgumentException(tr("In der Datei wurden keine Vokabeln gefunden."))
        ParsedImport(decks, result.hasMeta)
    }

    private fun displayName(context: Context, uri: Uri): String =
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment.orEmpty()

    /* ───── text ───── */

    private val header = Regex("^#\\s+(.+?)(?:\\s+\\((.*)\\))?\\s*$")
    private val delimiters = listOf("\t", ";", "|", " - ", " – ", " = ", ",", ":")

    fun parseText(text: String, defaultName: String): ParsedImport {
        data class Acc(val name: String, val kind: String?, val src: String?, val tgt: String?, val lines: MutableList<String> = mutableListOf())
        val decks = mutableListOf<Acc>()
        var current: Acc? = null
        var hasMeta = false
        for (raw in text.lines()) {
            val line = raw.trimEnd()
            if (line.isBlank()) continue
            val h = header.matchEntire(line.trim())
            if (h != null) {
                val label = h.groupValues[2]
                var kind: String? = null; var s: String? = null; var t: String? = null
                if (label.equals("Karteikarten", true)) kind = "cards"
                else if ("→" in label) {
                    kind = "language"
                    s = tagOf(label.substringBefore("→")); t = tagOf(label.substringAfter("→"))
                }
                if (kind != null) hasMeta = true
                current = Acc(h.groupValues[1].trim(), kind, s, t).also { decks += it }
                continue
            }
            if (line.startsWith("#")) continue // Anki comment lines like #separator:tab
            if (current == null) current = Acc(defaultName, null, null, null).also { decks += it }
            current.lines += line
        }
        if (decks.any { it.kind == null }) hasMeta = false
        val all = decks.flatMap { it.lines }
        val delim = delimiters.firstOrNull { d -> all.count { d in it } >= (all.size * 0.6).toInt().coerceAtLeast(1) }
            ?: throw IllegalArgumentException(tr("Das Format wurde nicht erkannt. Erwartet wird pro Zeile „Wort;Übersetzung“ (auch Tab oder Komma)."))
        val parsed = decks.map { d ->
            ImportedDeck(
                d.name, d.kind, d.src, d.tgt, "",
                d.lines.mapNotNull { splitLine(it, delim) },
            )
        }
        return ParsedImport(parsed, hasMeta)
    }

    private fun tagOf(label: String): String? {
        val l = label.trim()
        if (l.equals("Automatisch erkannt", true) || l.startsWith("Automatisch") || l.startsWith("Sprache")) return "auto"
        return SupportedLanguages.firstOrNull { it.label.equals(l, true) }?.tag
    }

    private fun splitLine(line: String, delim: String): ImportedCard? {
        val parts = if (delim.length == 1 && (delim == ";" || delim == ",")) csv(line, delim[0])
        else line.split(delim, limit = 3)
        val cleaned = parts.map { clean(it) }
        val s = cleaned.getOrNull(0).orEmpty()
        val t = cleaned.getOrNull(1).orEmpty()
        if (s.isBlank() || t.isBlank()) return null
        return ImportedCard(s, t, cleaned.getOrNull(2)?.takeIf { it.isNotBlank() })
    }

    /** Splits one CSV line and respects "quoted, fields". */
    private fun csv(line: String, d: Char): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == d && !quoted -> { out += sb.toString(); sb.clear() }
                else -> sb.append(c)
            }
            i++
        }
        out += sb.toString()
        return out
    }

    private fun clean(s: String) = s.replace(Regex("<[^>]*>"), " ").replace(Regex("\\[sound:[^]]*]"), "")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("\\s+"), " ").trim().trim('"').trim()

    /* ───── Anki package ───── */

    private fun readAnki(context: Context, uri: Uri): List<ImportedDeck> {
        val dbFile = File(context.cacheDir, "anki_import.db")
        var found = false
        var onlyNew = false
        context.contentResolver.openInputStream(uri)?.let { ZipInputStream(it) }?.use { zip ->
            val best = HashMap<String, ByteArray>()
            while (true) {
                val e = zip.nextEntry ?: break
                when (e.name) {
                    "collection.anki21", "collection.anki2" -> best[e.name] = zip.readBytes()
                    "collection.anki21b" -> onlyNew = true
                }
            }
            val bytes = best["collection.anki21"] ?: best["collection.anki2"]
            if (bytes != null) { dbFile.writeBytes(bytes); found = true }
        }
        if (!found) {
            throw IllegalArgumentException(
                if (onlyNew) tr("Dieses Anki-Paket nutzt das neue Format. Exportiere in Anki bitte als „Notizen als Text“ oder mit „Ältere Versionen unterstützen“.")
                else tr("Das Anki-Paket konnte nicht gelesen werden."),
            )
        }
        val db = SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val names = HashMap<Long, String>()
            db.rawQuery("select decks from col", null).use { c ->
                if (c.moveToFirst()) {
                    val obj = Json.parseToJsonElement(c.getString(0)).jsonObject
                    obj.forEach { (id, v) -> names[id.toLong()] = v.jsonObject["name"]?.jsonPrimitive?.content ?: "Anki" }
                }
            }
            val byDeck = LinkedHashMap<Long, MutableList<ImportedCard>>()
            db.rawQuery("select c.did, n.flds from notes n join cards c on c.nid = n.id group by n.id", null).use { c ->
                while (c.moveToNext()) {
                    val fields = c.getString(1).split('\u001f').map { clean(it) }
                    val s = fields.getOrNull(0).orEmpty(); val t = fields.getOrNull(1).orEmpty()
                    if (s.isNotBlank() && t.isNotBlank()) byDeck.getOrPut(c.getLong(0)) { mutableListOf() } += ImportedCard(s, t)
                }
            }
            return byDeck.map { (id, cards) -> ImportedDeck(names[id] ?: "Anki", null, null, null, "", cards) }
        } finally {
            db.close()
            dbFile.delete()
        }
    }
}
