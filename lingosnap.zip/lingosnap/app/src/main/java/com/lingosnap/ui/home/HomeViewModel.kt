package com.lingosnap.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Mastery
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val cards: List<Flashcard> = emptyList(),
    val due: Int = 0,
    val mastered: Int = 0,
    val loading: Boolean = true,
)

class HomeViewModel(private val repo: CardRepository) : ViewModel() {

    val state: StateFlow<HomeUiState> = repo.observeCards()
        .map { cards ->
            val now = System.currentTimeMillis()
            HomeUiState(
                cards = cards,
                due = cards.count { it.dueAt <= now },
                mastered = cards.count { Mastery.of(it.level) == Mastery.Mastered },
                loading = false,
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun delete(card: Flashcard) = viewModelScope.launch { repo.delete(card) }

    companion object {
        val Factory = viewModelFactory { initializer { HomeViewModel(app().container.repository) } }
    }
}
