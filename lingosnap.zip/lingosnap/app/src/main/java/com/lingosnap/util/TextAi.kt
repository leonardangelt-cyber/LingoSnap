package com.lingosnap.util

import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.lingosnap.data.remote.VocabPair
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** A translation and the side of the card it belongs to: [foreign] = the language that is learned, otherwise the translation language. */
class Translated(val text: String, val foreign: Boolean)

/**
 * Language detection and translation on the phone (Google ML Kit): the languages are read from the text, and the translation models
 * (one per language, downloaded once, afterwards no internet is needed) translate between the deck's two languages.
 */
object TextAi {
    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { c.resume(it) }
        addOnFailureListener { c.resumeWithException(it) }
        addOnCanceledListener { c.cancel() }
    }

    private val identifier by lazy {
        LanguageIdentification.getClient(LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.01f).build())
    }

    /** How likely the text is in which language: tag to 0..1 (empty when unknown). */
    suspend fun languages(text: String): Map<String, Float> {
        if (text.isBlank()) return emptyMap()
        return runCatching {
            identifier.identifyPossibleLanguages(text.trim()).await()
                .filter { it.languageTag != "und" }.associate { it.languageTag to it.confidence }
        }.getOrDefault(emptyMap())
    }

    /**
     * Puts the foreign word first and the translation second, for every pair, from the languages of the texts and the deck's languages.
     * A list is judged as a whole: unclear lines follow the way round the rest of the list is written.
     */
    suspend fun orient(pairs: List<VocabPair>, source: String, target: String): List<VocabPair> {
        if (pairs.isEmpty() || source == target) return pairs
        val diffs = pairs.map { Orient.diff(languages(it.source), languages(it.target), source, target) }
        val swap = Orient.decide(diffs)
        return pairs.mapIndexed { i, p -> if (swap[i]) p.copy(source = p.target, target = p.source) else p }
    }

    private val translators = HashMap<String, Translator>()
    private fun translator(from: String, to: String): Translator? {
        val f = TranslateLanguage.fromLanguageTag(Orient.base(from)) ?: return null
        val t = TranslateLanguage.fromLanguageTag(Orient.base(to)) ?: return null
        return synchronized(translators) {
            translators.getOrPut("$f>$t") { Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(f).setTargetLanguage(t).build()) }
        }
    }

    /** True when the phone can translate between the two languages. */
    fun supports(from: String, to: String) = translator(from, to) != null

    /** Set by the app: a better, dictionary-like translation (needs the AI key and a connection); null = not available. */
    @Volatile var smart: (suspend (text: String, from: String, to: String) -> String?)? = null

    suspend fun translate(text: String, from: String, to: String): Result<String> {
        smart?.let { s -> val r = runCatching { s(text, from, to) }.getOrNull(); if (!r.isNullOrBlank()) return Result.success(r) }
        return translateOnDevice(text, from, to)
    }

    suspend fun translateOnDevice(text: String, from: String, to: String): Result<String> = runCatching {
        val engine = translator(from, to) ?: error(tr("Diese Sprache kann nicht übersetzt werden."))
        engine.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        engine.translate(text.trim()).await().trim()
    }.recoverCatching { e ->
        if (e is kotlinx.coroutines.CancellationException) throw e
        throw IllegalStateException(tr("Übersetzen nicht möglich. Beim ersten Mal wird das Sprachpaket geladen – dafür braucht das Handy Internet."), e)
    }

    /**
     * Translates a word into the other language of the deck: a text in the translation language becomes the foreign word, any other text
     * the translation. For a deck with an unknown ("auto") foreign language only a foreign text can be translated.
     */
    suspend fun translateFor(text: String, source: String, target: String): Result<Translated> {
        val langs = languages(text)
        val known = source.isNotBlank() && source != "auto"
        val top = langs.maxByOrNull { it.value }?.key
        val isTarget = if (known) {
            val pt = langs.entries.filter { Orient.base(it.key) == Orient.base(target) }.sumOf { it.value.toDouble() }
            val ps = langs.entries.filter { Orient.base(it.key) == Orient.base(source) }.sumOf { it.value.toDouble() }
            pt > ps
        } else top != null && Orient.base(top) == Orient.base(target)
        return when {
            known && isTarget -> translate(text, target, source).map { Translated(it, foreign = true) }
            known -> translate(text, source, target).map { Translated(it, foreign = false) }
            isTarget -> Result.failure(IllegalStateException(tr("Die Sprache des Decks wird automatisch erkannt. Schreibe das Fremdwort – es wird dann übersetzt.")))
            top == null -> Result.failure(IllegalStateException(tr("Die Sprache konnte nicht erkannt werden.")))
            else -> translate(text, top, target).map { Translated(it, foreign = false) }
        }
    }
}
