package com.lingosnap.ui.deck

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lingosnap.container
import com.lingosnap.data.model.Deck
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.create.LanguageField
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/** Change name, languages or subject of an existing deck. */
@Composable
fun EditDeckDialog(deck: Deck, onDismiss: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(deck.name) }
    var source by remember { mutableStateOf(deck.sourceLang) }
    var target by remember { mutableStateOf(deck.targetLang) }
    var subject by remember { mutableStateOf(deck.description) }
    var busy by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = { if (!busy) onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.padding(16.dp), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainerHigh) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Deck bearbeiten", style = MaterialTheme.typography.headlineSmall.bold())
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    AppTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Name des Decks") }, singleLine = true)
                    if (deck.isLanguage) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LanguageField("Ich lerne", source, Modifier.weight(1f), allowAuto = true) { source = it }
                            IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                                Icon(Icons.Rounded.SwapHoriz, "Tauschen")
                            }
                            LanguageField("Meine Sprache", target, Modifier.weight(1f)) { target = it }
                        }
                        Text(
                            "Die Sprachen gelten für alle Karten dieses Decks (Vorlesen und Anzeige).",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    } else {
                        AppTextField(
                            subject, { subject = it }, Modifier.fillMaxWidth(),
                            label = { Text("Worum geht es? (hilft der KI)") }, minLines = 2,
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss, enabled = !busy) { Text("Abbrechen") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = !busy && name.isNotBlank(),
                        onClick = {
                            busy = true
                            scope.launch {
                                repo.updateDeck(deck, name, source, target, subject)
                                onDismiss()
                            }
                        },
                    ) { Text("Speichern") }
                }
            }
        }
    }
}
