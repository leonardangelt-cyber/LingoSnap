package com.lingosnap.ui.study

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.languageNameEn
import com.lingosnap.ui.components.IconBadge
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.tr
import kotlinx.coroutines.launch

/**
 * Chat with the AI. With a [card] the questions are about that card (differences, examples, usage);
 * without one it is a free chat about learning and the app. The answer is typed out letter by letter.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatSheet(card: Flashcard?, onDismiss: () -> Unit) {
    val gemini = LocalContext.current.container.gemini
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val language = card?.sourceLang?.isNotBlank() == true
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scroll = rememberScrollState()
    // the answer that is being "typed": latest text from the stream and how many letters are shown so far
    var target by remember { mutableStateOf("") }
    var revealed by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            if (revealed < target.length) {
                revealed = (revealed + maxOf(2, (target.length - revealed) / 12)).coerceAtMost(target.length)
                delay(18)
            } else delay(40)
        }
    }
    LaunchedEffect(messages.size, loading, revealed / 12) { scroll.scrollTo(scroll.maxValue) }

    var elapsed by remember { mutableIntStateOf(0) }
    var retryIn by remember { mutableIntStateOf(0) }
    var lastQuestion by remember { mutableStateOf("") }
    LaunchedEffect(loading) {
        elapsed = 0
        while (loading) { delay(1000); elapsed++ }
    }
    LaunchedEffect(retryIn > 0) { while (retryIn > 0) { delay(1000); retryIn-- } }

    fun ask(q: String, retry: Boolean = false) {
        if (loading || q.isBlank()) return
        // on a retry the question is already in the list
        val history = if (retry && messages.lastOrNull()?.first == true) messages.dropLast(1) else messages.toList()
        if (!retry) messages += true to q.trim()
        lastQuestion = q.trim()
        input = ""; loading = true; error = null; retryIn = 0; target = ""; revealed = 0
        scope.launch {
            val partial: (String) -> Unit = { target = it }
            val r = kotlinx.coroutines.withTimeoutOrNull(45_000) {
                if (card != null) gemini.chatAbout(card.source, card.target, if (language) languageNameEn(card.sourceLang) else "", history, q.trim(), partial)
                else gemini.chatGeneral(history, q.trim(), partial)
            } ?: Result.failure(Exception(tr("Die KI antwortet zu langsam. Versuche es noch einmal.")))
            r.onSuccess { full ->
                target = full
                while (revealed < full.length) delay(20)
                messages += false to full
            }.onFailure { e ->
                error = e.message ?: tr("Die KI hat nicht geantwortet")
                // rate limit: say how long to wait (the API names it in its message, e.g. "retry in 23s")
                if (e is com.lingosnap.data.remote.GeminiException.Http && e.code == 429) {
                    retryIn = Regex("(\\d+)(?:\\.\\d+)?\\s*s", RegexOption.IGNORE_CASE).find(e.detail.substringAfter("retry in", ""))?.groupValues?.get(1)?.toIntOrNull()?.plus(1)?.coerceIn(5, 120) ?: 30
                }
            }
            target = ""; revealed = 0
            loading = false
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerLow,
        shape = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
    ) {
        Column(Modifier.navigationBarsPadding().imePadding().padding(bottom = 12.dp)) {
            // header: Axi + what we talk about
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Icons.Rounded.SmartToy, 56, cs.primaryContainer, cs.onPrimaryContainer)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr("Lern-Chat"), style = MaterialTheme.typography.titleLarge.bold())
                    Text(
                        if (card != null) tr("Fragen zu dieser Karte") else tr("Frag mich zum Lernen oder zur App"),
                        style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
                    )
                }
            }
            if (card != null) Surface(
                Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth(),
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerHigh,
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Style, null, Modifier.size(20.dp), tint = cs.primary)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(card.source, style = MaterialTheme.typography.titleMedium.bold(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(card.target, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            // conversation
            Column(
                Modifier.heightIn(min = 120.dp, max = 340.dp).verticalScroll(scroll).padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (messages.isEmpty()) Bubble(false, if (card != null) tr("Hallo! Was möchtest du über diese Karte wissen?") else tr("Hallo! Ich helfe dir beim Lernen und erkläre dir die App."))
                messages.forEach { (user, text) -> Bubble(user, text) }
                if (loading) { if (revealed > 0) Bubble(false, target.take(revealed) + "▍") else TypingBubble(if (elapsed == 0) tr("Wird gesendet …") else tr("Die KI antwortet … {0} s", elapsed)) }
                error?.let { msg ->
                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = cs.errorContainer, contentColor = cs.onErrorContainer) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(msg, style = MaterialTheme.typography.bodyMedium)
                            if (retryIn > 0) Text(tr("Neuer Versuch in {0} s möglich.", retryIn), style = MaterialTheme.typography.labelLarge)
                            androidx.compose.material3.FilledTonalButton(onClick = { ask(lastQuestion, retry = true) }, enabled = retryIn == 0 && !loading) {
                                Text(tr("Erneut versuchen"))
                            }
                        }
                    }
                }
            }
            // quick questions
            if (messages.isEmpty()) {
                val ideas: List<Pair<ImageVector, String>> = when {
                    card == null -> listOf(
                        Icons.Rounded.Lightbulb to tr("Wie lerne ich am besten?"),
                        Icons.Rounded.HelpOutline to tr("Was kann die App?"),
                        Icons.Rounded.FormatListBulleted to tr("Wie lege ich ein Deck an?"),
                    )
                    language -> listOf(
                        Icons.Rounded.CompareArrows to tr("Wie unterscheidet es sich von ähnlichen Wörtern?"),
                        Icons.Rounded.FormatListBulleted to tr("Gib mir drei weitere Beispiele"),
                        Icons.Rounded.HelpOutline to tr("Wann benutze ich es nicht?"),
                    )
                    else -> listOf(
                        Icons.Rounded.Lightbulb to tr("Erkläre es mir einfacher"),
                        Icons.Rounded.FormatListBulleted to tr("Gib mir ein Beispiel aus dem Alltag"),
                        Icons.Rounded.CompareArrows to tr("Was verwechselt man damit oft?"),
                    )
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ideas.forEach { (icon, text) ->
                        AssistChip(
                            onClick = { ask(text) }, label = { Text(text) },
                            leadingIcon = { Icon(icon, null, Modifier.size(AssistChipDefaults.IconSize), tint = cs.primary) },
                            shape = CircleShape,
                        )
                    }
                }
            }
            // input pill
            Surface(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth(),
                shape = CircleShape, color = cs.surfaceContainerHighest,
            ) {
                Row(Modifier.padding(start = 20.dp, end = 6.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        if (input.isEmpty()) Text(if (card != null) tr("Frage zu dieser Karte") else tr("Schreibe eine Nachricht"), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
                        BasicTextField(
                            input, { input = it }, Modifier.fillMaxWidth(),
                            textStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface),
                            cursorBrush = SolidColor(cs.primary),
                            maxLines = 4,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { ask(input) }),
                        )
                    }
                    FilledIconButton(onClick = { ask(input) }, enabled = input.isNotBlank() && !loading, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Rounded.Send, tr("Senden"))
                    }
                }
            }
        }
    }
}

@Composable
private fun Bubble(user: Boolean, text: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
        if (!user) {
            IconBadge(Icons.Rounded.SmartToy, 32, cs.primaryContainer, cs.onPrimaryContainer)
            Spacer(Modifier.width(8.dp))
        }
        Surface(
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (user) 20.dp else 6.dp, bottomEnd = if (user) 6.dp else 20.dp),
            color = if (user) cs.primary else cs.surfaceContainerHigh,
            contentColor = if (user) cs.onPrimary else cs.onSurface,
            modifier = Modifier.widthIn(max = 300.dp),
        ) { Text(text, Modifier.padding(horizontal = 16.dp, vertical = 12.dp), style = MaterialTheme.typography.bodyLarge) }
    }
}

@Composable
private fun TypingBubble(label: String) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "typing")
    Row(verticalAlignment = Alignment.Bottom) {
        IconBadge(Icons.Rounded.SmartToy, 32, cs.primaryContainer, cs.onPrimaryContainer)
        Spacer(Modifier.width(8.dp))
        Surface(shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerHigh) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                for (i in 0..2) {
                    val y by t.animateFloat(0f, -6f, infiniteRepeatable(tween(420, delayMillis = i * 140), RepeatMode.Reverse), label = "dot$i")
                    Box(Modifier.offset(y = y.dp).size(8.dp).clip(CircleShape).background(cs.onSurfaceVariant))
                }
                Spacer(Modifier.width(6.dp))
                Text(label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            }
        }
    }
}
