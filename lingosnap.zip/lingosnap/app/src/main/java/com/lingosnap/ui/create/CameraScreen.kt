package com.lingosnap.ui.create

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FlashAuto
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Full-screen in-app camera: live preview, tap to focus, pinch to zoom, flash modes and
 * several shots in one go. The photos are handed back as content URIs.
 */
@Composable
fun CameraDialog(onDone: (List<Uri>) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    val shots = remember { mutableStateListOf<Uri>() }
    var confirmDiscard by remember { mutableStateOf(false) }

    fun close() {
        if (shots.isEmpty()) onClose() else confirmDiscard = true
    }

    Dialog(
        onDismissRequest = { close() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnClickOutside = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            var granted by remember {
                mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            }
            var asked by remember { mutableStateOf(false) }
            val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
                granted = it
                asked = true
            }
            LaunchedEffect(Unit) { if (!granted) permission.launch(Manifest.permission.CAMERA) }

            if (granted) {
                CameraContent(shots = shots, onClose = { close() }, onDone = { onDone(shots.toList()) })
            } else {
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Kamera-Zugriff nötig", color = Color.White, style = MaterialTheme.typography.titleLarge.bold())
                    Text(
                        "LingoSnap braucht die Kamera, um Seiten und Notizen zu fotografieren. Die Bilder bleiben auf deinem Gerät, bis du sie auswertest.",
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
                    )
                    Button(onClick = {
                        if (asked) {
                            context.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        } else permission.launch(Manifest.permission.CAMERA)
                    }) { Text(if (asked) "Einstellungen öffnen" else "Zugriff erlauben") }
                    TextButton(onClick = onClose) { Text("Abbrechen", color = Color.White) }
                }
            }

            if (confirmDiscard) {
                AlertDialog(
                    onDismissRequest = { confirmDiscard = false },
                    title = { Text("Aufnahmen verwerfen?") },
                    text = { Text("${shots.size} Aufnahmen wurden noch nicht ausgewertet.") },
                    confirmButton = {
                        TextButton(onClick = {
                            shots.forEach { deleteShot(context, it) }
                            shots.clear()
                            confirmDiscard = false
                            onClose()
                        }) { Text("Verwerfen") }
                    },
                    dismissButton = { TextButton(onClick = { confirmDiscard = false }) { Text("Weiter fotografieren") } },
                )
            }
        }
    }
}

@Composable
private fun CameraContent(shots: MutableList<Uri>, onClose: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(ImageCapture.FLASH_MODE_AUTO)
            .build()
    }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var capturing by remember { mutableStateOf(false) }
    var focusAt by remember { mutableStateOf<androidx.compose.ui.geometry.Offset?>(null) }
    val focusAlpha = remember { Animatable(0f) }
    val shutterFlash = remember { Animatable(0f) }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                p.unbindAll()
                camera = p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            } catch (e: Exception) {
                error = "Die Kamera konnte nicht gestartet werden."
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose { runCatching { provider?.unbindAll() } }
    }

    LaunchedEffect(flashMode) { imageCapture.flashMode = flashMode }

    fun capture() {
        if (capturing) return
        capturing = true
        val dir = File(context.cacheDir, "images").apply { mkdirs() }
        val file = File.createTempFile("scan_", ".jpg", dir)
        imageCapture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    shots.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                    capturing = false
                }

                override fun onError(exception: ImageCaptureException) {
                    file.delete()
                    capturing = false
                    error = "Das Foto konnte nicht gespeichert werden."
                }
            },
        )
    }

    LaunchedEffect(focusAt) {
        if (focusAt != null) {
            focusAlpha.snapTo(1f)
            focusAlpha.animateTo(0f, tween(900))
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        // top bar
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onClose,
                colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White),
            ) { Icon(Icons.Rounded.Close, "Schließen") }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Text(
                    if (shots.isEmpty()) "Seite fotografieren" else "${shots.size} ${if (shots.size == 1) "Aufnahme" else "Aufnahmen"}",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            IconButton(
                onClick = {
                    flashMode = when (flashMode) {
                        ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                        ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                        else -> ImageCapture.FLASH_MODE_AUTO
                    }
                },
                colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White),
            ) {
                Icon(
                    when (flashMode) {
                        ImageCapture.FLASH_MODE_ON -> Icons.Rounded.FlashOn
                        ImageCapture.FLASH_MODE_OFF -> Icons.Rounded.FlashOff
                        else -> Icons.Rounded.FlashAuto
                    },
                    "Blitz",
                )
            }
        }

        // viewfinder
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .aspectRatio(3f / 4f, matchHeightConstraintsFirst = true)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF111111))
                    .pointerInput(camera) {
                        detectTapGestures { offset ->
                            val cam = camera ?: return@detectTapGestures
                            focusAt = offset
                            val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                            cam.cameraControl.startFocusAndMetering(
                                FocusMeteringAction.Builder(point)
                                    .setAutoCancelDuration(3, TimeUnit.SECONDS)
                                    .build(),
                            )
                        }
                    }
                    .pointerInput(camera) {
                        detectTransformGestures { _, _, zoom, _ ->
                            val cam = camera ?: return@detectTransformGestures
                            val state = cam.cameraInfo.zoomState.value ?: return@detectTransformGestures
                            cam.cameraControl.setZoomRatio((state.zoomRatio * zoom).coerceIn(state.minZoomRatio, state.maxZoomRatio))
                        }
                    },
            ) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                focusAt?.let { p ->
                    Box(
                        Modifier
                            .offset { IntOffset((p.x - with(density) { 28.dp.toPx() }).roundToInt(), (p.y - with(density) { 28.dp.toPx() }).roundToInt()) }
                            .size(56.dp)
                            .scale(0.8f + 0.2f * focusAlpha.value)
                            .border(2.dp, Color.White.copy(alpha = focusAlpha.value), CircleShape),
                    )
                }
                Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = shutterFlash.value)))
                error?.let {
                    Text(
                        it,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    )
                }
            }
        }

        // thumbnails of what has been taken
        if (shots.isNotEmpty()) {
            LazyRow(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(shots.toList(), key = { it.toString() }) { uri ->
                    Thumb(uri) {
                        shots.remove(uri)
                        deleteShot(context, uri)
                    }
                }
            }
        }

        // shutter row
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f))
            val source = remember { MutableInteractionSource() }
            val pressed by source.collectIsPressedAsState()
            val inner by animateFloatAsState(if (pressed || capturing) 0.82f else 1f, tween(90), label = "shutter")
            Box(
                Modifier
                    .size(80.dp)
                    .border(4.dp, Color.White, CircleShape)
                    .padding(8.dp)
                    .scale(inner)
                    .clip(CircleShape)
                    .background(if (capturing) Color.White.copy(alpha = 0.6f) else Color.White)
                    .clickable(interactionSource = source, indication = null, enabled = camera != null && !capturing) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        capture()
                    },
            )
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                if (shots.isNotEmpty()) {
                    Button(onClick = onDone) { Text("Fertig (${shots.size})") }
                }
            }
        }
    }

    LaunchedEffect(capturing) {
        if (capturing) {
            shutterFlash.snapTo(0.7f)
            shutterFlash.animateTo(0f, tween(220))
        }
    }
}

@Composable
private fun Thumb(uri: Uri, onRemove: () -> Unit) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            }.getOrNull()
        }
    }
    Box(Modifier.size(width = 52.dp, height = 68.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF222222)).clickable(onClick = onRemove)) {
        bitmap?.let {
            Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(3.dp).size(18.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Close, "Entfernen", tint = Color.White, modifier = Modifier.size(12.dp)) }
    }
}

private fun deleteShot(context: android.content.Context, uri: Uri) {
    runCatching { uri.lastPathSegment?.let { File(File(context.cacheDir, "images"), it.substringAfterLast('/')).delete() } }
}
