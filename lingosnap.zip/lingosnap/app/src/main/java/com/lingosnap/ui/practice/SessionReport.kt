package com.lingosnap.ui.practice

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Flashcard
import com.lingosnap.ui.components.IconBadge
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.tr

/** How a part of the session is coloured in the bar: strong, solid, so-so, bad. */
enum class Tone { Easy, Good, Okay, Bad }

class ReportSegment(val label: String, val count: Int, val tone: Tone)

/** A card in the lists below the bar; [given] is what the learner answered (typing, multiple choice), [times] how often it went wrong. */
class ReportItem(val card: Flashcard, val given: String? = null, val times: Int = 1)

/**
 * Everything the "session over" screen shows besides the ring: the breakdown, the time, the cards that went wrong (with the answer given),
 * the cards that were known, and when the cards come back. Every learning mode fills what it knows; empty parts are not shown.
 */
class SessionReport(
    val total: Int,
    val segments: List<ReportSegment> = emptyList(),
    val seconds: Int = 0,
    val missed: List<ReportItem> = emptyList(),
    val known: List<ReportItem> = emptyList(),
    /** Next review time (ms) of every card that was reviewed in the repetition system. */
    val dueAts: List<Long> = emptyList(),
    val tip: String? = null,
)

fun formatDuration(seconds: Int): String =
    if (seconds < 60) tr("{0} s", seconds) else tr("{0}:{1} min", seconds / 60, (seconds % 60).toString().padStart(2, '0'))

/** The statistic tiles under the ring that come from the report itself (time and pace). */
fun SessionReport.timeStats(unit: String = tr("Karte")): List<ResultStat> {
    if (seconds <= 0) return emptyList()
    val list = mutableListOf(ResultStat(Icons.Rounded.Timer, formatDuration(seconds)))
    if (total > 0) list += ResultStat(Icons.Rounded.Schedule, tr("Ø {0} s pro {1}", ((seconds.toFloat() / total) + 0.5f).toInt().coerceAtLeast(1), unit))
    return list
}

@Composable
private fun tone(t: Tone): Color {
    val cs = MaterialTheme.colorScheme
    return when (t) { Tone.Easy -> cs.tertiary; Tone.Good -> cs.primary; Tone.Okay -> cs.secondary; Tone.Bad -> cs.error }
}

/** One bar split by the parts of the session with a legend (colour dot, name, count, share) below. */
@Composable
fun BreakdownCard(segments: List<ReportSegment>, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val sum = segments.sumOf { it.count }.coerceAtLeast(1)
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = cs.surfaceContainer) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(tr("Ergebnis im Detail"), style = MaterialTheme.typography.titleMedium.bold())
            Row(Modifier.fillMaxWidth().height(16.dp).background(cs.surfaceContainerHighest, CircleShape), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                segments.filter { it.count > 0 }.forEach { s ->
                    Box(Modifier.weight(s.count.toFloat()).height(16.dp).background(tone(s.tone), CircleShape))
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                segments.forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).background(tone(s.tone), CircleShape))
                        Spacer(Modifier.width(10.dp))
                        Text(s.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        Text("${s.count}", style = MaterialTheme.typography.titleSmall.bold())
                        Text("  ${(s.count * 100f / sum + 0.5f).toInt()} %", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

/** When the reviewed cards come back: today, tomorrow, within a week, later – each with a bar. */
@Composable
fun SchedulePlanCard(dueAts: List<Long>, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val now = System.currentTimeMillis()
    val day = 24L * 60 * 60 * 1000
    val rows = listOf(
        tr("Heute noch") to dueAts.count { it < now + day / 2 },
        tr("Morgen") to dueAts.count { it >= now + day / 2 && it < now + 2 * day },
        tr("In 2 bis 7 Tagen") to dueAts.count { it >= now + 2 * day && it < now + 8 * day },
        tr("Später") to dueAts.count { it >= now + 8 * day },
    ).filter { it.second > 0 }
    if (rows.isEmpty()) return
    val max = rows.maxOf { it.second }.toFloat()
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = cs.surfaceContainer) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Icons.Rounded.Schedule, 36, cs.secondaryContainer, cs.onSecondaryContainer)
                Spacer(Modifier.width(12.dp))
                Text(tr("Nächste Wiederholung"), style = MaterialTheme.typography.titleMedium.bold())
            }
            rows.forEach { (label, n) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, Modifier.width(120.dp), style = MaterialTheme.typography.bodyMedium)
                    Box(Modifier.weight(1f).height(10.dp).background(cs.surfaceContainerHighest, CircleShape)) {
                        Box(Modifier.fillMaxWidth(n / max).height(10.dp).background(cs.secondary, CircleShape))
                    }
                    Text(tr("{0} Karten", n), Modifier.width(76.dp).padding(start = 8.dp), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                }
            }
        }
    }
}

/** A list of cards, the first few open, the rest behind "show all". Missed cards show the answer that was given, if there is one. */
@Composable
fun CardListSection(title: String, items: List<ReportItem>, good: Boolean, startOpen: Boolean, modifier: Modifier = Modifier) {
    if (items.isEmpty()) return
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(startOpen) }
    var all by remember { mutableStateOf(false) }
    val list = if (all) items else items.take(10)
    Column(modifier.fillMaxWidth().animateContentSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("$title (${items.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, color = if (good) cs.primary else cs.error)
            Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = cs.onSurfaceVariant)
        }
        if (open) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                list.forEachIndexed { i, it ->
                    SegmentedItem(
                        index = i, count = list.size,
                        headline = it.card.source,
                        supporting = buildString {
                            append(it.card.target)
                            if (!it.given.isNullOrBlank() && !it.given.equals(it.card.target, true)) append("\n").append(tr("Deine Antwort: {0}", it.given))
                            else if (!good && it.times > 1) append("\n").append(tr("{0} mal falsch", it.times))
                        },
                        leading = {
                            if (good) IconBadge(Icons.Rounded.Check, 40, cs.primaryContainer, cs.onPrimaryContainer)
                            else IconBadge(Icons.Rounded.Close, 40, cs.errorContainer, cs.onErrorContainer)
                        },
                    )
                }
            }
            if (items.size > 10) Text(
                if (all) tr("Weniger anzeigen") else tr("Alle {0} anzeigen", items.size),
                Modifier.clickable { all = !all }.padding(horizontal = 8.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelLarge, color = cs.primary,
            )
        }
    }
}

/** One short, concrete recommendation. */
@Composable
fun TipCard(text: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Lightbulb, null, Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        }
    }
}

/** A recommendation that fits the result. */
fun tipFor(total: Int, missed: Int, dueTomorrow: Int = 0): String? = when {
    total == 0 -> null
    missed == 0 -> if (dueTomorrow > 0) tr("Stark – alles gewusst. Morgen sind {0} Karten wieder fällig, so bleibt das Wissen lange erhalten.", dueTomorrow)
        else tr("Stark – alles gewusst. Wiederhole in ein paar Tagen, damit es lange hält.")
    missed * 3 >= total -> tr("Jede dritte Karte war schwierig. Übe diese {0} Karten am besten gleich noch einmal, dann bleiben sie hängen.", missed)
    else -> tr("{0} Karten brauchen noch Übung. Eine kurze Wiederholung dieser Karten heute festigt sie.", missed)
}

/** Right/wrong report for the modes that only know that. */
fun simpleReport(total: Int, known: List<ReportItem>, missed: List<ReportItem>, seconds: Int, almost: Int = 0): SessionReport = SessionReport(
    total = total,
    segments = listOfNotNull(
        ReportSegment(tr("Richtig"), known.size - almost, Tone.Good),
        if (almost > 0) ReportSegment(tr("Fast richtig oder mit Hilfe"), almost, Tone.Okay) else null,
        ReportSegment(tr("Falsch"), missed.size, Tone.Bad),
    ),
    seconds = seconds, missed = missed, known = known, tip = tipFor(total, missed.size),
)

/** For the modes that only count: right and wrong as a bar plus a tip. */
fun countReport(total: Int, correct: Int): SessionReport = SessionReport(
    total = total,
    segments = listOf(ReportSegment(tr("Richtig"), correct, Tone.Good), ReportSegment(tr("Falsch"), total - correct, Tone.Bad)),
    tip = tipFor(total, total - correct),
)
