@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.lingosnap.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.ui.components.IconBadge
import com.lingosnap.util.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private class Entry(val card: Flashcard, val src: String, val dst: String, val ex: String)
private class Hits(val decks: List<Deck>, val cards: List<Pair<Flashcard, Deck>>, val more: Int)

/** Full-screen search: the lower-case index is built once off the main thread, typing is debounced and matching runs in the background. */
@Composable
fun SearchOverlay(decks: List<Deck>, cards: List<Flashcard>, onOpenDeck: (Long) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<Hits?>(null) }
    var index by remember { mutableStateOf<List<Entry>?>(null) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(cards) {
        index = withContext(Dispatchers.Default) {
            cards.map { Entry(it, it.source.lowercase(), it.target.lowercase(), it.example.orEmpty().lowercase()) }
        }
    }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    LaunchedEffect(query, index, decks) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) { hits = null; return@LaunchedEffect }
        delay(120)
        val idx = index ?: return@LaunchedEffect
        hits = withContext(Dispatchers.Default) {
            val byId = decks.associateBy { it.id }
            val deckHits = decks.filter { it.name.lowercase().contains(q) || it.description.lowercase().contains(q) }
            val all = ArrayList<Pair<Flashcard, Deck>>()
            var total = 0
            for (e in idx) {
                if (e.src.contains(q) || e.dst.contains(q) || e.ex.contains(q)) {
                    total++
                    if (all.size < 100) byId[e.card.deckId]?.let { all.add(e.card to it) }
                }
            }
            Hits(deckHits, all, (total - all.size).coerceAtLeast(0))
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Column(Modifier.fillMaxSize().background(cs.surface).statusBarsPadding().imePadding()) {
            Surface(
                Modifier.fillMaxWidth().padding(12.dp).height(60.dp),
                shape = CircleShape, color = cs.surfaceContainerHigh,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, tr("Suche schließen")) }
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text(tr("Deck, Wort oder Übersetzung suchen"), style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        BasicTextField(
                            query, { query = it }, Modifier.fillMaxWidth().focusRequester(focus),
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface),
                            cursorBrush = SolidColor(cs.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {}),
                        )
                    }
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, tr("Leeren")) }
                    else Icon(Icons.Rounded.Search, null, Modifier.padding(end = 16.dp), tint = cs.onSurfaceVariant)
                }
            }
            val h = hits
            when {
                query.isBlank() -> Hint(tr("Suche in Decknamen, Wörtern, Übersetzungen und Beispielen."))
                h == null -> Unit
                h.decks.isEmpty() && h.cards.isEmpty() -> Hint(tr("Nichts gefunden."))
                else -> LazyColumn(
                    Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    if (h.decks.isNotEmpty()) {
                        item(key = "hd") { Section(tr("Decks"), Icons.Rounded.Layers) }
                        itemsIndexed(h.decks, key = { _, d -> "d${d.id}" }) { i, d ->
                            ResultRow(
                                i, h.decks.size,
                                if (d.isLanguage) Icons.Rounded.Translate else Icons.Rounded.Style,
                                highlight(d.name, query.trim()), null,
                                onClick = { onDismiss(); onOpenDeck(d.id) },
                            )
                        }
                    }
                    if (h.cards.isNotEmpty()) {
                        item(key = "hc") { Section(tr("Karten"), Icons.Rounded.Style) }
                        itemsIndexed(h.cards, key = { _, p -> "c${p.first.id}" }) { i, (c, d) ->
                            ResultRow(
                                i, h.cards.size,
                                if (d.isLanguage) Icons.Rounded.Translate else Icons.Rounded.Style,
                                highlight(c.source, query.trim()),
                                highlight(c.target, query.trim()).let { t -> buildAnnotatedString { append(t); append("  •  "); append(d.name) } },
                                onClick = { onDismiss(); onOpenDeck(d.id) },
                            )
                        }
                        if (h.more > 0) item(key = "more") {
                            Text(tr("… und {0} weitere. Suche genauer.", h.more), Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Top) {
        Spacer(Modifier.height(32.dp))
        IconBadge(Icons.Rounded.Search, 64, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
        Spacer(Modifier.height(16.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Section(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.padding(start = 4.dp, top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun ResultRow(index: Int, count: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, title: AnnotatedString, sub: AnnotatedString?, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = com.lingosnap.ui.components.segmentShape(index, count), color = cs.surfaceContainer,
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon, 40, cs.secondaryContainer, cs.onSecondaryContainer)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (sub != null) Text(sub, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun highlight(text: String, q: String): AnnotatedString {
    if (q.isEmpty()) return AnnotatedString(text)
    val bg = MaterialTheme.colorScheme.primaryContainer
    val fg = MaterialTheme.colorScheme.onPrimaryContainer
    return buildAnnotatedString {
        var i = 0
        while (i < text.length) {
            val j = text.indexOf(q, i, ignoreCase = true)
            if (j < 0) { append(text.substring(i)); break }
            append(text.substring(i, j))
            withStyle(SpanStyle(background = bg, color = fg, fontWeight = FontWeight.SemiBold)) { append(text.substring(j, j + q.length)) }
            i = j + q.length
        }
    }
}
