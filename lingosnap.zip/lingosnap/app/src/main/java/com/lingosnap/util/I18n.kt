package com.lingosnap.util

import android.content.Context
import kotlinx.serialization.json.Json
import java.util.Locale

/**
 * Translations of all texts in the app. The German text itself is the key; {0}, {1} … are the values that get filled in.
 * German (and any language without a file) uses the key / English as it is written in code and in assets/i18n/en.json.
 */
object Lang {
    private var app: Context? = null
    private val cache = HashMap<String, Map<String, String>>()

    private var prefs: android.content.SharedPreferences? = null

    fun init(context: Context) {
        app = context.applicationContext
        prefs = app?.getSharedPreferences("lingosnap_lang", Context.MODE_PRIVATE)
    }

    /** Languages the app is translated into: tag to its own name. */
    val appLanguages: List<Pair<String, String>> = listOf(
        "de" to "Deutsch", "en" to "English", "es" to "Español", "fr" to "Français", "it" to "Italiano", "pt" to "Português",
        "nl" to "Nederlands", "pl" to "Polski", "tr" to "Türkçe", "ru" to "Русский", "ja" to "日本語", "zh" to "中文",
    )

    /** The language the user picked in the settings (null = follow the phone). */
    var override: String?
        get() = prefs?.getString("lang", null)?.takeIf { l -> appLanguages.any { it.first == l } }
        set(v) { prefs?.edit()?.apply { if (v == null) remove("lang") else putString("lang", v) }?.apply() }

    val locale: Locale get() = override?.let { Locale.forLanguageTag(it) } ?: Locale.getDefault()

    /** Language code of the phone, e.g. "de", "en", "es". */
    val code: String get() = locale.language.lowercase()

    /** English name of the phone's language, used inside AI prompts ("German", "Spanish" …). */
    val aiName: String get() = locale.getDisplayLanguage(Locale.ENGLISH).ifBlank { "English" }

    /** Name of a language in the phone's language ("Spanisch", "Spanish", "Español"). */
    fun displayName(tag: String): String =
        Locale.forLanguageTag(tag).getDisplayLanguage(locale).replaceFirstChar { it.uppercase(locale) }.ifBlank { tag }

    @Synchronized
    fun table(): Map<String, String> {
        val c = code
        if (c == "de") return emptyMap()
        return cache.getOrPut(c) { load(c) }
    }

    private fun load(c: String): Map<String, String> {
        val ctx = app ?: return emptyMap()
        fun read(name: String): Map<String, String> = runCatching {
            ctx.assets.open("i18n/$name.json").use { Json.decodeFromString<Map<String, String>>(it.readBytes().decodeToString()) }
        }.getOrDefault(emptyMap())
        val english = read("en")
        return if (c == "en") english else english + read(c)
    }
}

/** Translates a German UI text into the phone's language; [args] fill the {0}, {1} … gaps. */
fun tr(key: String, vararg args: Any?): String {
    var text = Lang.table()[key] ?: key
    for (i in args.indices) text = text.replace("{$i}", args[i].toString())
    return text
}
