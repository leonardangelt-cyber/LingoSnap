package com.lingosnap.util

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.lingosnap.MainActivity
import com.lingosnap.container
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import java.util.Calendar

/** Daily "time to learn" notification, scheduled with an inexact alarm (no special permission) and re-armed after each run and after boot. */
object Reminders {
    private const val CHANNEL = "reminders"
    private const val REQUEST = 4711

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, REQUEST, Intent(context, ReminderReceiver::class.java).setAction("com.lingosnap.REMIND"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    /** Arms the next alarm (or cancels it when reminders are off). */
    fun apply(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val st = context.container.stats.stats.value
        if (!st.remindersOn) { am.cancel(pending(context)); return }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, st.reminderHour); set(Calendar.MINUTE, st.reminderMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 30_000) add(Calendar.DAY_OF_YEAR, 1)
        }
        runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending(context)) }
    }

    internal fun notify(context: Context, due: Int, goalLine: String? = null) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, tr("Lern-Erinnerung"), NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle(tr("Zeit zum Lernen"))
            .setContentText(goalLine ?: if (due > 0) tr("{0} Karten warten auf dich.", due) else tr("Ein paar Minuten halten deine Serie am Leben."))
            .setStyle(NotificationCompat.BigTextStyle().bigText(listOfNotNull(goalLine, if (due > 0) tr("{0} Karten warten auf dich.", due) else null).joinToString("\n").ifBlank { tr("Ein paar Minuten halten deine Serie am Leben.") }))
            .setContentIntent(open).setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(REQUEST, n) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) { Reminders.apply(app); return }
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val c = app.container
                val st = c.stats.stats.value
                if (st.remindersOn) {
                    val now = System.currentTimeMillis()
                    val all = c.repository.cards.first()
                    val due = all.count { it.dueAt <= now }
                    // a deck with a goal date: say what to learn today
                    val decks = c.repository.decks.first().associateBy { it.id }
                    val goalLine = DeckGoals.allGoals().entries.sortedBy { it.value }.firstNotNullOfOrNull { (id, date) ->
                        val d = decks[id] ?: return@firstNotNullOfOrNull null
                        val p = DeckGoals.plan(all.filter { it.deckId == id }, date)
                        if (p.newToday + p.due > 0) tr("Heute: {0} neue und {1} zu wiederholen in „{2}“.", p.newToday, p.due, d.name) else null
                    }
                    if (!st.remindOnlyDue || due > 0 || goalLine != null) Reminders.notify(app, due, goalLine)
                }
                Reminders.apply(app)
            } finally { pending.finish() }
        }
    }
}
