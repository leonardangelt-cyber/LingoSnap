package com.lingosnap.ui

import com.lingosnap.data.model.StudyScope

object Routes {
    const val Setup = "setup"
    const val Home = "home"
    const val Library = "library"
    const val Create = "create"
    const val Add = "add/{deckId}?method={method}"
    const val Achievements = "achievements"
    const val Settings = "settings"
    const val Deck = "deck/{deckId}"
    const val Study = "study/{scope}/{id}/{mode}"

    fun create() = "create"
    fun add(deckId: Long, method: Int = -1) = "add/$deckId?method=$method"
    fun deck(id: Long) = "deck/$id"
    fun study(scope: StudyScope, id: Long, mode: String) = "study/${scope.name}/$id/$mode"
}

object StudyMode {
    const val FlashDue = "flash_due"
    const val FlashAll = "flash_all"
    const val Choice = "choice"
    const val Typing = "typing"
    const val Match = "match"
}
