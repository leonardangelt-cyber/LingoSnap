package com.lingosnap.ui

import com.lingosnap.data.model.StudyScope

object Routes {
    const val Setup = "setup"
    const val Home = "home"
    const val Library = "library"
    const val Create = "create"
    const val Add = "add/{deckId}?method={method}"
    const val Achievements = "achievements"
    const val Settings = "settings"
    const val AiSettings = "settings/ai"
    const val Deck = "deck/{deckId}"
    const val Study = "study/{scope}/{id}/{mode}?dir={dir}&from={from}&to={to}"

    fun create() = "create"
    fun add(deckId: Long, method: Int = -1) = "add/${deckId}?method=${method}"
    fun deck(id: Long) = "deck/${id}"
    fun study(scope: StudyScope, id: Long, mode: String, dir: String = StudyDir.Forward, from: Int = 0, to: Int = 0) =
        "study/${scope.name}/${id}/${mode}?dir=${dir}&from=${from}&to=${to}"
}

object StudyDir {
    const val Forward = "fwd"
    const val Reverse = "rev"
    const val Mixed = "mix"
}

object StudyMode {
    const val FlashDue = "flash_due"
    const val FlashAll = "flash_all"
    const val Choice = "choice"
    const val Typing = "typing"
    const val Match = "match"
    const val Cloze = "cloze"
    const val Listen = "listen"
    const val Sentence = "sentence"
    const val Speak = "speak"
}
