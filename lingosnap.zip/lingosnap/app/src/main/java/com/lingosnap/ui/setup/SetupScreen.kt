@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.lingosnap.ui.setup

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton

@Composable
fun SetupScreen(onDone: () -> Unit, vm: SetupViewModel = viewModel(factory = SetupViewModel.Factory)) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val uriHandler = LocalUriHandler.current

    LaunchedEffect(ui.saved) { if (ui.saved) onDone() }

    AppBackground {
        Column(
            Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Surface(Modifier.size(96.dp), shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.primaryContainer) {
                Icon(Icons.Rounded.Key, null, Modifier.padding(26.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Text("Welcome to LingoSnap", style = MaterialTheme.typography.headlineLargeEmphasized)
            Text(
                "Paste your personal Google Gemini API key. It is stored encrypted on this device only and used to read your photos and craft mnemonics.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            OutlinedTextField(
                value = ui.key,
                onValueChange = vm::onKeyChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Gemini API key") },
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                isError = ui.error != null,
                supportingText = { ui.error?.let { Text(it) } },
                visualTransformation = if (ui.visible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = vm::toggleVisible) {
                        Icon(if (ui.visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Toggle visibility")
                    }
                },
            )

            BouncyButton(
                onClick = vm::saveAndVerify,
                enabled = ui.key.isNotBlank() && !ui.validating,
                modifier = Modifier.fillMaxWidth().height(60.dp),
            ) {
                AnimatedVisibility(ui.validating) { LoadingIndicator(Modifier.size(32.dp)) }
                Text(if (ui.validating) "  Checking…" else "Verify & save", style = MaterialTheme.typography.titleMedium)
            }

            TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                Text("Get a free key in Google AI Studio")
            }
        }
    }
}
