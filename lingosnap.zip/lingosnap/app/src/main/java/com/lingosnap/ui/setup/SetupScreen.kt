@file:OptIn(ExperimentalMaterial3Api::class)

package com.lingosnap.ui.setup

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.MorphLoader
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.floating
import com.lingosnap.ui.theme.bold

@Composable
fun SetupScreen(onDone: () -> Unit, vm: SetupViewModel = viewModel(factory = SetupViewModel.Factory)) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val uriHandler = LocalUriHandler.current
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(ui.saved) { if (ui.saved) onDone() }

    AppBackground {
        Column(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Hero
            Box(Modifier.entrance(0).floating()) {
                CookieBadge(size = 150.dp, color = cs.primaryContainer, lobes = 10) {
                    CookieBadge(size = 92.dp, color = cs.primary.copy(alpha = 0.18f), lobes = 7, spinMillis = 16000)
                    Icon(Icons.Rounded.Key, null, Modifier.size(54.dp), tint = cs.onPrimaryContainer)
                }
            }

            Column(Modifier.entrance(1), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "LingoSnap",
                    style = MaterialTheme.typography.displayMedium.bold(),
                    color = cs.onSurface,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Foto machen. Jedes Wort lernen.",
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }

            // Key card
            Surface(
                Modifier.fillMaxWidth().entrance(2),
                shape = MaterialTheme.shapes.extraLarge,
                color = cs.surfaceContainerHigh,
                tonalElevation = 2.dp,
                shadowElevation = 6.dp,
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lock, null, tint = cs.primary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Dein Gemini API-Schlüssel", style = MaterialTheme.typography.titleMedium.bold())
                    }
                    Text(
                        "Wird verschlüsselt nur auf diesem Gerät gespeichert. Die KI nutzt ihn für Fotos, Vokabel-Generator und Eselsbrücken.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = ui.key,
                        onValueChange = vm::onKeyChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Gemini API-Schlüssel") },
                        singleLine = true,
                        shape = MaterialTheme.shapes.large,
                        isError = ui.error != null,
                        visualTransformation = if (ui.visible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = vm::toggleVisible) {
                                Icon(
                                    if (ui.visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    "Anzeigen/Verbergen",
                                )
                            }
                        },
                    )
                    AnimatedVisibility(
                        visible = ui.error != null,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically(),
                    ) {
                        Surface(shape = MaterialTheme.shapes.medium, color = cs.errorContainer, contentColor = cs.onErrorContainer) {
                            Text(
                                ui.error.orEmpty(),
                                Modifier.padding(14.dp),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            }

            // Feature chips
            Row(Modifier.entrance(3), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureChip("📷", "Scannen")
                FeatureChip("🔊", "Hören")
                FeatureChip("💡", "Eselsbrücken")
            }

            BouncyButton(
                onClick = vm::saveAndVerify,
                enabled = ui.key.isNotBlank() && !ui.validating,
                modifier = Modifier.fillMaxWidth().height(64.dp).entrance(4),
            ) {
                if (ui.validating) {
                    MorphLoader(size = 26.dp, color = cs.onPrimary)
                    Spacer(Modifier.width(12.dp))
                    Text("Prüfe …", style = MaterialTheme.typography.titleMedium.bold())
                } else {
                    Text("Prüfen & speichern", style = MaterialTheme.typography.titleMedium.bold())
                }
            }

            TextButton(
                onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") },
                modifier = Modifier.entrance(5),
            ) {
                Text("Kostenlosen Schlüssel in Google AI Studio holen")
            }
        }
    }
}

@Composable
private fun FeatureChip(emoji: String, label: String) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji)
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge.bold())
        }
    }
}
