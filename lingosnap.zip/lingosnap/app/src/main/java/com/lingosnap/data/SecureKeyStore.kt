package com.lingosnap.data

import android.content.Context
import androidx.core.content.edit
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stores the user's Gemini API key encrypted (AES-256 GCM, key lives in Android Keystore). */
class SecureKeyStore(context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "lingosnap_secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    var apiKey: String?
        get() = prefs.getString(KEY, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(KEY) else putString(KEY, value.trim()) }

    val hasKey: Boolean get() = apiKey != null

    private companion object { const val KEY = "gemini_api_key" }
}
