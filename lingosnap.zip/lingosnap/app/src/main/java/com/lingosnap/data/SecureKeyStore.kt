package com.lingosnap.data

import android.content.Context
import androidx.core.content.edit
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stores the user's Gemini API key encrypted (AES-256 GCM, key lives in Android Keystore). */
class SecureKeyStore(context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "lingosnap_secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    var apiKey: String?
        get() = prefs.getString(KEY, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(KEY) else putString(KEY, value.trim()) }

    val hasKey: Boolean get() = apiKey != null

    /** True once the user either saved a key or skipped the first-run screen. */
    var setupDone: Boolean
        get() = prefs.getBoolean(DONE, false)
        set(value) = prefs.edit { putBoolean(DONE, value) }

    /** Model chosen by the user; null = automatic (best available). */
    var chosenModel: String?
        get() = prefs.getString(MODEL, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(MODEL) else putString(MODEL, value) }

    /** Models this key can use (comma separated, best first). */
    var models: List<String>
        get() = prefs.getString(MODELS, "").orEmpty().split(",").filter { it.isNotBlank() }
        set(value) = prefs.edit { putString(MODELS, value.joinToString(",")) }

    private companion object {
        const val KEY = "gemini_api_key"
        const val DONE = "setup_done"
        const val MODEL = "chosen_model"
        const val MODELS = "models"
    }
}
