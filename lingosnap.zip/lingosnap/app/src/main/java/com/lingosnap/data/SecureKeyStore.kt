package com.lingosnap.data

import android.content.Context
import androidx.core.content.edit
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stores the user's Gemini API key encrypted (AES-256 GCM, key lives in Android Keystore). */
class SecureKeyStore(context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "lingosnap_secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    var apiKey: String?
        get() = prefs.getString(KEY, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(KEY) else putString(KEY, value.trim()) }

    val hasKey: Boolean get() = apiKey != null

    /** True once the user either saved a key or skipped the first-run screen. */
    var setupDone: Boolean
        get() = prefs.getBoolean(DONE, false)
        set(value) = prefs.edit { putBoolean(DONE, value) }

    /** Model chosen by the user; null = automatic (best available). */
    var chosenModel: String?
        get() = prefs.getString(MODEL, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(MODEL) else putString(MODEL, value) }

    /** Models this key can use (comma separated, best first). */
    var models: List<String>
        get() = prefs.getString(MODELS, "").orEmpty().split(",").filter { it.isNotBlank() }
        set(value) = prefs.edit { putString(MODELS, value.joinToString(",")) }

    /** Detected provider name (see AiProvider), stored after a successful check. */
    var provider: String?
        get() = prefs.getString(PROVIDER, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(PROVIDER) else putString(PROVIDER, value) }

    /** Optional second key: used automatically when the first one hits its limit. */
    var backupKey: String?
        get() = prefs.getString(BACKUP_KEY, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(BACKUP_KEY) else putString(BACKUP_KEY, value.trim()) }
    var backupProvider: String?
        get() = prefs.getString(BACKUP_PROVIDER, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit { if (value.isNullOrBlank()) remove(BACKUP_PROVIDER) else putString(BACKUP_PROVIDER, value) }
    var backupModels: List<String>
        get() = prefs.getString(BACKUP_MODELS, "").orEmpty().split(",").filter { it.isNotBlank() }
        set(value) = prefs.edit { putString(BACKUP_MODELS, value.joinToString(",")) }

    /** After generating cards the AI checks them once more for wrong translations. */
    var qualityCheck: Boolean
        get() = prefs.getBoolean(QUALITY, false)
        set(value) = prefs.edit { putBoolean(QUALITY, value) }

    private companion object {
        const val BACKUP_KEY = "backup_api_key"
        const val BACKUP_PROVIDER = "backup_provider"
        const val BACKUP_MODELS = "backup_models"
        const val QUALITY = "quality_check"
        const val PROVIDER = "provider"
        const val KEY = "gemini_api_key"
        const val DONE = "setup_done"
        const val MODEL = "chosen_model"
        const val MODELS = "models"
    }
}
