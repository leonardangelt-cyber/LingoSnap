package com.lingosnap.ui.scan

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.CardRepository
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.ImageUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class Draft(val id: Int, val pair: VocabPair, val selected: Boolean = true)

enum class ScanPhase { Idle, Loading, Review }

data class ScanUiState(
    val sourceLang: String = "en",
    val targetLang: String = "de",
    val phase: ScanPhase = ScanPhase.Idle,
    val drafts: List<Draft> = emptyList(),
    val error: String? = null,
    val saved: Boolean = false,
) {
    val selectedCount get() = drafts.count { it.selected }
}

class ScanViewModel(
    private val repo: CardRepository,
    private val appContext: Context,
) : ViewModel() {

    private val _ui = MutableStateFlow(ScanUiState())
    val ui: StateFlow<ScanUiState> = _ui.asStateFlow()

    fun setSource(tag: String) = _ui.update { it.copy(sourceLang = tag) }
    fun setTarget(tag: String) = _ui.update { it.copy(targetLang = tag) }
    fun swapLanguages() = _ui.update { it.copy(sourceLang = it.targetLang, targetLang = it.sourceLang) }

    fun onImage(uri: Uri) {
        val s = _ui.value
        viewModelScope.launch {
            _ui.update { it.copy(phase = ScanPhase.Loading, error = null) }
            runCatching { ImageUtils.loadJpeg(appContext, uri) }
                .mapCatching { jpeg -> repo.extract(jpeg, s.sourceLang, s.targetLang).getOrThrow() }
                .fold(
                    onSuccess = { pairs ->
                        _ui.update {
                            if (pairs.isEmpty()) it.copy(phase = ScanPhase.Idle, error = "No vocabulary found – try a closer, well-lit photo.")
                            else it.copy(phase = ScanPhase.Review, drafts = pairs.mapIndexed { i, p -> Draft(i, p) })
                        }
                    },
                    onFailure = { e -> _ui.update { it.copy(phase = ScanPhase.Idle, error = e.message ?: "Something went wrong") } },
                )
        }
    }

    fun toggle(id: Int) = _ui.update { s -> s.copy(drafts = s.drafts.map { if (it.id == id) it.copy(selected = !it.selected) else it }) }

    fun saveSelected() {
        val s = _ui.value
        viewModelScope.launch {
            repo.save(s.drafts.filter { it.selected }.map { it.pair }, s.sourceLang, s.targetLang)
            _ui.update { it.copy(saved = true) }
        }
    }

    fun discard() = _ui.update { it.copy(phase = ScanPhase.Idle, drafts = emptyList()) }

    companion object {
        val Factory = viewModelFactory {
            initializer { ScanViewModel(app().container.repository, app().applicationContext) }
        }
    }
}
