package com.lingosnap.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageUtils {

    /** Decodes, rotates (EXIF) and downsizes an image to a JPEG that is cheap to upload. */
    suspend fun loadJpeg(context: Context, uri: Uri, maxEdge: Int = 1280, quality: Int = 80, enhance: Boolean = false): ByteArray =
        withContext(Dispatchers.IO) {
            val cr = context.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxEdge * 2) sample *= 2

            val decoded = cr.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: error("Could not read the image")

            val rotation = cr.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
            val scale = maxEdge.toFloat() / max(decoded.width, decoded.height)
            val matrix = Matrix().apply {
                if (scale < 1f) postScale(scale, scale)
                if (rotation != 0) postRotate(rotation.toFloat())
            }
            val finalBmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)

            val outBmp = if (enhance) enhanceForOcr(finalBmp) else finalBmp
            ByteArrayOutputStream().use { out ->
                outBmp.compress(Bitmap.CompressFormat.JPEG, if (enhance) 75 else quality, out)
                out.toByteArray()
            }
        }

    /**
     * Grayscale + more contrast (factor 1.4), light greys become pure white: removes shadows, paper texture and
     * grid lines so print and handwriting stand out for the text recognition. Works on a mutable copy in place.
     */
    fun enhanceForOcr(src: Bitmap): Bitmap {
        val bmp = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        val w = bmp.width
        val row = IntArray(w)
        for (y in 0 until bmp.height) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                val c = row[x]
                var g = (0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF))
                g = ((g - 128f) * 1.4f + 128f).coerceIn(0f, 255f)
                val v = if (g > 210f) 255 else g.toInt()
                row[x] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
            }
            bmp.setPixels(row, 0, w, 0, y, w, 1)
        }
        return bmp
    }
}
