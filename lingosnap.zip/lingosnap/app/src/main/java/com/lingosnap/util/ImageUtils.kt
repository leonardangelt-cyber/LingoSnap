package com.lingosnap.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageUtils {

    /** Decodes, rotates (EXIF) and downsizes an image to a JPEG that is cheap to upload. */
    suspend fun loadJpeg(context: Context, uri: Uri, maxEdge: Int = 1600, quality: Int = 85): ByteArray =
        withContext(Dispatchers.IO) {
            val cr = context.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxEdge * 2) sample *= 2

            val decoded = cr.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: error("Could not read the image")

            val rotation = cr.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
            val scale = maxEdge.toFloat() / max(decoded.width, decoded.height)
            val matrix = Matrix().apply {
                if (scale < 1f) postScale(scale, scale)
                if (rotation != 0) postRotate(rotation.toFloat())
            }
            val finalBmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)

            ByteArrayOutputStream().use { out ->
                finalBmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
                out.toByteArray()
            }
        }
}
