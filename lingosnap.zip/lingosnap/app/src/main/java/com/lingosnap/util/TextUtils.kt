package com.lingosnap.util

import com.lingosnap.data.remote.VocabPair
import java.text.Normalizer

private val diacritics = Regex("\\p{M}+")
private val articles = setOf(
    "der", "die", "das", "den", "dem", "ein", "eine",
    "el", "la", "los", "las", "un", "una",
    "the", "a", "an", "le", "les", "l", "il", "lo", "gli", "o", "os", "as",
)

fun normalize(s: String): String =
    Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD)
        .replace(diacritics, "")
        .replace(Regex("[^\\p{L}\\p{N} ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

/** Normalized word without its article: "la casa" -> "casa". */
fun baseForm(s: String): String = withoutArticle(s)

private fun withoutArticle(s: String): String {
    val parts = normalize(s).split(" ")
    return if (parts.size > 1 && parts.first() in articles) parts.drop(1).joinToString(" ") else parts.joinToString(" ")
}

/** All acceptable spellings of an answer: "primero / primera" -> [primero, primera]. */
fun answerCandidates(answer: String): List<String> {
    val alternatives = answer.split("/", ";", ",").map { it.trim() }.filter { it.isNotEmpty() }
    val all = (listOf(answer) + alternatives)
    return all.flatMap { listOf(normalize(it), withoutArticle(it)) }.filter { it.isNotEmpty() }.distinct()
}

fun levenshtein(a: String, b: String): Int {
    if (a == b) return 0
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length
    var prev = IntArray(b.length + 1) { it }
    var cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
        cur[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        }
        val t = prev; prev = cur; cur = t
    }
    return prev[b.length]
}

enum class AnswerResult { Correct, Close, Wrong }

fun checkAnswer(input: String, expected: String): AnswerResult {
    val typed = normalize(input)
    if (typed.isEmpty()) return AnswerResult.Wrong
    val typedNoArticle = withoutArticle(input)
    val candidates = answerCandidates(expected)
    if (candidates.isEmpty()) return AnswerResult.Wrong
    if (candidates.any { it == typed || it == typedNoArticle }) return AnswerResult.Correct
    val best = candidates.minOf { minOf(levenshtein(it, typed), levenshtein(it, typedNoArticle)) }
    val allowed = if (typed.length >= 6) 2 else 1
    return if (best <= allowed) AnswerResult.Close else AnswerResult.Wrong
}

/** Parses pasted vocabulary lines like `casa;Haus`, `casa - Haus`, `casa<TAB>Haus`, `casa = Haus`. */
fun parseVocabText(text: String): List<VocabPair> {
    val separators = listOf(";", "\t", " - ", " – ", " — ", "=", ":", "|")
    return text.lines()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .mapNotNull { line ->
            val sep = separators.firstOrNull { line.contains(it) } ?: return@mapNotNull null
            val parts = line.split(sep, limit = 3).map { it.trim() }
            if (parts.size >= 2 && parts[0].isNotEmpty() && parts[1].isNotEmpty()) {
                VocabPair(parts[0], parts[1], parts.getOrNull(2)?.takeIf { it.isNotEmpty() })
            } else null
        }
        .distinctBy { it.source.lowercase() to it.target.lowercase() }
}
