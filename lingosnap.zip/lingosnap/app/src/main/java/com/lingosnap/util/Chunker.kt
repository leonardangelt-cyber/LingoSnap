package com.lingosnap.util

/** Cuts a long text into blocks of at most [MAX] characters, at line breaks ("chunkDocumentText" of the web app). */
object Chunker {
    const val MAX = 10_000

    /** A line that is longer than [max] on its own is cut hard, every other block ends at a line break. */
    fun chunk(text: String, max: Int = MAX): List<String> {
        if (text.isBlank()) return emptyList()
        val out = ArrayList<String>()
        val sb = StringBuilder()
        fun flush() { if (sb.isNotBlank()) out += sb.toString().trim(); sb.clear() }
        for (line in text.lines()) {
            if (line.length > max) {
                flush()
                line.chunked(max).forEach { out += it }
                continue
            }
            if (sb.length + line.length + 1 > max) flush()
            sb.append(line).append('\n')
        }
        flush()
        return out
    }
}
