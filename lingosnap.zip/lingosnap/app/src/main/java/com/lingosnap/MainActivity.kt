package com.lingosnap

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.lingosnap.ui.home.HomeScreen
import com.lingosnap.ui.scan.ScanScreen
import com.lingosnap.ui.setup.SetupScreen
import com.lingosnap.ui.study.StudyScreen
import com.lingosnap.ui.theme.LingoSnapTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LingoSnapTheme { LingoSnapNav() } }
    }
}

private object Route {
    const val Setup = "setup"
    const val Home = "home"
    const val Scan = "scan"
    const val Study = "study"
}

@Composable
private fun LingoSnapNav() {
    val nav = rememberNavController()
    val start = if (LocalContext.current.container.keyStore.hasKey) Route.Home else Route.Setup
    val slide = spring<androidx.compose.ui.unit.IntOffset>(dampingRatio = 0.85f, stiffness = 380f)

    NavHost(
        navController = nav,
        startDestination = start,
        enterTransition = { slideInHorizontally(slide) { it / 3 } + fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { slideOutHorizontally(slide) { it / 3 } + fadeOut() },
    ) {
        composable(Route.Setup) {
            SetupScreen(onDone = {
                nav.navigate(Route.Home) { popUpTo(Route.Setup) { inclusive = true } }
            })
        }
        composable(Route.Home) {
            HomeScreen(
                onScan = { nav.navigate(Route.Scan) },
                onStudy = { nav.navigate(Route.Study) },
                onSettings = { nav.navigate(Route.Setup) },
            )
        }
        composable(Route.Scan) {
            ScanScreen(onBack = { nav.popBackStack() })
        }
        composable(Route.Study) {
            StudyScreen(onBack = { nav.popBackStack() })
        }
    }
}
