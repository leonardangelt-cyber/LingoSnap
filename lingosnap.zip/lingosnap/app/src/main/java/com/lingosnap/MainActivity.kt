package com.lingosnap

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalLibrary
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.Routes
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.achievements.AchievementsScreen
import com.lingosnap.ui.components.FloatingNavBar
import com.lingosnap.ui.components.NavItemSpec
import com.lingosnap.ui.create.CreateScreen
import com.lingosnap.ui.deck.DeckScreen
import com.lingosnap.ui.home.HomeScreen
import com.lingosnap.ui.library.LibraryScreen
import com.lingosnap.ui.practice.ChoiceScreen
import com.lingosnap.ui.practice.MatchScreen
import com.lingosnap.ui.practice.TypingScreen
import com.lingosnap.ui.settings.SettingsScreen
import com.lingosnap.ui.setup.SetupScreen
import com.lingosnap.ui.study.StudyScreen
import com.lingosnap.ui.theme.LingoSnapTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val stats by container.stats.stats.collectAsStateWithLifecycle()
            val dark = when (stats.darkMode) {
                1 -> true
                2 -> false
                else -> isSystemInDarkTheme()
            }
            // keep status/navigation bar icons readable when the user overrides the system theme
            DisposableEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(AndroidColor.TRANSPARENT)
                } else {
                    SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            LingoSnapTheme(darkMode = stats.darkMode, accent = stats.accent) { LingoSnapNav() }
        }
    }
}

private val TabItems = listOf(
    NavItemSpec(Routes.Home, "Start", Icons.Rounded.Home),
    NavItemSpec(Routes.Library, "Bibliothek", Icons.Rounded.LocalLibrary),
    NavItemSpec("create", "Neu", Icons.Rounded.Add, isCenter = true),
    NavItemSpec(Routes.Achievements, "Erfolge", Icons.Rounded.EmojiEvents),
    NavItemSpec(Routes.Settings, "Optionen", Icons.Rounded.Settings),
)

private fun tabRoute(item: NavItemSpec) = if (item.route == "create") Routes.create() else item.route

@Composable
private fun LingoSnapNav() {
    val nav = rememberNavController()
    val start = if (LocalContext.current.container.keyStore.hasKey) Routes.Home else Routes.Setup
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route

    val isTab = route != null && TabItems.any { route.startsWith(it.route) }
    val slide = spring<IntOffset>(dampingRatio = 0.85f, stiffness = 380f)

    fun goTab(item: NavItemSpec) {
        nav.navigate(tabRoute(item)) {
            popUpTo(Routes.Home) { saveState = false }
            launchSingleTop = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        NavHost(
            navController = nav,
            startDestination = start,
            // tabs: material "fade through"
            enterTransition = { fadeIn(tween(320, delayMillis = 90)) + scaleIn(tween(320, delayMillis = 90), initialScale = 0.96f) },
            exitTransition = { fadeOut(tween(110)) },
            popEnterTransition = { fadeIn(tween(320, delayMillis = 90)) + scaleIn(tween(320, delayMillis = 90), initialScale = 0.96f) },
            popExitTransition = { fadeOut(tween(110)) },
        ) {
            composable(Routes.Setup) {
                SetupScreen(onDone = {
                    if (nav.previousBackStackEntry != null) nav.popBackStack()
                    else nav.navigate(Routes.Home) { popUpTo(Routes.Setup) { inclusive = true } }
                })
            }
            composable(Routes.Home) {
                HomeScreen(
                    onOpenDeck = { nav.navigate(Routes.deck(it)) },
                    onStudy = { scope, id, mode -> nav.navigate(Routes.study(scope, id, mode)) },
                    onCreate = { nav.navigate(Routes.create()) },
                    onSearch = { goTab(TabItems[1]) },
                )
            }
            composable(Routes.Library) {
                LibraryScreen(onOpenDeck = { nav.navigate(Routes.deck(it)) })
            }
            composable(
                Routes.Create,
                arguments = listOf(navArgument("deckId") { type = NavType.LongType; defaultValue = 0L }),
            ) { entry ->
                CreateScreen(
                    deckId = entry.arguments?.getLong("deckId") ?: 0L,
                    onFinished = { deckId ->
                        nav.navigate(Routes.deck(deckId)) {
                            popUpTo(Routes.Home)
                            launchSingleTop = true
                        }
                    },
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.Achievements) { AchievementsScreen() }
            composable(Routes.Settings) {
                SettingsScreen(onChangeKey = { nav.navigate(Routes.Setup) })
            }
            composable(
                Routes.Deck,
                arguments = listOf(navArgument("deckId") { type = NavType.LongType }),
                enterTransition = { slideInHorizontally(slide) { it / 3 } + fadeIn() },
                popExitTransition = { slideOutHorizontally(slide) { it / 3 } + fadeOut() },
            ) { entry ->
                val deckId = entry.arguments?.getLong("deckId") ?: 0L
                DeckScreen(
                    deckId = deckId,
                    onBack = { nav.popBackStack() },
                    onStudy = { scope, id, mode -> nav.navigate(Routes.study(scope, id, mode)) },
                    onAddMore = { nav.navigate(Routes.create(deckId)) },
                )
            }
            composable(
                Routes.Study,
                arguments = listOf(
                    navArgument("scope") { type = NavType.StringType },
                    navArgument("id") { type = NavType.LongType },
                    navArgument("mode") { type = NavType.StringType },
                ),
                enterTransition = { slideInVertically(slide) { it / 4 } + fadeIn() },
                popExitTransition = { slideOutVertically(slide) { it / 4 } + fadeOut() },
            ) { entry ->
                val scope = runCatching { StudyScope.valueOf(entry.arguments?.getString("scope").orEmpty()) }
                    .getOrDefault(StudyScope.All)
                val id = entry.arguments?.getLong("id") ?: 0L
                val mode = entry.arguments?.getString("mode").orEmpty()
                val back: () -> Unit = { nav.popBackStack() }
                when (mode) {
                    StudyMode.Choice -> ChoiceScreen(scope, id, back)
                    StudyMode.Typing -> TypingScreen(scope, id, back)
                    StudyMode.Match -> MatchScreen(scope, id, back)
                    else -> StudyScreen(scope, id, onlyDue = mode != StudyMode.FlashAll, onBack = back)
                }
            }
        }

        AnimatedVisibility(
            visible = isTab,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.7f, stiffness = 300f)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            FloatingNavBar(
                items = TabItems,
                selectedRoute = route,
                onSelect = { r -> goTab(TabItems.first { it.route == r }) },
            )
        }
    }
}
