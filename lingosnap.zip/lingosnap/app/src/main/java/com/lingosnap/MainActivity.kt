package com.lingosnap

import kotlinx.coroutines.launch
import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalLibrary
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.background
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.Routes
import com.lingosnap.ui.StudyDir
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.create.AddCardsScreen
import com.lingosnap.ui.create.NewDeckScreen
import com.lingosnap.ui.deck.DeckScreen
import com.lingosnap.ui.home.HomeScreen
import com.lingosnap.ui.practice.ChoiceScreen
import com.lingosnap.ui.practice.MatchScreen
import com.lingosnap.ui.practice.TypingScreen
import com.lingosnap.ui.settings.AiSettingsScreen
import com.lingosnap.ui.settings.SettingsScreen
import com.lingosnap.ui.setup.SetupScreen
import com.lingosnap.ui.study.StudyScreen
import com.lingosnap.ui.theme.LingoSnapTheme

class MainActivity : ComponentActivity() {
    /** Set when the user taps the "AI finished" notification. */
    private val openDeck = androidx.compose.runtime.mutableStateOf<Long?>(null)

    private fun readDeckLink(intent: android.content.Intent?) {
        val text = intent?.dataString ?: return
        com.lingosnap.util.DeckLink.decode(text)?.let { com.lingosnap.util.PendingImport.state.value = it }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        readDeckLink(intent)
        openDeck.value = intent.getLongExtra(com.lingosnap.util.EXTRA_OPEN_DECK, -1L).takeIf { it > 0 }
    }

    override fun onStop() {
        super.onStop()
        val backup = container.autoBackup
        if (backup.enabled) container.appScope.launch { backup.run() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readDeckLink(intent)
        openDeck.value = intent?.getLongExtra(com.lingosnap.util.EXTRA_OPEN_DECK, -1L)?.takeIf { it > 0 }
        setContent {
            val stats by container.stats.stats.collectAsStateWithLifecycle()
            val dark = when (stats.darkMode) {
                1 -> true
                2 -> false
                else -> isSystemInDarkTheme()
            }
            // keep status/navigation bar icons readable when the user overrides the system theme
            DisposableEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(AndroidColor.TRANSPARENT)
                } else {
                    SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            LingoSnapTheme(darkMode = stats.darkMode, accent = 0) { LingoSnapNav(openDeck) }
        }
    }
}

@Composable
private fun LingoSnapNav(openDeck: androidx.compose.runtime.MutableState<Long?>) {
    val nav = rememberNavController()
    val keys = LocalContext.current.container.keyStore
    androidx.compose.runtime.LaunchedEffect(openDeck.value) {
        val id = openDeck.value
        if (id != null) {
            openDeck.value = null
            nav.navigate(Routes.add(id, 1))
        }
    }
    val start = if (keys.hasKey || keys.setupDone) Routes.Home else Routes.Setup
    val slide = spring<IntOffset>(dampingRatio = 0.85f, stiffness = 380f)

    // tablets / landscape: keep the content in a comfortable column in the middle
    Box(Modifier.fillMaxSize().background(androidx.compose.material3.MaterialTheme.colorScheme.surface), contentAlignment = Alignment.TopCenter) {
        NavHost(
            navController = nav,
            startDestination = start,
            modifier = Modifier.fillMaxHeight().widthIn(max = 760.dp).fillMaxWidth(),
            // tabs: material "fade through"
            enterTransition = { fadeIn(tween(320, delayMillis = 90)) + scaleIn(tween(320, delayMillis = 90), initialScale = 0.96f) },
            exitTransition = { fadeOut(tween(110)) },
            popEnterTransition = { fadeIn(tween(320, delayMillis = 90)) + scaleIn(tween(320, delayMillis = 90), initialScale = 0.96f) },
            popExitTransition = { fadeOut(tween(110)) },
        ) {
            composable(Routes.Setup) {
                SetupScreen(onDone = {
                    if (nav.previousBackStackEntry != null) nav.popBackStack()
                    else nav.navigate(Routes.Home) { popUpTo(Routes.Setup) { inclusive = true } }
                })
            }
            composable(Routes.Home) {
                HomeScreen(
                    onOpenDeck = { nav.navigate(Routes.deck(it)) },
                    onStudy = { scope, id, mode -> nav.navigate(Routes.study(scope, id, mode)) },
                    onCreate = { nav.navigate(Routes.create()) },
                    onSettings = { nav.navigate(Routes.Settings) },
                )
            }
            composable(Routes.Create) {
                NewDeckScreen(
                    onCreated = { id ->
                        nav.navigate(Routes.add(id)) { popUpTo(Routes.Create) { inclusive = true } }
                    },
                    onBack = { nav.popBackStack() },
                )
            }
            composable(
                Routes.Add,
                arguments = listOf(
                    navArgument("deckId") { type = NavType.LongType },
                    navArgument("method") { type = NavType.IntType; defaultValue = -1 },
                ),
            ) { entry ->
                val id = entry.arguments?.getLong("deckId") ?: 0L
                AddCardsScreen(
                    deckId = id,
                    initialMethod = entry.arguments?.getInt("method") ?: -1,
                    onFinished = {
                        if (nav.previousBackStackEntry?.destination?.route == Routes.Deck) {
                            nav.popBackStack()
                        } else {
                            nav.navigate(Routes.deck(id)) { popUpTo(Routes.Add) { inclusive = true } }
                        }
                    },
                    onBack = { nav.popBackStack() },
                )
            }
            composable(
                Routes.Settings,
                enterTransition = { slideInHorizontally(slide) { it / 3 } + fadeIn() },
                popExitTransition = { slideOutHorizontally(slide) { it / 3 } + fadeOut() },
            ) {
                SettingsScreen(onBack = { nav.popBackStack() }, onOpenAi = { nav.navigate(Routes.AiSettings) })
            }
            composable(
                Routes.AiSettings,
                enterTransition = { slideInHorizontally(slide) { it / 3 } + fadeIn() },
                popExitTransition = { slideOutHorizontally(slide) { it / 3 } + fadeOut() },
            ) {
                AiSettingsScreen(onBack = { nav.popBackStack() }, onChangeKey = { nav.navigate(Routes.Setup) })
            }
            composable(
                Routes.Deck,
                arguments = listOf(navArgument("deckId") { type = NavType.LongType }),
                enterTransition = { slideInHorizontally(slide) { it / 3 } + fadeIn() },
                popExitTransition = { slideOutHorizontally(slide) { it / 3 } + fadeOut() },
            ) { entry ->
                val deckId = entry.arguments?.getLong("deckId") ?: 0L
                DeckScreen(
                    deckId = deckId,
                    onBack = { nav.popBackStack() },
                    onStudy = { scope, id, mode, dir, from, to -> nav.navigate(Routes.study(scope, id, mode, dir, from, to)) },
                    onAddMore = { nav.navigate(Routes.add(deckId)) },
                )
            }
            composable(
                Routes.Study,
                arguments = listOf(
                    navArgument("scope") { type = NavType.StringType },
                    navArgument("id") { type = NavType.LongType },
                    navArgument("mode") { type = NavType.StringType },
                    navArgument("dir") { type = NavType.StringType; defaultValue = StudyDir.Forward },
                    navArgument("from") { type = NavType.IntType; defaultValue = 0 },
                    navArgument("to") { type = NavType.IntType; defaultValue = 0 },
                ),
                enterTransition = { slideInVertically(slide) { it / 4 } + fadeIn() },
                popExitTransition = { slideOutVertically(slide) { it / 4 } + fadeOut() },
            ) { entry ->
                val scope = runCatching { StudyScope.valueOf(entry.arguments?.getString("scope").orEmpty()) }
                    .getOrDefault(StudyScope.All)
                val id = entry.arguments?.getLong("id") ?: 0L
                val mode = entry.arguments?.getString("mode").orEmpty()
                val dir = entry.arguments?.getString("dir") ?: StudyDir.Forward
                val from = entry.arguments?.getInt("from") ?: 0
                val to = entry.arguments?.getInt("to") ?: 0
                val back: () -> Unit = { nav.popBackStack() }
                when (mode) {
                    StudyMode.Choice -> ChoiceScreen(scope, id, dir, back, from, to)
                    StudyMode.Typing -> TypingScreen(scope, id, dir, back, from, to)
                    StudyMode.Match -> MatchScreen(scope, id, dir, back, from, to)
                    StudyMode.Cloze -> com.lingosnap.ui.practice.ClozeScreen(scope, id, back, from, to)
                    StudyMode.Listen -> com.lingosnap.ui.practice.ListenScreen(scope, id, back, from, to)
                    StudyMode.Speak -> com.lingosnap.ui.practice.SpeakScreen(scope, id, back, from, to)
                    StudyMode.Sentence -> com.lingosnap.ui.practice.SentenceScreen(scope, id, back, from, to)
                    else -> StudyScreen(scope, id, dir, onlyDue = mode != StudyMode.FlashAll, onBack = back, from = from, to = to)
                }
            }
        }
    }
}
