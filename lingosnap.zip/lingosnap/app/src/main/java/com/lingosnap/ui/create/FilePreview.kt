package com.lingosnap.ui.create

import com.lingosnap.util.tr
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** What is shown for one chosen file: name, kind, size. */
private class FileInfo(val name: String, val kind: Kind, val size: Long) {
    enum class Kind { Image, Pdf, Word, Slides, Text }
}

private fun fileInfo(context: Context, uri: Uri): FileInfo {
    var name = ""
    var size = -1L
    runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst()) {
                name = it.getString(0).orEmpty()
                if (!it.isNull(1)) size = it.getLong(1)
            }
        }
    }
    if (name.isBlank()) name = uri.lastPathSegment.orEmpty()
    val lower = name.lowercase()
    val mime = context.contentResolver.getType(uri).orEmpty()
    val kind = when {
        mime.startsWith("image/") || listOf(".jpg", ".jpeg", ".png", ".webp", ".heic").any { lower.endsWith(it) } -> FileInfo.Kind.Image
        mime == "application/pdf" || lower.endsWith(".pdf") -> FileInfo.Kind.Pdf
        lower.endsWith(".docx") -> FileInfo.Kind.Word
        lower.endsWith(".pptx") -> FileInfo.Kind.Slides
        else -> FileInfo.Kind.Text
    }
    return FileInfo(name, kind, size)
}

private fun sizeText(bytes: Long): String = when {
    bytes < 0 -> ""
    bytes < 1024 * 1024 -> "${maxOf(1, bytes / 1024)} KB"
    else -> String.format(java.util.Locale.getDefault(), "%.1f MB", bytes / 1024f / 1024f)
}

/** Small picture of a photo or of the first page of a PDF; null for other files. */
private fun thumbnail(context: Context, uri: Uri, kind: FileInfo.Kind, px: Int = 240): Bitmap? = runCatching {
    when (kind) {
        FileInfo.Kind.Image -> {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= px) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
        FileInfo.Kind.Pdf -> context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            PdfRenderer(pfd).use { r ->
                if (r.pageCount == 0) null
                else r.openPage(0).use { page ->
                    val h = (page.height * px.toFloat() / page.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(px, h, Bitmap.Config.ARGB_8888)
                    Canvas(bmp).drawColor(AndroidColor.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            }
        }
        else -> null
    }
}.getOrNull()

/** One chosen file as a small preview card with a remove button. */
@Composable
fun FilePreviewRow(uri: Uri, onRemove: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val info = remember(uri) { fileInfo(context, uri) }
    val thumb by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { thumbnail(context, uri, info.kind)?.asImageBitmap() }
    }
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerHigh) {
        Row(Modifier.padding(start = 10.dp, top = 10.dp, bottom = 10.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                val bmp = thumb
                if (bmp != null) {
                    Image(bmp, null, Modifier.size(64.dp), contentScale = ContentScale.Crop)
                } else {
                    Surface(Modifier.size(64.dp), color = cs.secondaryContainer) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                when (info.kind) {
                                    FileInfo.Kind.Image -> Icons.Rounded.Image
                                    FileInfo.Kind.Pdf -> Icons.Rounded.PictureAsPdf
                                    FileInfo.Kind.Slides -> Icons.Rounded.Slideshow
                                    else -> Icons.Rounded.Description
                                },
                                null, tint = cs.onSecondaryContainer,
                            )
                        }
                    }
                }
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(info.name, style = MaterialTheme.typography.titleSmall.bold(), maxLines = 2, overflow = TextOverflow.Ellipsis)
                val kind = when (info.kind) {
                    FileInfo.Kind.Image -> tr("Bild")
                    FileInfo.Kind.Pdf -> "PDF"
                    FileInfo.Kind.Word -> "Word"
                    FileInfo.Kind.Slides -> "PowerPoint"
                    FileInfo.Kind.Text -> tr("Text")
                }
                Text(listOf(kind, sizeText(info.size)).filter { it.isNotEmpty() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            IconButton(onClick = onRemove) { Icon(Icons.Rounded.Close, tr("Datei entfernen")) }
        }
    }
}
