package com.lingosnap.util

import com.lingosnap.util.tr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.lingosnap.MainActivity

const val EXTRA_OPEN_DECK = "open_deck"

/** Notifications for AI jobs that run in the background. */
class Notifier(private val context: Context) {
    init {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(PROGRESS, tr("KI arbeitet"), NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(DONE, tr("KI fertig"), NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    /** Keeps the process alive (and shows an ongoing notification) while the user does something else. */
    fun startKeepAlive() {
        runCatching { ContextCompat.startForegroundService(context, Intent(context, AiKeepAliveService::class.java)) }
    }

    fun stopKeepAlive() {
        runCatching { context.stopService(Intent(context, AiKeepAliveService::class.java)) }
    }

    private var lastShown = ""

    /** Updates the ongoing notification: percent and what the AI is doing right now. */
    fun progress(deckId: Long, deckName: String, percent: Int, status: String) {
        val key = "${percent}|${status}"
        if (key == lastShown) return
        lastShown = key
        val n = NotificationCompat.Builder(context, PROGRESS)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(tr("KI arbeitet – {0}", deckName))
            .setContentText("${percent} % • ${status}")
            .setProgress(100, percent, false)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel, tr("Abbrechen"),
                PendingIntent.getBroadcast(
                    context, deckId.toInt(),
                    Intent(context, AiCancelReceiver::class.java).putExtra("deck", deckId),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                ),
            )
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()
        runCatching {
            if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                @Suppress("MissingPermission")
                NotificationManagerCompat.from(context).notify(1, n)
            }
        }
    }

    fun cancelProgress() {
        lastShown = ""
        runCatching { NotificationManagerCompat.from(context).cancel(1) }
    }

    fun done(deckId: Long, title: String, text: String) {
        val open = PendingIntent.getActivity(
            context, deckId.toInt(),
            Intent(context, MainActivity::class.java)
                .putExtra(EXTRA_OPEN_DECK, deckId)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(context, DONE)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        runCatching {
            if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                @Suppress("MissingPermission")
                NotificationManagerCompat.from(context).notify(1000 + deckId.toInt(), n)
            }
        }
    }

    companion object {
        const val PROGRESS = "ai_progress"
        const val DONE = "ai_done"
    }
}

class AiKeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n: Notification = NotificationCompat.Builder(this, Notifier.PROGRESS)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(tr("KI arbeitet"))
            .setContentText(tr("Du bekommst eine Nachricht, sobald es fertig ist."))
            .setProgress(0, 0, true)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)
        return START_NOT_STICKY
    }
}

/** Running AI jobs per deck, so the deck list can show progress. */
data class JobInfo(val percent: Int, val status: String)

object AiJobs {
    val state = kotlinx.coroutines.flow.MutableStateFlow<Map<Long, JobInfo>>(emptyMap())
    private val handles = java.util.concurrent.ConcurrentHashMap<Long, kotlinx.coroutines.Job>()
    fun set(deckId: Long, info: JobInfo) { state.value = state.value + (deckId to info) }
    fun clear(deckId: Long) { state.value = state.value - deckId; handles.remove(deckId) }
    fun register(deckId: Long, job: kotlinx.coroutines.Job) { handles[deckId] = job }
    /** Stops the running AI job of a deck (from the deck list or the notification). */
    fun cancel(deckId: Long) { handles[deckId]?.cancel() }
}

/** "Abbrechen" button of the progress notification. */
class AiCancelReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AiJobs.cancel(intent.getLongExtra("deck", 0L))
    }
}

/** Results of AI jobs that finished after the add-cards screen was closed. */
object PendingStore {
    private val map = java.util.concurrent.ConcurrentHashMap<Long, List<com.lingosnap.data.remote.VocabPair>>()
    fun put(deckId: Long, pairs: List<com.lingosnap.data.remote.VocabPair>) { map[deckId] = pairs }
    fun take(deckId: Long): List<com.lingosnap.data.remote.VocabPair>? = map.remove(deckId)
}
