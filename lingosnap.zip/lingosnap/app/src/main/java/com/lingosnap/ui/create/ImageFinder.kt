package com.lingosnap.ui.create

import androidx.compose.material.icons.rounded.Image
import com.lingosnap.util.tr

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.remote.ImageSearch
import com.lingosnap.data.remote.WebImage
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.util.CardImages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Finds a picture for a card on Wikipedia / Wikimedia Commons. The AI turns the card into good search terms first;
 * the learner picks one result, it is stored like any other card picture and the finder returns its path.
 */
@Composable
fun ImageFinderDialog(question: String, answer: String, onPicked: (String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val gemini = context.container.gemini
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf(question.trim()) }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    var results by remember { mutableStateOf<List<WebImage>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    suspend fun run(q: String) {
        loading = true
        message = null
        results = runCatching { ImageSearch.search(q) }.getOrDefault(emptyList())
        if (results.isEmpty()) message = tr("Keine Bilder gefunden. Probiere einen anderen Suchbegriff.")
        loading = false
    }

    LaunchedEffect(Unit) {
        // the AI proposes better terms than the raw question; the first one is used right away
        val terms = runCatching { gemini.imageQueries(question, answer).getOrNull() }.getOrNull().orEmpty()
        suggestions = terms
        if (terms.isNotEmpty()) query = terms.first()
        run(query)
    }

    com.lingosnap.ui.components.FormSheet(
        title = tr("Bild suchen"),
        icon = androidx.compose.material.icons.Icons.Rounded.Image,
        onDismiss = onDismiss,
        busy = saving,
    ) {
                AppTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text(tr("Suchbegriff")) },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { scope.launch { run(query) } }),
                )
                if (suggestions.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        suggestions.forEach { t ->
                            FilterChip(selected = query == t, onClick = { query = t; scope.launch { run(t) } }, label = { Text(t) })
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 340.dp), contentAlignment = Alignment.Center) {
                    when {
                        loading || saving -> CircularProgressIndicator()
                        message != null -> Text(message.orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else -> LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            items(results, key = { it.url }) { img ->
                                WebThumb(img) {
                                    saving = true
                                    scope.launch {
                                        val bytes = ImageSearch.bytes(img.url)
                                        val path = bytes?.let {
                                            withContext(Dispatchers.IO) {
                                                val f = File.createTempFile("web_", ".img", File(context.cacheDir, "images").apply { mkdirs() })
                                                f.writeBytes(it)
                                                CardImages.import(context, android.net.Uri.fromFile(f)).also { f.delete() }
                                            }
                                        }
                                        saving = false
                                        if (path != null) onPicked(path) else message = tr("Das Bild konnte nicht geladen werden.")
                                    }
                                }
                            }
                        }
                    }
                }
                Text(
                    tr("Quelle: Wikipedia und Wikimedia Commons. Manche Bilder verlangen eine Namensnennung, Details stehen auf der Bildseite."),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
    }
}

@Composable
private fun WebThumb(img: WebImage, onClick: () -> Unit) {
    val bitmap by produceState<ImageBitmap?>(null, img.url) {
        value = withContext(Dispatchers.IO) {
            ImageSearch.bytes(img.url)?.let { b ->
                runCatching {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                    BitmapFactory.decodeByteArray(b, 0, b.size, opts)?.asImageBitmap()
                }.getOrNull()
            }
        }
    }
    Box(
        Modifier.aspectRatio(1f).clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.surfaceContainerHigh).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        bitmap?.let { Image(it, img.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}
