package com.lingosnap.util

import com.lingosnap.util.tr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** One request to the AI: some text and/or some images that are only loaded when the request starts (keeps memory low). */
class Batch(val text: String = "", val images: (suspend () -> List<ByteArray>)? = null)

/** Everything the user picked, split into requests of a size the AI can answer completely. */
class Material(val batches: List<Batch>)

/** Turns pictures, PDFs, Word and PowerPoint files (and plain text) into material for the AI. No limit on files or pages. */
object DocumentReader {
    private const val IMAGES_PER_BATCH = 6
    private const val CHARS_PER_BATCH = 12000

    val MIME_TYPES = arrayOf(
        "image/*",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain",
    )

    private sealed interface Src {
        class Photo(val uri: Uri) : Src
        class PdfPage(val uri: Uri, val index: Int) : Src
    }

    private val pdfLock = Mutex()

    suspend fun read(context: Context, uris: List<Uri>): Material = withContext(Dispatchers.IO) {
        val sources = ArrayList<Src>()
        val text = StringBuilder()
        for (uri in uris) {
            val name = displayName(context, uri)
            val lower = name.lowercase()
            val mime = context.contentResolver.getType(uri).orEmpty()
            when {
                mime.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") ->
                    sources += Src.Photo(uri)
                mime == "application/pdf" || lower.endsWith(".pdf") -> readPdf(context, uri, sources, text)
                lower.endsWith(".docx") -> text.appendLine(readDocx(context, uri))
                lower.endsWith(".pptx") -> text.appendLine(readPptx(context, uri))
                mime.startsWith("text/") || lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".csv") ->
                    text.appendLine(context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty())
                else -> throw IllegalArgumentException(
                    tr("„{0}“ wird nicht unterstützt. Möglich sind Bilder, PDF, Word (.docx), PowerPoint (.pptx) und Textdateien.", name),
                )
            }
        }
        val batches = ArrayList<Batch>()
        sources.chunked(IMAGES_PER_BATCH).forEach { chunk ->
            batches += Batch(images = { loadImages(context, chunk) })
        }
        chunkText(compact(text.toString())).forEach { batches += Batch(text = it) }
        if (batches.isEmpty()) throw IllegalArgumentException(tr("In der Datei wurde kein lesbarer Inhalt gefunden."))
        Material(batches)
    }

    private fun displayName(context: Context, uri: Uri): String =
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment.orEmpty()

    /* ───── text preparation ───── */

    /** Removes page numbers, repeated headers/footers and blank runs: fewer tokens, same content. */
    fun compact(raw: String): String {
        val lines = raw.lines().map { it.trim() }
        val repeated = lines.filter { it.length in 3..60 }.groupingBy { it }.eachCount().filter { it.value >= 25 }.keys
        val out = StringBuilder()
        var blank = 0
        for (l in lines) {
            if (l.matches(Regex("\\d{1,5}")) || l in repeated) continue
            if (l.isEmpty()) { if (++blank <= 1) out.append('\n'); continue }
            blank = 0
            out.append(l).append('\n')
        }
        return out.toString().trim()
    }

    /** Cuts the text into requests of about [CHARS_PER_BATCH] characters, preferably at blank lines. */
    private fun chunkText(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (line in text.lines()) {
            val full = sb.length + line.length > CHARS_PER_BATCH
            val soft = sb.length > CHARS_PER_BATCH * 0.8 && line.isBlank()
            if ((full || soft) && sb.isNotEmpty()) { out += sb.toString(); sb.clear() }
            var rest = line
            while (rest.length > CHARS_PER_BATCH) { out += rest.take(CHARS_PER_BATCH); rest = rest.drop(CHARS_PER_BATCH) }
            sb.appendLine(rest)
        }
        if (sb.isNotBlank()) out += sb.toString()
        return out
    }

    /* ───── images ───── */

    private suspend fun loadImages(context: Context, chunk: List<Src>): List<ByteArray> {
        val out = ArrayList<ByteArray>()
        var i = 0
        while (i < chunk.size) {
            val s = chunk[i]
            if (s is Src.Photo) { out += ImageUtils.loadJpeg(context, s.uri); i++ }
            else if (s is Src.PdfPage) {
                // render neighbouring pages of the same file in one go
                val pages = ArrayList<Int>()
                var j = i
                while (j < chunk.size && (chunk[j] as? Src.PdfPage)?.uri == s.uri) { pages += (chunk[j] as Src.PdfPage).index; j++ }
                out += renderPdfPages(context, s.uri, pages)
                i = j
            }
        }
        return out
    }

    private suspend fun renderPdfPages(context: Context, uri: Uri, pages: List<Int>): List<ByteArray> = pdfLock.withLock {
        withContext(Dispatchers.IO) {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: error(tr("Datei konnte nicht geöffnet werden"))
            val out = ArrayList<ByteArray>()
            pfd.use {
                PdfRenderer(it).use { renderer ->
                    for (i in pages) {
                        renderer.openPage(i).use { page ->
                            val w = 1024
                            val h = (page.height * w.toFloat() / page.width).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            Canvas(bmp).drawColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            out += ByteArrayOutputStream().use { s ->
                                bmp.compress(Bitmap.CompressFormat.JPEG, 75, s)
                                s.toByteArray()
                            }
                            bmp.recycle()
                        }
                    }
                }
            }
            out
        }
    }

    /* ───── PDF: text layer first, page images only for scans ───── */

    private fun readPdf(context: Context, uri: Uri, sources: MutableList<Src>, text: StringBuilder) {
        val extracted = runCatching { pdfText(context, uri) }.getOrNull()
        if (extracted != null) { text.appendLine(extracted); return }
        // scanned PDF without a text layer: every page is sent as an image, loaded one request at a time
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: error(tr("Datei konnte nicht geöffnet werden"))
        val count = pfd.use { PdfRenderer(it).use { r -> r.pageCount } }
        for (i in 0 until count) sources += Src.PdfPage(uri, i)
    }

    /** Text of the whole PDF, or null if it is a scan (little or no text on the first pages). */
    private fun pdfText(context: Context, uri: Uri): String? {
        PDFBoxResourceLoader.init(context.applicationContext)
        context.contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { doc ->
                val pages = doc.numberOfPages
                if (pages == 0) return null
                val probeEnd = minOf(pages, 5)
                val probe = PDFTextStripper().apply { startPage = 1; endPage = probeEnd }.getText(doc)
                if (probe.length < probeEnd * 150) return null
                return PDFTextStripper().apply { sortByPosition = true }.getText(doc)
            }
        }
        return null
    }

    /* ───── Word / PowerPoint ───── */

    private fun zipEntries(context: Context, uri: Uri, wanted: (String) -> Boolean): Map<String, String> {
        val map = LinkedHashMap<String, String>()
        context.contentResolver.openInputStream(uri)?.let { ZipInputStream(it) }?.use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (wanted(e.name)) map[e.name] = zip.readBytes().toString(Charsets.UTF_8)
            }
        }
        return map
    }

    private fun readDocx(context: Context, uri: Uri): String {
        val xml = zipEntries(context, uri) { it == "word/document.xml" }["word/document.xml"] ?: return ""
        return xml.replace("</w:p>", "\n").replace("<w:tab/>", " ").let { collect(it, "w:t") }
    }

    private fun readPptx(context: Context, uri: Uri): String {
        val slides = zipEntries(context, uri) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
        return slides.entries
            .sortedBy { Regex("(\\d+)\\.xml").find(it.key)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
            .joinToString("\n\n") { (name, xml) ->
                val n = Regex("(\\d+)\\.xml").find(name)?.groupValues?.get(1)
                tr("Folie {0}:\n", n) + collect(xml.replace("</a:p>", "\n"), "a:t")
            }
    }

    /** Joins the content of all <tag>…</tag> elements, keeping line breaks. */
    private fun collect(xml: String, tag: String): String {
        val re = Regex("<${tag}(?:\\s[^>]*)?>(.*?)</${tag}>|\n", RegexOption.DOT_MATCHES_ALL)
        val sb = StringBuilder()
        re.findAll(xml).forEach { m ->
            if (m.value == "\n") sb.append('\n') else sb.append(unescape(m.groupValues[1]))
        }
        return sb.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
    }

    private fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&")
}
