package com.lingosnap.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** What the AI gets to read: page images and/or extracted text. */
class Material(val images: List<ByteArray>, val text: String) {
    /** Splits everything into requests of a size the AI can answer completely: a few pages or a few thousand characters each. */
    fun batches(imagesPerBatch: Int = 6, charsPerBatch: Int = 12000): List<Pair<List<ByteArray>, String>> {
        val out = ArrayList<Pair<List<ByteArray>, String>>()
        images.chunked(imagesPerBatch).forEach { out += it to "" }
        val paragraphs = text.split("\n")
        val sb = StringBuilder()
        for (line in paragraphs) {
            if (sb.length + line.length > charsPerBatch && sb.isNotEmpty()) { out += emptyList<ByteArray>() to sb.toString(); sb.clear() }
            // a single very long line is cut into pieces
            var rest = line
            while (rest.length > charsPerBatch) { out += emptyList<ByteArray>() to rest.take(charsPerBatch); rest = rest.drop(charsPerBatch) }
            sb.appendLine(rest)
        }
        if (sb.isNotBlank()) out += emptyList<ByteArray>() to sb.toString()
        return out
    }
}

/** Turns pictures, PDFs, Word and PowerPoint files (and plain text) into material for the AI. */
object DocumentReader {

    val MIME_TYPES = arrayOf(
        "image/*",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain",
    )

    suspend fun read(context: Context, uris: List<Uri>): Material = withContext(Dispatchers.IO) {
        val images = ArrayList<ByteArray>()
        val text = StringBuilder()
        for (uri in uris) {
            val name = displayName(context, uri)
            val lower = name.lowercase()
            val mime = context.contentResolver.getType(uri).orEmpty()
            when {
                mime.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") ->
                    images += ImageUtils.loadJpeg(context, uri)
                mime == "application/pdf" || lower.endsWith(".pdf") -> images += renderPdf(context, uri)
                lower.endsWith(".docx") -> text.appendLine(readDocx(context, uri))
                lower.endsWith(".pptx") -> text.appendLine(readPptx(context, uri))
                mime.startsWith("text/") || lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".csv") ->
                    text.appendLine(context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty())
                else -> throw IllegalArgumentException(
                    "„$name“ wird nicht unterstützt. Möglich sind Bilder, PDF, Word (.docx), PowerPoint (.pptx) und Textdateien.",
                )
            }
        }
        if (images.isEmpty() && text.isBlank()) {
            throw IllegalArgumentException("In der Datei wurde kein lesbarer Inhalt gefunden.")
        }
        Material(images, text.toString())
    }

    private fun displayName(context: Context, uri: Uri): String =
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment.orEmpty()

    private fun renderPdf(context: Context, uri: Uri): List<ByteArray> {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: error("Datei konnte nicht geöffnet werden")
        val out = ArrayList<ByteArray>()
        pfd.use {
            PdfRenderer(it).use { renderer ->
                for (i in 0 until renderer.pageCount) {
                    renderer.openPage(i).use { page ->
                        val w = 1280
                        val h = (page.height * w.toFloat() / page.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        Canvas(bmp).drawColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out += ByteArrayOutputStream().use { s ->
                            bmp.compress(Bitmap.CompressFormat.JPEG, 75, s)
                            s.toByteArray()
                        }
                        bmp.recycle()
                    }
                }
            }
        }
        return out
    }

    private fun zipEntries(context: Context, uri: Uri, wanted: (String) -> Boolean): Map<String, String> {
        val map = LinkedHashMap<String, String>()
        context.contentResolver.openInputStream(uri)?.let { ZipInputStream(it) }?.use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (wanted(e.name)) map[e.name] = zip.readBytes().toString(Charsets.UTF_8)
            }
        }
        return map
    }

    private fun readDocx(context: Context, uri: Uri): String {
        val xml = zipEntries(context, uri) { it == "word/document.xml" }["word/document.xml"] ?: return ""
        return xml.replace("</w:p>", "\n").replace("<w:tab/>", " ").let { collect(it, "w:t") }
    }

    private fun readPptx(context: Context, uri: Uri): String {
        val slides = zipEntries(context, uri) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
        return slides.entries
            .sortedBy { Regex("(\\d+)\\.xml").find(it.key)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
            .joinToString("\n\n") { (name, xml) ->
                val n = Regex("(\\d+)\\.xml").find(name)?.groupValues?.get(1)
                "Folie $n:\n" + collect(xml.replace("</a:p>", "\n"), "a:t")
            }
    }

    /** Joins the content of all <tag>…</tag> elements, keeping line breaks. */
    private fun collect(xml: String, tag: String): String {
        val re = Regex("<$tag(?:\\s[^>]*)?>(.*?)</$tag>|\n", RegexOption.DOT_MATCHES_ALL)
        val sb = StringBuilder()
        re.findAll(xml).forEach { m ->
            if (m.value == "\n") sb.append('\n') else sb.append(unescape(m.groupValues[1]))
        }
        return sb.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
    }

    private fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&")
}
