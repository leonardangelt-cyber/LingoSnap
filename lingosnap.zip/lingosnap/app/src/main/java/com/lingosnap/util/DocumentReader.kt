package com.lingosnap.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/**
 * One request to the AI: a block of text, or a file (a photo, or a scanned PDF) that is only loaded when the request starts.
 * [pdf] = the original PDF (sent as it is to providers that read PDFs); [images] = the same content as photos for the others.
 */
class Batch(
    val label: String,
    val text: String = "",
    val pdf: (suspend () -> ByteArray)? = null,
    val images: (suspend () -> List<ByteArray>)? = null,
)

/** Everything the user picked, as the requests that are sent one after another. */
class Material(val batches: List<Batch>, val firstFileName: String)

/**
 * File reading as in the web app: a photo is optimised and sent as one request; a PDF, Word or PowerPoint file is read for its text first
 * (blocks of at most 10,000 characters, one request each); only a PDF without text (a scan) goes to the AI as it is; text files are sent as text.
 */
object DocumentReader {
    /** A PDF as it is goes into one request up to this size (the AI accepts about 20 MB per request, base64 adds a third). */
    private const val MAX_PDF_BYTES = 14L * 1024 * 1024
    private const val PAGES_PER_BATCH = 4
    /** Less text than this in a PDF = a scan. */
    private const val MIN_TEXT_CHARS = 40

    val MIME_TYPES = arrayOf(
        "image/*",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain",
        "text/csv",
        "text/tab-separated-values",
        "text/markdown",
        "application/json",
    )

    private val pdfLock = Mutex()

    private val textExtensions = listOf(".txt", ".csv", ".tsv", ".md", ".json")

    suspend fun read(context: Context, uris: List<Uri>): Material = withContext(Dispatchers.IO) {
        // the files are read at the same time (text extraction of big PDFs is the slow part); the order of the requests stays the same
        val perFile = coroutineScope {
            uris.map { uri -> async { readOne(context, uri) } }.awaitAll()
        }
        val batches = perFile.flatten()
        if (batches.isEmpty()) throw IllegalArgumentException(tr("In der Datei wurde kein lesbarer Inhalt gefunden."))
        Material(batches, displayName(context, uris.first()).substringBeforeLast('.'))
    }

    private suspend fun readOne(context: Context, uri: Uri): List<Batch> {
        val name = displayName(context, uri)
        val lower = name.lowercase()
        val mime = context.contentResolver.getType(uri).orEmpty()
        return when {
            mime.startsWith("image/") || listOf(".jpg", ".jpeg", ".png", ".webp", ".heic").any { lower.endsWith(it) } ->
                // optimised on the phone first: 1280 px, grey, more contrast, JPEG 75 %
                listOf(Batch(name, images = { listOf(ImageUtils.loadJpeg(context, uri, maxEdge = 1280, enhance = true)) }))
            mime == "application/pdf" || lower.endsWith(".pdf") -> readPdf(context, uri, name)
            lower.endsWith(".docx") -> textBatches(name, readDocx(context, uri))
            lower.endsWith(".pptx") -> textBatches(name, readPptx(context, uri))
            mime.startsWith("text/") || mime == "application/json" || textExtensions.any { lower.endsWith(it) } -> {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                textBatches(name, raw)
            }
            else -> throw IllegalArgumentException(
                tr("„{0}“ wird nicht unterstützt. Möglich sind Bilder, PDF, Word (.docx), PowerPoint (.pptx) und Textdateien.", name),
            )
        }
    }

    private fun textBatches(name: String, text: String): List<Batch> {
        if (text.isBlank()) throw IllegalArgumentException(tr("„{0}“ enthält keinen lesbaren Text.", name))
        return Chunker.chunk(text).mapIndexed { i, t -> Batch(if (i == 0) name else "$name (${i + 1})", text = t) }
    }

    fun displayName(context: Context, uri: Uri): String =
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment.orEmpty()

    /* ───── PDF: text first (digital PDF), the PDF itself only for scans ───── */

    private fun readPdf(context: Context, uri: Uri, name: String): List<Batch> {
        val text = runCatching { pdfText(context, uri) }.getOrNull().orEmpty()
        if (text.trim().length >= MIN_TEXT_CHARS) return textBatches(name, text)

        // no text found: a scan. The PDF goes to the AI as one request.
        val size = context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        val pageCount = context.contentResolver.openFileDescriptor(uri, "r")?.use { PdfRenderer(it).use { r -> r.pageCount } }
            ?: error(tr("Datei konnte nicht geöffnet werden"))
        if (size in 1..MAX_PDF_BYTES) {
            return listOf(
                Batch(
                    name,
                    pdf = { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error(tr("Datei konnte nicht geöffnet werden")) },
                    // for providers that cannot read a PDF: the first pages as photos
                    images = { renderPdfPages(context, uri, (0 until minOf(pageCount, 20)).toList()) },
                ),
            )
        }
        // a huge scan does not fit into one request: a few pages at a time as photos
        return (0 until pageCount).chunked(PAGES_PER_BATCH).mapIndexed { i, pages ->
            Batch("$name (${pages.first() + 1}–${pages.last() + 1})", images = { renderPdfPages(context, uri, pages) })
        }
    }

    private suspend fun renderPdfPages(context: Context, uri: Uri, pages: List<Int>): List<ByteArray> = pdfLock.withLock {
        withContext(Dispatchers.IO) {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: error(tr("Datei konnte nicht geöffnet werden"))
            val out = ArrayList<ByteArray>()
            pfd.use {
                PdfRenderer(it).use { renderer ->
                    for (i in pages) {
                        renderer.openPage(i).use { page ->
                            val w = 1280
                            val h = (page.height * w.toFloat() / page.width).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            Canvas(bmp).drawColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            ImageUtils.enhanceForOcr(bmp)
                            out += ByteArrayOutputStream().use { s ->
                                bmp.compress(Bitmap.CompressFormat.JPEG, 75, s)
                                s.toByteArray()
                            }
                            bmp.recycle()
                        }
                    }
                }
            }
            out
        }
    }

    /** All text of the PDF (empty for a scan). */
    private fun pdfText(context: Context, uri: Uri): String {
        PDFBoxResourceLoader.init(context.applicationContext)
        context.contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { doc ->
                if (doc.numberOfPages == 0) return ""
                return PDFTextStripper().apply { sortByPosition = true }.getText(doc)
            }
        }
        return ""
    }

    /* ───── Word / PowerPoint ───── */

    private fun zipEntries(context: Context, uri: Uri, wanted: (String) -> Boolean): Map<String, String> {
        val map = LinkedHashMap<String, String>()
        context.contentResolver.openInputStream(uri)?.let { ZipInputStream(it) }?.use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (wanted(e.name)) map[e.name] = zip.readBytes().toString(Charsets.UTF_8)
            }
        }
        return map
    }

    private fun readDocx(context: Context, uri: Uri): String {
        val xml = zipEntries(context, uri) { it == "word/document.xml" }["word/document.xml"] ?: return ""
        return xml.replace("</w:p>", "\n").replace("<w:tab/>", " ").let { collect(it, "w:t") }
    }

    private fun readPptx(context: Context, uri: Uri): String {
        val slides = zipEntries(context, uri) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
        return slides.entries
            .sortedBy { Regex("(\\d+)\\.xml").find(it.key)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
            .joinToString("\n\n") { (name, xml) ->
                val n = Regex("(\\d+)\\.xml").find(name)?.groupValues?.get(1)
                tr("Folie {0}:\n", n) + collect(xml.replace("</a:p>", "\n"), "a:t")
            }
    }

    /** Joins the content of all <tag>…</tag> elements, keeping line breaks. */
    private fun collect(xml: String, tag: String): String {
        val re = Regex("<${tag}(?:\\s[^>]*)?>(.*?)</${tag}>|\n", RegexOption.DOT_MATCHES_ALL)
        val sb = StringBuilder()
        re.findAll(xml).forEach { m ->
            if (m.value == "\n") sb.append('\n') else sb.append(unescape(m.groupValues[1]))
        }
        return sb.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
    }

    private fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&")
}
