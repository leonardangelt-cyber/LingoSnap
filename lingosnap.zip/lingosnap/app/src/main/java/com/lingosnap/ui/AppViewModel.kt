package com.lingosnap.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.CardRepository
import com.lingosnap.data.Stats
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.LearnProgress
import com.lingosnap.data.model.Srs
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Everything the main screens need, as one immutable snapshot. */
data class AppState(
    val groups: List<DeckGroup> = emptyList(),
    val decks: List<Deck> = emptyList(),
    val cards: List<Flashcard> = emptyList(),
    val stats: Stats = Stats(),
    val loading: Boolean = true,
) {
    val mastered: Int get() = cards.count { it.level >= Srs.MAX_LEVEL }

    fun dueCount(now: Long = System.currentTimeMillis()): Int = cards.count { it.dueAt <= now }
    fun cardsOf(deckId: Long): List<Flashcard> = cards.filter { it.deckId == deckId }
    fun decksOf(groupId: Long?): List<Deck> = decks.filter { it.groupId == groupId }
    fun deck(id: Long): Deck? = decks.firstOrNull { it.id == id }

    val progress: LearnProgress
        get() = LearnProgress(stats = stats, cardCount = cards.size, deckCount = decks.size, mastered = mastered)
}

class AppViewModel(private val repo: CardRepository) : ViewModel() {

    val state: StateFlow<AppState> = combine(
        repo.groups, repo.decks, repo.cards, repo.stats.stats,
    ) { groups, decks, cards, stats ->
        AppState(groups = groups, decks = decks, cards = cards, stats = stats, loading = false)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppState())

    fun deleteDeck(id: Long) = viewModelScope.launch { repo.deleteDeck(id) }
    fun deleteGroup(id: Long, withDecks: Boolean) = viewModelScope.launch { repo.deleteGroup(id, withDecks) }
    fun createGroup(name: String) = viewModelScope.launch { repo.createGroup(name) }

    fun addCard(deck: Deck, source: String, target: String, example: String?, imagePath: String? = null) =
        viewModelScope.launch { repo.addCard(deck, source, target, example, imagePath) }

    fun updateCard(card: Flashcard) = viewModelScope.launch { repo.updateCard(card) }
    fun deleteCard(card: Flashcard) = viewModelScope.launch { repo.deleteCard(card) }
    fun deleteCards(cards: List<Flashcard>) = viewModelScope.launch { repo.deleteCards(cards) }
    fun moveDeckToFolder(deck: Deck, groupId: Long?) = viewModelScope.launch { repo.moveDeckToFolder(deck, groupId) }
    fun createFolderFor(deck: Deck, name: String) = viewModelScope.launch { repo.createFolderFor(deck, name) }
    fun deleteCardsSoft(cards: List<Flashcard>) = viewModelScope.launch { repo.deleteCardsSoft(cards) }
    fun restoreCards(cards: List<Flashcard>) = viewModelScope.launch { repo.restoreCards(cards) }
    fun purgeImages(cards: List<Flashcard>) = repo.purgeImages(cards)
    fun moveCards(cards: List<Flashcard>, target: Deck) = viewModelScope.launch { repo.moveCards(cards, target) }
    fun mergeDecks(from: Deck, into: Deck) = viewModelScope.launch { repo.mergeDecks(from, into) }
    fun clearEverything() = viewModelScope.launch { repo.clearEverything() }

    // settings
    fun setUserName(name: String) = repo.stats.setUserName(name)
    fun setDarkMode(mode: Int) = repo.stats.setDarkMode(mode)
    fun setDailyGoalValue(goal: Int) = repo.stats.setDailyGoal(goal)
    fun setReminders(on: Boolean) = repo.stats.setReminders(on)
    fun setReminderTime(hour: Int, minute: Int) = repo.stats.setReminderTime(hour, minute)
    fun setRemindOnlyDue(on: Boolean) = repo.stats.setRemindOnlyDue(on)
    fun setStreakFreezeOn(on: Boolean) = repo.stats.setStreakFreeze(on)
    fun setAccent(accent: Int) = repo.stats.setAccent(accent)
    fun setAccentStyle(style: Int) = repo.stats.setAccentStyle(style)
    fun setDailyGoal(goal: Int) = repo.stats.setDailyGoal(goal)
    fun setStreakFreeze(on: Boolean) = repo.stats.setStreakFreeze(on)

    companion object {
        val Factory = viewModelFactory { initializer { AppViewModel(app().container.repository) } }
    }
}
