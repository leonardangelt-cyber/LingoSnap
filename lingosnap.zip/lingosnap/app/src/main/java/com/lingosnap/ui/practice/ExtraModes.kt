package com.lingosnap.ui.practice

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageNameEn
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.AnswerResult
import com.lingosnap.util.checkAnswer
import kotlinx.coroutines.launch

/** The word as it appears in the example sentence (so "la casa" also matches "… casa …"), or null. */
private fun gapOf(card: Flashcard): String? {
    val ex = card.example?.takeIf { it.isNotBlank() } ?: return null
    val words = card.source.trim().split(Regex("\\s+"))
    val options = listOf(card.source.trim(), words.drop(1).joinToString(" ")).filter { it.isNotBlank() }.distinct()
    for (o in options) {
        val i = ex.indexOf(o, ignoreCase = true)
        if (i >= 0) return ex.substring(i, i + o.length)
    }
    return null
}

/**
 * One round of "type what you see/hear": shared by the cloze and listening modes.
 * [prompt] draws the question, [expected] is the right answer.
 */
@Composable
private fun TextDrill(
    title: String,
    vm: PracticeViewModel,
    cards: List<Flashcard>,
    emptyText: String,
    onBack: () -> Unit,
    expected: (Flashcard) -> String,
    onCard: (Flashcard) -> Unit = {},
    prompt: @Composable ColumnScope.(Flashcard) -> Unit,
) {
    var index by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<AnswerResult?>(null) }
    var correctCount by remember { mutableIntStateOf(0) }
    var handled by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val finished = !vm.loading && index >= cards.size
    val current = cards.getOrNull(index)

    LaunchedEffect(finished) {
        if (finished && !handled && cards.isNotEmpty()) {
            handled = true
            vm.finish(perfect = correctCount == cards.size, bonusXp = correctCount * 4)
        }
    }
    LaunchedEffect(index, vm.loading) {
        if (!vm.loading && current != null) {
            onCard(current)
            runCatching { focus.requestFocus() }
        }
    }

    fun submit() {
        val c = current ?: return
        if (result != null || input.isBlank()) return
        val r = checkAnswer(input, expected(c))
        result = r
        vm.review(c, r != AnswerResult.Wrong)
        if (r != AnswerResult.Wrong) correctCount++
    }

    PracticeScaffold(
        title = title,
        progress = if (cards.isEmpty()) 0f else index / cards.size.toFloat(),
        loading = vm.loading,
        onBack = onBack,
    ) {
        if (cards.isEmpty()) {
            Text(emptyText, style = MaterialTheme.typography.titleMedium)
        } else if (finished) {
            ResultPane("", "$correctCount von ${cards.size} richtig", "Übung macht den Meister.", correctCount * 4, correctCount >= cards.size / 2, onBack)
        } else if (current != null) {
            val cs = MaterialTheme.colorScheme
            val tint by animateColorAsState(
                when (result) {
                    AnswerResult.Correct -> cs.primaryContainer
                    AnswerResult.Close -> cs.tertiaryContainer
                    AnswerResult.Wrong -> cs.errorContainer
                    null -> cs.surfaceContainerHigh
                },
                label = "drillTint",
            )
            Surface(Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh) {
                Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    prompt(current)
                }
            }
            Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, color = tint) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppTextField(
                        value = input,
                        onValueChange = { if (result == null) input = it },
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        singleLine = true,
                        readOnly = result != null,
                        label = { Text("Deine Antwort") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { if (result == null) submit() else { input = ""; result = null; index++ } }),
                        shape = MaterialTheme.shapes.large,
                    )
                    when (result) {
                        AnswerResult.Correct -> Text("Richtig!", style = MaterialTheme.typography.titleMedium.bold())
                        AnswerResult.Close -> Text("Fast! Richtig wäre: ${expected(current)}", style = MaterialTheme.typography.titleMedium.bold())
                        AnswerResult.Wrong -> Text("Leider falsch. Richtig: ${expected(current)}", style = MaterialTheme.typography.titleMedium.bold())
                        null -> {}
                    }
                }
            }
            Row(Modifier.fillMaxWidth().imePadding(), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.weight(1f))
                if (result == null) Button(onClick = { submit() }, enabled = input.isNotBlank()) { Text("Prüfen") }
                else Button(onClick = { input = ""; result = null; index++ }) { Text("Weiter") }
            }
        }
    }
}

/** Fill the gap: the example sentence with the word left out. */
@Composable
fun ClozeScreen(scope: StudyScope, id: Long, onBack: () -> Unit, from: Int = 0, to: Int = 0) {
    val vm = rememberPractice(scope, id, "cloze", 10, from, to)
    val cards = remember(vm.pool) { vm.pool.filter { gapOf(it) != null }.shuffled().take(10) }
    val cs = MaterialTheme.colorScheme
    TextDrill(
        title = "Lückentext", vm = vm, cards = cards,
        emptyText = "Für diese Lernart brauchen die Karten Beispielsätze, die das Wort enthalten. Öffne eine Karte im Lernen und tippe auf das Satz-Symbol, dann erzeugt die KI einen.",
        onBack = onBack,
        expected = { gapOf(it).orEmpty() },
    ) { card ->
        val gap = gapOf(card).orEmpty()
        val sentence = card.example.orEmpty().replaceFirst(gap, "_____", ignoreCase = true)
        Text("Welches Wort fehlt?", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        Text(sentence, style = MaterialTheme.typography.headlineSmall.bold(), textAlign = TextAlign.Center)
        Text("Gesucht: ${card.target}", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
    }
}

/** Listening: the word is read aloud, the learner types it. */
@Composable
fun ListenScreen(scope: StudyScope, id: Long, onBack: () -> Unit, from: Int = 0, to: Int = 0) {
    val vm = rememberPractice(scope, id, "listen", 10, from, to)
    val cards = remember(vm.pool) { vm.pool.filter { it.sourceLang.isNotBlank() }.shuffled().take(10) }
    val tts = LocalContext.current.container.tts
    val cs = MaterialTheme.colorScheme
    TextDrill(
        title = "Hören", vm = vm, cards = cards,
        emptyText = "Diese Lernart gibt es nur für Sprach-Decks.",
        onBack = onBack,
        expected = { it.source },
        onCard = { tts.speak(it.source, it.sourceLang) },
    ) { card ->
        Text("Tippe, was du hörst", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        FilledTonalIconButton(onClick = { tts.speak(card.source, card.sourceLang) }, modifier = Modifier.size(72.dp)) {
            Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Nochmal anhören", Modifier.size(36.dp))
        }
        Text("Bedeutung: ${card.target}", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
    }
}

/** Write your own sentence with the word; the AI gives short feedback. */
@Composable
fun SentenceScreen(scope: StudyScope, id: Long, onBack: () -> Unit, from: Int = 0, to: Int = 0) {
    val vm = rememberPractice(scope, id, "sentence", 5, from, to)
    val cards = remember(vm.pool) { vm.pool.filter { it.sourceLang.isNotBlank() }.shuffled().take(5) }
    val gemini = LocalContext.current.container.gemini
    val scopeCo = rememberCoroutineScope()
    var index by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    val finished = !vm.loading && index >= cards.size
    val current = cards.getOrNull(index)
    val cs = MaterialTheme.colorScheme

    fun check() {
        val c = current ?: return
        if (checking || input.isBlank()) return
        checking = true; error = null
        scopeCo.launch {
            gemini.checkSentence(c.source, c.target, languageNameEn(c.sourceLang), input.trim())
                .onSuccess { feedback = it }
                .onFailure { error = it.message ?: "Die Prüfung hat nicht geklappt" }
            checking = false
        }
    }

    PracticeScaffold(
        title = "Eigener Satz",
        progress = if (cards.isEmpty()) 0f else index / cards.size.toFloat(),
        loading = vm.loading,
        onBack = onBack,
    ) {
        if (cards.isEmpty()) {
            Text("Diese Lernart gibt es nur für Sprach-Decks.", style = MaterialTheme.typography.titleMedium)
        } else if (finished) {
            ResultPane("", "${cards.size} Sätze geschrieben", "Eigene Sätze festigen Wörter besonders gut.", 0, false, onBack)
        } else if (current != null) {
            Surface(Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh) {
                Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Schreibe einen Satz mit", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    Text(current.source, style = MaterialTheme.typography.headlineLarge.bold(), textAlign = TextAlign.Center)
                    Text(current.target, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
            }
            AppTextField(
                value = input,
                onValueChange = { if (feedback == null) input = it },
                modifier = Modifier.fillMaxWidth(),
                readOnly = feedback != null,
                minLines = 2,
                label = { Text("Dein Satz") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                shape = MaterialTheme.shapes.large,
            )
            if (checking) CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
            error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
            feedback?.let { f ->
                Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer) {
                    Text(f, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge)
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().imePadding()) {
                Spacer(Modifier.weight(1f))
                if (feedback == null) Button(onClick = { check() }, enabled = input.isNotBlank() && !checking, modifier = Modifier.heightIn(min = 48.dp)) { Text("Prüfen") }
                else Button(onClick = { input = ""; feedback = null; error = null; index++ }) { Text("Weiter") }
            }
        }
    }
}

/** Pronunciation: the learner says the word, the phone's speech recognition listens. */
@Composable
fun SpeakScreen(scope: StudyScope, id: Long, onBack: () -> Unit, from: Int = 0, to: Int = 0) {
    val vm = rememberPractice(scope, id, "speak", 8, from, to)
    val cards = remember(vm.pool) { vm.pool.filter { it.sourceLang.isNotBlank() }.shuffled().take(8) }
    val context = LocalContext.current
    val tts = context.container.tts
    val cs = MaterialTheme.colorScheme
    var index by remember { mutableIntStateOf(0) }
    var listening by remember { mutableStateOf(false) }
    var heard by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<AnswerResult?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var correctCount by remember { mutableIntStateOf(0) }
    var handled by remember { mutableStateOf(false) }
    val finished = !vm.loading && index >= cards.size
    val current = cards.getOrNull(index)
    val available = remember { android.speech.SpeechRecognizer.isRecognitionAvailable(context) }
    val recognizer = remember { if (available) android.speech.SpeechRecognizer.createSpeechRecognizer(context) else null }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { recognizer?.destroy() } }

    LaunchedEffect(finished) {
        if (finished && !handled && cards.isNotEmpty()) {
            handled = true
            vm.finish(perfect = correctCount == cards.size, bonusXp = correctCount * 5)
        }
    }

    fun listen() {
        val c = current ?: return
        val rec = recognizer ?: return
        heard = null; result = null; message = null; listening = true
        rec.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            override fun onError(error: Int) {
                listening = false
                message = when (error) {
                    android.speech.SpeechRecognizer.ERROR_NO_MATCH, android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ich habe nichts verstanden. Versuch es noch einmal."
                    android.speech.SpeechRecognizer.ERROR_NETWORK, android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Die Spracherkennung braucht gerade Internet."
                    android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Ohne Mikrofon-Erlaubnis geht es nicht."
                    else -> "Die Spracherkennung hat nicht geklappt (Code $error)."
                }
            }
            override fun onResults(results: android.os.Bundle?) {
                listening = false
                val list = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() }.orEmpty()
                if (list.isEmpty()) { message = "Ich habe nichts verstanden. Versuch es noch einmal."; return }
                val best = list.map { checkAnswer(it, c.source) }.let { r ->
                    r.firstOrNull { it == AnswerResult.Correct } ?: r.firstOrNull { it == AnswerResult.Close } ?: AnswerResult.Wrong
                }
                heard = list.first()
                result = best
                vm.review(c, best != AnswerResult.Wrong)
                if (best != AnswerResult.Wrong) correctCount++
            }
        })
        rec.startListening(
            android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, c.sourceLang)
                putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            },
        )
    }

    val permission = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listen() else message = "Ohne Mikrofon-Erlaubnis geht es nicht."
    }
    fun start() {
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) listen()
        else permission.launch(android.Manifest.permission.RECORD_AUDIO)
    }

    PracticeScaffold(
        title = "Sprechen",
        progress = if (cards.isEmpty()) 0f else index / cards.size.toFloat(),
        loading = vm.loading,
        onBack = onBack,
    ) {
        when {
            !available -> Text("Auf diesem Gerät gibt es keine Spracherkennung.", style = MaterialTheme.typography.titleMedium)
            cards.isEmpty() -> Text("Diese Lernart gibt es nur für Sprach-Decks.", style = MaterialTheme.typography.titleMedium)
            finished -> ResultPane("", "$correctCount von ${cards.size} gut ausgesprochen", "Je öfter du laut sprichst, desto sicherer wirst du.", correctCount * 5, correctCount >= cards.size / 2, onBack)
            current != null -> {
                Surface(Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh) {
                    Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Sage auf ${com.lingosnap.data.model.languageName(current.sourceLang)}", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                        Text(current.target, style = MaterialTheme.typography.headlineLarge.bold(), textAlign = TextAlign.Center)
                        if (result != null) Text("Gesucht: ${current.source}", style = MaterialTheme.typography.titleMedium, color = cs.primary)
                    }
                }
                heard?.let {
                    Text(
                        "Verstanden: $it",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (result == AnswerResult.Wrong) cs.error else cs.primary,
                    )
                }
                when (result) {
                    AnswerResult.Correct -> Text("Sehr gut!", style = MaterialTheme.typography.titleMedium.bold())
                    AnswerResult.Close -> Text("Fast – das ist nah dran.", style = MaterialTheme.typography.titleMedium.bold())
                    AnswerResult.Wrong -> Text("Das war es noch nicht.", style = MaterialTheme.typography.titleMedium.bold())
                    null -> {}
                }
                message?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(onClick = { tts.speak(current.source, current.sourceLang) }) {
                        Icon(Icons.AutoMirrored.Rounded.VolumeUp, "So klingt es")
                    }
                    Spacer(Modifier.weight(1f))
                    if (result != null) {
                        androidx.compose.material3.OutlinedButton(onClick = { start() }) { Text("Nochmal") }
                        Spacer(Modifier.padding(4.dp))
                        Button(onClick = { heard = null; result = null; message = null; index++ }) { Text("Weiter") }
                    } else {
                        Button(onClick = { start() }, enabled = !listening, modifier = Modifier.heightIn(min = 56.dp)) {
                            if (listening) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                            else Icon(Icons.Rounded.Mic, null)
                            Spacer(Modifier.padding(4.dp))
                            Text(if (listening) "Ich höre zu …" else "Sprechen")
                        }
                    }
                }
            }
        }
    }
}
