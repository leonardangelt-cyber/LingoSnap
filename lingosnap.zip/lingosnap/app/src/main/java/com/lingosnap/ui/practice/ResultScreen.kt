package com.lingosnap.ui.practice

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Flashcard
import com.lingosnap.ui.components.IconBadge
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.tr

/** One stat tile: icon above a short text. */
class ResultStat(val icon: ImageVector, val text: String)

/**
 * The shared "session over" screen. Layout: a hero card (ring with the share of right answers next to the headline),
 * a row of fused stat tiles, the cards that went wrong as one fused list, and the buttons at the bottom.
 * [ratio] < 0 hides the ring and shows a check mark instead.
 */
@Composable
fun ColumnScope.ResultScreen(
    headline: String,
    detail: String,
    ratio: Float,
    stats: List<ResultStat>,
    wrong: List<Flashcard> = emptyList(),
    primaryLabel: String? = null,
    onPrimary: () -> Unit = {},
    doneLabel: String,
    onDone: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val shown by animateFloatAsState(if (go) ratio.coerceIn(0f, 1f) else 0f, tween(1100, easing = FastOutSlowInEasing), label = "ring")

    Column(
        Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // hero
        Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp), color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
            Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(104.dp), contentAlignment = Alignment.Center) {
                    if (ratio >= 0f) {
                        val track = cs.onPrimaryContainer.copy(alpha = 0.15f)
                        val bar = cs.primary
                        Canvas(Modifier.size(104.dp)) {
                            val w = 12.dp.toPx()
                            val s = Size(size.width - w, size.height - w)
                            drawArc(track, 0f, 360f, false, Offset(w / 2, w / 2), s, style = Stroke(w, cap = StrokeCap.Round))
                            if (shown > 0f) drawArc(bar, -90f, 360f * shown, false, Offset(w / 2, w / 2), s, style = Stroke(w, cap = StrokeCap.Round))
                        }
                        Text("${(shown * 100).toInt()}%", style = MaterialTheme.typography.titleLarge.bold())
                    } else IconBadge(Icons.Rounded.EmojiEvents, 88)
                }
                Spacer(Modifier.width(20.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(headline, style = MaterialTheme.typography.headlineSmall.bold())
                    if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer.copy(alpha = 0.8f))
                }
            }
        }
        // fused stat tiles
        if (stats.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            stats.forEachIndexed { i, st ->
                val big = 32.dp; val small = 6.dp
                val shape = RoundedCornerShape(
                    topStart = if (i == 0) big else small, bottomStart = if (i == 0) big else small,
                    topEnd = if (i == stats.lastIndex) big else small, bottomEnd = if (i == stats.lastIndex) big else small,
                )
                Surface(Modifier.weight(1f), shape = shape, color = cs.surfaceContainer) {
                    Column(Modifier.padding(vertical = 16.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconBadge(st.icon, 40, cs.secondaryContainer, cs.onSecondaryContainer)
                        Text(st.text, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        // wrong cards as one fused list
        if (wrong.isNotEmpty()) {
            Text(tr("Noch üben"), Modifier.padding(start = 8.dp, top = 8.dp), style = MaterialTheme.typography.titleSmall, color = cs.error)
            val list = wrong.take(8)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                list.forEachIndexed { i, c ->
                    SegmentedItem(
                        index = i, count = list.size, headline = c.source, supporting = c.target,
                        leading = { IconBadge(Icons.Rounded.Close, 40, cs.errorContainer, cs.onErrorContainer) },
                    )
                }
            }
            if (wrong.size > 8) Text(tr("… und {0} weitere", wrong.size - 8), Modifier.padding(start = 8.dp), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
    }
    if (primaryLabel != null) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onDone, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text(doneLabel) }
            Button(onClick = onPrimary, modifier = Modifier.weight(2f).heightIn(min = 56.dp)) {
                Icon(Icons.Rounded.Replay, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(primaryLabel)
            }
        }
    } else Button(onClick = onDone, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
        Icon(Icons.Rounded.Check, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(doneLabel)
    }
}

fun xpStat(xp: Int): ResultStat? = if (xp > 0) ResultStat(Icons.Rounded.Bolt, "+$xp XP") else null
fun streakStat(n: Int): ResultStat? = if (n >= 2) ResultStat(Icons.Rounded.LocalFireDepartment, tr("Serie {0}", n)) else null
