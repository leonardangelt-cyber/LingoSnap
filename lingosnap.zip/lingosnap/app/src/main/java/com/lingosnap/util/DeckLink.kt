package com.lingosnap.util

import com.lingosnap.data.Backup
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/** A deck packed into one text link: lingosnap://import?d=… (compressed, without pictures). */
object DeckLink {
    private const val PREFIX = "lingosnap://import?d="
    /** Longer links break in many messengers – use a file for big decks. */
    const val MAX_CHARS = 60_000

    fun encode(deck: Deck, cards: List<Flashcard>): String? {
        val json = Backup.toJson(listOf(deck), cards, withImages = false)
        val out = ByteArrayOutputStream()
        GZIPOutputStream(out).use { it.write(json.toByteArray()) }
        val link = PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(out.toByteArray())
        return link.takeIf { it.length <= MAX_CHARS }
    }

    /** Finds a link anywhere in [text] (a whole pasted message is fine). */
    fun decode(text: String): ParsedImport? {
        val start = text.indexOf(PREFIX)
        if (start < 0) return null
        val payload = text.substring(start + PREFIX.length).takeWhile { it.isLetterOrDigit() || it == '-' || it == '_' }
        return runCatching {
            val bytes = Base64.getUrlDecoder().decode(payload)
            val json = GZIPInputStream(ByteArrayInputStream(bytes)).use { it.readBytes() }.toString(Charsets.UTF_8)
            Backup.parse(json)?.let { ParsedImport(it, true) }
        }.getOrNull()
    }
}

/** A deck that arrived by link and waits for the import dialog on the home screen. */
object PendingImport {
    val state = MutableStateFlow<ParsedImport?>(null)
}
