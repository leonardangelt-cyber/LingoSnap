package com.lingosnap.util

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Thin wrapper around Android's native TextToSpeech engine (one shared instance). */
class TtsManager(context: Context) : TextToSpeech.OnInitListener {

    private var ready = false
    private var pending: Pair<String, String>? = null
    private val tts = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        pending?.let { (text, tag) -> speak(text, tag) }
        pending = null
    }

    /** @return false if the language voice is missing/unsupported (caller can show a hint). */
    fun speak(text: String, languageTag: String): Boolean {
        if (!ready) { pending = text to languageTag; return true }
        val result = tts.setLanguage(Locale.forLanguageTag(languageTag))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) return false
        tts.setSpeechRate(0.9f)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lingosnap-${System.nanoTime()}")
        return true
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
