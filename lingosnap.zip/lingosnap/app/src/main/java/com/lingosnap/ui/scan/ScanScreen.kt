@file:OptIn(ExperimentalMaterial3Api::class)

package com.lingosnap.ui.scan

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.MorphLoader
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun ScanScreen(onBack: () -> Unit, vm: ScanViewModel = viewModel(factory = ScanViewModel.Factory)) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(ui.saved) { if (ui.saved) onBack() }

    // --- image sources ---
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let(vm::onImage)
    }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) captureUri?.let(vm::onImage)
    }
    fun launchCamera() {
        val dir = File(context.cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        captureUri = uri
        camera.launch(uri)
    }

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = {
                AnimatedVisibility(
                    visible = ui.phase == ScanPhase.Review && ui.selectedCount > 0,
                    enter = scaleIn(spring(dampingRatio = 0.5f, stiffness = 320f)) + fadeIn(),
                    exit = scaleOut() + fadeOut(),
                ) {
                    ExtendedFloatingActionButton(
                        onClick = vm::saveSelected,
                        icon = { Icon(Icons.Rounded.Check, null) },
                        text = { Text("Save ${ui.selectedCount} cards", style = MaterialTheme.typography.titleMedium.bold()) },
                    )
                }
            },
        ) { pad ->
            Column(
                Modifier.padding(top = pad.calculateTopPadding()).padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Row(Modifier.fillMaxWidth().entrance(0).padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                    Spacer(Modifier.width(14.dp))
                    Text("Scan vocabulary", style = MaterialTheme.typography.headlineSmall.bold())
                }

                LanguageRow(
                    ui.sourceLang, ui.targetLang, vm::setSource, vm::setTarget, vm::swapLanguages,
                    Modifier.entrance(1),
                )

                AnimatedContent(
                    targetState = ui.phase,
                    modifier = Modifier.weight(1f),
                    transitionSpec = {
                        (fadeIn(tween(350)) + scaleIn(spring(0.8f, 300f), initialScale = 0.92f)) togetherWith
                            (fadeOut(tween(200)) + scaleOut(targetScale = 0.92f))
                    },
                    label = "scanPhase",
                ) { phase ->
                    when (phase) {
                        ScanPhase.Idle -> IdlePane(
                            error = ui.error,
                            onCamera = ::launchCamera,
                            onGallery = {
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                        )
                        ScanPhase.Loading -> LoadingPane()
                        ScanPhase.Review -> LazyColumn(
                            contentPadding = PaddingValues(bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            item {
                                Column(Modifier.padding(bottom = 6.dp)) {
                                    Text("${ui.drafts.size} words found", style = MaterialTheme.typography.titleLarge.bold())
                                    Text(
                                        "Tap a word to include or skip it",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                            itemsIndexed(ui.drafts, key = { _, d -> d.id }) { i, d ->
                                DraftRow(
                                    d,
                                    onToggle = { vm.toggle(d.id) },
                                    modifier = Modifier.entrance(minOf(i, 10), 45L),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IdlePane(error: String?, onCamera: () -> Unit, onGallery: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        AnimatedVisibility(visible = error != null, enter = fadeIn() + scaleIn(), exit = fadeOut()) {
            Surface(shape = MaterialTheme.shapes.large, color = cs.errorContainer, contentColor = cs.onErrorContainer) {
                Text(error.orEmpty(), Modifier.padding(16.dp))
            }
        }
        SourceCard(
            title = "Take a photo",
            subtitle = "Textbook page, notes, whiteboard",
            icon = Icons.Rounded.CameraAlt,
            brush = Brush.linearGradient(listOf(cs.primary, cs.tertiary)),
            content = cs.onPrimary,
            onClick = onCamera,
            modifier = Modifier.entrance(2),
        )
        SourceCard(
            title = "Pick from gallery",
            subtitle = "Use a screenshot or an existing photo",
            icon = Icons.Rounded.PhotoLibrary,
            brush = Brush.linearGradient(listOf(cs.secondary, cs.primary)),
            content = cs.onSecondary,
            onClick = onGallery,
            modifier = Modifier.entrance(3),
        )
    }
}

@Composable
private fun SourceCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    brush: Brush,
    content: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .fillMaxWidth()
            .height(150.dp)
            .pressScale(source, 0.96f)
            .clip(MaterialTheme.shapes.extraLarge)
            .background(brush)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
    ) {
        CookieBadge(
            size = 190.dp,
            color = content.copy(alpha = 0.10f),
            lobes = 10,
            spinMillis = 36000,
            modifier = Modifier.align(Alignment.CenterEnd).offset(x = 60.dp),
        )
        Row(
            Modifier.fillMaxSize().padding(24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            CookieBadge(size = 68.dp, color = content.copy(alpha = 0.22f), lobes = 8) {
                Icon(icon, null, Modifier.size(32.dp), tint = content)
            }
            Column {
                Text(title, style = MaterialTheme.typography.titleLarge.bold(), color = content)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = content.copy(alpha = 0.85f))
            }
        }
    }
}

@Composable
private fun LoadingPane() {
    val messages = remember { listOf("Reading your page…", "Spotting the words…", "Translating…", "Almost there…") }
    var index by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1800)
            index = (index + 1) % messages.size
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(28.dp)) {
            MorphLoader(size = 110.dp)
            AnimatedContent(
                targetState = index,
                transitionSpec = {
                    (slideInVertically(spring(stiffness = 300f)) { it / 2 } + fadeIn()) togetherWith
                        (slideOutVertically { -it / 2 } + fadeOut())
                },
                label = "loadingText",
            ) { i ->
                Text(messages[i], style = MaterialTheme.typography.titleLarge.bold())
            }
        }
    }
}

@Composable
private fun DraftRow(d: Draft, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val container by animateColorAsState(
        if (d.selected) cs.secondaryContainer else cs.surfaceContainerLow,
        tween(250),
        label = "draftBg",
    )
    val source = remember { MutableInteractionSource() }
    Surface(
        modifier.fillMaxWidth().pressScale(source, 0.97f),
        shape = MaterialTheme.shapes.large,
        color = container,
        contentColor = if (d.selected) cs.onSecondaryContainer else cs.onSurface,
    ) {
        Row(
            Modifier
                .clickable(interactionSource = source, indication = null, onClick = onToggle)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(d.pair.source, style = MaterialTheme.typography.titleMedium.bold())
                Text(d.pair.target, color = cs.onSurfaceVariant)
            }
            val tick by animateColorAsState(if (d.selected) cs.primary else cs.outlineVariant, label = "tick")
            Box(Modifier.size(30.dp).background(tick, CircleShape), contentAlignment = Alignment.Center) {
                AnimatedVisibility(
                    visible = d.selected,
                    enter = scaleIn(spring(dampingRatio = 0.4f, stiffness = 400f)),
                    exit = scaleOut(),
                ) {
                    Icon(Icons.Rounded.Check, null, Modifier.size(18.dp), tint = cs.onPrimary)
                }
            }
        }
    }
}

@Composable
private fun LanguageRow(
    source: String,
    target: String,
    onSource: (String) -> Unit,
    onTarget: (String) -> Unit,
    onSwap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var swaps by remember { mutableIntStateOf(0) }
    val angle by animateFloatAsState(swaps * 180f, spring(dampingRatio = 0.55f, stiffness = 300f), label = "swap")
    Surface(
        modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            LanguageMenu("FROM", source, onSource, Modifier.weight(1f))
            FilledIconButton(onClick = { swaps++; onSwap() }, modifier = Modifier.padding(horizontal = 6.dp)) {
                Icon(Icons.Rounded.SwapHoriz, "Swap languages", Modifier.rotate(angle))
            }
            LanguageMenu("TO", target, onTarget, Modifier.weight(1f))
        }
    }
}

@Composable
private fun LanguageMenu(caption: String, tag: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Box(modifier) {
        Surface(
            onClick = { open = true },
            shape = MaterialTheme.shapes.large,
            color = cs.secondaryContainer,
            contentColor = cs.onSecondaryContainer,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(caption, style = MaterialTheme.typography.labelSmall, color = cs.onSecondaryContainer.copy(alpha = 0.7f))
                Text(languageName(tag), style = MaterialTheme.typography.titleMedium.bold(), textAlign = TextAlign.Center)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            SupportedLanguages.forEach { l ->
                DropdownMenuItem(text = { Text(l.label) }, onClick = { onSelect(l.tag); open = false })
            }
        }
    }
}
