@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package com.lingosnap.ui.scan

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppBackground
import java.io.File

@Composable
fun ScanScreen(onBack: () -> Unit, vm: ScanViewModel = viewModel(factory = ScanViewModel.Factory)) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(ui.saved) { if (ui.saved) onBack() }

    // --- image sources ---
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let(vm::onImage) }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) captureUri?.let(vm::onImage)
    }
    fun launchCamera() {
        val dir = File(context.cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        captureUri = uri
        camera.launch(uri)
    }

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text("Scan vocabulary") },
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                )
            },
            floatingActionButton = {
                if (ui.phase == ScanPhase.Review && ui.selectedCount > 0) {
                    ExtendedFloatingActionButton(
                        onClick = vm::saveSelected,
                        icon = { Icon(Icons.Rounded.Check, null) },
                        text = { Text("Save ${ui.selectedCount} cards") },
                    )
                }
            },
        ) { pad ->
            Column(Modifier.padding(pad).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                LanguageRow(ui.sourceLang, ui.targetLang, vm::setSource, vm::setTarget, vm::swapLanguages)

                AnimatedContent(
                    targetState = ui.phase,
                    transitionSpec = { (fadeIn(spring()) + scaleIn(spring(0.8f, 300f), initialScale = .92f)) togetherWith (fadeOut() + scaleOut(targetScale = .92f)) },
                    label = "scanPhase",
                ) { phase ->
                    when (phase) {
                        ScanPhase.Idle -> IdlePane(ui.error, ::launchCamera) {
                            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                        ScanPhase.Loading -> Box(Modifier.fillMaxWidth().height(320.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
                                LoadingIndicator(Modifier.size(72.dp))
                                Text("Reading your page…", style = MaterialTheme.typography.titleMedium)
                            }
                        }
                        ScanPhase.Review -> LazyColumn(
                            contentPadding = PaddingValues(bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            items(ui.drafts, key = { it.id }) { d ->
                                Card(
                                    Modifier.fillMaxWidth().clickable { vm.toggle(d.id) },
                                    shape = MaterialTheme.shapes.large,
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (d.selected) MaterialTheme.colorScheme.secondaryContainer
                                        else MaterialTheme.colorScheme.surfaceContainerLow,
                                    ),
                                ) {
                                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(d.selected, { vm.toggle(d.id) })
                                        Column(Modifier.weight(1f)) {
                                            Text(d.pair.source, style = MaterialTheme.typography.titleMedium)
                                            Text(d.pair.target, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IdlePane(error: String?, onCamera: () -> Unit, onGallery: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        error?.let {
            Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.errorContainer), shape = MaterialTheme.shapes.large) {
                Text(it, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }
        SourceCard("Take a photo", "Textbook page, notes, whiteboard", Icons.Rounded.CameraAlt, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer, onCamera)
        SourceCard("Pick from gallery", "Use an existing screenshot or photo", Icons.Rounded.PhotoLibrary, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer, onGallery)
    }
}

@Composable
private fun SourceCard(
    title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
    container: Color, content: Color, onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        Modifier.fillMaxWidth().height(140.dp),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = container, contentColor = content),
    ) {
        Row(Modifier.fillMaxSize().padding(24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Icon(icon, null, Modifier.size(44.dp))
            Column {
                Text(title, style = MaterialTheme.typography.headlineSmallEmphasized)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun LanguageRow(
    source: String, target: String,
    onSource: (String) -> Unit, onTarget: (String) -> Unit, onSwap: () -> Unit,
) {
    var swaps by remember { mutableStateOf(0) }
    val angle by animateFloatAsState(swaps * 180f, spring(0.6f, 350f), label = "swap")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        LanguageMenu(source, onSource, Modifier.weight(1f))
        IconButton(onClick = { swaps++; onSwap() }) { Icon(Icons.Rounded.SwapHoriz, "Swap languages", Modifier.rotate(angle)) }
        LanguageMenu(target, onTarget, Modifier.weight(1f))
    }
}

@Composable
private fun LanguageMenu(tag: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, Modifier.fillMaxWidth()) { Text(languageName(tag), textAlign = TextAlign.Center) }
        DropdownMenu(open, { open = false }) {
            SupportedLanguages.forEach { l -> DropdownMenuItem(text = { Text(l.label) }, onClick = { onSelect(l.tag); open = false }) }
        }
    }
}
