package com.lingosnap.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.media.ExifInterface
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Pictures on flashcards: copied (and shrunk) into the app's private storage. */
object CardImages {
    private var base: File? = null
    fun init(c: Context) { base = File(c.filesDir, "card_images").apply { mkdirs() } }

    fun toBase64(path: String): String? = runCatching {
        val f = File(path)
        if (f.exists()) java.util.Base64.getEncoder().encodeToString(f.readBytes()) else null
    }.getOrNull()

    fun saveBase64(data: String): String? = runCatching {
        val dir = base ?: return null
        val file = File(dir, "${UUID.randomUUID()}.jpg")
        file.writeBytes(java.util.Base64.getDecoder().decode(data))
        file.absolutePath
    }.getOrNull()

    private fun dir(c: Context) = File(c.filesDir, "card_images").apply { mkdirs() }

    suspend fun import(c: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = c.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })!!
            val rotation = runCatching {
                when (ExifInterface(bytes.inputStream()).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }.getOrDefault(0f)
            if (rotation != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation) }, true)
            val file = File(dir(c), "${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            file.absolutePath
        }.getOrNull()
    }

    fun delete(path: String?) {
        if (path.isNullOrBlank()) return
        runCatching { File(path).delete() }
    }

    fun load(path: String, maxPx: Int): ImageBitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxPx) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
    }.getOrNull()
}

/** Shows a card picture; draws nothing while loading or when the file is gone. */
@Composable
fun CardImage(path: String?, modifier: Modifier = Modifier, maxHeight: Dp = 200.dp, maxPx: Int = 1024, crop: Boolean = false) {
    if (path.isNullOrBlank()) return
    val bitmap by produceState<ImageBitmap?>(null, path) { value = withContext(Dispatchers.IO) { CardImages.load(path, maxPx) } }
    bitmap?.let {
        Image(
            it, null,
            modifier.clip(RoundedCornerShape(16.dp)).heightIn(max = maxHeight),
            contentScale = if (crop) ContentScale.Crop else ContentScale.Fit,
        )
    }
}
