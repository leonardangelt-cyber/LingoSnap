package com.lingosnap.ui.create

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.lingosnap.ui.components.OptionSheet
import androidx.compose.material.icons.rounded.ExpandMore
import com.lingosnap.ui.components.SegmentedItem
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.Surface
import androidx.compose.material3.RadioButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Style
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/** Two calm steps: 1) what kind of deck, 2) name and languages. Cards are added on the next screen. */
@Composable
fun NewDeckScreen(onCreated: (Long) -> Unit, onBack: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    var step by rememberSaveable { mutableIntStateOf(0) }
    var languageDeck by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "de")
    }
    var busy by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val progress by animateFloatAsState(if (step == 0) 0.5f else 1f, label = "newDeckStep")

    fun create() {
        busy = true
        scope.launch {
            val id = if (languageDeck) repo.createDeck(name, null, source, target, "")
            else repo.createDeck(name, null, "", "", subject, kind = "cards")
            onCreated(id)
        }
    }

    LargeScreen(
        title = "Neues Deck",
        onBack = { if (step > 0) step = 0 else onBack() },
        bottomBar = {
            Surface(color = cs.surfaceContainer) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(16.dp)) {
                    Button(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                        enabled = !busy && (step == 0 || name.isNotBlank()),
                        onClick = { if (step == 0) step = 1 else create() },
                    ) { Text(if (step == 0) "Weiter" else "Deck erstellen") }
                }
            }
        },
    ) { inner ->
        Column(
            Modifier.padding(inner).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Schritt ${step + 1} von 2", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            }

            if (step == 0) {
                Text("Was möchtest du lernen?", style = MaterialTheme.typography.titleLarge)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    SegmentedItem(
                        0, 2, "Sprache lernen",
                        supporting = "Vokabeln mit Wort, Übersetzung, Beispielsatz und Vorlesen",
                        onClick = { languageDeck = true },
                        leading = { Icon(Icons.Rounded.Translate, null, tint = cs.primary) },
                        trailing = { RadioButton(selected = languageDeck, onClick = { languageDeck = true }) },
                    )
                    SegmentedItem(
                        1, 2, "Karteikarten",
                        supporting = "Frage und Antwort zu jedem anderen Thema",
                        onClick = { languageDeck = false },
                        leading = { Icon(Icons.Rounded.Style, null, tint = cs.primary) },
                        trailing = { RadioButton(selected = !languageDeck, onClick = { languageDeck = false }) },
                    )
                }
            } else {
                Text(if (languageDeck) "Sprache lernen" else "Karteikarten", style = MaterialTheme.typography.titleLarge)
                AppTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name des Decks") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (languageDeck) {
                    Text("Sprachen", style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LanguageField("Ich lerne", source, Modifier.weight(1f), allowAuto = true) { source = it }
                        IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                            Icon(Icons.Rounded.SwapHoriz, "Tauschen")
                        }
                        LanguageField("Meine Sprache", target, Modifier.weight(1f)) { target = it }
                    }
                    Surface(shape = MaterialTheme.shapes.large, color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer) {
                        Text(
                            "Bei „Automatisch“ erkennt die KI die Sprache jedes Worts selbst und übersetzt fehlende Übersetzungen in deine Zielsprache.",
                            Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                } else {
                    AppTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Worum geht es? (hilft der KI)") },
                        placeholder = { Text("z. B. Biologie Klasse 9, Zellaufbau") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

@Composable
private fun LanguageField(label: String, value: String, modifier: Modifier = Modifier, allowAuto: Boolean = false, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        AppTextField(
            value = if (value == "auto") "Automatisch" else languageName(value),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable { open = true })
    }
    if (open) {
        OptionSheet(
            title = label,
            options = (if (allowAuto) listOf("auto" to "Automatisch") else emptyList()) + SupportedLanguages.map { it.tag to it.label },
            selected = value,
            onPick = { onPick(it); open = false },
            onDismiss = { open = false },
        )
    }
}
