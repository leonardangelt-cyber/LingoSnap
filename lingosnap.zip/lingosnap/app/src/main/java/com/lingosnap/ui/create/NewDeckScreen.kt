package com.lingosnap.ui.create

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/** Step 1: type, name and (for languages) the two languages. Cards are added on the next screen. */
@Composable
fun NewDeckScreen(onCreated: (Long) -> Unit, onBack: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    var languageDeck by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "de")
    }
    var busy by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    LargeScreen(title = "Neues Deck", onBack = onBack) { inner ->
        Column(
            Modifier.padding(inner).imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("Art", style = MaterialTheme.typography.titleSmall.bold(), color = cs.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = languageDeck, onClick = { languageDeck = true }, label = { Text("Sprache lernen") })
                FilterChip(selected = !languageDeck, onClick = { languageDeck = false }, label = { Text("Karteikarten") })
            }
            Text(
                if (languageDeck) "Vokabeln mit Wort und Übersetzung, inklusive Vorlesen. Die Sprache wird automatisch erkannt."
                else "Normale Karteikarten mit Frage und Antwort – für jedes beliebige Thema.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            if (languageDeck) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LanguageField("Ich lerne", source, Modifier.weight(1f), allowAuto = true) { source = it }
                    IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                        Icon(Icons.Rounded.SwapHoriz, "Tauschen")
                    }
                    LanguageField("Meine Sprache", target, Modifier.weight(1f)) { target = it }
                }
                Text(
                    "Die KI erkennt die Sprache der Vokabeln selbst und übersetzt fehlende Übersetzungen in deine Sprache.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            } else {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Worum geht es? (hilft der KI)") },
                    placeholder = { Text("z. B. Biologie Klasse 9, Zellaufbau") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.height(8.dp))
            Button(
                enabled = name.isNotBlank() && !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    busy = true
                    scope.launch {
                        val id = if (languageDeck) repo.createDeck(name, null, source, target, "")
                        else repo.createDeck(name, null, "", "", subject, kind = "cards")
                        onCreated(id)
                    }
                },
            ) { Text("Weiter") }
        }
    }
}

@Composable
private fun LanguageField(label: String, value: String, modifier: Modifier = Modifier, allowAuto: Boolean = false, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(
            value = if (value == "auto") "Automatisch erkennen" else languageName(value),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (allowAuto) DropdownMenuItem(text = { Text("Automatisch erkennen") }, onClick = { onPick("auto"); open = false })
            SupportedLanguages.forEach { l ->
                DropdownMenuItem(text = { Text(l.label) }, onClick = { onPick(l.tag); open = false })
            }
        }
    }
}
