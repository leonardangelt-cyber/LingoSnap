package com.lingosnap.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.StudyDir

/** Asked before every learning mode: which way round should the cards be shown? */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectionSheet(deck: Deck, modeTitle: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val a = if (!deck.isLanguage) "Frage" else if (deck.sourceLang == "auto") "Wort" else languageName(deck.sourceLang)
    val b = if (!deck.isLanguage) "Antwort" else languageName(deck.targetLang)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
            Text("Wie herum lernen?", style = MaterialTheme.typography.headlineSmall)
            Text(modeTitle, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                SegmentedItem(
                    0, 3, "$a → $b",
                    supporting = if (deck.isLanguage) "Du siehst das Wort, du nennst die Übersetzung" else "Du siehst die Frage, du nennst die Antwort",
                    onClick = { onPick(StudyDir.Forward) },
                    leading = { Icon(Icons.Rounded.ArrowForward, null, tint = cs.primary) },
                )
                SegmentedItem(
                    1, 3, "$b → $a",
                    supporting = if (deck.isLanguage) "Du siehst die Übersetzung, du nennst das Wort" else "Du siehst die Antwort, du nennst die Frage",
                    onClick = { onPick(StudyDir.Reverse) },
                    leading = { Icon(Icons.Rounded.SwapHoriz, null, tint = cs.primary) },
                )
                SegmentedItem(
                    2, 3, "Gemischt",
                    supporting = "Die Richtung wechselt von Karte zu Karte",
                    onClick = { onPick(StudyDir.Mixed) },
                    leading = { Icon(Icons.Rounded.Shuffle, null, tint = cs.primary) },
                )
            }
        }
    }
}
