package com.lingosnap.ui.create

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.container
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.theme.bold
import java.io.File

@Composable
fun AddCardsScreen(deckId: Long, onFinished: () -> Unit, onBack: () -> Unit) {
    val vm: AddCardsViewModel = viewModel(
        key = "add-$deckId",
        factory = viewModelFactory { initializer { AddCardsViewModel(app().container.repository, deckId) } },
    )
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var method by rememberSaveable { mutableIntStateOf(0) }

    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = cameraUri
        if (ok && uri != null) vm.scan(context, listOf(uri))
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(5)) { uris ->
        if (uris.isNotEmpty()) vm.scan(context, uris)
    }

    AppBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
                Column {
                    Text("Karten hinzufügen", style = MaterialTheme.typography.titleLarge.bold())
                    vm.deck?.let {
                        Text(
                            "${it.name} • ${languageName(it.sourceLang)} → ${languageName(it.targetLang)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
            }
            Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Manuell", "Foto", "KI").forEachIndexed { i, label ->
                    FilterChip(selected = method == i, onClick = { method = i }, label = { Text(label) })
                }
            }

            LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 8.dp)) {
                item {
                    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        when (method) {
                            0 -> ManualInput(vm)
                            1 -> {
                                Text("Fotografiere eine Vokabelliste oder Buchseite. Du kannst bis zu 5 Bilder auf einmal wählen.", color = cs.onSurfaceVariant)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(enabled = !vm.busy, onClick = {
                                        val dir = File(context.cacheDir, "images").apply { mkdirs() }
                                        val file = File.createTempFile("scan_", ".jpg", dir)
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        cameraUri = uri
                                        camera.launch(uri)
                                    }) {
                                        Icon(Icons.Rounded.CameraAlt, null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("Kamera")
                                    }
                                    FilledTonalButton(enabled = !vm.busy, onClick = {
                                        gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    }) {
                                        Icon(Icons.Rounded.PhotoLibrary, null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("Galerie")
                                    }
                                }
                            }
                            else -> {
                                OutlinedTextField(
                                    value = vm.topic,
                                    onValueChange = { vm.topic = it },
                                    label = { Text("Thema, z. B. Im Restaurant") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(10, 20, 30).forEach { n ->
                                        FilterChip(selected = vm.count == n, onClick = { vm.count = n }, label = { Text("$n Wörter") })
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("A1", "A2", "B1", "B2").forEach { l ->
                                        FilterChip(selected = vm.level == l, onClick = { vm.level = l }, label = { Text(l) })
                                    }
                                }
                                FilledTonalButton(enabled = vm.topic.isNotBlank() && !vm.busy, onClick = { vm.generate() }) {
                                    Text("Generieren")
                                }
                            }
                        }
                        if (method != 0) ModelLine()
                        if (method != 0 && (vm.busy || vm.status != null)) {
                            val animated by androidx.compose.animation.core.animateFloatAsState(vm.progress, label = "aiProgress")
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                androidx.compose.material3.LinearProgressIndicator(
                                    progress = { animated },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Row {
                                    Text(vm.status.orEmpty(), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                    Text("${(animated * 100).toInt()} %", style = MaterialTheme.typography.bodySmall.bold(), color = cs.onSurfaceVariant)
                                }
                            }
                        }
                        vm.error?.let { Text(it, color = cs.error) }
                    }
                }
                if (vm.drafts.isNotEmpty()) {
                    item {
                        Text(
                            "Neu (${vm.drafts.size})",
                            style = MaterialTheme.typography.titleSmall.bold(),
                            color = cs.primary,
                            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp),
                        )
                    }
                    items(vm.drafts.size) { i ->
                        val d = vm.drafts[i]
                        ListItem(
                            modifier = Modifier.clickable { d.selected = !d.selected },
                            headlineContent = { Text(d.pair.source) },
                            supportingContent = { Text(d.pair.target) },
                            trailingContent = { Checkbox(checked = d.selected, onCheckedChange = { d.selected = it }) },
                        )
                        HorizontalDivider()
                    }
                }
            }

            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !vm.busy,
                    onClick = { vm.save(onFinished) },
                ) {
                    Text(if (vm.selectedCount > 0) "${vm.selectedCount} Karten speichern" else "Fertig")
                }
            }
        }
    }
}

@Composable
private fun ManualInput(vm: AddCardsViewModel) {
    var word by rememberSaveable { mutableStateOf("") }
    var translation by rememberSaveable { mutableStateOf("") }
    var bulk by rememberSaveable { mutableStateOf(false) }
    var bulkText by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    fun add() {
        vm.addManual(word, translation)
        word = ""; translation = ""
        runCatching { focus.requestFocus() }
    }

    if (!bulk) {
        OutlinedTextField(
            value = word, onValueChange = { word = it }, label = { Text("Wort") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().focusRequester(focus),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )
        OutlinedTextField(
            value = translation, onValueChange = { translation = it }, label = { Text("Übersetzung") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { add() }),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = word.isNotBlank() && translation.isNotBlank(), onClick = { add() }) { Text("Hinzufügen") }
            TextButton(onClick = { bulk = true }) { Text("Liste einfügen") }
        }
    } else {
        OutlinedTextField(
            value = bulkText, onValueChange = { bulkText = it }, minLines = 5,
            label = { Text("Ein Paar pro Zeile, z. B. casa;Haus") },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = bulkText.isNotBlank(), onClick = { vm.addList(bulkText); bulkText = ""; bulk = false }) {
                Text("Übernehmen")
            }
            TextButton(onClick = { bulk = false }) { Text("Zurück") }
        }
    }
}

@Composable
private fun ModelLine() {
    val gemini = LocalContext.current.container.gemini
    val provider by gemini.provider.collectAsState()
    val model by gemini.activeModel.collectAsState()
    val text = when {
        provider == null -> "Kein API-Schlüssel – unter Optionen eintragen."
        else -> "${provider?.label} • ${model ?: "automatisch"}"
    }
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
