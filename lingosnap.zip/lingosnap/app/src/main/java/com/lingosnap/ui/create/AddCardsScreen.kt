package com.lingosnap.ui.create

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.material3.IconButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.container
import com.lingosnap.ui.components.AppChip
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold
import java.io.File

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun AddCardsScreen(deckId: Long, initialMethod: Int, onFinished: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val repository = context.container.repository
    val vm: AddCardsViewModel = viewModel(
        key = "add-$deckId",
        factory = viewModelFactory { initializer { AddCardsViewModel(repository, deckId, context.container.appScope, context.container.notifier) } },
    )
    val cs = MaterialTheme.colorScheme
    // -1 = first show the "how do you want to add cards?" menu
    var method by rememberSaveable { mutableIntStateOf(initialMethod) }
    val isLang = vm.deck?.isLanguage != false

    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = cameraUri
        if (ok && uri != null) vm.scan(context, listOf(uri))
    }
    val files = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.scan(context, uris)
    }
    // asks once for the right to show the "fertig" notification, then continues in the background either way
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.moveToBackground() }
    // inside a method: back returns to the "how do you want to add cards" menu
    androidx.activity.compose.BackHandler(enabled = method >= 0 && initialMethod < 0 && !vm.busy) { method = -1 }

    LargeScreen(
        title = "Karten hinzufügen",
        onBack = { if (method >= 0 && initialMethod < 0) method = -1 else onBack() },
        bottomBar = {
            if (method >= 0) {
                Surface(color = cs.surfaceContainer, tonalElevation = 0.dp) {
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(16.dp)) {
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !vm.busy,
                            onClick = { vm.save(onFinished) },
                        ) {
                            Text(if (vm.selectedCount > 0) "${vm.selectedCount} Karten speichern" else "Fertig")
                        }
                    }
                }
            }
        },
    ) { inner ->
        if (method < 0) {
            Column(Modifier.padding(inner).padding(horizontal = 16.dp)) {
                vm.deck?.let {
                    Text(
                        it.name,
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                    )
                }
                GroupHeader("Wie möchtest du Karten hinzufügen?")
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    SegmentedItem(
                        0, 3, "Foto oder Datei scannen",
                        supporting = "Kamera, Bild, PDF, Word oder PowerPoint",
                        onClick = { method = 1 },
                        leading = { Icon(Icons.Rounded.CameraAlt, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        1, 3, "Mit KI erzeugen",
                        supporting = "Thema eingeben, Karten generieren lassen",
                        onClick = { method = 2 },
                        leading = { Icon(Icons.Rounded.Psychology, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        2, 3, "Selbst eintippen",
                        supporting = "Einzeln oder als Liste einfügen",
                        onClick = { method = 0 },
                        leading = { Icon(Icons.Rounded.Edit, null, tint = cs.primary) },
                    )
                }
                TextButton(onClick = onFinished, modifier = Modifier.padding(top = 16.dp)) { Text("Später hinzufügen") }
            }
        } else {
            LazyColumn(Modifier.padding(inner), contentPadding = PaddingValues(bottom = 16.dp)) {
                item {
                    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        vm.deck?.let {
                            Text(it.name, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                        }
                        Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainerLow) {
                          Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        when (method) {
                            0 -> ManualInput(vm, isLang)
                            1 -> {
                                Text(
                                    if (isLang) "Fotografiere eine Vokabelliste oder Buchseite, oder wähle Bilder, PDF, Word oder PowerPoint. Beliebig viele Dateien und Seiten."
                                    else "Fotografiere Notizen oder Folien, oder wähle Bilder, PDF, Word oder PowerPoint. Beliebig viele Dateien und Seiten.",
                                    color = cs.onSurfaceVariant,
                                )
                                AppTextField(
                                    value = vm.hint,
                                    onValueChange = { vm.hint = it },
                                    label = { Text("Hinweis für die KI (optional)") },
                                    placeholder = {
                                        Text(if (isLang) "z. B. nur Verben, ohne Namen" else "z. B. nur Definitionen, Jahreszahlen abfragen")
                                    },
                                    minLines = 2,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                if (isLang) {
                                    Text("Nur Wörter ab Niveau", style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("" to "Alle", "A2" to "A2", "B1" to "B1", "B2" to "B2", "C1" to "C1").forEach { (v, label) ->
                                            AppChip(vm.minLevel == v, { vm.minLevel = v }, label)
                                        }
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(enabled = !vm.busy, onClick = {
                                        val dir = File(context.cacheDir, "images").apply { mkdirs() }
                                        val file = File.createTempFile("scan_", ".jpg", dir)
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        cameraUri = uri
                                        camera.launch(uri)
                                    }) {
                                        Icon(Icons.Rounded.CameraAlt, null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("Kamera")
                                    }
                                    FilledTonalButton(enabled = !vm.busy, onClick = {
                                        files.launch(com.lingosnap.util.DocumentReader.MIME_TYPES)
                                    }) {
                                        Icon(Icons.Rounded.UploadFile, null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("Datei / Bild")
                                    }
                                }
                                ModelLine()
                            }
                            else -> {
                                AppTextField(
                                    value = vm.topic,
                                    onValueChange = { vm.topic = it },
                                    label = { Text(if (isLang) "Thema, z. B. Im Restaurant" else "Thema, z. B. Der Erste Weltkrieg") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Text("Anzahl der Karten", style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(10, 20, 30).forEach { n ->
                                        AppChip(vm.count == n, { vm.count = n }, "$n")
                                    }
                                }
                                Text(if (isLang) "Sprachniveau" else "Schwierigkeit", style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    (if (isLang) listOf("A1", "A2", "B1", "B2") else listOf("Leicht", "Mittel", "Schwer")).forEach { l ->
                                        AppChip(vm.level == l, { vm.level = l }, l)
                                    }
                                }
                                AppTextField(
                                    value = vm.hint,
                                    onValueChange = { vm.hint = it },
                                    label = { Text("Hinweis für die KI (optional)") },
                                    minLines = 2,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Button(enabled = vm.topic.isNotBlank() && !vm.busy, onClick = { vm.generate() }) {
                                    Text("Generieren")
                                }
                                ModelLine()
                            }
                        }
                          }
                        }
                    }
                }
                vm.notice?.let { n ->
                    item {
                        Surface(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            shape = MaterialTheme.shapes.large, color = cs.errorContainer, contentColor = cs.onErrorContainer,
                        ) { Text(n, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium) }
                    }
                }
                if (vm.drafts.isNotEmpty()) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            GroupHeader("Neu (${vm.selectedCount} von ${vm.drafts.size})", Modifier.weight(1f))
                            val allOn = vm.selectedCount == vm.drafts.size
                            TextButton(onClick = { vm.drafts.forEach { it.selected = !allOn } }) {
                                Text(if (allOn) "Keine" else "Alle")
                            }
                        }
                    }
                    items(vm.drafts.size) { i ->
                        val d = vm.drafts[i]
                        Column(Modifier.padding(horizontal = 16.dp).padding(vertical = 1.dp)) {
                            SegmentedItem(
                                index = i,
                                count = vm.drafts.size,
                                headline = d.pair.source,
                                supporting = d.pair.target + (d.pair.example?.let { "\n$it" } ?: "") + (d.note?.let { "\n$it" } ?: ""),
                                onClick = { d.selected = !d.selected },
                                trailing = {
                                    var edit by remember { mutableStateOf(false) }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { edit = true }) { Icon(Icons.Rounded.Edit, "Eintrag bearbeiten") }
                                        Checkbox(checked = d.selected, onCheckedChange = { d.selected = it })
                                    }
                                    if (edit) {
                                        var src by remember { mutableStateOf(d.pair.source) }
                                        var tgt by remember { mutableStateOf(d.pair.target) }
                                        androidx.compose.material3.AlertDialog(
                                            onDismissRequest = { edit = false },
                                            shape = MaterialTheme.shapes.extraLarge,
                                            title = { Text("Eintrag bearbeiten") },
                                            text = {
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    AppTextField(src, { src = it }, Modifier.fillMaxWidth(), label = { Text("Vorderseite") })
                                                    AppTextField(tgt, { tgt = it }, Modifier.fillMaxWidth(), label = { Text("Rückseite") })
                                                }
                                            },
                                            confirmButton = {
                                                TextButton(enabled = src.isNotBlank() && tgt.isNotBlank(), onClick = {
                                                    d.pair = d.pair.copy(source = src.trim(), target = tgt.trim()); edit = false
                                                }) { Text("Speichern") }
                                            },
                                            dismissButton = { TextButton(onClick = { edit = false }) { Text("Abbrechen") } },
                                        )
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }

    if (vm.showProgress) AiProgressDialog(vm, onBackground = {
        val needsPermission = android.os.Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (needsPermission) notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS) else vm.moveToBackground()
    })
    if (vm.conflicts.isNotEmpty()) ConflictDialog(vm)
}

/** Loading menu: shows every step the AI goes through, the model and the percentage. */
@Composable
private fun AiProgressDialog(vm: AddCardsViewModel, onBackground: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val labels = if (vm.scanning)
        listOf("Dateien vorbereiten", "An die KI senden", "Text lesen und Einträge erkennen", "Liste zusammenstellen", "Auf Duplikate prüfen")
    else
        listOf("Anfrage vorbereiten", "An die KI senden", "Einträge erzeugen", "Liste zusammenstellen", "Auf Duplikate prüfen")
    val finished = !vm.busy
    val animated by androidx.compose.animation.core.animateFloatAsState(vm.progress, label = "aiProgress")

    Dialog(
        onDismissRequest = { if (finished) vm.dismissProgress() },
        properties = DialogProperties(dismissOnBackPress = finished, dismissOnClickOutside = false),
    ) {
        Surface(shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainerHigh) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    when {
                        vm.error != null -> "Das hat nicht geklappt"
                        finished -> "Fertig"
                        else -> "KI arbeitet"
                    },
                    style = MaterialTheme.typography.headlineSmall.bold(),
                )

                if (vm.error == null) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        labels.forEachIndexed { i, label ->
                            val state = when {
                                vm.step > i -> 2 // done
                                vm.step == i && !finished -> 1 // running
                                else -> 0
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                when (state) {
                                    2 -> Icon(Icons.Rounded.Check, null, tint = cs.primary, modifier = Modifier.size(24.dp))
                                    1 -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                                    else -> Icon(Icons.Rounded.RadioButtonUnchecked, null, tint = cs.outline, modifier = Modifier.size(24.dp))
                                }
                                Spacer(Modifier.width(14.dp))
                                Text(
                                    label,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (state == 0) cs.onSurfaceVariant else cs.onSurface,
                                )
                            }
                        }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        LinearProgressIndicator(progress = { animated }, modifier = Modifier.fillMaxWidth())
                        Row {
                            Text(
                                if (finished) "${vm.found} Einträge gefunden" else (vm.status ?: "") + if (vm.found > 0) " • ${vm.found} gefunden" else "",
                                Modifier.weight(1f),
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                            Text("${(animated * 100).toInt()} %", style = MaterialTheme.typography.labelLarge.bold())
                        }
                    }
                } else {
                    Text(vm.error.orEmpty(), color = cs.error)
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    if (!finished) {
                        TextButton(onClick = { vm.cancelAi() }) { Text("Abbrechen") }
                        TextButton(onClick = onBackground) { Text("Im Hintergrund") }
                    } else {
                        Button(onClick = { vm.dismissProgress() }) { Text(if (vm.error != null) "Schließen" else "Weiter") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManualInput(vm: AddCardsViewModel, isLang: Boolean) {
    var word by rememberSaveable { mutableStateOf("") }
    var translation by rememberSaveable { mutableStateOf("") }
    var bulk by rememberSaveable { mutableStateOf(false) }
    var bulkText by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    fun add() {
        vm.addManual(word, translation)
        word = ""; translation = ""
        runCatching { focus.requestFocus() }
    }

    if (!bulk) {
        AppTextField(
            value = word, onValueChange = { word = it }, label = { Text(if (isLang) "Wort" else "Frage") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().focusRequester(focus),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )
        AppTextField(
            value = translation, onValueChange = { translation = it }, label = { Text(if (isLang) "Übersetzung" else "Antwort") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { add() }),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(enabled = word.isNotBlank() && translation.isNotBlank(), onClick = { add() }) { Text("Hinzufügen") }
            TextButton(onClick = { bulk = true }) { Text("Liste einfügen") }
        }
    } else {
        AppTextField(
            value = bulkText, onValueChange = { bulkText = it }, minLines = 5,
            label = { Text(if (isLang) "Ein Paar pro Zeile, z. B. casa;Haus" else "Eine Karte pro Zeile: Frage;Antwort") },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(enabled = bulkText.isNotBlank(), onClick = { vm.addList(bulkText); bulkText = ""; bulk = false }) {
                Text("Übernehmen")
            }
            TextButton(onClick = { bulk = false }) { Text("Zurück") }
        }
    }
}

@Composable
private fun ModelLine() {
    val gemini = LocalContext.current.container.gemini
    val provider by gemini.provider.collectAsState()
    if (provider != null) return
    val text = "Kein API-Schlüssel hinterlegt – unter Optionen eintragen."
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Same word twice: shows both versions side by side and lets the user pick the one to keep. */
@Composable
private fun ConflictDialog(vm: AddCardsViewModel) {
    val cs = MaterialTheme.colorScheme
    Dialog(onDismissRequest = { vm.cancelConflicts() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.padding(16.dp),
            shape = MaterialTheme.shapes.extraLarge,
            color = cs.surfaceContainerHigh,
        ) {
            Column(Modifier.padding(vertical = 24.dp)) {
                Column(Modifier.padding(horizontal = 24.dp)) {
                    Text("Doppelte Vokabeln", style = MaterialTheme.typography.headlineSmall.bold())
                    Text(
                        "Diese Wörter gibt es mehrfach. Wähle pro Wort, welche Version bleibt, oder füge sie zusammen.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
                    )
                }
                LazyColumn(
                    Modifier.weight(1f, fill = false).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(vm.conflicts.size) { ci ->
                        val c = vm.conflicts[ci]
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            c.options.forEachIndexed { oi, o ->
                                SegmentedItem(
                                    index = oi,
                                    count = c.options.size,
                                    headline = if (o.kind == Option.KEEP_ALL) "Alle behalten" else "${o.pair.source} – ${o.pair.target}",
                                    supporting = if (o.kind == Option.KEEP_ALL) "Alle Versionen bleiben als eigene Karten"
                                    else o.label + (o.pair.example?.let { " • $it" } ?: ""),
                                    onClick = { c.chosen = oi },
                                    leading = {
                                        androidx.compose.material3.RadioButton(selected = c.chosen == oi, onClick = { c.chosen = oi })
                                    },
                                )
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 16.dp), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { vm.cancelConflicts() }) { Text("Abbrechen") }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.resolveConflicts() }) { Text("Übernehmen") }
                }
            }
        }
    }
}
