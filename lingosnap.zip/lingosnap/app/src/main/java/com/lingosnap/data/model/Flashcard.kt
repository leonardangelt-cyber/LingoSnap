package com.lingosnap.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.Locale
import java.util.concurrent.TimeUnit

@Entity(
    tableName = "cards",
    indices = [Index(value = ["source", "target", "sourceLang", "targetLang"], unique = true)],
)
data class Flashcard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val source: String,
    val target: String,
    /** BCP-47 language tags, e.g. "en", "de" (also used for TTS) */
    val sourceLang: String,
    val targetLang: String,
    /** 0 = new … 5 = mastered */
    val level: Int = 0,
    val dueAt: Long = 0L,
    val mnemonic: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

enum class Mastery(val label: String) {
    New("New"), Learning("Learning"), Mastered("Mastered");

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level >= Srs.MAX_LEVEL -> Mastered
            else -> Learning
        }
    }
}

enum class Rating(val label: String, val delta: Int) {
    Hard("Hard", -1), Good("Good", 1), Easy("Easy", 2)
}

/** Tiny Leitner-style spaced repetition: 5 levels, growing intervals. */
object Srs {
    const val MAX_LEVEL = 5
    private val intervalDays = longArrayOf(0, 1, 3, 7, 14, 30)

    fun review(card: Flashcard, rating: Rating, now: Long = System.currentTimeMillis()): Flashcard {
        val level = (card.level + rating.delta).coerceIn(0, MAX_LEVEL)
        val due = if (rating == Rating.Hard) now + TimeUnit.MINUTES.toMillis(10)
        else now + TimeUnit.DAYS.toMillis(intervalDays[level])
        return card.copy(level = level, dueAt = due)
    }
}

data class Language(val tag: String, val label: String)

val SupportedLanguages = listOf(
    Language("en", "English"), Language("de", "German"), Language("fr", "French"),
    Language("es", "Spanish"), Language("it", "Italian"), Language("pt", "Portuguese"),
    Language("nl", "Dutch"), Language("pl", "Polish"), Language("tr", "Turkish"),
    Language("ru", "Russian"), Language("ja", "Japanese"), Language("zh", "Chinese"),
)

fun languageName(tag: String): String =
    SupportedLanguages.firstOrNull { it.tag == tag }?.label
        ?: Locale.forLanguageTag(tag).getDisplayLanguage(Locale.ENGLISH)
