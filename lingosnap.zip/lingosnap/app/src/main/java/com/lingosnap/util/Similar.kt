package com.lingosnap.util

/**
 * Fast search for the same and similar words. Instead of comparing every pair (n²) it
 *  1. puts identical normalized words into one hash bucket, and
 *  2. compares a new word only with words that start with the same letter and have a similar length,
 *     using a bounded edit distance that stops as soon as the limit is passed.
 * 5000 words take a few milliseconds.
 */
object Similar {
    /**
     * [bases] are normalized words (see [baseForm]); [isNew] marks the entries that are being added.
     * [onPair] is called for every pair that is the same or similar and contains at least one new entry.
     */
    fun find(bases: List<String>, isNew: (Int) -> Boolean, onPair: (Int, Int) -> Unit) {
        val exact = HashMap<String, MutableList<Int>>()
        val buckets = HashMap<Long, MutableList<Int>>()
        for (i in bases.indices) {
            val b = bases[i]
            if (b.isEmpty()) continue
            exact.getOrPut(b) { ArrayList(2) }.add(i)
            if (b.length >= 5) buckets.getOrPut(key(b[0], b.length)) { ArrayList(4) }.add(i)
        }
        // same word
        for (list in exact.values) {
            if (list.size < 2) continue
            if (list.any(isNew)) for (k in 1 until list.size) onPair(list[0], list[k])
        }
        // spelling variants
        for (i in bases.indices) {
            if (!isNew(i)) continue
            val b = bases[i]
            if (b.length < 5) continue
            for (len in b.length - 2..b.length + 2) {
                val list = buckets[key(b[0], len)] ?: continue
                val max = if (minOf(b.length, len) >= 9) 2 else 1
                for (j in list) {
                    if (j == i || bases[j] == b) continue
                    if (isNew(j) && j < i) continue // new-new pairs once
                    if (withinDistance(b, bases[j], max)) onPair(i, j)
                }
            }
        }
    }

    private fun key(c: Char, len: Int): Long = (c.code.toLong() shl 20) or len.toLong()

    /** True if the edit distance is at most [max] (stops early). */
    fun withinDistance(a: String, b: String, max: Int): Boolean {
        if (kotlin.math.abs(a.length - b.length) > max) return false
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                val v = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > max) return false
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length] <= max
    }
}
