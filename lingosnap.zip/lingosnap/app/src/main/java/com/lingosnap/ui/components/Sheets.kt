package com.lingosnap.ui.components

import com.lingosnap.util.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.lingosnap.ui.theme.bold

/** Shared look of every bottom sheet: big rounded top, clear drag handle, saturated surface. */
@Composable
fun SheetHandle() {
    Box(
        Modifier.padding(top = 12.dp, bottom = 6.dp).size(width = 40.dp, height = 5.dp)
            .clip(CircleShape).background(MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
    )
}

/** Round, saturated icon badge used in sheet headers and rows. */
@Composable
fun IconBadge(icon: ImageVector, size: Int = 48, container: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.primary, content: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onPrimary) {
    Surface(shape = CircleShape, color = container, modifier = Modifier.size(size.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = content, modifier = Modifier.size((size * 0.5f).dp))
        }
    }
}

/**
 * The one pop-up shape of the app: everything the user fills in or chooses from slides up from the bottom.
 * Only short yes/no questions (delete, discard) stay as a centred dialog.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormSheet(
    title: String,
    onDismiss: () -> Unit,
    confirmLabel: String? = null,
    onConfirm: () -> Unit = {},
    confirmEnabled: Boolean = true,
    dismissLabel: String = tr("Abbrechen"),
    busy: Boolean = false,
    subtitle: String? = null,
    icon: ImageVector? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(
        onDismissRequest = { if (!busy) onDismiss() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        shape = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
        containerColor = cs.surfaceContainerLow,
        dragHandle = { SheetHandle() },
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 20.dp).padding(bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    IconBadge(icon)
                    Spacer(Modifier.width(14.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.headlineSmall.bold(), color = cs.onSurface)
                    if (subtitle != null) {
                        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            Column(
                Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(top = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content,
            )
            Row(Modifier.fillMaxWidth().padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(
                    onClick = onDismiss, enabled = !busy, shape = CircleShape,
                    modifier = Modifier.weight(1f).height(52.dp),
                ) { Text(dismissLabel, style = MaterialTheme.typography.titleSmall) }
                if (confirmLabel != null) {
                    Button(
                        onClick = onConfirm, enabled = confirmEnabled && !busy, shape = CircleShape,
                        modifier = Modifier.weight(1.3f).height(52.dp),
                    ) { Text(confirmLabel, style = MaterialTheme.typography.titleSmall.bold()) }
                }
            }
        }
    }
}
