package com.lingosnap.ui.practice

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.delay

private const val ROUND = 10

@Composable
fun ChoiceScreen(scope: StudyScope, id: Long, dir: String, onBack: () -> Unit, from: Int = 0, to: Int = 0) {
    val vm = rememberPractice(scope, id, "choice", ROUND, from, to)
    val cards = vm.cards
    var index by remember { mutableIntStateOf(0) }
    var correctCount by remember { mutableIntStateOf(0) }
    var combo by remember { mutableIntStateOf(0) }
    var bestCombo by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<String?>(null) }
    var awarded by remember { mutableIntStateOf(0) }
    var finishedHandled by remember { mutableStateOf(false) }

    val finished = !vm.loading && index >= cards.size
    val current = cards.getOrNull(index)

    val rev = current?.let { isReversed(dir, it, index) } ?: false
    val answer = current?.back(rev).orEmpty()
    val options = remember(current?.id, rev, vm.pool.size) {
        current?.let { c ->
            val wrong = vm.pool.map { it.back(rev) }.filter { it != c.back(rev) }.distinct().shuffled().take(3)
            (wrong + c.back(rev)).shuffled()
        } ?: emptyList()
    }

    LaunchedEffect(finished) {
        if (finished && !finishedHandled && cards.isNotEmpty()) {
            finishedHandled = true
            awarded = correctCount * 3 + bestCombo * 2
            vm.finish(perfect = correctCount == cards.size, bonusXp = awarded)
        }
    }

    PracticeScaffold(
        title = "Multiple Choice",
        progress = if (cards.isEmpty()) 0f else index / cards.size.toFloat(),
        loading = vm.loading,
        onBack = onBack,
    ) {
        if (cards.isEmpty()) {
            Text("Dieses Deck hat noch keine Karten.", style = MaterialTheme.typography.titleMedium)
        } else if (finished) {
            ResultPane(
                emoji = if (correctCount >= cards.size * 0.8) "" else "",
                headline = "$correctCount von ${cards.size} richtig",
                detail = "Beste Serie: $bestCombo",
                xp = awarded,
                confetti = correctCount >= cards.size / 2,
                onBack = onBack,
            )
        } else if (current != null) {
            val cs = MaterialTheme.colorScheme
            Text(
                if (combo >= 2) "$combo in Folge" else "Frage ${index + 1} / ${cards.size}",
                style = MaterialTheme.typography.labelLarge.bold(),
                color = cs.onSurfaceVariant,
            )
            AnimatedContent(
                targetState = current,
                transitionSpec = {
                    (slideInHorizontally(spring(0.8f, 300f)) { it } + fadeIn()) togetherWith
                        (slideOutHorizontally { -it } + fadeOut())
                },
                label = "question",
            ) { card ->
                Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainerHigh) {
                    Column(Modifier.padding(32.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (card.sourceLang.isBlank()) (if (rev) "Antwort" else "Frage") else "Was bedeutet …", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                        Text(card.front(rev), style = MaterialTheme.typography.headlineLarge.bold(), textAlign = TextAlign.Center)
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                options.forEach { opt ->
                    val state = when {
                        picked == null -> 0
                        opt == answer -> 1
                        opt == picked -> 2
                        else -> 0
                    }
                    val bg by animateColorAsState(
                        when (state) {
                            1 -> cs.primary
                            2 -> cs.errorContainer
                            else -> cs.surfaceContainerHigh
                        },
                        label = "opt",
                    )
                    val fg = when (state) {
                        1 -> cs.onPrimary
                        2 -> cs.onErrorContainer
                        else -> cs.onSurface
                    }
                    val src = remember { MutableInteractionSource() }
                    Surface(
                        Modifier.fillMaxWidth().pressScale(src, 0.96f),
                        shape = MaterialTheme.shapes.medium,
                        color = bg,
                        contentColor = fg,
                    ) {
                        Text(
                            opt,
                            Modifier
                                .clickable(enabled = picked == null, interactionSource = src, indication = null) { picked = opt }
                                .fillMaxWidth()
                                .padding(18.dp),
                            style = MaterialTheme.typography.titleMedium.bold(),
                        )
                    }
                }
            }
            if (picked != null && !current.example.isNullOrBlank()) {
                Text(
                    current.example.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
            LaunchedEffect(picked) {
                val p = picked ?: return@LaunchedEffect
                val ok = p == answer
                vm.review(current, ok)
                if (ok) { correctCount++; combo++; if (combo > bestCombo) bestCombo = combo } else combo = 0
                delay(if (ok) 900 else 1600)
                picked = null
                index++
            }
        }
    }
}
