package com.lingosnap.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.edit
import androidx.documentfile.provider.DocumentFile
import com.lingosnap.data.Backup
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.languageName
import com.lingosnap.data.model.typeLabelFor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.put

/**
 * Keeps a copy of everything in a folder the user picked once (Drive, SD card, Downloads …); the app needs the right to write there,
 * which the system dialog asks for. Inside the chosen folder the app makes a folder "LingoSnap" with
 *  - "Komplett-Backup": the whole app (all decks with learning state and pictures, groups) and all settings, and
 *  - "Decks": one text file per deck, sorted into one folder per language.
 * It writes again a few seconds after something changed, and when the app goes to the background.
 */
@OptIn(kotlinx.coroutines.FlowPreview::class)
class AutoBackup(private val context: Context, private val repo: CardRepository) {
    private val prefs = context.getSharedPreferences("autobackup", Context.MODE_PRIVATE)
    private val lock = kotlinx.coroutines.sync.Mutex()

    val folder: String? get() = prefs.getString("folder", null)
    val lastRun: Long get() = prefs.getLong("last", 0L)
    val lastError: String? get() = prefs.getString("error", null)
    val enabled: Boolean get() = folder != null

    /** Name of the chosen folder for the display. */
    val folderName: String? get() = folder?.let { runCatching { DocumentFile.fromTreeUri(context, Uri.parse(it))?.name }.getOrNull() }

    fun setFolder(uri: Uri?) {
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
        }
        prefs.edit { if (uri == null) remove("folder") else putString("folder", uri.toString()); remove("hash"); remove("error") }
    }

    /** Backs up again a little after every change of decks, cards or groups (many changes in a row = one backup). */
    fun startWatching(scope: CoroutineScope) {
        scope.launch {
            combine(repo.decks, repo.cards, repo.groups) { d, c, g -> Triple(d.size, c.size, g.size) to (c.hashCode() xor d.hashCode() xor g.hashCode()) }
                .debounce(15_000)
                .collect { if (enabled) run() }
        }
    }

    /**
     * Writes the backup. Returns true when the folder is up to date afterwards. Without [force] nothing is written when nothing changed
     * since the last backup.
     */
    suspend fun run(force: Boolean = false): Boolean = lock.withLock {
        withContext(Dispatchers.IO) {
            val uri = folder?.let(Uri::parse) ?: return@withContext false
            runCatching {
                val decks = repo.decks.first()
                val cards = repo.cards.first()
                val groups = repo.groups.first()
                // a fresh, empty app must never overwrite the copy that is in the folder
                if (decks.isEmpty()) return@runCatching true
                val root = DocumentFile.fromTreeUri(context, uri)?.takeIf { it.canWrite() } ?: error(tr("Der Ordner ist nicht mehr beschreibbar. Wähle ihn neu aus."))
                val json = Backup.toJson(decks, cards, groups = groups)
                val settings = settingsJson()
                val files = deckFiles(decks, cards)
                val hash = (json.hashCode().toString() + "/" + settings.hashCode() + "/" + files.hashCode())
                if (!force && hash == prefs.getString("hash", null)) return@runCatching true

                val app = root.dir("LingoSnap")
                val full = app.dir("Komplett-Backup")
                full.write("lingosnap-backup.json", "application/json", json)
                full.write("einstellungen.json", "application/json", settings)
                val decksDir = app.dir("Decks")
                val wantedDirs = files.keys.map { it.first }.toSet()
                // folders of languages that are gone are removed, so the folder always shows what the app has
                decksDir.listFiles().filter { it.isDirectory && it.name !in wantedDirs }.forEach { it.delete() }
                wantedDirs.forEach { lang ->
                    val dir = decksDir.dir(lang)
                    val wantedFiles = files.keys.filter { it.first == lang }.map { it.second }.toSet()
                    dir.listFiles().filter { it.isFile && it.name !in wantedFiles }.forEach { it.delete() }
                    wantedFiles.forEach { name -> dir.write(name, "text/plain", files.getValue(lang to name)) }
                }
                prefs.edit { putLong("last", System.currentTimeMillis()); putString("hash", hash); remove("error") }
                true
            }.getOrElse { e ->
                prefs.edit { putString("error", e.message ?: e.javaClass.simpleName) }
                false
            }
        }
    }

    private fun DocumentFile.dir(name: String): DocumentFile = findFile(name)?.takeIf { it.isDirectory } ?: createDirectory(name) ?: error("Ordner „$name“ konnte nicht angelegt werden.")

    private fun DocumentFile.write(name: String, mime: String, text: String) {
        val file = findFile(name)?.takeIf { it.isFile } ?: createFile(mime, name) ?: error("Datei „$name“ konnte nicht angelegt werden.")
        context.contentResolver.openOutputStream(file.uri, "wt")!!.use { it.write(text.toByteArray()) }
    }

    /** Settings and statistics of the app as they are stored on the phone (not the API keys: those never leave the device). */
    private fun settingsJson(): String {
        val root = kotlinx.serialization.json.buildJsonObject {
            for (name in listOf("lingosnap_stats", "feedback", "lingosnap_lang")) {
                val all = context.getSharedPreferences(name, Context.MODE_PRIVATE).all
                put(name, kotlinx.serialization.json.buildJsonObject {
                    all.toSortedMap().forEach { (k, v) ->
                        when (v) {
                            is Boolean -> put(k, v)
                            is Number -> put(k, v)
                            is String -> put(k, v)
                            is Set<*> -> put(k, kotlinx.serialization.json.buildJsonArray { v.forEach { add(kotlinx.serialization.json.JsonPrimitive(it.toString())) } })
                        }
                    }
                })
            }
        }
        return kotlinx.serialization.json.Json { prettyPrint = true }.encodeToString(kotlinx.serialization.json.JsonElement.serializer(), root)
    }

    /** (language folder, file name) to the text of the file: one line "word ; translation" per card. */
    private fun deckFiles(decks: List<Deck>, cards: List<Flashcard>): Map<Pair<String, String>, String> {
        fun safe(s: String) = s.replace(Regex("[\\/:*?\"<>|\n\r\t]+"), "_").trim().trim('.').take(80).ifBlank { "Deck" }
        val out = LinkedHashMap<Pair<String, String>, String>()
        val used = HashSet<Pair<String, String>>()
        for (d in decks.sortedBy { it.name.lowercase() }) {
            val folder = safe(
                when {
                    !d.isLanguage -> tr("Karteikarten")
                    d.sourceLang == "auto" || d.sourceLang.isBlank() -> tr("Automatisch erkannt")
                    else -> languageName(d.sourceLang)
                },
            )
            var name = safe(d.name) + ".txt"
            var n = 2
            while (!used.add(folder to name)) name = safe(d.name) + " (" + n++ + ").txt"
            val dc = cards.filter { it.deckId == d.id }.sortedBy { it.id }
            out[folder to name] = buildString {
                append("# ").append(d.name).append('\n')
                append("# ").append(d.typeLabelFor(dc)).append('\n')
                dc.forEach { c ->
                    append(c.source.replace("\n", " ")).append(" ; ").append(c.target.replace("\n", " "))
                    if (!c.example.isNullOrBlank()) append(" ; ").append(c.example.replace("\n", " "))
                    append('\n')
                }
            }
        }
        return out
    }
}

/** Remembers the last crash so it can be copied from the settings and sent for fixing. */
object CrashLog {
    fun install(context: Context) {
        val file = java.io.File(context.filesDir, "last_crash.txt")
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { file.writeText("${java.util.Date()}\n${e.stackTraceToString()}") }
            old?.uncaughtException(t, e)
        }
    }

    fun report(context: Context): String {
        val crash = runCatching { java.io.File(context.filesDir, "last_crash.txt").takeIf { it.exists() }?.readText() }.getOrNull()
        val version = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull()
        return "LingoSnap $version, Android ${android.os.Build.VERSION.RELEASE} (${android.os.Build.MODEL})\n\n" +
            (crash ?: tr("Kein Absturz gespeichert."))
    }
}
