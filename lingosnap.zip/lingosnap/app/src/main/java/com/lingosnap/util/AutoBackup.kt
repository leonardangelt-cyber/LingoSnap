package com.lingosnap.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.edit
import androidx.documentfile.provider.DocumentFile
import com.lingosnap.data.Backup
import com.lingosnap.data.CardRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/** Writes one backup file into a folder the user picked once (Drive, SD card, Downloads …), at most once a day. */
class AutoBackup(private val context: Context, private val repo: CardRepository) {
    private val prefs = context.getSharedPreferences("autobackup", Context.MODE_PRIVATE)

    val folder: String? get() = prefs.getString("folder", null)
    val lastRun: Long get() = prefs.getLong("last", 0L)
    val enabled: Boolean get() = folder != null

    fun setFolder(uri: Uri?) {
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
        }
        prefs.edit { if (uri == null) remove("folder") else putString("folder", uri.toString()) }
    }

    /** Returns true when a file was written. [force] ignores the once-a-day limit. */
    suspend fun run(force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val uri = folder?.let(Uri::parse) ?: return@withContext false
        if (!force && System.currentTimeMillis() - lastRun < 20L * 3600_000L) return@withContext false
        runCatching {
            val decks = repo.decks.first()
            if (decks.isEmpty()) return@runCatching false
            val json = Backup.toJson(decks, repo.cards.first())
            val dir = DocumentFile.fromTreeUri(context, uri) ?: return@runCatching false
            val file = dir.findFile(NAME + ".json") ?: dir.createFile("application/json", NAME) ?: return@runCatching false
            context.contentResolver.openOutputStream(file.uri, "wt")!!.use { it.write(json.toByteArray()) }
            prefs.edit { putLong("last", System.currentTimeMillis()) }
            true
        }.getOrDefault(false)
    }

    companion object { const val NAME = "lingosnap-backup" }
}

/** Remembers the last crash so it can be copied from the settings and sent for fixing. */
object CrashLog {
    fun install(context: Context) {
        val file = java.io.File(context.filesDir, "last_crash.txt")
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { file.writeText("${java.util.Date()}\n${e.stackTraceToString()}") }
            old?.uncaughtException(t, e)
        }
    }

    fun report(context: Context): String {
        val crash = runCatching { java.io.File(context.filesDir, "last_crash.txt").takeIf { it.exists() }?.readText() }.getOrNull()
        val version = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull()
        return "LingoSnap $version, Android ${android.os.Build.VERSION.RELEASE} (${android.os.Build.MODEL})\n\n" +
            (crash ?: "Kein Absturz gespeichert.")
    }
}
