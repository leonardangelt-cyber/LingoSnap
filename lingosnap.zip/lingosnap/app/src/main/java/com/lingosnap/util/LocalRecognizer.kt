package com.lingosnap.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.lingosnap.data.remote.VocabPair
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** What the recognition without AI found: the pairs, and how many lines had no translation next to them. */
class LocalResult(val pairs: List<VocabPair>, val skipped: Int)

/**
 * Reads vocabulary without any AI, on the phone: text blocks are split at their separators, photos and scanned pages go through the
 * text recognition of ML Kit (Latin letters) and are paired by their rows: left part = word, right part = translation.
 * Handwriting and unusual layouts are much weaker than with the AI – this is the fallback and the offline way.
 */
object LocalRecognizer {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { c.resume(it) }
        addOnFailureListener { c.resumeWithException(it) }
        addOnCanceledListener { c.cancel() }
    }

    /** Page size that works well for the recognition: big enough for small print, not so big that it gets slow. */
    private const val TARGET_WIDTH = 2000

    private fun scaled(src: Bitmap): Bitmap {
        val w = src.width
        if (w in (TARGET_WIDTH * 3 / 4)..(TARGET_WIDTH * 5 / 4)) return src
        val f = TARGET_WIDTH.toFloat() / w
        return Bitmap.createScaledBitmap(src, TARGET_WIDTH, (src.height * f).toInt().coerceAtLeast(1), true)
    }

    /** Grey and with stretched contrast: helps with grey paper, shadows and weak print. */
    private fun enhanced(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val m = ColorMatrix().apply { setSaturation(0f) }
        val k = 1.6f; val t = (-0.5f * k + 0.5f) * 255f
        m.postConcat(ColorMatrix(floatArrayOf(k, 0f, 0f, 0f, t, 0f, k, 0f, 0f, t, 0f, 0f, k, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        Canvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        return out
    }

    private class Page(val rows: List<OcrRow>, val loose: List<String>) {
        val score get() = rows.size * 2 + loose.size
    }

    private suspend fun page(bmp: Bitmap): Page {
        val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
        val words = result.textBlocks.flatMap { it.lines }.flatMap { it.elements }
            .mapNotNull { e -> e.boundingBox?.let { OcrWord(e.text, it.left, it.top, it.right, it.bottom) } }
        val l = OcrLayout.layout(words)
        return Page(l.rows, l.loose)
    }

    suspend fun read(batch: Batch, source: String, target: String, orient: Boolean = true): LocalResult {
        val pairs = ArrayList<VocabPair>()
        var skipped = 0
        fun addEntries(text: String) {
            ManualLines.parse(text).forEach { e -> if (e.second != null) pairs += VocabPair(e.first, e.second, e.example) else skipped++ }
        }
        if (batch.text.isNotBlank()) addEntries(batch.text)
        batch.images?.invoke()?.forEach { jpg ->
            val raw = BitmapFactory.decodeByteArray(jpg, 0, jpg.size) ?: return@forEach
            val bmp = scaled(raw)
            val first = runCatching { page(bmp) }.getOrNull()
            // second try on a contrast-enhanced copy; the better result (more rows) wins
            val second = runCatching { enhanced(bmp).let { e -> page(e).also { e.recycle() } } }.getOrNull()
            val best = listOfNotNull(first, second).maxByOrNull { it.score }
            if (bmp !== raw) bmp.recycle()
            raw.recycle()
            if (best == null) return@forEach
            best.rows.forEach { r -> pairs += VocabPair(r.first.trim(), r.second.trim(), r.example) }
            best.loose.forEach { addEntries(it) }
        }
        val clean = pairs.distinctBy { it.source.lowercase() + "|" + it.target.lowercase() }
        return LocalResult(if (orient && source != target) TextAi.orient(clean, source, target) else clean, skipped)
    }
}
