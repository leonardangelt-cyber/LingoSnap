package com.lingosnap.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.content.edit
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin

/** Very light haptics plus two short synthesized sounds for right and wrong answers. */
class FeedbackManager(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("feedback", Context.MODE_PRIVATE)
    private val vibrator: Vibrator? = context.applicationContext.getSystemService(Vibrator::class.java)

    var haptics: Boolean
        get() = prefs.getBoolean("haptics", true)
        set(v) = prefs.edit { putBoolean("haptics", v) }

    var sounds: Boolean
        get() = prefs.getBoolean("sounds", true)
        set(v) = prefs.edit { putBoolean("sounds", v) }

    private val rate = 22050
    private val correctSound by lazy { synth(listOf(659.0 to 90, 880.0 to 140)) }
    private val wrongSound by lazy { synth(listOf(247.0 to 120, 196.0 to 200)) }

    /** Tiny tick for taps (flip card, choose a mode). */
    fun tap() = buzz(longArrayOf(0, 8), intArrayOf(0, 40))

    fun correct() {
        buzz(longArrayOf(0, 12), intArrayOf(0, 70))
        if (sounds) play(correctSound)
    }

    fun wrong() {
        buzz(longArrayOf(0, 18, 60, 18), intArrayOf(0, 90, 0, 90))
        if (sounds) play(wrongSound)
    }

    private fun buzz(timings: LongArray, amplitudes: IntArray) {
        if (!haptics) return
        runCatching {
            val v = vibrator ?: return
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
        }
    }

    private fun synth(notes: List<Pair<Double, Int>>): ShortArray {
        val out = ArrayList<Short>()
        for ((freq, ms) in notes) {
            val n = rate * ms / 1000
            for (i in 0 until n) {
                val fade = minOf(1.0, i / 200.0, (n - i) / 400.0)
                out.add((sin(2 * PI * freq * i / rate) * fade * 0.28 * Short.MAX_VALUE).toInt().toShort())
            }
        }
        return out.toShortArray()
    }

    private fun play(samples: ShortArray) {
        thread(isDaemon = true) {
            runCatching {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build(),
                    )
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(samples.size * 2)
                    .build()
                track.write(samples, 0, samples.size)
                track.play()
                Thread.sleep(samples.size * 1000L / rate + 80)
                track.release()
            }
        }
    }
}
