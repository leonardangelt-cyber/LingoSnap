package com.lingosnap.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.content.edit
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Very light haptics plus two short synthesized sounds for right and wrong answers. */
class FeedbackManager(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("feedback", Context.MODE_PRIVATE)
    private val vibrator: Vibrator? = context.applicationContext.getSystemService(Vibrator::class.java)

    var haptics: Boolean
        get() = prefs.getBoolean("haptics", true)
        set(v) = prefs.edit { putBoolean("haptics", v) }

    var sounds: Boolean
        get() = prefs.getBoolean("sounds", true)
        set(v) = prefs.edit { putBoolean("sounds", v) }

    /** "srs" = spaced repetition, "rounds" = right/wrong rounds until everything is right. */
    var learnMode: String
        get() = prefs.getString("learnMode", "srs") ?: "srs"
        set(v) = prefs.edit { putString("learnMode", v) }

    private val rate = 22050
    // right: bright, bell-like rising triad that rings out; wrong: one soft, low "thud" that sinks
    private val correctSound by lazy {
        bell(784.0, 70) + bell(988.0, 70) + bell(1319.0, 360)
    }
    private val wrongSound by lazy { reed(311.0, 150) + reed(233.0, 320) }

    /** Tiny tick for taps (flip card, choose a mode). */
    fun tap() = buzz(longArrayOf(0, 8), intArrayOf(0, 40))

    fun correct() {
        buzz(longArrayOf(0, 12), intArrayOf(0, 70))
        if (sounds) play(correctSound)
    }

    fun wrong() {
        buzz(longArrayOf(0, 18, 60, 18), intArrayOf(0, 90, 0, 90))
        if (sounds) play(wrongSound)
    }

    private fun buzz(timings: LongArray, amplitudes: IntArray) {
        if (!haptics) return
        runCatching {
            val v = vibrator ?: return
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
        }
    }

    /** A struck-bell like tone: a few harmonics with an exponential decay. */
    private fun bell(freq: Double, ms: Int): ShortArray {
        val n = rate * ms / 1000
        return ShortArray(n) { i ->
            val t = i.toDouble() / rate
            val env = exp(-t * 9.0) * minOf(1.0, i / 120.0) * minOf(1.0, (n - i) / 300.0)
            val v = sin(2 * PI * freq * t) + 0.35 * sin(2 * PI * freq * 2 * t) + 0.12 * sin(2 * PI * freq * 3 * t)
            (v * env * 0.26 * Short.MAX_VALUE).toInt().toShort()
        }
    }

    /** A reedy "nope" tone: rich in overtones so small phone speakers reproduce it clearly. */
    private fun reed(freq: Double, ms: Int): ShortArray {
        val n = rate * ms / 1000
        return ShortArray(n) { i ->
            val t = i.toDouble() / rate
            val env = minOf(1.0, i / 150.0) * minOf(1.0, (n - i) / 500.0) * (0.55 + 0.45 * exp(-t * 6.0))
            val v = sin(2 * PI * freq * t) + 0.55 * sin(2 * PI * freq * 2 * t) + 0.35 * sin(2 * PI * freq * 3 * t) + 0.2 * sin(2 * PI * freq * 5 * t)
            (v / 2.1 * env * 0.55 * Short.MAX_VALUE).toInt().toShort()
        }
    }

    private fun play(samples: ShortArray) {
        thread(isDaemon = true) {
            runCatching {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build(),
                    )
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(samples.size * 2)
                    .build()
                track.write(samples, 0, samples.size)
                track.play()
                Thread.sleep(samples.size * 1000L / rate + 80)
                track.release()
            }
        }
    }
}
