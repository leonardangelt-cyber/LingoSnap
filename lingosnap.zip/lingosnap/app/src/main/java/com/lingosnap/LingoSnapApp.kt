package com.lingosnap

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.room.Room
import com.lingosnap.data.CardRepository
import com.lingosnap.data.SecureKeyStore
import com.lingosnap.data.local.AppDatabase
import com.lingosnap.data.remote.GeminiClient
import com.lingosnap.util.TtsManager

/** Hand-rolled DI container – swap for Hilt/Koin once the app grows. */
class AppContainer(context: Context) {
    val keyStore = SecureKeyStore(context)
    val gemini = GeminiClient(keyStore)
    private val db = Room.databaseBuilder(context, AppDatabase::class.java, "lingosnap.db").build()
    val repository = CardRepository(db.cardDao(), gemini)
    val tts = TtsManager(context)
}

class LingoSnapApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

val Context.container: AppContainer get() = (applicationContext as LingoSnapApp).container
fun CreationExtras.app(): LingoSnapApp = this[APPLICATION_KEY] as LingoSnapApp
