package com.lingosnap.ui.study

import com.lingosnap.util.tr

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.StudyScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Direction { Forward, Reverse, Mixed }

sealed interface MnemonicState {
    data object Idle : MnemonicState
    data object Loading : MnemonicState
    data class Ready(val text: String) : MnemonicState
    data class Error(val message: String) : MnemonicState
}

data class Feedback(val rating: Rating, val newLevel: Int, val nonce: Int)

/** One immutable snapshot of the whole screen – the UI is a pure function of this. */
data class StudyUiState(
    val loading: Boolean = true,
    /** Head of the queue is the card on screen. */
    val queue: List<Flashcard> = emptyList(),
    val direction: Direction = Direction.Forward,
    val flipped: Boolean = false,
    val reviewed: Int = 0,
    val sessionSize: Int = 0,
    val mnemonic: MnemonicState = MnemonicState.Idle,
    val feedback: Feedback? = null,
    /** "Richtig/Falsch" mode: rounds repeat the wrong cards until all are right. */
    val rounds: Boolean = false,
    val roundNumber: Int = 1,
    val roundCorrect: Int = 0,
    val roundWrong: List<Flashcard> = emptyList(),
    val exampleLoading: Boolean = false,
    val exampleError: String? = null,
    // for the report at the end
    val startedAt: Long = 0L,
    val endedAt: Long = 0L,
    /** How often each rating was pressed: Nochmal, Schwer, Gut, Einfach. */
    val counts: List<Int> = listOf(0, 0, 0, 0),
    /** Every card of the session once, in the order seen. */
    val seen: List<Flashcard> = emptyList(),
    /** Card id -> how often it was "Nochmal". */
    val again: Map<Long, Int> = emptyMap(),
    /** Card id -> when it is due next (repetition system). */
    val nextDue: Map<Long, Long> = emptyMap(),
) {
    val current: Flashcard? get() = queue.firstOrNull()
    /** Round over, some cards were wrong: ask whether to go again. */
    val roundSummary: Boolean get() = rounds && !loading && queue.isEmpty() && roundWrong.isNotEmpty()
    val finished: Boolean get() = !loading && queue.isEmpty() && roundWrong.isEmpty()
    val sourceFirst: Boolean
        get() = when (direction) {
            Direction.Forward -> true
            Direction.Reverse -> false
            Direction.Mixed -> ((current?.id ?: 0L) + reviewed) % 2L == 0L
        }
    val progress: Float get() = if (sessionSize == 0) 0f else (sessionSize - queue.size).coerceAtLeast(0) / sessionSize.toFloat()
}

class StudyViewModel(
    private val repo: CardRepository,
    private val scope: StudyScope,
    private val id: Long,
    private val onlyDue: Boolean,
    private val dir: String = "fwd",
    private val rounds: Boolean = false,
    private val from: Int = 0,
    private val to: Int = 0,
) : ViewModel() {

    private val _ui = MutableStateFlow(
        StudyUiState(direction = when (dir) { "rev" -> Direction.Reverse; "mix" -> Direction.Mixed; else -> Direction.Forward }),
    )
    val ui: StateFlow<StudyUiState> = _ui.asStateFlow()

    init { load() }

    fun load() = viewModelScope.launch {
        val all = repo.selectRange(repo.cardsFor(scope, id), from, to)
        if (rounds) {
            val list = all.shuffled()
            _ui.update { StudyUiState(loading = false, queue = list, sessionSize = list.size, direction = it.direction, rounds = true, startedAt = System.currentTimeMillis()) }
            prefetch()
            return@launch
        }
        val now = System.currentTimeMillis()
        val due = if (onlyDue && from >= 0) all.filter { it.dueAt <= now }.sortedWith(compareBy({ it.dueAt }, { it.level })).take(30) else emptyList()
        // nothing due? then practise the weakest cards anyway – learning is always possible
        val list = if (due.isNotEmpty()) due.shuffled() else all.shuffled().sortedBy { it.level }.take(30)
        _ui.update { StudyUiState(loading = false, queue = list, sessionSize = list.size, direction = it.direction, startedAt = System.currentTimeMillis()) }
        prefetch()
    }

    fun flip() = _ui.update { it.copy(flipped = !it.flipped) }
    fun setDirection(d: Direction) = _ui.update { it.copy(direction = d, flipped = false) }

    /** Starts the next round with only the cards that were wrong. */
    fun nextRound() = _ui.update { s ->
        val list = s.roundWrong.shuffled()
        s.copy(queue = list, roundWrong = emptyList(), sessionSize = list.size, roundCorrect = 0, roundNumber = s.roundNumber + 1, flipped = false, endedAt = 0L)
    }

    fun rate(rating: Rating) {
        val card = _ui.value.current ?: return
        if (_ui.value.rounds) {
            _ui.update { s ->
                s.copy(
                    queue = s.queue.drop(1),
                    roundWrong = if (rating == Rating.Again) s.roundWrong + card else s.roundWrong,
                    roundCorrect = s.roundCorrect + if (rating == Rating.Again) 0 else 1,
                    flipped = false,
                    reviewed = s.reviewed + 1,
                    mnemonic = MnemonicState.Idle,
                    exampleError = null,
                ).withOutcome(card, rating, null)
            }
            return
        }
        viewModelScope.launch {
            val updated = repo.review(card, rating)
            _ui.update { s ->
                // "Nochmal" cards come back at the end of this session.
                val rest = s.queue.drop(1) + if (rating == Rating.Again) listOf(updated) else emptyList()
                s.copy(
                    queue = rest,
                    flipped = false,
                    reviewed = s.reviewed + 1,
                    mnemonic = MnemonicState.Idle,
                    exampleError = null,
                    sessionSize = if (rating == Rating.Again) s.sessionSize + 1 else s.sessionSize,
                    feedback = Feedback(rating, updated.level, (s.feedback?.nonce ?: 0) + 1),
                ).withOutcome(card, rating, updated.dueAt)
            }
            prefetch()
        }
    }

    /* ── help while learning: example sentence + mnemonic come in bulk, ahead of the cards, so tapping the symbols is instant ── */

    private val requested = HashSet<Long>()
    private val pending = HashMap<Long, kotlinx.coroutines.CompletableDeferred<Unit>>()

    /** Asks for the help of the next cards: the 5 nearest in one small (fast) request, the following ones in bigger batches. */
    private fun prefetch() {
        val todo = _ui.value.queue.take(20)
            .filter { (it.example.isNullOrBlank() || it.mnemonic.isNullOrBlank()) && it.id !in requested }
        if (todo.isEmpty()) return
        val chunks = (listOf(todo.take(5)) + todo.drop(5).chunked(10)).filter { it.isNotEmpty() }
        chunks.forEach { chunk ->
            val done = kotlinx.coroutines.CompletableDeferred<Unit>()
            chunk.forEach { requested += it.id; pending[it.id] = done }
            viewModelScope.launch {
                repo.fillHelp(chunk).onSuccess { applyHelp(it) }
                chunk.forEach { pending.remove(it.id) }
                done.complete(Unit)
            }
        }
    }

    private fun applyHelp(list: List<com.lingosnap.data.remote.HelpResult>) {
        if (list.isEmpty()) return
        val byId = list.associateBy { it.id }
        _ui.update { s ->
            s.copy(queue = s.queue.map { c ->
                val r = byId[c.id] ?: return@map c
                c.copy(example = c.example.takeUnless { it.isNullOrBlank() } ?: r.example, mnemonic = c.mnemonic ?: r.mnemonic)
            })
        }
    }

    /** Waits for a running prefetch of this card, otherwise asks right away (both aids in one request). */
    private suspend fun ensureHelp(card: Flashcard): Result<Unit> {
        pending[card.id]?.await()
        val now = _ui.value.queue.firstOrNull { it.id == card.id } ?: card
        if (!now.example.isNullOrBlank() && !now.mnemonic.isNullOrBlank()) return Result.success(Unit)
        return repo.fillHelp(listOf(now)).map { applyHelp(it) }
    }

    private fun currentCard(id: Long) = _ui.value.queue.firstOrNull { it.id == id }

    fun requestMnemonic(force: Boolean = false) {
        val card = _ui.value.current ?: return
        if (!force && !card.mnemonic.isNullOrBlank()) {
            _ui.update { it.copy(mnemonic = MnemonicState.Ready(card.mnemonic.orEmpty())) }
            return
        }
        _ui.update { it.copy(mnemonic = MnemonicState.Loading) }
        viewModelScope.launch {
            if (force) {
                // "another one": a fresh idea for this card only
                repo.mnemonicFor(card, true).fold(
                    onSuccess = { updated ->
                        _ui.update { s ->
                            s.copy(queue = s.queue.map { if (it.id == updated.id) updated else it }, mnemonic = MnemonicState.Ready(updated.mnemonic.orEmpty()))
                        }
                    },
                    onFailure = { e -> _ui.update { it.copy(mnemonic = MnemonicState.Error(e.message ?: tr("Eselsbrücke konnte nicht erstellt werden"))) } },
                )
                return@launch
            }
            ensureHelp(card).fold(
                onSuccess = {
                    val text = currentCard(card.id)?.mnemonic
                    _ui.update { it.copy(mnemonic = if (text.isNullOrBlank()) MnemonicState.Error(tr("Eselsbrücke konnte nicht erstellt werden")) else MnemonicState.Ready(text)) }
                },
                onFailure = { e -> _ui.update { it.copy(mnemonic = MnemonicState.Error(e.message ?: tr("Eselsbrücke konnte nicht erstellt werden"))) } },
            )
        }
    }

    /** Shows the example sentence; it is usually there already thanks to [prefetch]. */
    fun requestExample() {
        val card = _ui.value.current ?: return
        if (!card.example.isNullOrBlank() || _ui.value.exampleLoading) return
        _ui.update { it.copy(exampleLoading = true, exampleError = null) }
        viewModelScope.launch {
            ensureHelp(card).fold(
                onSuccess = {
                    val ok = !currentCard(card.id)?.example.isNullOrBlank()
                    _ui.update { it.copy(exampleLoading = false, exampleError = if (ok) null else tr("Beispielsatz fehlgeschlagen")) }
                },
                onFailure = { e -> _ui.update { it.copy(exampleLoading = false, exampleError = e.message ?: tr("Beispielsatz fehlgeschlagen")) } },
            )
        }
    }

    fun dismissMnemonic() = _ui.update { it.copy(mnemonic = MnemonicState.Idle) }
}


/** Remembers what happened with one card for the report; sets the end time when the last card is done. */
private fun StudyUiState.withOutcome(card: Flashcard, rating: Rating, dueAt: Long?): StudyUiState {
    val now = System.currentTimeMillis()
    val c = counts.toMutableList().also { it[rating.ordinal] = it[rating.ordinal] + 1 }
    val next = copy(
        counts = c,
        seen = if (seen.any { it.id == card.id }) seen else seen + card,
        again = if (rating == Rating.Again) again + (card.id to ((again[card.id] ?: 0) + 1)) else again,
        nextDue = if (dueAt != null) nextDue + (card.id to dueAt) else nextDue,
    )
    return if (next.queue.isEmpty() && next.endedAt == 0L) next.copy(endedAt = now) else next
}

/** The report of the session; rounds count a card once as wrong or right per round. */
fun StudyUiState.report(): com.lingosnap.ui.practice.SessionReport {
    val tonesNames = listOf(
        Rating.Again to com.lingosnap.ui.practice.Tone.Bad, Rating.Hard to com.lingosnap.ui.practice.Tone.Okay,
        Rating.Good to com.lingosnap.ui.practice.Tone.Good, Rating.Easy to com.lingosnap.ui.practice.Tone.Easy,
    )
    val segments = if (rounds) listOf(
        com.lingosnap.ui.practice.ReportSegment(tr("Richtig"), counts[Rating.Good.ordinal] + counts[Rating.Hard.ordinal] + counts[Rating.Easy.ordinal], com.lingosnap.ui.practice.Tone.Good),
        com.lingosnap.ui.practice.ReportSegment(tr("Falsch"), counts[Rating.Again.ordinal], com.lingosnap.ui.practice.Tone.Bad),
    ) else tonesNames.map { (r, t) -> com.lingosnap.ui.practice.ReportSegment(r.label, counts[r.ordinal], t) }
    val missed = seen.filter { it.id in again }.map { com.lingosnap.ui.practice.ReportItem(it, times = again[it.id] ?: 1) }
    val known = seen.filter { it.id !in again }.map { com.lingosnap.ui.practice.ReportItem(it) }
    val end = if (endedAt > 0L) endedAt else System.currentTimeMillis()
    val seconds = if (startedAt > 0L) ((end - startedAt) / 1000).toInt() else 0
    val tomorrow = nextDue.values.count { it in (System.currentTimeMillis() + 12L * 3600_000)..(System.currentTimeMillis() + 48L * 3600_000) }
    return com.lingosnap.ui.practice.SessionReport(
        total = reviewed.coerceAtLeast(counts.sum()), segments = segments, seconds = seconds, missed = missed, known = known,
        dueAts = nextDue.values.toList(),
        tip = com.lingosnap.ui.practice.tipFor(seen.size, missed.size, tomorrow),
    )
}

/** Report of the round that just ended (right/wrong mode): this round's numbers and the cards that are still wrong. */
fun StudyUiState.roundReport(): com.lingosnap.ui.practice.SessionReport {
    val total = roundCorrect + roundWrong.size
    val end = if (endedAt > 0L) endedAt else System.currentTimeMillis()
    return com.lingosnap.ui.practice.SessionReport(
        total = total,
        segments = listOf(
            com.lingosnap.ui.practice.ReportSegment(tr("Richtig"), roundCorrect, com.lingosnap.ui.practice.Tone.Good),
            com.lingosnap.ui.practice.ReportSegment(tr("Falsch"), roundWrong.size, com.lingosnap.ui.practice.Tone.Bad),
        ),
        seconds = if (startedAt > 0L) ((end - startedAt) / 1000).toInt() else 0,
        missed = roundWrong.map { com.lingosnap.ui.practice.ReportItem(it, times = again[it.id] ?: 1) },
        tip = com.lingosnap.ui.practice.tipFor(total, roundWrong.size),
    )
}
