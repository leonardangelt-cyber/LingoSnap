package com.lingosnap.ui.study

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.StudyScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Direction { Forward, Reverse, Mixed }

sealed interface MnemonicState {
    data object Idle : MnemonicState
    data object Loading : MnemonicState
    data class Ready(val text: String) : MnemonicState
    data class Error(val message: String) : MnemonicState
}

data class Feedback(val rating: Rating, val newLevel: Int, val nonce: Int)

/** One immutable snapshot of the whole screen – the UI is a pure function of this. */
data class StudyUiState(
    val loading: Boolean = true,
    /** Head of the queue is the card on screen. */
    val queue: List<Flashcard> = emptyList(),
    val direction: Direction = Direction.Forward,
    val flipped: Boolean = false,
    val reviewed: Int = 0,
    val sessionSize: Int = 0,
    val mnemonic: MnemonicState = MnemonicState.Idle,
    val feedback: Feedback? = null,
) {
    val current: Flashcard? get() = queue.firstOrNull()
    val finished: Boolean get() = !loading && queue.isEmpty()
    val sourceFirst: Boolean
        get() = when (direction) {
            Direction.Forward -> true
            Direction.Reverse -> false
            Direction.Mixed -> ((current?.id ?: 0L) + reviewed) % 2L == 0L
        }
    val progress: Float get() = if (sessionSize == 0) 0f else (sessionSize - queue.size).coerceAtLeast(0) / sessionSize.toFloat()
}

class StudyViewModel(
    private val repo: CardRepository,
    private val scope: StudyScope,
    private val id: Long,
    private val onlyDue: Boolean,
) : ViewModel() {

    private val _ui = MutableStateFlow(StudyUiState())
    val ui: StateFlow<StudyUiState> = _ui.asStateFlow()

    init { load() }

    fun load() = viewModelScope.launch {
        val list = if (onlyDue) repo.dueCards(scope, id, 30)
        else repo.cardsFor(scope, id).sortedBy { it.level }.take(50)
        _ui.update { StudyUiState(loading = false, queue = list, sessionSize = list.size, direction = it.direction) }
    }

    fun flip() = _ui.update { it.copy(flipped = !it.flipped) }
    fun setDirection(d: Direction) = _ui.update { it.copy(direction = d, flipped = false) }

    fun rate(rating: Rating) {
        val card = _ui.value.current ?: return
        viewModelScope.launch {
            val updated = repo.review(card, rating)
            _ui.update { s ->
                // "Hard" cards come back at the end of this session.
                val rest = s.queue.drop(1) + if (rating == Rating.Hard) listOf(updated) else emptyList()
                s.copy(
                    queue = rest,
                    flipped = false,
                    reviewed = s.reviewed + 1,
                    mnemonic = MnemonicState.Idle,
                    sessionSize = if (rating == Rating.Hard) s.sessionSize + 1 else s.sessionSize,
                    feedback = Feedback(rating, updated.level, (s.feedback?.nonce ?: 0) + 1),
                )
            }
        }
    }

    fun requestMnemonic(force: Boolean = false) {
        val card = _ui.value.current ?: return
        _ui.update { it.copy(mnemonic = MnemonicState.Loading) }
        viewModelScope.launch {
            repo.mnemonicFor(card, force).fold(
                onSuccess = { updated ->
                    _ui.update { s ->
                        s.copy(
                            queue = s.queue.map { if (it.id == updated.id) updated else it },
                            mnemonic = MnemonicState.Ready(updated.mnemonic.orEmpty()),
                        )
                    }
                },
                onFailure = { e -> _ui.update { it.copy(mnemonic = MnemonicState.Error(e.message ?: "Eselsbrücke konnte nicht erstellt werden")) } },
            )
        }
    }

    fun dismissMnemonic() = _ui.update { it.copy(mnemonic = MnemonicState.Idle) }
}
