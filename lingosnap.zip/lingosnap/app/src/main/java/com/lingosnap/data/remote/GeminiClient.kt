package com.lingosnap.data.remote

import android.util.Base64
import com.lingosnap.data.SecureKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
data class VocabPair(val source: String, val target: String, val example: String? = null)

@Serializable
private data class VocabResponse(val pairs: List<VocabPair> = emptyList())

sealed class GeminiException(message: String) : Exception(message) {
    data object MissingKey : GeminiException("Kein API-Schlüssel hinterlegt. Trage ihn unter Optionen ein.")
    data object EmptyAnswer : GeminiException("Die KI hat keine Antwort geliefert. Versuche es noch einmal.")
    class NoResult(raw: String) : GeminiException(
        "Es wurden keine Einträge erkannt." + if (raw.isBlank()) "" else " Antwort der KI: " + raw.trim().take(160),
    )
    class Http(val code: Int, detail: String) : GeminiException(
        when (code) {
            401, 403 -> "Der API-Schlüssel wurde abgelehnt. ($detail)"
            429 -> "Zu viele Anfragen oder Limit erreicht – warte kurz. ($detail)"
            else -> "Fehler $code: $detail"
        },
    )
}

/** Which service a key belongs to – detected automatically from the key itself. */
enum class AiProvider(val label: String) {
    Gemini("Google Gemini"),
    OpenAi("OpenAI"),
    Anthropic("Anthropic Claude"),
    OpenRouter("OpenRouter"),
    Groq("Groq"),
    XAi("xAI Grok");

    companion object {
        /** Best guess from the key prefix; null = unknown (all providers are tried). */
        fun guess(key: String): AiProvider? = when {
            key.startsWith("AIza") -> Gemini
            key.startsWith("sk-ant-") -> Anthropic
            key.startsWith("sk-or-") -> OpenRouter
            key.startsWith("gsk_") -> Groq
            key.startsWith("xai-") -> XAi
            key.startsWith("sk-") -> OpenAi
            else -> null
        }
    }
}

/** Live callbacks while the AI answers (all optional). */
class Progress(
    val onModel: (String) -> Unit = {},
    val onFirstText: () -> Unit = {},
    val onPair: (VocabPair) -> Unit = {},
)

/** Result of a successful key check. */
data class Verified(val provider: AiProvider, val models: List<String>)

/**
 * Talks to Gemini, OpenAI, Claude, OpenRouter, Groq or Grok – whichever the pasted key belongs to.
 * The key is only ever sent as a header, never inside a URL.
 */
class GeminiClient(
    private val keyStore: SecureKeyStore,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .callTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build(),
) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val _provider = MutableStateFlow(keyStore.provider?.let { n -> AiProvider.entries.firstOrNull { it.name == n } })
    val provider: StateFlow<AiProvider?> = _provider

    private val _models = MutableStateFlow(keyStore.models)
    val models: StateFlow<List<String>> = _models

    private val _activeModel = MutableStateFlow(keyStore.chosenModel ?: keyStore.models.firstOrNull())
    val activeModel: StateFlow<String?> = _activeModel

    fun chooseModel(model: String?) {
        keyStore.chosenModel = model
        _activeModel.value = model ?: keyStore.models.firstOrNull()
    }

    /** Detects the provider and lists usable models. Works with any supported key. */
    suspend fun refreshModels(keyOverride: String? = null): Result<Verified> = runCatching {
        val key = keyOverride ?: keyStore.apiKey ?: throw GeminiException.MissingKey
        val guessed = AiProvider.guess(key)
        val candidates = if (guessed != null) listOf(guessed) else AiProvider.entries.toList()
        var rejected: GeminiException.Http? = null
        var found: Verified? = null
        for (p in candidates) {
            try {
                val list = listModels(p, key)
                if (list.isNotEmpty()) { found = Verified(p, list); break }
            } catch (e: GeminiException.Http) {
                if (guessed != null) throw e
                rejected = e
            } catch (e: java.io.IOException) {
                if (guessed != null) throw e
            } catch (e: IllegalArgumentException) {
                if (guessed != null) throw e
            }
        }
        val verified = found ?: throw (rejected ?: GeminiException.Http(404, "Für diesen Schlüssel wurden keine Modelle gefunden."))
        if (keyOverride == null) apply(verified)
        verified
    }

    fun apply(v: Verified) {
        keyStore.provider = v.provider.name
        keyStore.models = v.models
        _provider.value = v.provider
        _models.value = v.models
        val chosen = keyStore.chosenModel
        if (chosen != null && chosen !in v.models) keyStore.chosenModel = null
        _activeModel.value = keyStore.chosenModel ?: v.models.firstOrNull()
    }

    suspend fun validateKey(key: String): Result<Verified> = refreshModels(key)

    /* ───────────────────────── tasks ───────────────────────── */

    suspend fun extractVocabulary(
        images: List<ByteArray>,
        sourceLangName: String,
        targetLangName: String,
        context: String,
        progress: Progress = Progress(),
    ): Result<List<VocabPair>> = runCatching {
        val general = sourceLangName.isBlank()
        val job = if (general) """
            The image(s) show learning material: notes, a textbook or slide page, a printed text or a list.
            Turn the content into flashcards. "source" = the question, "target" = the short correct answer.
            - If the page already contains questions with answers, copy them.
            - If it is running text or notes, write good questions about the important facts, definitions and terms. Answers must be short and precise.
            - One fact per card. No duplicates. Use the language of the material unless told otherwise.
        """ else """
            The image(s) show a vocabulary list, a textbook page, notes or a running text.
            Create vocabulary cards: "source" in $sourceLangName, "target" in $targetLangName.
            - If it is a vocabulary list: extract every entry (translate the missing side if only one language is visible).
            - If it is running text (article, story, dialogue, exercise): pick the useful words and phrases a learner should study
              (nouns with article, verbs in infinitive form, expressions) – up to about 30 entries – and translate them.
            - Skip headings, page numbers, names and duplicates. Keep articles/gender. Fix obvious OCR typos.
        """
        val prompt = """
            ${job.trimIndent()}
            ${context}
            Always return at least the entries you can find. Do not add example sentences.
            $JSON_RULE
        """.trimIndent()
        finishPairs(execute(Task(prompt, images, 0.2, json = true), progress), progress)
    }

    suspend fun generateVocabulary(
        topic: String,
        sourceLangName: String,
        targetLangName: String,
        count: Int,
        level: String,
        context: String,
        progress: Progress = Progress(),
    ): Result<List<VocabPair>> = runCatching {
        val general = sourceLangName.isBlank()
        val prompt = if (general) """
            Create exactly $count flashcards about: "$topic". Difficulty: $level.
            "source" = a clear question, "target" = the short, correct answer (a few words or one sentence).
            One fact per card, no duplicates, no trick questions, answers must be factually correct.
            $context
            $JSON_RULE
        """.trimIndent() else """
            Vocabulary list for a language learner. Topic: "$topic". Level: $level. Exactly $count entries.
            "source" = word or phrase in $sourceLangName, "target" = translation in $targetLangName.
            Nouns with article. Common, useful words only. No duplicates. No example sentences.
            $context
            $JSON_RULE
        """.trimIndent()
        finishPairs(execute(Task(prompt, emptyList(), 0.5, json = true), progress), progress)
    }

    suspend fun generateMnemonic(
        source: String, sourceLangName: String,
        target: String, targetLangName: String,
        explanationLang: String = "German",
    ): Result<String> = runCatching {
        val prompt = if (sourceLangName.isBlank()) """
            You are a witty memory coach. Invent ONE vivid mnemonic (a short memory aid) that helps remember
            the answer "$target" to the flashcard question "$source". Max. 2 short sentences.
            Write in $explanationLang. Return only the mnemonic text.
        """.trimIndent() else """
            You are a witty memory coach. Invent ONE vivid, funny mnemonic (an "Eselsbrücke")
            that links the $sourceLangName word "$source" with its $targetLangName translation "$target".
            Use sound-alikes, an absurd mental image or a mini story. Max. 2 short sentences.
            Write the explanation in $explanationLang, but keep both vocabulary words in their original language.
            Return only the mnemonic text.
        """.trimIndent()
        execute(Task(prompt, emptyList(), 1.0, json = false), Progress()).trim()
    }

    /* ───────────────────────── core ───────────────────────── */

    private class Task(val prompt: String, val images: List<ByteArray>, val temperature: Double, val json: Boolean)

    private suspend fun execute(task: Task, progress: Progress): String {
        val key = keyStore.apiKey ?: throw GeminiException.MissingKey
        var found = _provider.value
        var available = keyStore.models
        if (found == null || available.isEmpty()) {
            val v = refreshModels().getOrThrow()
            found = v.provider
            available = v.models
        }
        val provider: AiProvider = found ?: throw GeminiException.MissingKey
        val wantImages = task.images.isNotEmpty()
        var order = (listOfNotNull(keyStore.chosenModel) + available).distinct()
        if (wantImages) {
            val capable = order.filter { supportsVision(provider, it) }
            if (capable.isNotEmpty()) order = capable
            // lite models read text from photos less reliably – try them last
            order = order.sortedBy { "lite" in it || "nano" in it }
        }
        order = order.take(4)
        var last: GeminiException? = null
        var emitted = 0
        var first = true
        val onText: (String) -> Unit = { text ->
            if (first) { first = false; progress.onFirstText() }
            if (task.json) {
                val pairs = extractPairs(text)
                while (emitted < pairs.size) progress.onPair(pairs[emitted++])
            }
        }
        for (m in order) {
            try {
                progress.onModel(m)
                val text = when (provider) {
                    AiProvider.Gemini -> callGemini(m, key, task, onText)
                    AiProvider.Anthropic -> callAnthropic(m, key, task, onText)
                    else -> callOpenAiCompatible(provider, m, key, task, onText)
                }
                _activeModel.value = m
                return text
            } catch (e: GeminiException.Http) {
                if (e.code == 401 || e.code == 403) throw e
                last = e // 400 (unsupported model/feature), 404, 429, 5xx -> try next model
            }
        }
        throw last ?: GeminiException.EmptyAnswer
    }

    private fun supportsVision(p: AiProvider, m: String): Boolean = when (p) {
        AiProvider.Gemini, AiProvider.Anthropic, AiProvider.OpenRouter -> true
        AiProvider.OpenAi -> listOf("gpt-4o", "gpt-4.1", "gpt-4.5", "gpt-5", "gpt-4-turbo", "o1", "o3", "o4").any { m.startsWith(it) }
        AiProvider.Groq -> "llama-4" in m || "vision" in m
        AiProvider.XAi -> "vision" in m || Regex("grok-[4-9]").containsMatchIn(m)
    }

    /* ── Gemini ── */

    private val vocabSchema: JsonElement = Json.parseToJsonElement(
        """{"type":"OBJECT","properties":{"pairs":{"type":"ARRAY","items":{"type":"OBJECT",
        "properties":{"source":{"type":"STRING"},"target":{"type":"STRING"},"example":{"type":"STRING"}},
        "required":["source","target"]}}},"required":["pairs"]}""",
    )

    private suspend fun callGemini(model: String, key: String, task: Task, onText: (String) -> Unit): String {
        fun body(noThinking: Boolean) = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject {
                    putJsonArray("parts") {
                        task.images.forEach { img ->
                            addJsonObject {
                                putJsonObject("inline_data") {
                                    put("mime_type", "image/jpeg")
                                    put("data", Base64.encodeToString(img, Base64.NO_WRAP))
                                }
                            }
                        }
                        addJsonObject { put("text", task.prompt) }
                    }
                }
            }
            putJsonObject("generationConfig") {
                put("temperature", task.temperature)
                if (task.json) {
                    put("responseMimeType", "application/json")
                    put("responseSchema", vocabSchema)
                }
                if (noThinking) putJsonObject("thinkingConfig") {
                    if ("gemini-3" in model) put("thinkingLevel", "low") else put("thinkingBudget", 0)
                }
            }
        }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
        val headers = mapOf("x-goog-api-key" to key)
        val fast = ("2.5" in model && "pro" !in model) || "gemini-3" in model
        val pick: (JsonObject) -> String? = { o ->
            o["candidates"]?.jsonArray?.firstOrNull()?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray
                ?.filter { it.jsonObject["thought"]?.jsonPrimitive?.contentOrNull != "true" }
                ?.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }
                ?.joinToString("")
        }
        return try {
            stream(url, headers, body(fast), pick, onText)
        } catch (e: GeminiException.Http) {
            if (fast && e.code == 400) stream(url, headers, body(false), pick, onText) else throw e
        }
    }

    /* ── OpenAI, OpenRouter, Groq, xAI (same chat format) ── */

    private fun baseUrl(p: AiProvider) = when (p) {
        AiProvider.OpenAi -> "https://api.openai.com/v1"
        AiProvider.OpenRouter -> "https://openrouter.ai/api/v1"
        AiProvider.Groq -> "https://api.groq.com/openai/v1"
        AiProvider.XAi -> "https://api.x.ai/v1"
        else -> error("not openai compatible")
    }

    private suspend fun callOpenAiCompatible(p: AiProvider, model: String, key: String, task: Task, onText: (String) -> Unit): String {
        val body = buildJsonObject {
            put("model", model)
            put("stream", true)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    if (task.images.isEmpty()) {
                        put("content", task.prompt)
                    } else {
                        putJsonArray("content") {
                            addJsonObject { put("type", "text"); put("text", task.prompt) }
                            task.images.forEach { img ->
                                addJsonObject {
                                    put("type", "image_url")
                                    putJsonObject("image_url") {
                                        put("url", "data:image/jpeg;base64," + Base64.encodeToString(img, Base64.NO_WRAP))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return stream(
            baseUrl(p) + "/chat/completions",
            mapOf("Authorization" to "Bearer $key"),
            body,
            { o -> o["choices"]?.jsonArray?.firstOrNull()?.jsonObject?.get("delta")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull },
            onText,
        )
    }

    /* ── Anthropic ── */

    private suspend fun callAnthropic(model: String, key: String, task: Task, onText: (String) -> Unit): String {
        val body = buildJsonObject {
            put("model", model)
            put("max_tokens", 4096)
            put("stream", true)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    putJsonArray("content") {
                        task.images.forEach { img ->
                            addJsonObject {
                                put("type", "image")
                                putJsonObject("source") {
                                    put("type", "base64")
                                    put("media_type", "image/jpeg")
                                    put("data", Base64.encodeToString(img, Base64.NO_WRAP))
                                }
                            }
                        }
                        addJsonObject { put("type", "text"); put("text", task.prompt) }
                    }
                }
            }
        }
        return stream(
            "https://api.anthropic.com/v1/messages",
            anthropicHeaders(key),
            body,
            { o -> o["delta"]?.jsonObject?.get("text")?.jsonPrimitive?.contentOrNull },
            onText,
        )
    }

    private fun anthropicHeaders(key: String) = mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")

    /* ── model lists ── */

    private suspend fun listModels(p: AiProvider, key: String): List<String> = when (p) {
        AiProvider.Gemini -> {
            val root = get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000", mapOf("x-goog-api-key" to key))
            val names = root.obj("models")?.jsonArray.orEmpty().filter { m ->
                m.jsonObject["supportedGenerationMethods"]?.jsonArray?.any { it.jsonPrimitive.contentOrNull == "generateContent" } == true
            }.mapNotNull { it.jsonObject["name"]?.jsonPrimitive?.contentOrNull?.removePrefix("models/") }
            rankGemini(names)
        }
        AiProvider.Anthropic -> {
            val root = get("https://api.anthropic.com/v1/models?limit=100", anthropicHeaders(key))
            rankClaude(root.ids())
        }
        AiProvider.OpenRouter -> {
            // /key checks the key itself; /models is public
            get("https://openrouter.ai/api/v1/key", mapOf("Authorization" to "Bearer $key"))
            rankOpenRouter(get("https://openrouter.ai/api/v1/models", emptyMap()).ids())
        }
        AiProvider.OpenAi -> rankOpenAi(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
        AiProvider.Groq -> rankGroq(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
        AiProvider.XAi -> rankXai(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
    }

    private fun JsonElement.ids(): List<String> =
        obj("data")?.jsonArray.orEmpty().mapNotNull { it.jsonObject["id"]?.jsonPrimitive?.contentOrNull }

    /* ── http ── */

    private suspend fun get(url: String, headers: Map<String, String>): JsonElement = send(url, headers, null)
    private suspend fun post(url: String, headers: Map<String, String>, body: JsonObject): JsonElement = send(url, headers, body)

    private suspend fun send(url: String, headers: Map<String, String>, body: JsonObject?): JsonElement =
        withContext(Dispatchers.IO) {
            val builder = Request.Builder().url(url)
            headers.forEach { (k, v) -> builder.header(k, v) }
            if (body != null) builder.post(body.toString().toRequestBody("application/json".toMediaType())) else builder.get()
            http.newCall(builder.build()).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    val detail = runCatching {
                        val e = json.parseToJsonElement(raw).jsonObject["error"]
                        (e as? JsonObject)?.get("message")?.jsonPrimitive?.contentOrNull ?: (e as? JsonPrimitive)?.contentOrNull
                    }.getOrNull()
                    throw GeminiException.Http(res.code, (detail ?: res.message).take(300))
                }
                json.parseToJsonElement(raw)
            }
        }

    private suspend fun stream(
        url: String,
        headers: Map<String, String>,
        body: JsonObject,
        pick: (JsonObject) -> String?,
        onText: (String) -> Unit,
    ): String = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        builder.post(body.toString().toRequestBody("application/json".toMediaType()))
        http.newCall(builder.build()).execute().use { res ->
            if (!res.isSuccessful) {
                val raw = res.body?.string().orEmpty()
                val detail = runCatching {
                    val e = json.parseToJsonElement(raw).jsonObject["error"]
                    (e as? JsonObject)?.get("message")?.jsonPrimitive?.contentOrNull ?: (e as? JsonPrimitive)?.contentOrNull
                }.getOrNull()
                throw GeminiException.Http(res.code, (detail ?: res.message).take(300))
            }
            val source = res.body?.source() ?: throw GeminiException.EmptyAnswer
            val sb = StringBuilder()
            while (true) {
                currentCoroutineContext().ensureActive()
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val payload = line.removePrefix("data:").trim()
                if (payload.isEmpty() || payload == "[DONE]") continue
                val obj = runCatching { json.parseToJsonElement(payload).jsonObject }.getOrNull() ?: continue
                val piece = pick(obj)
                if (!piece.isNullOrEmpty()) {
                    sb.append(piece)
                    onText(sb.toString())
                }
            }
            sb.toString().takeIf { it.isNotBlank() } ?: throw GeminiException.EmptyAnswer
        }
    }

    /** Complete {"source":..,"target":..} objects found so far in a partial JSON answer. */
    private fun extractPairs(text: String): List<VocabPair> =
        Regex("\\{[^{}]*\\}").findAll(text).mapNotNull { m ->
            runCatching { json.decodeFromString<VocabPair>(m.value) }.getOrNull()
        }.filter { it.source.isNotBlank() && it.target.isNotBlank() }.toList()

    private fun finishPairs(raw: String, progress: Progress): List<VocabPair> =
        parsePairs(raw).ifEmpty { throw GeminiException.NoResult(raw) }

    private fun JsonElement.obj(name: String): JsonElement? = (this as? JsonObject)?.get(name)

    private fun parsePairs(raw: String): List<VocabPair> {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) throw GeminiException.NoResult(raw)
        val parsed = runCatching { json.decodeFromString<VocabResponse>(raw.substring(start, end + 1)).pairs }
            .getOrElse { extractPairs(raw) }
        return parsed
            .map { VocabPair(it.source.trim(), it.target.trim(), it.example?.trim()?.takeIf { e -> e.isNotEmpty() }) }
            .filter { it.source.isNotEmpty() && it.target.isNotEmpty() }
            .distinctBy { it.source.lowercase() to it.target.lowercase() }
    }

    private companion object {
        const val JSON_RULE = """Answer with ONLY a JSON object, no markdown: {"pairs":[{"source":"...","target":"...","example":"..."}]}"""
    }
}

/* ───────────────────────── ranking: newest generation first, fast tiers first ───────────────────────── */

private fun num(regex: String, s: String): Double =
    Regex(regex).find(s)?.groupValues?.drop(1)?.filter { it.isNotEmpty() }?.joinToString(".")?.toDoubleOrNull() ?: 0.0

private fun String.isSnapshot() = Regex("-\\d{4}-\\d{2}-\\d{2}$|-\\d{8}$|-\\d{3,4}$").containsMatchIn(this)

private fun rankGemini(names: List<String>): List<String> {
    val bad = listOf("tts", "image", "embedding", "live", "audio", "robotics", "computer", "learnlm", "aqa", "gemma", "imagen", "veo", "native")
    fun tier(n: String) = when { "flash-lite" in n -> 4; "flash" in n -> 3; "pro" in n -> 1; else -> 0 }
    return names.filter { it.startsWith("gemini") && bad.none { b -> b in it } }.distinct()
        .sortedWith(
            compareByDescending<String> { num("gemini-(\\d+)(?:\\.(\\d+))?", it) }
                .thenByDescending { tier(it) }
                .thenByDescending { if (listOf("preview", "exp").any { b -> b in it }) 0 else 1 }
                .thenBy { it },
        )
}

private fun rankClaude(ids: List<String>): List<String> {
    fun tier(n: String) = when { "haiku" in n -> 3; "sonnet" in n -> 2; else -> 1 }
    fun ver(n: String): Double {
        val m = Regex("claude-(?:haiku|sonnet|opus)-(\\d+)(?:-(\\d{1,2}))?(?!\\d)").find(n)
        if (m != null) return "${m.groupValues[1]}.${m.groupValues[2].ifEmpty { "0" }}".toDouble()
        val old = Regex("claude-(\\d+)(?:-(\\d+))?").find(n)
        return if (old != null) "${old.groupValues[1]}.${old.groupValues[2].ifEmpty { "0" }}".toDouble() else 0.0
    }
    return ids.filter { it.startsWith("claude") }.distinct()
        .sortedWith(compareByDescending<String> { ver(it) }.thenByDescending { tier(it) }.thenBy { it.isSnapshot() }.thenBy { it })
}

private fun rankOpenAi(ids: List<String>): List<String> {
    val bad = listOf("embedding", "tts", "whisper", "audio", "realtime", "image", "transcribe", "moderation", "dall", "search", "instruct", "codex", "davinci", "babbage", "pro", "deep-research", "computer", "omni", "sora", "chat-latest")
    val chat = ids.filter { (it.startsWith("gpt-") || Regex("^o\\d").containsMatchIn(it)) && bad.none { b -> b in it } }.distinct()
    val clean = chat.filterNot { it.isSnapshot() }.ifEmpty { chat }
    fun tier(n: String) = when { "nano" in n -> 1; "mini" in n -> 3; else -> 2 }
    return clean.sortedWith(
        compareByDescending<String> { if (it.startsWith("gpt-")) num("gpt-(\\d+)(?:\\.(\\d+))?", it) else 0.0 }
            .thenByDescending { tier(it) }
            .thenBy { it },
    )
}

private fun rankGroq(ids: List<String>): List<String> {
    val bad = listOf("whisper", "tts", "guard", "playai", "orpheus", "embed")
    val ok = ids.filter { m -> bad.none { it in m } }.distinct()
    return ok.sortedWith(
        compareByDescending<String> { "llama-4" in it }
            .thenByDescending { "llama-3.3" in it }
            .thenByDescending { "versatile" in it }
            .thenBy { it },
    )
}

private fun rankXai(ids: List<String>): List<String> {
    val ok = ids.filter { "grok" in it && "image" !in it && "imagine" !in it }.distinct()
    return ok.sortedWith(
        compareByDescending<String> { num("grok-(\\d+)(?:\\.(\\d+))?", it) }
            .thenByDescending { "fast" in it || "mini" in it }
            .thenBy { it },
    )
}

private fun rankOpenRouter(ids: List<String>): List<String> {
    val prefer = listOf(
        "google/gemini-2.5-flash", "google/gemini-flash", "openai/gpt-4o-mini", "openai/gpt-5-mini",
        "anthropic/claude-haiku", "anthropic/claude-3.5-haiku", "meta-llama/llama-4", "google/gemini-2.0-flash",
    )
    val picked = prefer.flatMap { p -> ids.filter { it.startsWith(p) && !it.endsWith(":free") }.sorted().take(2) }.distinct()
    return picked.ifEmpty { ids.take(12) }
}
