package com.lingosnap.data.remote

import android.util.Base64
import com.lingosnap.data.SecureKeyStore
import com.lingosnap.util.Lang
import com.lingosnap.util.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
data class VocabResponse(val pairs: List<VocabPair> = emptyList())

@Serializable
data class VocabPair(
    val source: String,
    val target: String,
    val example: String? = null,
    val lang: String? = null,
    /** From the AI: [image number (1-based), x, y, width, height] of a picture belonging to this card, as fractions of that image. */
    val figure: List<Float>? = null,
    /** Local path of a picture cut out of the scan (set by the app, never by the AI). */
    val image: String? = null,
)

sealed class GeminiException(message: String) : Exception(message) {
    data object MissingKey : GeminiException(tr("Kein API-Schlüssel hinterlegt. Trage ihn unter Optionen ein."))
    data object EmptyAnswer : GeminiException(tr("Die KI hat keine Antwort geliefert. Versuche es noch einmal."))
    class NoResult(raw: String) : GeminiException(
        tr("Es wurden keine Einträge erkannt.") + if (raw.isBlank()) "" else tr(" Antwort der KI: {0}", raw.trim().take(160)),
    )
    /** The provider could not be reached at all (offline, DNS, VPN, wrong clock, timeout). */
    class Network(val detail: String) : GeminiException(
        tr("Keine Verbindung zum KI-Anbieter. Prüfe Internet, VPN, Datum und Uhrzeit. ({0})", detail),
    )
    class Http(val code: Int, val detail: String) : GeminiException(
        when (code) {
            401, 403 -> tr("Der API-Schlüssel wurde abgelehnt. ({0})", detail)
            400 -> if (Regex("api key|API_KEY|key not valid", RegexOption.IGNORE_CASE).containsMatchIn(detail)) tr("Der API-Schlüssel wurde abgelehnt. ({0})", detail)
                else tr("Fehler {0}: {1}", code, detail)
            429 -> when {
                Regex("PerDay|per day|daily", RegexOption.IGNORE_CASE).containsMatchIn(detail) ->
                    tr("Das Tageslimit deines Schlüssels ist aufgebraucht. Es wird im Lauf des Tages zurückgesetzt, oder du hinterlegst unter KI-Einstellungen einen Reserve-Schlüssel. ({0})", detail)
                Regex("PerMinute|per minute", RegexOption.IGNORE_CASE).containsMatchIn(detail) ->
                    tr("Das Minutenlimit wurde erreicht. Warte eine Minute und versuche es noch einmal. ({0})", detail)
                else -> tr("Zu viele Anfragen oder Limit erreicht. Warte kurz oder nimm weniger Seiten auf einmal. ({0})", detail)
            }
            else -> tr("Fehler {0}: {1}", code, detail)
        },
    )
}

/** Which service a key belongs to – detected automatically from the key itself. */
enum class AiProvider(val label: String) {
    Gemini("Google Gemini"),
    OpenAi("OpenAI"),
    Anthropic("Anthropic Claude"),
    OpenRouter("OpenRouter"),
    Groq("Groq"),
    XAi("xAI Grok");

    companion object {
        /** Best guess from the key prefix; null = unknown (all providers are tried). */
        fun guess(key: String): AiProvider? = when {
            key.startsWith("AIza") -> Gemini
            key.startsWith("sk-ant-") -> Anthropic
            key.startsWith("sk-or-") -> OpenRouter
            key.startsWith("gsk_") -> Groq
            key.startsWith("xai-") -> XAi
            key.startsWith("sk-") -> OpenAi
            else -> null
        }
    }
}

/** Live callbacks while the AI answers (all optional). */
class Progress(
    val onModel: (String) -> Unit = {},
    val onFirstText: () -> Unit = {},
    val onPair: (VocabPair) -> Unit = {},
    /** Called when the provider's rate limit was hit and we wait [seconds] before trying again. */
    val onWait: (Int) -> Unit = {},
    /** The answer so far (grows while it streams in). */
    val onPartial: (String) -> Unit = {},
    /** A model gave up (model name, short reason): the next one is tried. */
    val onFailed: (String, String) -> Unit = { _, _ -> },
)

/** Result of a successful key check. */
data class Verified(val provider: AiProvider, val models: List<String>)

/**
 * Talks to Gemini, OpenAI, Claude, OpenRouter, Groq or Grok – whichever the pasted key belongs to.
 * The key is only ever sent as a header, never inside a URL.
 */
class GeminiClient(
    private val keyStore: SecureKeyStore,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .callTimeout(240, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        // IPv4 first (a broken IPv6 route otherwise stalls every request) and plain HTTP/1.1, which is the most robust for streaming
        .dns(object : okhttp3.Dns {
            override fun lookup(hostname: String) = okhttp3.Dns.SYSTEM.lookup(hostname).sortedBy { it is java.net.Inet6Address }
        })
        .protocols(listOf(okhttp3.Protocol.HTTP_1_1))
        .build(),
) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /** Checks (key and model list) must answer fast: short timeouts. */
    private val checkHttp: OkHttpClient = http.newBuilder()
        .connectTimeout(8, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).callTimeout(20, TimeUnit.SECONDS).build()

    init { keyStore.chosenModel = null } // the model is always picked automatically

    private val _provider = MutableStateFlow(keyStore.provider?.let { n -> AiProvider.entries.firstOrNull { it.name == n } })
    val provider: StateFlow<AiProvider?> = _provider

    private val _models = MutableStateFlow(keyStore.models)
    val models: StateFlow<List<String>> = _models

    private val _activeModel = MutableStateFlow(keyStore.chosenModel ?: keyStore.models.firstOrNull())
    val activeModel: StateFlow<String?> = _activeModel

    fun chooseModel(model: String?) {
        keyStore.chosenModel = model
        _activeModel.value = model ?: keyStore.models.firstOrNull()
    }

    /** Detects the provider and lists usable models. Works with any supported key. */
    suspend fun refreshModels(keyOverride: String? = null): Result<Verified> = runCatching {
        kotlinx.coroutines.withTimeoutOrNull(30_000) { refreshModelsRaw(keyOverride).getOrThrow() }
            ?: throw GeminiException.Network(tr("Zeitüberschreitung"))
    }

    private suspend fun refreshModelsRaw(keyOverride: String?): Result<Verified> = runCatching {
        val key = cleanKey(keyOverride ?: keyStore.apiKey ?: throw GeminiException.MissingKey)
        val guessed = AiProvider.guess(key)
        val candidates = if (guessed != null) listOf(guessed) else AiProvider.entries.toList()
        var rejected: GeminiException.Http? = null
        var offline: GeminiException.Network? = null
        var found: Verified? = null
        for (p in candidates) {
            try {
                // one quiet retry: a first request often fails on a flaky connection
                val list = try { listModels(p, key) } catch (e: java.io.IOException) { currentCoroutineContext().ensureActive(); delay(400); listModels(p, key) }
                if (list.isNotEmpty()) { found = Verified(p, list); break }
                // accepted, but no model matched our filter: use the provider's standard models instead of failing
                found = Verified(p, defaultModels(p)); break
            } catch (e: GeminiException.Http) {
                if (guessed != null) throw e
                rejected = e
            } catch (e: java.io.IOException) {
                val n = GeminiException.Network(netDetail(e))
                if (guessed != null) throw n
                offline = n
            } catch (e: IllegalArgumentException) {
                if (guessed != null) throw e
            } catch (e: kotlinx.serialization.SerializationException) {
                if (guessed != null) throw GeminiException.Http(502, tr("Unerwartete Antwort des Anbieters"))
            }
        }
        val verified = found ?: throw (rejected ?: offline ?: GeminiException.Http(404, tr("Für diesen Schlüssel wurden keine Modelle gefunden.")))
        if (keyOverride == null) apply(verified)
        verified
    }

    fun apply(v: Verified) {
        keyStore.provider = v.provider.name
        keyStore.models = v.models
        _provider.value = v.provider
        _models.value = v.models
        keyStore.chosenModel = null
        _activeModel.value = keyStore.chosenModel ?: v.models.firstOrNull()
    }

    /** Saves (or, with null, removes) the reserve key after checking it. */
    suspend fun setBackupKey(key: String?): Result<Verified?> = runCatching {
        if (key.isNullOrBlank()) {
            keyStore.backupKey = null; keyStore.backupProvider = null; keyStore.backupModels = emptyList()
            return@runCatching null
        }
        val v = refreshModels(key.trim()).getOrThrow()
        keyStore.backupKey = cleanKey(key); keyStore.backupProvider = v.provider.name; keyStore.backupModels = v.models
        v
    }

    suspend fun validateKey(key: String): Result<Verified> = refreshModels(key)

    /* ───────────────────────── tasks ───────────────────────── */

    /**
     * The file recognition of the web app, one request: a block of text, a photo, or a scanned PDF.
     * Model cascade (flash-lite, pro-preview, flash) as long as no model returns valid cards; the second API takes over on overload (see [execute]).
     */
    suspend fun recognize(
        text: String,
        pdf: (suspend () -> ByteArray)?,
        images: (suspend () -> List<ByteArray>)?,
        sourceLangName: String,
        targetLangName: String,
        progress: Progress = Progress(),
    ): Result<List<VocabPair>> = runCatching {
        val auto = sourceLangName.isBlank() || sourceLangName == "AUTO"
        val prompt = buildString {
            append(EXHAUSTIVE_SYSTEM_PROMPT)
            append("\n\n")
            append(if (auto) "The language being learned: detect it yourself. " else "The language being learned (front side): $sourceLangName. ")
            append("Translation language (back side): ${targetLangName.ifBlank { Lang.aiName }}.\n")
            append(if (auto) RECOGNIZE_JSON_AUTO else RECOGNIZE_JSON)
            if (text.isNotBlank()) append("\n\nMATERIAL TEXT:\n").append(text)
        }
        val inline = pdf?.let { listOf("application/pdf" to it()) }.orEmpty()
        val task = Task(
            prompt, emptyList(), 0.1, json = true, fast = true,
            inline = inline, lazyImages = images, stream = false, maxOutput = 8192,
            // only an answer with at least one valid card counts; otherwise the next model is asked
            accept = { CardParser.parse(it).isNotEmpty() },
        )
        finishPairs(execute(task, progress), progress)
    }

    /** Short search terms for an encyclopedia picture that fits a card. */
    suspend fun imageQueries(question: String, answer: String): Result<List<String>> = runCatching {
        val prompt = """
            Flashcard. Question: "$question" Answer: "$answer"
            Give 3 short search terms in ${Lang.aiName} (1-3 words each, the most specific first) that would find a fitting, clear encyclopedia picture
            (a photo, diagram or map that shows what this card is about). Answer with ONLY a JSON array of strings.
        """.trimIndent()
        val raw = execute(Task(prompt, emptyList(), 0.2, json = false), Progress())
        val start = raw.indexOf('[')
        val end = raw.lastIndexOf(']')
        if (start < 0 || end <= start) emptyList()
        else json.parseToJsonElement(raw.substring(start, end + 1)).jsonArray
            .mapNotNull { it.jsonPrimitive.contentOrNull?.trim()?.takeIf { t -> t.isNotEmpty() } }.take(3)
    }

    suspend fun generateVocabulary(
        topic: String,
        sourceLangName: String,
        targetLangName: String,
        count: Int,
        level: String,
        context: String,
        progress: Progress = Progress(),
    ): Result<List<VocabPair>> = runCatching {
        val general = sourceLangName.isBlank()
        val prompt = if (general) """
            Create exactly $count flashcards about: "$topic".${if (level.isBlank()) "" else " Difficulty: $level."}
            "source" = a clear question, "target" = the short, correct answer (a few words or one sentence).
            One fact per card (minimum information principle), no duplicates, no trick questions, answers must be factually correct.
            Each question is specific and understandable on its own, no yes/no questions. Mix definitions with "why"/"how" questions,
            causes and effects and short applications, so that learning needs real recall. Answers under 15 words.
            "example" = ONE short sentence that explains why the answer is true or gives a concrete example.
            $context
            $JSON_RULE
        """.trimIndent() else """
            Vocabulary list for a language learner. Topic: "$topic".${if (level.isBlank()) "" else " Level: $level."} Exactly $count entries.
            "source" = word or phrase in ${if (sourceLangName == "AUTO") "the language named in the topic or instructions (default: English)" else sourceLangName},
            "target" = translation in $targetLangName. "lang" = ISO 639-1 code of the source language.
            Nouns with article. Prefer the most frequent, most useful words for this topic (frequency matters more than rarity).
            Where natural, use common collocations and fixed phrases as one entry (e.g. "make a decision") besides single words. No duplicates.
            "example" = one short, natural sentence (max. 12 words) in the source language that uses the word in a typical context.
            $context
            $JSON_RULE_LANG
        """.trimIndent()
        finishPairs(execute(Task(prompt, emptyList(), 0.5, json = true), progress), progress)
    }

    suspend fun generateMnemonic(
        source: String, sourceLangName: String,
        target: String, targetLangName: String,
        explanationLang: String = Lang.aiName,
    ): Result<String> = runCatching {
        val prompt = if (sourceLangName.isBlank()) """
            You are a witty memory coach. Invent ONE vivid mnemonic (a short memory aid) that helps remember
            the answer "$target" to the flashcard question "$source". Max. 2 short sentences.
            Write in $explanationLang. Return only the mnemonic text.
        """.trimIndent() else """
            You are a witty memory coach. Invent ONE vivid, funny mnemonic (an "Eselsbrücke")
            that links the $sourceLangName word "$source" with its $targetLangName translation "$target".
            Use sound-alikes, an absurd mental image or a mini story. Max. 2 short sentences.
            Write the explanation in $explanationLang, but keep both vocabulary words in their original language.
            Return only the mnemonic text.
        """.trimIndent()
        execute(Task(prompt, emptyList(), 1.0, json = false), Progress()).trim()
    }

    /** Example sentences and mnemonics for many cards with ONE request (see [CardHelp]). */
    suspend fun generateHelp(items: List<HelpItem>): Result<List<HelpResult>> = runCatching {
        if (items.isEmpty()) return@runCatching emptyList()
        val raw = execute(Task(CardHelp.prompt(items, Lang.aiName), emptyList(), 0.8, json = false, fast = true), Progress())
        CardHelp.parse(raw).ifEmpty { throw GeminiException.NoResult(raw) }
    }

    /** One short example sentence (in the source language) for a card that has none yet. */
    suspend fun generateExample(
        source: String, sourceLangName: String, target: String, targetLangName: String,
    ): Result<String> = runCatching {
        val prompt = if (sourceLangName.isBlank()) """
            Flashcard question: "$source" – answer: "$target".
            Explain in ${Lang.aiName}, in at most 2 short sentences, why this answer is correct or what is behind it,
            so that it is easier to understand and remember. Do not repeat the question. Return only the explanation.
        """.trimIndent() else """
            Write ONE short, natural example sentence (max. 12 words) in $sourceLangName that uses "$source" (meaning: "$target" in $targetLangName).
            Return only the sentence, no translation, no quotes.
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.7, json = false), Progress()).trim().trim('"')
    }

    /** Answers a learner's question about one card; [history] = earlier turns (true = learner). */
    suspend fun chatAbout(
        source: String, target: String, languageName: String,
        history: List<Pair<Boolean, String>>, question: String,
        onPartial: (String) -> Unit = {},
    ): Result<String> = runCatching {
        val topic = if (languageName.isBlank()) "Flashcard: question \"$source\" – answer \"$target\"."
        else "Vocabulary card ($languageName): \"$source\" = \"$target\"."
        val talk = history.joinToString("\n") { (user, text) -> (if (user) "Learner: " else "Tutor: ") + text }
        val prompt = """
            You are a friendly, precise tutor in the LingoSnap app. $topic
            Answer the learner's question in ${Lang.aiName}, concrete and short (max. 120 words). Use $languageName examples where useful.
            ${if (talk.isNotBlank()) "Conversation so far:\n$talk" else ""}
            Learner: $question
            Tutor:
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.5, json = false, urgent = true), Progress(onPartial = onPartial)).trim()
    }

    /** Free chat (no card): learning tips and help with the app. */
    suspend fun chatGeneral(history: List<Pair<Boolean, String>>, question: String, onPartial: (String) -> Unit = {}): Result<String> = runCatching {
        val talk = history.joinToString("\n") { (user, text) -> (if (user) "User: " else "Assistant: ") + text }
        val prompt = """
            You are the friendly learning assistant of the flashcard app LingoSnap.
            The app can: create decks (vocabulary or flashcards) by typing, scanning photos or files, or with AI; learn with flashcards, multiple choice, writing, cloze and listening/speaking; spaced repetition; statistics, streaks and XP.
            Answer in ${Lang.aiName}, warm, short (max. 80 words), no emojis. Help with learning and with the app. If asked something unrelated, answer briefly and steer back to learning.
            ${if (talk.isNotBlank()) "Conversation so far:\n$talk" else ""}
            User: $question
            Assistant:
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.6, json = false, urgent = true), Progress(onPartial = onPartial)).trim()
    }

    /** Short daily study plan toward a goal date (plain text in the app language). */
    suspend fun dailyPlan(
        deckName: String, languageName: String, total: Int, remaining: Int, daysLeft: Int,
        newToday: Int, due: Int, words: List<Pair<String, String>>, onPartial: (String) -> Unit = {},
    ): Result<String> = runCatching {
        val list = words.take(40).joinToString("\n") { "- ${it.first} = ${it.second}" }
        val prompt = """
            You are a friendly study coach in a flashcard app. Write today's study plan for the deck "$deckName"${if (languageName.isNotBlank()) " ($languageName vocabulary)" else ""}.
            Facts: $total cards in total, $remaining not mastered yet, $daysLeft day(s) left until the learner's goal date, today: $newToday new cards and $due reviews due.
            ${if (list.isNotBlank()) "Today's new cards:\n$list" else "There are no new cards left to start."}
            Write in ${Lang.aiName}, max. 70 words, no emojis, no markdown: one motivating sentence, then what to do today (new cards first, then reviews), and one short learning tip for these cards.
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.6, json = false, urgent = true), Progress(onPartial = onPartial)).trim()
    }

    /** Short feedback for a sentence the learner wrote with [word]. */
    suspend fun checkSentence(word: String, meaning: String, languageName: String, sentence: String): Result<String> = runCatching {
        val prompt = """
            A learner of $languageName wrote ONE sentence using the word "$word" (meaning: "$meaning"):
            "$sentence"
            Answer in ${Lang.aiName}, max. 60 words, in exactly three lines. Each line starts with its label, translated into ${Lang.aiName}:
            Verdict: <correct / almost correct / has mistakes> – <one short reason>
            Better: <the corrected or improved sentence in $languageName>
            Tip: <one short tip on usage of "$word">
        """.trimIndent()
        execute(Task(prompt, emptyList(), 0.3, json = false), Progress()).trim()
    }

    /* ───────────────────────── core ───────────────────────── */

    /** At most three requests at the same time and at least ~0.7 s between two request starts: keeps free-tier keys from running dry. */
    private val gate = Semaphore(4)
    private val spacing = Mutex()
    private var lastStart = 0L
    /** Pause before each request start. Grows after a rate limit, shrinks again while all goes well. */
    @Volatile private var gap = 400L

    private suspend fun <T> throttled(block: suspend () -> T): T = gate.withPermit {
        spacing.withLock {
            val wait = lastStart + gap - System.currentTimeMillis()
            if (wait > 0) delay(wait)
            lastStart = System.currentTimeMillis()
        }
        block()
    }

    /** Time one model gets for a whole answer when it is not streamed (long lists take their time). */
    internal var attemptTimeoutMs = 75_000L

    private class Task(
        val prompt: String,
        val images: List<ByteArray>,
        val temperature: Double,
        val json: Boolean,
        val urgent: Boolean = false,
        val fast: Boolean = false,
        /** Files sent as they are (mime type, bytes), e.g. a scanned PDF. */
        val inline: List<Pair<String, ByteArray>> = emptyList(),
        /** Photos for providers that cannot read [inline] files (loaded only when needed). */
        val lazyImages: (suspend () -> List<ByteArray>)? = null,
        /** false = one answer at the end (like the web app's server), true = the answer streams in. */
        val stream: Boolean = true,
        val maxOutput: Int = 0,
        /** An answer is only accepted if this returns true; otherwise the next model is asked. */
        val accept: ((String) -> Boolean)? = null,
    ) {
        val hasFiles get() = images.isNotEmpty() || inline.isNotEmpty() || lazyImages != null
        private var loaded: List<ByteArray>? = null
        /** The photos to send: given ones, or loaded now. Providers that read the PDF itself need no photos of it. */
        suspend fun photos(pdfOk: Boolean): List<ByteArray> {
            if (images.isNotEmpty()) return images
            if (pdfOk && inline.isNotEmpty()) return emptyList()
            return loaded ?: lazyImages?.invoke().orEmpty().also { loaded = it }
        }
    }

    private suspend fun execute(task: Task, progress: Progress): String {
        val key = cleanKey(keyStore.apiKey ?: throw GeminiException.MissingKey)
        var found = _provider.value
        var available = keyStore.models
        if (found == null || available.isEmpty()) {
            val v = refreshModels().getOrThrow()
            found = v.provider
            available = v.models
        }
        val provider: AiProvider = found ?: throw GeminiException.MissingKey
        val wantImages = task.hasFiles
        var scanner = CardParser.Stream()
        var first = true
        val onText: (String) -> Unit = { text ->
            if (first) { first = false; progress.onFirstText() }
            progress.onPartial(text)
            // only the new part of the answer is read (see CardParser.Stream)
            if (task.json) scanner.feed(text).forEach { progress.onPair(it) }
        }
        val onAttempt: () -> Unit = { scanner = CardParser.Stream() }
        val order = if (task.urgent) speedOrder((listOfNotNull(keyStore.chosenModel) + available).distinct()).take(3)
        else if (task.fast) cascadeOrder(provider, available, wantImages)
        else modelOrder(provider, available, keyStore.chosenModel, wantImages)
        class Source(val name: String, val provider: AiProvider, val key: String, val order: List<String>, val auth: Boolean)
        val sources = ArrayList<Source>()
        sources += Source("primary", provider, key, order, true)
        // second API: another key or another provider, used when the first one is overloaded, out of quota or down
        val spareKey = keyStore.backupKey
        val spareProvider = keyStore.backupProvider?.let { n -> AiProvider.entries.firstOrNull { it.name == n } }
        if (spareKey != null && spareProvider != null) {
            val spareOrder = if (task.fast) cascadeOrder(spareProvider, keyStore.backupModels, wantImages)
            else modelOrder(spareProvider, keyStore.backupModels, null, wantImages).take(3)
            sources += Source("backup", spareProvider, spareKey, spareOrder, false)
        }
        // circuit breaker: a source that just failed for overload is asked last for the next 60 s
        val now = System.currentTimeMillis()
        val sorted = sources.filter { (cooldownUntil[it.name] ?: 0L) <= now } + sources.filter { (cooldownUntil[it.name] ?: 0L) > now }
        var last: GeminiException? = null
        for (src in sorted) {
            val r = tryModels(src.provider, src.key, src.order, task, progress, onText, failOnAuth = src.auth, onAttempt = onAttempt)
            if (r.text != null) return r.text
            last = r.error ?: last
            if (r.overloaded) cooldownUntil[src.name] = System.currentTimeMillis() + 60_000L
            else {
                // a real mistake in the request (e.g. 400) would fail the same way at the second API: do not loop on
                val e = r.error
                if (e is GeminiException.Http && e.code == 400) throw e
            }
        }
        throw last ?: GeminiException.EmptyAnswer
    }

    private val cooldownUntil = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** For chat: small, fast models first, slow "thinking" models last. */
    private fun speedOrder(order: List<String>): List<String> {
        fun slow(m: String) = listOf("pro", "opus", "thinking", "reason", "o1", "o3", "o4", "deep").any { it in m.lowercase() }
        fun quick(m: String) = listOf("lite", "nano", "mini", "haiku", "flash", "instant", "8b", "small").any { it in m.lowercase() }
        return order.sortedWith(compareBy({ slow(it) }, { !quick(it) }))
    }

    /**
     * Document scans: the model cascade of the web app first (flash-lite, then pro-preview, then flash) as far as the key has these models,
     * then the other quick models; slow thinking models last.
     */
    private fun cascadeOrder(provider: AiProvider, available: List<String>, wantImages: Boolean): List<String> {
        fun id(m: String) = m.removePrefix("models/")
        var rest = available.distinct()
        if (wantImages) {
            val capable = rest.filter { supportsVision(provider, it) }
            if (capable.isNotEmpty()) rest = capable
        }
        fun slow(m: String) = listOf("pro", "opus", "thinking", "reason", "o1", "o3", "o4", "deep").any { it in m.lowercase() }
        rest = rest.sortedBy { slow(it) }
        val preferred = if (provider == AiProvider.Gemini)
            listOf("gemini-3.1-flash-lite", "gemini-3.1-pro-preview", "gemini-3.8-flash").mapNotNull { p -> rest.firstOrNull { id(it) == p } }
        else emptyList()
        return (preferred + rest).distinct().take(3) // the three models of the web app, then give up on this source
    }

    /** Pacing happens before every request (see throttled); a rate limit slows the following requests and tries the next model at once. */
    private fun modelOrder(provider: AiProvider, available: List<String>, chosen: String?, wantImages: Boolean): List<String> {
        var order = (listOfNotNull(chosen) + available).distinct()
        if (wantImages) {
            val capable = order.filter { supportsVision(provider, it) }
            if (capable.isNotEmpty()) order = capable
            // lite models read text from photos less reliably – try them last
            order = order.sortedBy { "lite" in it || "nano" in it }
        }
        return order.take(4)
    }

    private class Attempt(val text: String?, val error: GeminiException?, val overloaded: Boolean)

    private suspend fun tryModels(
        provider: AiProvider, key: String, order: List<String>, task: Task, progress: Progress,
        onText: (String) -> Unit, failOnAuth: Boolean, onAttempt: () -> Unit = {},
    ): Attempt {
        var last: GeminiException? = null
        var overloaded = false
        for (m in order) {
            try {
                progress.onModel(m)
                onAttempt()
                val run: suspend () -> String = {
                    // no first words after 25 s: give up on this model and try the next one
                    val gotText = java.util.concurrent.atomic.AtomicBoolean(false)
                    val watched: (String) -> Unit = { t -> gotText.set(true); onText(t) }
                    coroutineScope {
                        val dog = if (task.urgent) null else launch {
                            // streaming: first words within 25 s; one answer at the end: the whole answer within 75 s (long lists take time)
                            delay(if (task.stream) 25_000L else attemptTimeoutMs)
                            if (!gotText.get()) throw java.io.IOException(tr("Zeitüberschreitung"))
                        }
                        try {
                            when (provider) {
                                AiProvider.Gemini -> callGemini(m, key, task, watched)
                                AiProvider.Anthropic -> callAnthropic(m, key, task, watched)
                                else -> callOpenAiCompatible(provider, m, key, task, watched)
                            }
                        } finally { dog?.cancel() }
                    }
                }
                // a chat message should not queue behind the pacing of bulk jobs
                val text = if (task.urgent) run() else throttled { run() }
                // only an answer with valid cards ends the loop, otherwise the next model is asked
                if (task.accept?.invoke(text) == false) {
                    last = GeminiException.NoResult(text)
                    progress.onFailed(m, tr("keine Einträge erkannt"))
                    continue
                }
                _activeModel.value = m
                gap = maxOf(400L, gap - 200L)
                return Attempt(text, null, false)
            } catch (e: GeminiException.Http) {
                if (failOnAuth && (e.code == 401 || e.code == 403)) throw e
                if (e.code == 429) gap = minOf(maxOf(gap, 800L) * 2, 8000L)
                if (e.code == 429 || e.code in 500..504) overloaded = true
                last = e
                progress.onFailed(m, "HTTP ${e.code}")
            } catch (e: GeminiException.EmptyAnswer) {
                last = e
                progress.onFailed(m, tr("leere Antwort"))
            } catch (e: java.io.IOException) {
                currentCoroutineContext().ensureActive()
                overloaded = true
                last = GeminiException.Network(netDetail(e))
                progress.onFailed(m, e.message?.take(60) ?: tr("keine Verbindung"))
            }
        }
        return Attempt(null, last, overloaded)
    }

    private fun supportsVision(p: AiProvider, m: String): Boolean = when (p) {
        AiProvider.Gemini, AiProvider.Anthropic, AiProvider.OpenRouter -> true
        AiProvider.OpenAi -> listOf("gpt-4o", "gpt-4.1", "gpt-4.5", "gpt-5", "gpt-4-turbo", "o1", "o3", "o4").any { m.startsWith(it) }
        AiProvider.Groq -> "llama-4" in m || "vision" in m
        AiProvider.XAi -> "vision" in m || Regex("grok-[4-9]").containsMatchIn(m)
    }

    /* ── Gemini ── */

    private suspend fun callGemini(model: String, key: String, task: Task, onText: (String) -> Unit): String {
        val files: List<Pair<String, ByteArray>> = task.photos(pdfOk = true).map { "image/jpeg" to it } + task.inline
        fun body(noThinking: Boolean) = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject {
                    putJsonArray("parts") {
                        files.forEach { (mime, bytes) ->
                            addJsonObject {
                                putJsonObject("inline_data") {
                                    put("mime_type", mime)
                                    put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                                }
                            }
                        }
                        addJsonObject { put("text", task.prompt) }
                    }
                }
            }
            putJsonObject("generationConfig") {
                put("temperature", task.temperature)
                if (task.urgent) put("maxOutputTokens", 700) else if (task.maxOutput > 0) put("maxOutputTokens", task.maxOutput)
                if (task.json) {
                    // as in the web app: JSON mode only, no answer schema (a schema makes the first words come later)
                    put("responseMimeType", "application/json")
                }
                if (noThinking) putJsonObject("thinkingConfig") {
                    if ("gemini-3" in model) put("thinkingLevel", "low") else put("thinkingBudget", 0)
                }
            }
        }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:" + if (task.stream) "streamGenerateContent?alt=sse" else "generateContent"
        val headers = mapOf("x-goog-api-key" to key)
        val fast = ("2.5" in model && "pro" !in model) || "gemini-3" in model
        val pick: (JsonObject) -> String? = { o ->
            o["candidates"]?.jsonArray?.firstOrNull()?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray
                ?.filter { it.jsonObject["thought"]?.jsonPrimitive?.contentOrNull != "true" }
                ?.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }
                ?.joinToString("")
        }
        suspend fun run(noThinking: Boolean) =
            if (task.stream) stream(url, headers, body(noThinking), pick, onText) else once(url, headers, body(noThinking), pick, onText)
        return try {
            run(fast)
        } catch (e: GeminiException.Http) {
            if (fast && e.code == 400) run(false) else throw e
        }
    }

    /** One request, one answer at the end (the web app's way). */
    private suspend fun once(url: String, headers: Map<String, String>, body: JsonObject, pick: (JsonObject) -> String?, onText: (String) -> Unit): String {
        val text = (post(url, headers, body) as? JsonObject)?.let(pick)
        if (text.isNullOrBlank()) throw GeminiException.EmptyAnswer
        onText(text)
        return text
    }

    /* ── OpenAI, OpenRouter, Groq, xAI (same chat format) ── */

    private fun baseUrl(p: AiProvider) = when (p) {
        AiProvider.OpenAi -> "https://api.openai.com/v1"
        AiProvider.OpenRouter -> "https://openrouter.ai/api/v1"
        AiProvider.Groq -> "https://api.groq.com/openai/v1"
        AiProvider.XAi -> "https://api.x.ai/v1"
        else -> error("not openai compatible")
    }

    private suspend fun callOpenAiCompatible(p: AiProvider, model: String, key: String, task: Task, onText: (String) -> Unit): String {
        val photos = task.photos(pdfOk = false)
        val body = buildJsonObject {
            put("model", model)
            put("stream", task.stream)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    if (photos.isEmpty()) {
                        put("content", task.prompt)
                    } else {
                        putJsonArray("content") {
                            addJsonObject { put("type", "text"); put("text", task.prompt) }
                            photos.forEach { img ->
                                addJsonObject {
                                    put("type", "image_url")
                                    putJsonObject("image_url") {
                                        put("url", "data:image/jpeg;base64," + Base64.encodeToString(img, Base64.NO_WRAP))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        val url = baseUrl(p) + "/chat/completions"
        val headers = mapOf("Authorization" to "Bearer $key")
        if (!task.stream) return once(url, headers, body, { o ->
            o["choices"]?.jsonArray?.firstOrNull()?.jsonObject?.get("message")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull
        }, onText)
        return stream(
            url, headers, body,
            { o -> o["choices"]?.jsonArray?.firstOrNull()?.jsonObject?.get("delta")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull },
            onText,
        )
    }

    /* ── Anthropic ── */

    private suspend fun callAnthropic(model: String, key: String, task: Task, onText: (String) -> Unit): String {
        val photos = task.photos(pdfOk = true)
        val body = buildJsonObject {
            put("model", model)
            put("max_tokens", 16000)
            put("stream", task.stream)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    putJsonArray("content") {
                        task.inline.forEach { (mime, bytes) ->
                            addJsonObject {
                                put("type", "document")
                                putJsonObject("source") {
                                    put("type", "base64")
                                    put("media_type", mime)
                                    put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                                }
                            }
                        }
                        photos.forEach { img ->
                            addJsonObject {
                                put("type", "image")
                                putJsonObject("source") {
                                    put("type", "base64")
                                    put("media_type", "image/jpeg")
                                    put("data", Base64.encodeToString(img, Base64.NO_WRAP))
                                }
                            }
                        }
                        addJsonObject { put("type", "text"); put("text", task.prompt) }
                    }
                }
            }
        }
        val url = "https://api.anthropic.com/v1/messages"
        if (!task.stream) return once(url, anthropicHeaders(key), body, { o ->
            o["content"]?.jsonArray?.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }?.joinToString("")
        }, onText)
        return stream(
            url, anthropicHeaders(key), body,
            { o -> o["delta"]?.jsonObject?.get("text")?.jsonPrimitive?.contentOrNull },
            onText,
        )
    }

    private fun anthropicHeaders(key: String) = mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")

    /* ── model lists ── */

    private suspend fun listModels(p: AiProvider, key: String): List<String> = when (p) {
        AiProvider.Gemini -> {
            val root = get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", mapOf("x-goog-api-key" to key))
            val names = root.obj("models")?.jsonArray.orEmpty().filter { m ->
                m.jsonObject["supportedGenerationMethods"]?.jsonArray?.any { it.jsonPrimitive.contentOrNull == "generateContent" } == true
            }.mapNotNull { it.jsonObject["name"]?.jsonPrimitive?.contentOrNull?.removePrefix("models/") }
            rankGemini(names)
        }
        AiProvider.Anthropic -> {
            val root = get("https://api.anthropic.com/v1/models?limit=100", anthropicHeaders(key))
            rankClaude(root.ids())
        }
        AiProvider.OpenRouter -> {
            // /key checks the key itself; /models is public
            get("https://openrouter.ai/api/v1/key", mapOf("Authorization" to "Bearer $key"))
            rankOpenRouter(get("https://openrouter.ai/api/v1/models", emptyMap()).ids())
        }
        AiProvider.OpenAi -> rankOpenAi(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
        AiProvider.Groq -> rankGroq(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
        AiProvider.XAi -> rankXai(get(baseUrl(p) + "/models", mapOf("Authorization" to "Bearer $key")).ids())
    }

    private fun JsonElement.ids(): List<String> =
        obj("data")?.jsonArray.orEmpty().mapNotNull { it.jsonObject["id"]?.jsonPrimitive?.contentOrNull }

    /* ── http ── */

    /** Runs the blocking OkHttp call but aborts it as soon as the coroutine is cancelled (so "Abbrechen" works at once). */
    /**
     * Runs the call and reads the answer inside [block]. When the coroutine is cancelled (watchdog, user abort), the call is cancelled at once,
     * also while the body is being read. (Before, only the wait for the first response could be aborted; a stalled stream then
     * blocked until the 60 s read timeout, once per model.)
     */
    private suspend fun <T> okhttp3.Call.executeCancellable(block: suspend (okhttp3.Response) -> T): T = coroutineScope {
        val call = this@executeCancellable
        val killer = launch(Dispatchers.Default) { try { awaitCancellation() } finally { call.cancel() } }
        try { call.execute().use { block(it) } } finally { killer.cancel() }
    }

    private suspend fun get(url: String, headers: Map<String, String>): JsonElement = send(url, headers, null, checkHttp)
    private suspend fun post(url: String, headers: Map<String, String>, body: JsonObject): JsonElement = send(url, headers, body)

    private suspend fun send(url: String, headers: Map<String, String>, body: JsonObject?, client: OkHttpClient = http): JsonElement =
        withContext(Dispatchers.IO) {
            val builder = Request.Builder().url(url)
            headers.forEach { (k, v) -> builder.header(k, v) }
            if (body != null) builder.post(body.toString().toRequestBody("application/json".toMediaType())) else builder.get()
            client.newCall(builder.build()).executeCancellable { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    val detail = runCatching {
                        val e = json.parseToJsonElement(raw).jsonObject["error"]
                        (e as? JsonObject)?.get("message")?.jsonPrimitive?.contentOrNull ?: (e as? JsonPrimitive)?.contentOrNull
                    }.getOrNull()
                    throw GeminiException.Http(res.code, (detail ?: res.message).take(300))
                }
                json.parseToJsonElement(raw)
            }
        }

    private suspend fun stream(
        url: String,
        headers: Map<String, String>,
        body: JsonObject,
        pick: (JsonObject) -> String?,
        onText: (String) -> Unit,
    ): String = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        builder.post(body.toString().toRequestBody("application/json".toMediaType()))
        http.newCall(builder.build()).executeCancellable { res ->
            if (!res.isSuccessful) {
                val raw = res.body?.string().orEmpty()
                val detail = runCatching {
                    val e = json.parseToJsonElement(raw).jsonObject["error"]
                    (e as? JsonObject)?.get("message")?.jsonPrimitive?.contentOrNull ?: (e as? JsonPrimitive)?.contentOrNull
                }.getOrNull()
                throw GeminiException.Http(res.code, (detail ?: res.message).take(300))
            }
            val source = res.body?.source() ?: throw GeminiException.EmptyAnswer
            val sb = StringBuilder()
            while (true) {
                currentCoroutineContext().ensureActive()
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val payload = line.removePrefix("data:").trim()
                if (payload.isEmpty() || payload == "[DONE]") continue
                val obj = runCatching { json.parseToJsonElement(payload).jsonObject }.getOrNull() ?: continue
                val piece = pick(obj)
                if (!piece.isNullOrEmpty()) {
                    sb.append(piece)
                    onText(sb.toString())
                }
            }
            sb.toString().takeIf { it.isNotBlank() } ?: throw GeminiException.EmptyAnswer
        }
    }

    private fun JsonElement.obj(name: String): JsonElement? = (this as? JsonObject)?.get(name)

    private fun finishPairs(raw: String, progress: Progress): List<VocabPair> =
        CardParser.parse(raw).ifEmpty { throw GeminiException.NoResult(raw) }

    private companion object {
        /** The instruction of the web app's file recognition ("EXHAUSTIVE_SYSTEM_PROMPT"). */
        val EXHAUSTIVE_SYSTEM_PROMPT = """
You are an expert vocabulary extraction engine. The material (photo, scan, PDF or the text at the end) contains vocabulary: a word list, a textbook page, handwritten notes, a table or a text.
Your job: capture EVERY vocabulary entry. Do not stop early and do not skip entries; go through the whole material from top to bottom.
- Slanted, cursive or untidy handwriting: decipher it from the language context (which word makes sense here).
- Ignore margin notes, dates, headings (such as "Unit 3") and page numbers.
- Accept every common separator between the two sides: -, ->, =, :, /, tabs and table columns.
- Irregular verb forms (e.g. go - went - gone) stay together on the front side of ONE card.
- "front" = the word or phrase in the language being learned, "back" = its meaning. If the material shows no translation, translate it yourself.""".trimIndent()
        const val RECOGNIZE_JSON = """Answer with ONLY a JSON array, no markdown: [{"front":"...","back":"..."}]"""
        const val RECOGNIZE_JSON_AUTO = """Answer with ONLY a JSON array, no markdown: [{"front":"...","back":"...","lang":"xx"}] ("lang" = ISO 639-1 code of the front language)"""
        const val JSON_RULE_LANG = """Answer with ONLY a JSON object, no markdown: {"pairs":[{"source":"...","target":"...","lang":"xx","example":"..."}]}"""
        const val JSON_RULE = """Answer with ONLY a JSON object, no markdown: {"pairs":[{"source":"...","target":"...","example":"..."}]}"""
    }
}

/* ───────────────────────── ranking: newest generation first, fast tiers first ───────────────────────── */

private fun num(regex: String, s: String): Double =
    Regex(regex).find(s)?.groupValues?.drop(1)?.filter { it.isNotEmpty() }?.joinToString(".")?.toDoubleOrNull() ?: 0.0

private fun String.isSnapshot() = Regex("-\\d{4}-\\d{2}-\\d{2}$|-\\d{8}$|-\\d{3,4}$").containsMatchIn(this)

private fun rankGemini(names: List<String>): List<String> {
    val bad = listOf("tts", "image", "embedding", "live", "audio", "robotics", "computer", "learnlm", "aqa", "gemma", "imagen", "veo", "native")
    fun tier(n: String) = when { "flash-lite" in n -> 4; "flash" in n -> 3; "pro" in n -> 1; else -> 0 }
    return names.filter { it.startsWith("gemini") && bad.none { b -> b in it } }.distinct()
        .sortedWith(
            compareByDescending<String> { num("gemini-(\\d+)(?:\\.(\\d+))?", it) }
                .thenByDescending { tier(it) }
                .thenByDescending { if (listOf("preview", "exp").any { b -> b in it }) 0 else 1 }
                .thenBy { it },
        )
}

private fun rankClaude(ids: List<String>): List<String> {
    fun tier(n: String) = when { "haiku" in n -> 3; "sonnet" in n -> 2; else -> 1 }
    fun ver(n: String): Double {
        val m = Regex("claude-(?:haiku|sonnet|opus)-(\\d+)(?:-(\\d{1,2}))?(?!\\d)").find(n)
        if (m != null) return "${m.groupValues[1]}.${m.groupValues[2].ifEmpty { "0" }}".toDouble()
        val old = Regex("claude-(\\d+)(?:-(\\d+))?").find(n)
        return if (old != null) "${old.groupValues[1]}.${old.groupValues[2].ifEmpty { "0" }}".toDouble() else 0.0
    }
    return ids.filter { it.startsWith("claude") }.distinct()
        .sortedWith(compareByDescending<String> { ver(it) }.thenByDescending { tier(it) }.thenBy { it.isSnapshot() }.thenBy { it })
}

private fun rankOpenAi(ids: List<String>): List<String> {
    val bad = listOf("embedding", "tts", "whisper", "audio", "realtime", "image", "transcribe", "moderation", "dall", "search", "instruct", "codex", "davinci", "babbage", "pro", "deep-research", "computer", "omni", "sora", "chat-latest")
    val chat = ids.filter { (it.startsWith("gpt-") || Regex("^o\\d").containsMatchIn(it)) && bad.none { b -> b in it } }.distinct()
    val clean = chat.filterNot { it.isSnapshot() }.ifEmpty { chat }
    fun tier(n: String) = when { "nano" in n -> 1; "mini" in n -> 3; else -> 2 }
    return clean.sortedWith(
        compareByDescending<String> { if (it.startsWith("gpt-")) num("gpt-(\\d+)(?:\\.(\\d+))?", it) else 0.0 }
            .thenByDescending { tier(it) }
            .thenBy { it },
    )
}

private fun rankGroq(ids: List<String>): List<String> {
    val bad = listOf("whisper", "tts", "guard", "playai", "orpheus", "embed")
    val ok = ids.filter { m -> bad.none { it in m } }.distinct()
    return ok.sortedWith(
        compareByDescending<String> { "llama-4" in it }
            .thenByDescending { "llama-3.3" in it }
            .thenByDescending { "versatile" in it }
            .thenBy { it },
    )
}

private fun rankXai(ids: List<String>): List<String> {
    val ok = ids.filter { "grok" in it && "image" !in it && "imagine" !in it }.distinct()
    return ok.sortedWith(
        compareByDescending<String> { num("grok-(\\d+)(?:\\.(\\d+))?", it) }
            .thenByDescending { "fast" in it || "mini" in it }
            .thenBy { it },
    )
}

private fun rankOpenRouter(ids: List<String>): List<String> {
    val prefer = listOf(
        "google/gemini-2.5-flash", "google/gemini-flash", "openai/gpt-4o-mini", "openai/gpt-5-mini",
        "anthropic/claude-haiku", "anthropic/claude-3.5-haiku", "meta-llama/llama-4", "google/gemini-2.0-flash",
    )
    val picked = prefer.flatMap { p -> ids.filter { it.startsWith(p) && !it.endsWith(":free") }.sorted().take(2) }.distinct()
    return picked.ifEmpty { ids.take(12) }
}


/** Removes everything a paste can add around a key: spaces, line breaks, invisible characters, quotes, "Bearer ". */
fun cleanKey(raw: String): String {
    var k = raw.replace(Regex("[\\s\\u00A0\\u200B-\\u200F\\u2060\\uFEFF]"), "")
    k = k.trim('"', '\'', '`', '\u201C', '\u201D', '\u2018', '\u2019', '\u201E')
    for (p in listOf("Bearer", "bearer", "key=", "apikey=", "API_KEY=", "GEMINI_API_KEY=")) if (k.startsWith(p)) k = k.removePrefix(p)
    return k
}

/** Short, readable reason for a failed connection. */
internal fun netDetail(e: java.io.IOException): String = when (e) {
    is java.net.UnknownHostException -> tr("Server nicht gefunden")
    is java.net.SocketTimeoutException, is java.io.InterruptedIOException -> tr("Zeitüberschreitung")
    is javax.net.ssl.SSLException -> tr("Sichere Verbindung fehlgeschlagen")
    is java.net.ConnectException -> tr("Verbindung abgelehnt")
    else -> e.message?.take(80) ?: e::class.java.simpleName
}

/** Models to use when the list could not be fetched but the key is accepted. */
fun defaultModels(p: AiProvider): List<String> = when (p) {
    AiProvider.Gemini -> listOf("gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite")
    AiProvider.OpenAi -> listOf("gpt-4o-mini", "gpt-4o")
    AiProvider.Anthropic -> listOf("claude-haiku-4-5", "claude-sonnet-4-5")
    AiProvider.Groq -> listOf("llama-3.3-70b-versatile")
    AiProvider.OpenRouter -> listOf("google/gemini-2.0-flash-001")
    AiProvider.XAi -> listOf("grok-3-mini")
}
