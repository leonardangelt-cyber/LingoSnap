package com.lingosnap.data.remote

import android.util.Base64
import com.lingosnap.data.SecureKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
data class VocabPair(val source: String, val target: String, val example: String? = null)

@Serializable
private data class VocabResponse(val pairs: List<VocabPair> = emptyList())

@Serializable
private data class GenerateResponse(val candidates: List<Candidate> = emptyList()) {
    @Serializable data class Candidate(val content: Content? = null)
    @Serializable data class Content(val parts: List<Part> = emptyList())
    @Serializable data class Part(val text: String? = null, val thought: Boolean? = null)
}

@Serializable
private data class ErrorEnvelope(val error: Detail? = null) {
    @Serializable data class Detail(val message: String? = null)
}

sealed class GeminiException(message: String) : Exception(message) {
    data object MissingKey : GeminiException("Noch kein API-Key gespeichert.")
    data object EmptyAnswer : GeminiException("Gemini hat keine Antwort geliefert. Versuche es noch einmal.")
    class Http(val code: Int, detail: String) : GeminiException(
        when (code) {
            400, 403 -> "Der API-Key wurde abgelehnt. Bitte prüfe ihn. ($detail)"
            429 -> "Zu viele Anfragen – warte kurz und versuche es erneut."
            else -> "Gemini-Fehler $code: $detail"
        }
    )
}

/**
 * Minimal Gemini REST client. The key comes from [SecureKeyStore] and is sent via the
 * `x-goog-api-key` header (never in URLs or logs).
 */
class GeminiClient(
    private val keyStore: SecureKeyStore,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build(),
    // Tried in order; a model that answers 404 ("not available") is skipped automatically
    // and the first working one is remembered.
    private val models: List<String> = listOf("gemini-3.8-flash", "gemini-flash-latest", "gemini-2.5-flash"),
) {
    private val json = Json { ignoreUnknownKeys = true }
    @Volatile private var preferred: String? = null

    private val vocabSchema: JsonElement = Json.parseToJsonElement(
        """
        {"type":"OBJECT","properties":{"pairs":{"type":"ARRAY","items":{"type":"OBJECT",
        "properties":{"source":{"type":"STRING"},"target":{"type":"STRING"},"example":{"type":"STRING"}},
        "required":["source","target"]}}},"required":["pairs"]}
        """.trimIndent()
    )

    /** Vision -> vocabulary pairs as strict JSON (enforced through a response schema). */
    suspend fun extractVocabulary(
        jpeg: ByteArray,
        sourceLangName: String,
        targetLangName: String,
    ): Result<List<VocabPair>> = runCatching {
        val prompt = """
            You are an OCR and vocabulary extraction engine for language learners.
            The image shows a textbook page, vocabulary list or handwritten notes.
            Extract every vocabulary entry as a pair: "source" in $sourceLangName and "target" in $targetLangName.
            Rules:
            - If the image only contains one language, translate the missing side yourself.
            - Keep articles/gender (e.g. "der Tisch", "la casa") and phrasal verbs intact.
            - Skip headings, page numbers and duplicates. Put a short example sentence into "example" only if the page contains one.
            - Fix obvious OCR typos. Never invent entries that are not on the page.
        """.trimIndent()

        val body = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject {
                    putJsonArray("parts") {
                        addJsonObject {
                            putJsonObject("inline_data") {
                                put("mime_type", "image/jpeg")
                                put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
                            }
                        }
                        addJsonObject { put("text", prompt) }
                    }
                }
            }
            putJsonObject("generationConfig") {
                put("temperature", 0.2)
                put("responseMimeType", "application/json")
                put("responseSchema", vocabSchema)
            }
        }
        parsePairs(generate(body))
    }

    /** Topic -> vocabulary list (AI assistant when creating a deck). */
    suspend fun generateVocabulary(
        topic: String,
        sourceLangName: String,
        targetLangName: String,
        count: Int,
        level: String,
    ): Result<List<VocabPair>> = runCatching {
        val prompt = """
            Create a vocabulary list for a language learner.
            Topic: "$topic"
            Level: $level
            Number of entries: $count
            "source" is the word or phrase in $sourceLangName, "target" its translation in $targetLangName.
            Add a short, natural example sentence in $sourceLangName as "example".
            Include articles/gender for nouns. No duplicates. Useful, common vocabulary only.
        """.trimIndent()

        val body = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject { putJsonArray("parts") { addJsonObject { put("text", prompt) } } }
            }
            putJsonObject("generationConfig") {
                put("temperature", 0.7)
                put("responseMimeType", "application/json")
                put("responseSchema", vocabSchema)
            }
        }
        parsePairs(generate(body))
    }

    /** Funny, memorable "Eselsbrücke" linking both words. */
    suspend fun generateMnemonic(
        source: String, sourceLangName: String,
        target: String, targetLangName: String,
        explanationLang: String = "German",
    ): Result<String> = runCatching {
        val prompt = """
            You are a witty memory coach. Invent ONE vivid, funny mnemonic (an "Eselsbrücke")
            that links the $sourceLangName word "$source" with its $targetLangName translation "$target".
            Use sound-alikes, an absurd mental image or a mini story.
            Max. 2 short sentences plus one fitting emoji.
            Write the explanation in $explanationLang, but keep both vocabulary words in their original language.
            Return only the mnemonic text.
        """.trimIndent()
        generate(textBody(prompt, temperature = 1.0)).trim()
    }

    /** Cheap round-trip used to verify a key before saving it. */
    suspend fun validateKey(key: String): Result<Unit> = runCatching {
        generate(textBody("Reply with the single word: ok", temperature = 0.0), keyOverride = key)
        Unit
    }

    private fun parsePairs(raw: String): List<VocabPair> =
        json.decodeFromString<VocabResponse>(raw).pairs
            .map { VocabPair(it.source.trim(), it.target.trim(), it.example?.trim()?.takeIf { e -> e.isNotEmpty() }) }
            .filter { it.source.isNotEmpty() && it.target.isNotEmpty() }
            .distinctBy { it.source.lowercase() to it.target.lowercase() }

    private fun textBody(prompt: String, temperature: Double): JsonObject = buildJsonObject {
        putJsonArray("contents") {
            addJsonObject { putJsonArray("parts") { addJsonObject { put("text", prompt) } } }
        }
        putJsonObject("generationConfig") { put("temperature", temperature) }
    }

    private suspend fun generate(body: JsonObject, keyOverride: String? = null): String {
        val key = keyOverride ?: keyStore.apiKey ?: throw GeminiException.MissingKey
        val order = listOfNotNull(preferred) + models.filter { it != preferred }
        var last: GeminiException? = null
        for (m in order) {
            try {
                val text = call(m, key, body)
                preferred = m
                return text
            } catch (e: GeminiException.Http) {
                if (e.code == 404) { last = e; continue } // model not available -> try next
                throw e
            }
        }
        throw last ?: GeminiException.EmptyAnswer
    }

    private suspend fun call(model: String, key: String, body: JsonObject): String =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    val detail = runCatching { json.decodeFromString<ErrorEnvelope>(raw).error?.message }.getOrNull()
                    throw GeminiException.Http(res.code, detail ?: res.message)
                }
                json.decodeFromString<GenerateResponse>(raw)
                    .candidates.firstOrNull()?.content?.parts
                    ?.filter { it.thought != true }
                    ?.mapNotNull { it.text }
                    ?.joinToString("")
                    ?.takeIf { it.isNotBlank() }
                    ?: throw GeminiException.EmptyAnswer
            }
        }
}
