package com.lingosnap.data.remote

import android.util.Base64
import com.lingosnap.data.SecureKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable data class VocabPair(val source: String, val target: String)
@Serializable private data class VocabResponse(val pairs: List<VocabPair> = emptyList())

@Serializable private data class GenerateResponse(val candidates: List<Candidate> = emptyList()) {
    @Serializable data class Candidate(val content: Content? = null)
    @Serializable data class Content(val parts: List<Part> = emptyList())
    @Serializable data class Part(val text: String? = null)
}

@Serializable private data class ErrorEnvelope(val error: Detail? = null) {
    @Serializable data class Detail(val message: String? = null)
}

sealed class GeminiException(message: String) : Exception(message) {
    data object MissingKey : GeminiException("No API key saved yet.")
    data object EmptyAnswer : GeminiException("Gemini returned an empty answer. Try a sharper photo.")
    class Http(val code: Int, detail: String) : GeminiException(
        when (code) {
            400, 403 -> "The API key was rejected. Please check it. ($detail)"
            429 -> "Rate limit reached – wait a moment and try again."
            else -> "Gemini error $code: $detail"
        }
    )
}

/**
 * Minimal Gemini REST client. Uses the key from [SecureKeyStore] and the
 * `x-goog-api-key` header (the key never ends up in URLs or logs).
 */
class GeminiClient(
    private val keyStore: SecureKeyStore,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build(),
    private val model: String = "gemini-2.5-flash", // swap to "gemini-2.5-pro" for harder handwriting
) {
    private val json = Json { ignoreUnknownKeys = true }

    /** Vision → vocabulary pairs as strict JSON (enforced through a response schema). */
    suspend fun extractVocabulary(
        jpeg: ByteArray,
        sourceLangName: String,
        targetLangName: String,
    ): Result<List<VocabPair>> = runCatching {
        val prompt = """
            You are an OCR and vocabulary extraction engine for language learners.
            The image shows a textbook page, vocabulary list or handwritten notes.
            Extract every vocabulary entry as a pair: "source" in $sourceLangName and "target" in $targetLangName.
            Rules:
            - If the image only contains one language, translate the missing side yourself.
            - Keep articles/gender (e.g. "der Tisch") and phrasal verbs intact.
            - Skip headings, page numbers, example sentences and duplicates.
            - Fix obvious OCR typos. Never invent entries that are not on the page.
        """.trimIndent()

        val body = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject {
                    putJsonArray("parts") {
                        addJsonObject {
                            putJsonObject("inline_data") {
                                put("mime_type", "image/jpeg")
                                put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
                            }
                        }
                        addJsonObject { put("text", prompt) }
                    }
                }
            }
            putJsonObject("generationConfig") {
                put("temperature", 0.2)
                put("responseMimeType", "application/json")
                putJsonObject("responseSchema") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("pairs") {
                            put("type", "ARRAY")
                            putJsonObject("items") {
                                put("type", "OBJECT")
                                putJsonObject("properties") {
                                    putJsonObject("source") { put("type", "STRING") }
                                    putJsonObject("target") { put("type", "STRING") }
                                }
                                putJsonArray("required") { add(kotlinx.serialization.json.JsonPrimitive("source")); add(kotlinx.serialization.json.JsonPrimitive("target")) }
                            }
                        }
                    }
                    putJsonArray("required") { add(kotlinx.serialization.json.JsonPrimitive("pairs")) }
                }
            }
        }
        val raw = generate(body)
        json.decodeFromString<VocabResponse>(raw).pairs
            .map { VocabPair(it.source.trim(), it.target.trim()) }
            .filter { it.source.isNotEmpty() && it.target.isNotEmpty() }
            .distinct()
    }

    /** Funny, memorable "Eselsbrücke" linking both words. */
    suspend fun generateMnemonic(
        source: String, sourceLangName: String,
        target: String, targetLangName: String,
        explanationLang: String = "German",
    ): Result<String> = runCatching {
        val prompt = """
            You are a witty memory coach. Invent ONE vivid, funny mnemonic (an "Eselsbrücke")
            that links the $sourceLangName word "$source" with its $targetLangName translation "$target".
            Use sound-alikes, a absurd mental image or a mini story.
            Max. 2 short sentences plus one fitting emoji.
            Write the explanation in $explanationLang, but keep both vocabulary words in their original language.
            Return only the mnemonic text.
        """.trimIndent()
        generate(textBody(prompt, temperature = 1.0)).trim()
    }

    /** Cheap round-trip used by the onboarding screen to verify a key before saving it. */
    suspend fun validateKey(key: String): Result<Unit> = runCatching {
        generate(textBody("Reply with the single word: ok", temperature = 0.0), keyOverride = key)
        Unit
    }

    private fun textBody(prompt: String, temperature: Double): JsonObject = buildJsonObject {
        putJsonArray("contents") {
            addJsonObject { putJsonArray("parts") { addJsonObject { put("text", prompt) } } }
        }
        putJsonObject("generationConfig") { put("temperature", temperature) }
    }

    private suspend fun generate(body: JsonObject, keyOverride: String? = null): String =
        withContext(Dispatchers.IO) {
            val key = keyOverride ?: keyStore.apiKey ?: throw GeminiException.MissingKey
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    val detail = runCatching { json.decodeFromString<ErrorEnvelope>(raw).error?.message }.getOrNull()
                    throw GeminiException.Http(res.code, detail ?: res.message)
                }
                json.decodeFromString<GenerateResponse>(raw)
                    .candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: throw GeminiException.EmptyAnswer
            }
        }
}
