package com.lingosnap.data.remote

import android.util.Base64
import com.lingosnap.data.SecureKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
data class VocabPair(val source: String, val target: String, val example: String? = null)

@Serializable
private data class ModelList(val models: List<ModelInfo> = emptyList()) {
    @Serializable
    data class ModelInfo(val name: String, val supportedGenerationMethods: List<String> = emptyList())
}

private val excluded = listOf("tts", "image", "embedding", "live", "audio", "robotics", "computer", "learnlm", "aqa", "vision", "gemma", "imagen", "veo", "native")

/** Newest generation first, then flash before lite before pro, stable before preview. */
internal fun rankModels(names: List<String>): List<String> {
    fun version(n: String) = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(n)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
    fun tier(n: String) = when {
        "flash-lite" in n -> 2
        "flash" in n -> 3
        "pro" in n -> 1
        else -> 0
    }
    fun stable(n: String) = if (listOf("preview", "exp", "-0").any { it in n }) 0 else 1
    return names.filter { n -> n.startsWith("gemini") && excluded.none { it in n } }
        .distinct()
        .sortedWith(
            compareByDescending<String> { version(it) }
                .thenByDescending { tier(it) }
                .thenByDescending { stable(it) }
                .thenBy { it },
        )
}

@Serializable
private data class VocabResponse(val pairs: List<VocabPair> = emptyList())

@Serializable
private data class GenerateResponse(val candidates: List<Candidate> = emptyList()) {
    @Serializable data class Candidate(val content: Content? = null)
    @Serializable data class Content(val parts: List<Part> = emptyList())
    @Serializable data class Part(val text: String? = null, val thought: Boolean? = null)
}

@Serializable
private data class ErrorEnvelope(val error: Detail? = null) {
    @Serializable data class Detail(val message: String? = null)
}

sealed class GeminiException(message: String) : Exception(message) {
    data object MissingKey : GeminiException("Kein API-Schlüssel hinterlegt. Trage ihn unter Optionen ein.")
    data object EmptyAnswer : GeminiException("Gemini hat keine Antwort geliefert. Versuche es noch einmal.")
    class Http(val code: Int, detail: String) : GeminiException(
        when (code) {
            400, 403 -> "Der API-Key wurde abgelehnt. Bitte prüfe ihn. ($detail)"
            429 -> "Zu viele Anfragen – warte kurz und versuche es erneut."
            else -> "Gemini-Fehler $code: $detail"
        }
    )
}

/**
 * Minimal Gemini REST client. The key comes from [SecureKeyStore] and is sent via the
 * `x-goog-api-key` header (never in URLs or logs).
 */
class GeminiClient(
    private val keyStore: SecureKeyStore,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .callTimeout(120, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build(),
) {
    /** The model that answered last (or is going to be used); shown in the UI. */
    private val _activeModel = kotlinx.coroutines.flow.MutableStateFlow(keyStore.chosenModel ?: keyStore.models.firstOrNull())
    val activeModel: kotlinx.coroutines.flow.StateFlow<String?> = _activeModel

    private val _models = kotlinx.coroutines.flow.MutableStateFlow(keyStore.models)
    val models: kotlinx.coroutines.flow.StateFlow<List<String>> = _models

    fun chooseModel(model: String?) {
        keyStore.chosenModel = model
        _activeModel.value = model ?: keyStore.models.firstOrNull()
    }

    /** Asks Google which models this key may use; works for every key / model generation. */
    suspend fun refreshModels(keyOverride: String? = null): Result<List<String>> = runCatching {
        val key = keyOverride ?: keyStore.apiKey ?: throw GeminiException.MissingKey
        val found = fetchModels(key)
        if (found.isEmpty()) throw GeminiException.Http(404, "Für diesen Schlüssel sind keine Gemini-Modelle freigeschaltet.")
        if (keyOverride == null) applyModels(found)
        found
    }

    /** Saves the list for the (already verified) key. */
    fun applyModels(found: List<String>) {
        keyStore.models = found
        _models.value = found
        val chosen = keyStore.chosenModel
        if (chosen != null && chosen !in found) keyStore.chosenModel = null
        _activeModel.value = keyStore.chosenModel ?: found.firstOrNull()
    }

    private suspend fun fetchModels(key: String): List<String> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000")
            .header("x-goog-api-key", key)
            .get()
            .build()
        http.newCall(request).execute().use { res ->
            val raw = res.body?.string().orEmpty()
            if (!res.isSuccessful) {
                val detail = runCatching { json.decodeFromString<ErrorEnvelope>(raw).error?.message }.getOrNull()
                throw GeminiException.Http(res.code, detail ?: res.message)
            }
            val list = json.decodeFromString<ModelList>(raw).models
            rankModels(
                list.filter { "generateContent" in it.supportedGenerationMethods }
                    .map { it.name.removePrefix("models/") },
            )
        }
    }

    private val json = Json { ignoreUnknownKeys = true }

    private val vocabSchema: JsonElement = Json.parseToJsonElement(
        """
        {"type":"OBJECT","properties":{"pairs":{"type":"ARRAY","items":{"type":"OBJECT",
        "properties":{"source":{"type":"STRING"},"target":{"type":"STRING"},"example":{"type":"STRING"}},
        "required":["source","target"]}}},"required":["pairs"]}
        """.trimIndent()
    )

    /** Vision -> vocabulary pairs as strict JSON (enforced through a response schema). */
    suspend fun extractVocabulary(
        jpeg: ByteArray,
        sourceLangName: String,
        targetLangName: String,
    ): Result<List<VocabPair>> = runCatching {
        val prompt = """
            You are an OCR and vocabulary extraction engine for language learners.
            The image shows a textbook page, vocabulary list or handwritten notes.
            Extract every vocabulary entry as a pair: "source" in $sourceLangName and "target" in $targetLangName.
            Rules:
            - If the image only contains one language, translate the missing side yourself.
            - Keep articles/gender (e.g. "der Tisch", "la casa") and phrasal verbs intact.
            - Skip headings, page numbers and duplicates. Put a short example sentence into "example" only if the page contains one.
            - Fix obvious OCR typos. Never invent entries that are not on the page.
        """.trimIndent()

        val body = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject {
                    putJsonArray("parts") {
                        addJsonObject {
                            putJsonObject("inline_data") {
                                put("mime_type", "image/jpeg")
                                put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
                            }
                        }
                        addJsonObject { put("text", prompt) }
                    }
                }
            }
            putJsonObject("generationConfig") {
                put("temperature", 0.2)
                put("responseMimeType", "application/json")
                put("responseSchema", vocabSchema)
            }
        }
        parsePairs(generate(body))
    }

    /** Topic -> vocabulary list (AI assistant when creating a deck). */
    suspend fun generateVocabulary(
        topic: String,
        sourceLangName: String,
        targetLangName: String,
        count: Int,
        level: String,
    ): Result<List<VocabPair>> = runCatching {
        val prompt = """
            Create a vocabulary list for a language learner.
            Topic: "$topic"
            Level: $level
            Number of entries: $count
            "source" is the word or phrase in $sourceLangName, "target" its translation in $targetLangName.
            Add a short, natural example sentence in $sourceLangName as "example".
            Include articles/gender for nouns. No duplicates. Useful, common vocabulary only.
        """.trimIndent()

        val body = buildJsonObject {
            putJsonArray("contents") {
                addJsonObject { putJsonArray("parts") { addJsonObject { put("text", prompt) } } }
            }
            putJsonObject("generationConfig") {
                put("temperature", 0.7)
                put("responseMimeType", "application/json")
                put("responseSchema", vocabSchema)
            }
        }
        parsePairs(generate(body))
    }

    /** Funny, memorable "Eselsbrücke" linking both words. */
    suspend fun generateMnemonic(
        source: String, sourceLangName: String,
        target: String, targetLangName: String,
        explanationLang: String = "German",
    ): Result<String> = runCatching {
        val prompt = """
            You are a witty memory coach. Invent ONE vivid, funny mnemonic (an "Eselsbrücke")
            that links the $sourceLangName word "$source" with its $targetLangName translation "$target".
            Use sound-alikes, an absurd mental image or a mini story.
            Max. 2 short sentences plus one fitting emoji.
            Write the explanation in $explanationLang, but keep both vocabulary words in their original language.
            Return only the mnemonic text.
        """.trimIndent()
        generate(textBody(prompt, temperature = 1.0)).trim()
    }

    /** Verifies a key by listing its models; returns them best-first. */
    suspend fun validateKey(key: String): Result<List<String>> = refreshModels(key)

    private fun parsePairs(raw: String): List<VocabPair> =
        json.decodeFromString<VocabResponse>(raw).pairs
            .map { VocabPair(it.source.trim(), it.target.trim(), it.example?.trim()?.takeIf { e -> e.isNotEmpty() }) }
            .filter { it.source.isNotEmpty() && it.target.isNotEmpty() }
            .distinctBy { it.source.lowercase() to it.target.lowercase() }

    private fun textBody(prompt: String, temperature: Double): JsonObject = buildJsonObject {
        putJsonArray("contents") {
            addJsonObject { putJsonArray("parts") { addJsonObject { put("text", prompt) } } }
        }
        putJsonObject("generationConfig") { put("temperature", temperature) }
    }

    private suspend fun generate(body: JsonObject): String {
        val key = keyStore.apiKey ?: throw GeminiException.MissingKey
        var available = keyStore.models
        if (available.isEmpty()) {
            available = fetchModels(key)
            if (available.isNotEmpty()) applyModels(available)
        }
        val order = (listOfNotNull(keyStore.chosenModel) + available).distinct().take(6)
        if (order.isEmpty()) throw GeminiException.Http(404, "Keine Modelle verfügbar.")
        var last: GeminiException? = null
        for (m in order) {
            try {
                val text = call(m, key, body)
                _activeModel.value = m
                return text
            } catch (e: GeminiException.Http) {
                // model unavailable / over quota / overloaded -> try the next one
                if (e.code == 404 || e.code == 429 || e.code >= 500) { last = e; continue }
                if (e.code == 400 && !e.message.orEmpty().contains("API key", ignoreCase = true)) { last = e; continue }
                throw e
            }
        }
        throw last ?: GeminiException.EmptyAnswer
    }

    private suspend fun call(model: String, key: String, body: JsonObject): String =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    val detail = runCatching { json.decodeFromString<ErrorEnvelope>(raw).error?.message }.getOrNull()
                    throw GeminiException.Http(res.code, detail ?: res.message)
                }
                json.decodeFromString<GenerateResponse>(raw)
                    .candidates.firstOrNull()?.content?.parts
                    ?.filter { it.thought != true }
                    ?.mapNotNull { it.text }
                    ?.joinToString("")
                    ?.takeIf { it.isNotBlank() }
                    ?: throw GeminiException.EmptyAnswer
            }
        }
}
