package com.lingosnap.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem

@Composable
fun HomeScreen(
    onOpenDeck: (Long) -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onCreate: () -> Unit,
    onSettings: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    var deckToDelete by remember { mutableStateOf<Deck?>(null) }

    LargeScreen(
        title = "Decks",
        actions = { IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Optionen") } },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreate,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("Neues Deck") },
            )
        },
    ) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (state.decks.isEmpty() && !state.loading) {
                item {
                    Text(
                        "Noch keine Decks. Tippe auf „Neues Deck“, um loszulegen.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
            }
            items(state.decks.size, key = { state.decks[it].id }) { i ->
                val deck = state.decks[i]
                val cards = state.cardsOf(deck.id)
                val due = cards.count { it.dueAt <= System.currentTimeMillis() }
                SegmentedItem(
                    index = i,
                    count = state.decks.size,
                    headline = deck.name,
                    supporting = "${deck.typeLabel} • ${cards.size} Karten" + if (due > 0) " • $due fällig" else "",
                    onClick = { onOpenDeck(deck.id) },
                    trailing = {
                        IconButton(onClick = { deckToDelete = deck }) { Icon(Icons.Rounded.Delete, "Deck löschen") }
                    },
                    modifier = Modifier.animateItem(),
                )
            }
        }
    }

    deckToDelete?.let { deck ->
        ConfirmDialog(
            title = "Deck löschen?",
            text = "„${deck.name}“ und alle ${state.cardsOf(deck.id).size} Karten werden gelöscht.",
            confirmLabel = "Löschen",
            onConfirm = { vm.deleteDeck(deck.id) },
            onDismiss = { deckToDelete = null },
        )
    }
}
