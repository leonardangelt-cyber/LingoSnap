package com.lingosnap.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.AppState
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.theme.bold

@Composable
fun HomeScreen(
    onOpenDeck: (Long) -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onCreate: () -> Unit,
    onSettings: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val cs = MaterialTheme.colorScheme
    var deckToDelete by remember { mutableStateOf<Deck?>(null) }

    val due = state.dueCount()

    AppBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Decks", style = MaterialTheme.typography.headlineLarge.bold(), modifier = Modifier.weight(1f))
                IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Optionen") }
            }

            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            ) {
                item {
                    Surface(
                        Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        color = cs.surfaceContainerLow,
                        border = BorderStroke(1.dp, cs.outlineVariant),
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Heute", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                            Text(
                                if (due == 1) "1 Karte fällig" else "$due Karten fällig",
                                style = MaterialTheme.typography.headlineSmall.bold(),
                            )
                            Text(
                                "${state.cards.size} Karten insgesamt – du kannst jederzeit lernen",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                            Button(
                                onClick = { onStudy(StudyScope.All, 0L, StudyMode.FlashDue) },
                                enabled = state.cards.isNotEmpty(),
                            ) { Text("Jetzt lernen") }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }

                if (state.decks.isEmpty() && !state.loading) {
                    item {
                        Text(
                            "Noch keine Decks. Tippe auf „Neues Deck“, um loszulegen.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = cs.onSurfaceVariant,
                        )
                    }
                } else {
                    item {
                        Text(
                            "Deine Decks",
                            style = MaterialTheme.typography.titleSmall.bold(),
                            color = cs.primary,
                            modifier = Modifier.padding(bottom = 4.dp),
                        )
                    }
                    items(state.decks, key = { it.id }) { deck ->
                        DeckItem(deck, state, onOpenDeck) { deckToDelete = deck }
                        HorizontalDivider(color = cs.outlineVariant)
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = onCreate,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp),
            icon = { Icon(Icons.Rounded.Add, null) },
            text = { Text("Neues Deck") },
        )
    }

    deckToDelete?.let { deck ->
        ConfirmDialog(
            title = "Deck löschen?",
            text = "„${deck.name}“ und alle ${state.cardsOf(deck.id).size} Karten werden gelöscht.",
            confirmLabel = "Löschen",
            onConfirm = { vm.deleteDeck(deck.id) },
            onDismiss = { deckToDelete = null },
        )
    }
}

@Composable
private fun DeckItem(deck: Deck, state: AppState, onOpen: (Long) -> Unit, onDelete: () -> Unit) {
    val cards = state.cardsOf(deck.id)
    val due = cards.count { it.dueAt <= System.currentTimeMillis() }
    ListItem(
        modifier = Modifier.clickable { onOpen(deck.id) },
        headlineContent = { Text(deck.name, style = MaterialTheme.typography.titleMedium) },
        supportingContent = {
            Text("${deck.typeLabel} • ${cards.size} Karten" + if (due > 0) " • $due fällig" else "")
        },
        trailingContent = { IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Deck löschen") } },
    )
}
