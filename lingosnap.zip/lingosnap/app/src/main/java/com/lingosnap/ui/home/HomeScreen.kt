package com.lingosnap.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.rounded.FileDownload
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import androidx.compose.ui.Alignment
import androidx.compose.material3.Surface
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import com.lingosnap.ui.components.LearnMethodSheet
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.data.model.languageName
import com.lingosnap.data.model.typeLabelFor
import com.lingosnap.container
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.rounded.School
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenDeck: (Long) -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onCreate: () -> Unit,
    onSettings: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    var deckToDelete by remember { mutableStateOf<Deck?>(null) }
    var deckToFolder by remember { mutableStateOf<Deck?>(null) }
    var method by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var parsed by remember { mutableStateOf<com.lingosnap.util.ParsedImport?>(null) }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { com.lingosnap.util.ImportParsers.parse(ctx, uri) }
                .onSuccess { parsed = it }
                .onFailure { Toast.makeText(ctx, it.message ?: "Datei konnte nicht gelesen werden", Toast.LENGTH_LONG).show() }
        }
    }
    val feedback = LocalContext.current.container.feedback
    var learnMode by remember { mutableStateOf(feedback.learnMode) }

    var importMenu by remember { mutableStateOf(false) }
    val incoming by com.lingosnap.util.PendingImport.state.collectAsStateWithLifecycle()
    androidx.compose.runtime.LaunchedEffect(incoming) {
        incoming?.let { parsed = it; com.lingosnap.util.PendingImport.state.value = null }
    }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val pager = androidx.compose.foundation.pager.rememberPagerState { 2 }
    val tab = pager.currentPage
    val jobs by com.lingosnap.util.AiJobs.state.collectAsStateWithLifecycle()

    LargeScreen(
        title = "Decks",
        actions = {
            IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, if (searching) "Suche schließen" else "Suchen")
            }
            Box {
                IconButton(onClick = { importMenu = true }) { Icon(Icons.Rounded.FileDownload, "Importieren") }
                DropdownMenu(expanded = importMenu, onDismissRequest = { importMenu = false }) {
                    DropdownMenuItem(text = { Text("Datei wählen") }, onClick = { importMenu = false; importPicker.launch(com.lingosnap.util.ImportParsers.MIME_TYPES) })
                    DropdownMenuItem(text = { Text("Link aus Zwischenablage") }, onClick = {
                        importMenu = false
                        val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                        val found = com.lingosnap.util.DeckLink.decode(text)
                        if (found != null) parsed = found
                        else Toast.makeText(ctx, "In der Zwischenablage ist kein LingoSnap-Link.", Toast.LENGTH_LONG).show()
                    })
                }
            }
            IconButton(onClick = { method = true }) { Icon(Icons.Rounded.School, "Lernmethode") }
            IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Optionen") }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreate,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("Neues Deck") },
            )
        },
    ) { inner ->
        Column(Modifier.padding(inner)) {
            if (searching) com.lingosnap.ui.components.AppTextField(
                query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text("Deck, Wort oder Übersetzung suchen") }, singleLine = true,
            )
            val labels = listOf("Vokabeln", "Lernkarten")
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                labels.forEachIndexed { i, label ->
                    SegmentedButton(
                        selected = tab == i,
                        onClick = { scope.launch { pager.animateScrollToPage(i) } },
                        shape = SegmentedButtonDefaults.itemShape(i, labels.size),
                        colors = SegmentedButtonDefaults.colors(activeContainerColor = cs.primary, activeContentColor = cs.onPrimary),
                    ) { Text(label) }
                }
            }
            androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.weight(1f)) { page ->
            val q = query.trim()
            val shownDecks = state.decks.filter { if (page == 0) it.isLanguage else !it.isLanguage }.filter { d ->
                q.isEmpty() || d.name.contains(q, true) || state.cardsOf(d.id).any { it.source.contains(q, true) || it.target.contains(q, true) }
            }
            // language decks grouped by the language they teach
    val groups = remember(shownDecks, state.cards) {
        val withLabel = shownDecks.map { d ->
            val label = when {
                !d.isLanguage -> state.groups.firstOrNull { it.id == d.groupId }?.name ?: NO_FOLDER
                d.sourceLang != "auto" -> languageName(d.sourceLang)
                else -> state.cardsOf(d.id).groupingBy { it.sourceLang }.eachCount()
                    .maxByOrNull { it.value }?.key?.let { languageName(it) } ?: "Sprache offen"
            }
            label to d
        }
        withLabel.groupBy({ it.first }, { it.second }).toList()
            .sortedWith(compareBy({ it.first == NO_FOLDER }, { it.first == "Sprache offen" }, { it.first }))
    }

            LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (shownDecks.isEmpty() && !state.loading) {
                item {
                    Text(
                        if (q.isNotEmpty()) "Nichts gefunden."
                        else if (state.decks.isEmpty()) "Noch keine Decks. Tippe auf „Neues Deck“, um loszulegen."
                        else if (page == 0) "Noch keine Vokabel-Decks." else "Noch keine Lernkarten-Decks.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
            }
            groups.forEach { (label, decks) ->
                // language decks: one heading per language; plain card decks: headings only once folders exist
                if (page == 0 || groups.size > 1 || label != NO_FOLDER) item(key = "h-$label") {
                    GroupHeader(
                        if (page == 1 && label == NO_FOLDER) "Ohne Ordner" else label,
                        icon = if (page == 1) Icons.Rounded.Folder else Icons.Rounded.Translate,
                    )
                }
                items(decks.size, key = { decks[it].id }) { i ->
                    val deck = decks[i]
                    val cards = state.cardsOf(deck.id)
                    val due = cards.count { it.dueAt <= System.currentTimeMillis() }
                    val job = jobs[deck.id]
                    SegmentedItem(
                        index = i,
                        count = decks.size,
                        headline = deck.name,
                        supporting = job?.let { "${it.percent} % • ${it.status}" } ?: "${deck.typeLabelFor(cards)} • ${cards.size} Karten",
                        progress = job?.let { it.percent / 100f },
                        onClick = { onOpenDeck(deck.id) },
                        trailing = {
                            if (job != null) IconButton(onClick = { com.lingosnap.util.AiJobs.cancel(deck.id) }) {
                                Icon(Icons.Rounded.Close, "KI-Vorgang abbrechen")
                            } else Row(verticalAlignment = Alignment.CenterVertically) {
                                if (due > 0) {
                                    Surface(shape = RoundedCornerShape(50), color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
                                        Text("$due fällig", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                                var menu by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Mehr") }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        if (!deck.isLanguage) DropdownMenuItem(text = { Text("In Ordner legen") }, onClick = { menu = false; deckToFolder = deck })
                                        DropdownMenuItem(text = { Text("Deck löschen") }, onClick = { menu = false; deckToDelete = deck })
                                    }
                                }
                            }
                        },
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }
            }
        }
    }

    parsed?.let { p ->
        ImportDialog(p, onDismiss = { parsed = null })
    }

    if (method) {
        LearnMethodSheet(
            current = learnMode,
            onPick = { learnMode = it; feedback.learnMode = it; method = false },
            onDismiss = { method = false },
        )
    }

    deckToFolder?.let { deck ->
        FolderDialog(
            folders = state.groups.map { it.id to it.name },
            current = deck.groupId,
            onPick = { vm.moveDeckToFolder(deck, it); deckToFolder = null },
            onCreate = { name -> vm.createFolderFor(deck, name); deckToFolder = null },
            onDismiss = { deckToFolder = null },
        )
    }

    deckToDelete?.let { deck ->
        ConfirmDialog(
            title = "Deck löschen?",
            text = "„${deck.name}“ und alle ${state.cardsOf(deck.id).size} Karten werden gelöscht.",
            confirmLabel = "Löschen",
            onConfirm = { vm.deleteDeck(deck.id) },
            onDismiss = { deckToDelete = null },
        )
    }
}

private const val NO_FOLDER = "\u0000ohne"

@Composable
private fun FolderDialog(
    folders: List<Pair<Long, String>>,
    current: Long?,
    onPick: (Long?) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text("In Ordner legen") },
        text = {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val all = listOf<Pair<Long?, String>>(null to "Ohne Ordner") + folders
                androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    all.forEachIndexed { i, (id, label) ->
                        SegmentedItem(
                            index = i, count = all.size, headline = label,
                            onClick = { onPick(id) },
                            trailing = if (id == current) { { Icon(Icons.Rounded.Check, "Aktuell") } } else null,
                        )
                    }
                }
                com.lingosnap.ui.components.AppTextField(
                    name, { name = it }, Modifier.fillMaxWidth(),
                    label = { Text("Neuer Ordner") }, singleLine = true,
                )
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(enabled = name.isNotBlank(), onClick = { onCreate(name.trim()) }) { Text("Neu anlegen") }
        },
        dismissButton = { androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
