@file:OptIn(ExperimentalMaterial3Api::class)

package com.lingosnap.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Mastery
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.MasteryDots
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    onScan: () -> Unit,
    onStudy: () -> Unit,
    onSettings: () -> Unit,
    vm: HomeViewModel = viewModel(factory = HomeViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = { ScanFab(onScan) },
        ) { pad ->
            LazyColumn(
                contentPadding = PaddingValues(
                    start = 20.dp, end = 20.dp,
                    top = pad.calculateTopPadding() + 8.dp,
                    bottom = 140.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item { Header(onSettings, Modifier.entrance(0)) }
                item { HeroCard(state, onStudy, Modifier.entrance(1)) }

                if (state.cards.isEmpty() && !state.loading) {
                    item { EmptyState(onScan, Modifier.entrance(2)) }
                } else {
                    item {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp).entrance(2),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Your words", style = MaterialTheme.typography.titleLarge.bold(), modifier = Modifier.weight(1f))
                            Text(
                                "${state.cards.size}",
                                style = MaterialTheme.typography.titleMedium.bold(),
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                    itemsIndexed(state.cards, key = { _, c -> c.id }) { i, card ->
                        WordRow(
                            card = card,
                            onDelete = { vm.delete(card) },
                            modifier = Modifier.animateItem().entrance(minOf(i, 8) + 3, 55L),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        CookieBadge(size = 52.dp, color = cs.primary, lobes = 8, spinMillis = 18000) {
            Icon(Icons.Rounded.Translate, null, tint = cs.onPrimary, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Ready to learn?", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            Text("LingoSnap", style = MaterialTheme.typography.headlineMedium.bold())
        }
        FilledTonalIconButton(onClick = onSettings) { Icon(Icons.Rounded.Key, "API key") }
    }
}

@Composable
private fun HeroCard(state: HomeUiState, onStudy: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val due by animateIntAsState(state.due, tween(900, easing = FastOutSlowInEasing), label = "due")
    val ratio = if (state.cards.isEmpty()) 0f else state.mastered / state.cards.size.toFloat()
    val progress by animateFloatAsState(ratio, spring(dampingRatio = 0.8f, stiffness = 120f), label = "mastered")

    Box(
        modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(Brush.linearGradient(listOf(cs.primary, cs.tertiary))),
    ) {
        CookieBadge(
            size = 230.dp,
            color = cs.onPrimary.copy(alpha = 0.12f),
            lobes = 12,
            spinMillis = 40000,
            modifier = Modifier.align(Alignment.TopEnd).offset(x = 70.dp, y = (-70).dp),
        )
        Column(Modifier.padding(26.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                "TODAY",
                style = MaterialTheme.typography.labelLarge.bold(),
                color = cs.onPrimary.copy(alpha = 0.8f),
            )
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    "$due",
                    style = MaterialTheme.typography.displayLarge.copy(fontSize = 88.sp, fontWeight = FontWeight.ExtraBold),
                    color = cs.onPrimary,
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    if (state.due == 1) "card due" else "cards due",
                    style = MaterialTheme.typography.titleLarge.bold(),
                    color = cs.onPrimary.copy(alpha = 0.9f),
                    modifier = Modifier.padding(bottom = 16.dp),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip("📚  ${state.cards.size} words")
                StatChip("🏆  ${state.mastered} mastered")
            }
            WavyProgressBar(
                progress = progress,
                color = cs.onPrimary,
                trackColor = cs.onPrimary.copy(alpha = 0.3f),
            )
            BouncyButton(
                onClick = onStudy,
                enabled = state.due > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = cs.onPrimary,
                    contentColor = cs.primary,
                    disabledContainerColor = cs.onPrimary.copy(alpha = 0.35f),
                    disabledContentColor = cs.primary.copy(alpha = 0.6f),
                ),
            ) {
                Icon(Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text("Start session", style = MaterialTheme.typography.titleMedium.bold())
            }
        }
    }
}

@Composable
private fun StatChip(text: String) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = CircleShape, color = cs.onPrimary.copy(alpha = 0.18f), contentColor = cs.onPrimary) {
        Text(
            text,
            Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelLarge.bold(),
        )
    }
}

@Composable
private fun WordRow(card: Flashcard, onDelete: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Row(
            Modifier.padding(start = 20.dp, end = 6.dp, top = 14.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(card.source, style = MaterialTheme.typography.titleMedium.bold())
                Text(
                    card.target,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                MasteryDots(card.level)
                Text(
                    Mastery.of(card.level).label,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Rounded.Delete, "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun EmptyState(onScan: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.fillMaxWidth().padding(vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        CookieBadge(size = 120.dp, color = cs.secondaryContainer, lobes = 9) {
            Icon(Icons.Rounded.CameraAlt, null, Modifier.size(44.dp), tint = cs.onSecondaryContainer)
        }
        Text("No words yet", style = MaterialTheme.typography.headlineSmall.bold())
        Text(
            "Snap a textbook page or your notes and LingoSnap turns it into flashcards.",
            style = MaterialTheme.typography.bodyLarge,
            color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(4.dp))
        BouncyButton(onClick = onScan) {
            Icon(Icons.Rounded.CameraAlt, null)
            Spacer(Modifier.width(8.dp))
            Text("Scan first page", style = MaterialTheme.typography.titleMedium.bold())
        }
    }
}

@Composable
private fun ScanFab(onScan: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(450); shown = true }
    AnimatedVisibility(
        visible = shown,
        enter = scaleIn(spring(dampingRatio = 0.5f, stiffness = 300f)) + fadeIn(),
    ) {
        ExtendedFloatingActionButton(
            onClick = onScan,
            icon = { Icon(Icons.Rounded.CameraAlt, null) },
            text = { Text("Scan page", style = MaterialTheme.typography.titleMedium.bold()) },
        )
    }
}
