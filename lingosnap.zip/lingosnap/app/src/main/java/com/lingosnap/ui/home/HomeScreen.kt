package com.lingosnap.ui.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.data.model.rankFor
import com.lingosnap.ui.AppState
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.InfoChip
import com.lingosnap.ui.components.LangBadge
import com.lingosnap.ui.components.SectionLabel
import com.lingosnap.ui.components.StatTile
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold

@Composable
fun HomeScreen(
    onOpenDeck: (Long) -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onCreate: () -> Unit,
    onSearch: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val darkNow = when (stats.darkMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }

    var deckToDelete by remember { mutableStateOf<Deck?>(null) }
    var groupToDelete by remember { mutableStateOf<DeckGroup?>(null) }

    val looseByLang = state.decksOf(null).groupBy { it.sourceLang }

    AppBackground {
        LazyColumn(
            Modifier.statusBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                HeroCard(
                    state = state,
                    onStudy = { onStudy(StudyScope.All, 0L, StudyMode.FlashDue) },
                    onCreate = onCreate,
                    modifier = Modifier.entrance(1),
                )
            }
            item {
                Row(Modifier.entrance(2), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("", "Serie (Tage)", stats.activeStreak, Modifier.weight(1f))
                    StatTile("", "XP", stats.xp, Modifier.weight(1f))
                    StatTile("", "Gemeistert", state.mastered, Modifier.weight(1f))
                }
            }

            if (state.decks.isEmpty() && !state.loading) {
                item { EmptyState(onCreate, Modifier.entrance(3)) }
            }

            items(state.groups, key = { "group-${it.id}" }) { group ->
                GroupCard(
                    group = group,
                    state = state,
                    onOpenDeck = onOpenDeck,
                    onStudyGroup = { onStudy(StudyScope.Group, group.id, StudyMode.FlashDue) },
                    onDeleteGroup = { groupToDelete = group },
                    onDeleteDeck = { deckToDelete = it },
                    modifier = Modifier.animateItem().entrance(3),
                )
            }

            looseByLang.forEach { (lang, list) ->
                item(key = "lang-$lang") {
                    val total = list.sumOf { state.cardsOf(it.id).size }
                    SectionLabel(
                        "${languageName(lang)} • ${list.size} Decks ($total Karten)",
                        Modifier.padding(top = 8.dp).entrance(3),
                    )
                }
                items(list, key = { "deck-${it.id}" }) { deck ->
                    val cards = state.cardsOf(deck.id)
                    DeckRow(
                        deck = deck,
                        cardCount = cards.size,
                        dueCount = cards.count { it.dueAt <= System.currentTimeMillis() },
                        onClick = { onOpenDeck(deck.id) },
                        onDelete = { deckToDelete = deck },
                        modifier = Modifier.animateItem().entrance(4),
                    )
                }
            }
        }
    }

    deckToDelete?.let { deck ->
        ConfirmDialog(
            title = "Deck löschen?",
            text = "„${deck.name}“ und alle ${state.cardsOf(deck.id).size} Karten werden gelöscht.",
            confirmLabel = "Löschen",
            onConfirm = { vm.deleteDeck(deck.id) },
            onDismiss = { deckToDelete = null },
        )
    }
    groupToDelete?.let { group ->
        ConfirmDialog(
            title = "Gruppe löschen?",
            text = "Die Gruppe „${group.name}“ wird gelöscht. Die Decks darin bleiben erhalten.",
            confirmLabel = "Löschen",
            onConfirm = { vm.deleteGroup(group.id, withDecks = false) },
            onDismiss = { groupToDelete = null },
        )
    }
}

@Composable
private fun Header(
    name: String,
    darkNow: Boolean,
    onSearch: () -> Unit,
    onToggleTheme: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        CookieBadge(size = 52.dp, color = cs.primary, lobes = 8, spinMillis = 18000) {
            Icon(Icons.Rounded.Translate, null, tint = cs.onPrimary, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Hallo, $name 👋", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            Text("LingoSnap", style = MaterialTheme.typography.headlineMedium.bold())
        }
        FilledTonalIconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, "Suchen") }
        Spacer(Modifier.width(8.dp))
        FilledTonalIconButton(onClick = onToggleTheme) {
            AnimatedContent(
                targetState = darkNow,
                transitionSpec = {
                    (fadeIn(spring()) + scaleIn(spring(0.5f, 300f), initialScale = 0.4f)) togetherWith
                        (fadeOut() + scaleOut(targetScale = 0.4f))
                },
                label = "themeIcon",
            ) { dark ->
                Icon(if (dark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, "Design wechseln")
            }
        }
    }
}

@Composable
private fun HeroCard(
    state: AppState,
    onStudy: () -> Unit,
    onCreate: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val stats = state.stats
    val due = state.dueCount()
    val goal = stats.dailyGoal.coerceAtLeast(1)
    val ratio = (stats.todayCount / goal.toFloat()).coerceIn(0f, 1f)
    val progress by animateFloatAsState(ratio, label = "goal")

    Surface(
        modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        color = cs.primaryContainer,
        contentColor = cs.onPrimaryContainer,
    ) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Column {
                Text(
                    if (due == 1) "1 Karte fällig" else "$due Karten fällig",
                    style = MaterialTheme.typography.headlineMedium.bold(),
                )
                Text(
                    "Tagesziel: ${stats.todayCount} von $goal",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            WavyProgressBar(progress = progress, color = cs.primary, trackColor = cs.onPrimaryContainer.copy(alpha = 0.15f))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onStudy, enabled = due > 0) { Text("Jetzt lernen") }
                OutlinedButton(onClick = onCreate) { Text("Neues Deck") }
            }
        }
    }
}

@Composable
private fun HeroChip(text: String) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.large, color = cs.onPrimary.copy(alpha = 0.18f), contentColor = cs.onPrimary) {
        Text(text, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge.bold())
    }
}

@Composable
private fun GroupCard(
    group: DeckGroup,
    state: AppState,
    onOpenDeck: (Long) -> Unit,
    onStudyGroup: () -> Unit,
    onDeleteGroup: () -> Unit,
    onDeleteDeck: (Deck) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var expanded by rememberSaveable(group.id) { mutableStateOf(true) }
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, spring(0.6f, 300f), label = "chevron")
    val decks = state.decksOf(group.id)
    val cardTotal = decks.sumOf { state.cardsOf(it.id).size }
    val source = remember { MutableInteractionSource() }

    Surface(modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainer) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(interactionSource = source, indication = null) { expanded = !expanded }
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(Modifier.size(46.dp), shape = MaterialTheme.shapes.medium, color = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Folder, null) }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(group.name, style = MaterialTheme.typography.titleLarge.bold())
                    Text("${decks.size} Decks • $cardTotal Karten", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
                Icon(Icons.Rounded.ExpandMore, null, Modifier.graphicsLayer { rotationZ = chevron })
            }
            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(spring(0.8f, 300f)) + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) {
                Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = onStudyGroup, enabled = decks.isNotEmpty()) {
                            Icon(Icons.Rounded.PlayArrow, null)
                            Spacer(Modifier.width(4.dp))
                            Text("Gruppe lernen")
                        }
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = onDeleteGroup) { Icon(Icons.Rounded.Delete, "Gruppe löschen") }
                    }
                    if (decks.isEmpty()) {
                        Text(
                            "Noch leer – wähle beim Erstellen eines Decks diese Gruppe aus.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp),
                        )
                    }
                    decks.forEach { deck ->
                        val cards = state.cardsOf(deck.id)
                        DeckRow(
                            deck = deck,
                            cardCount = cards.size,
                            dueCount = cards.count { it.dueAt <= System.currentTimeMillis() },
                            onClick = { onOpenDeck(deck.id) },
                            onDelete = { onDeleteDeck(deck) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeckRow(
    deck: Deck,
    cardCount: Int,
    dueCount: Int,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    Surface(
        modifier.fillMaxWidth().pressScale(source, 0.97f),
        shape = MaterialTheme.shapes.large,
        color = cs.surfaceContainerHigh,
    ) {
        Row(
            Modifier
                .clickable(interactionSource = source, indication = null, onClick = onClick)
                .padding(start = 14.dp, end = 4.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LangBadge(deck.sourceLang)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(deck.name, style = MaterialTheme.typography.titleMedium.bold(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("$cardCount Karten", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
            if (dueCount > 0) {
                InfoChip("$dueCount fällig", container = cs.primaryContainer, content = cs.onPrimaryContainer)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Deck löschen", tint = cs.onSurfaceVariant) }
        }
    }
}

@Composable
private fun EmptyState(onCreate: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.fillMaxWidth().padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Noch keine Decks", style = MaterialTheme.typography.headlineSmall.bold())
        Text(
            "Erstelle ein Deck von Hand, mit KI oder per Foto von deiner Buchseite.",
            style = MaterialTheme.typography.bodyLarge,
            color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(4.dp))
        Button(onClick = onCreate) {
            Icon(Icons.Rounded.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Erstes Deck erstellen")
        }
    }
}
