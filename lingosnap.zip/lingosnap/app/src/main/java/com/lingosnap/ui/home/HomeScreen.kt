package com.lingosnap.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.AppState
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.theme.bold

@Composable
fun HomeScreen(
    onOpenDeck: (Long) -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onCreate: () -> Unit,
    onSearch: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val cs = MaterialTheme.colorScheme
    var deckToDelete by remember { mutableStateOf<Deck?>(null) }
    var groupToDelete by remember { mutableStateOf<DeckGroup?>(null) }

    val due = state.dueCount()
    val goal = stats.dailyGoal.coerceAtLeast(1)
    val goalProgress by animateFloatAsState((stats.todayCount / goal.toFloat()).coerceIn(0f, 1f), label = "goal")
    val loose = state.decksOf(null)

    AppBackground {
        LazyColumn(
            Modifier.statusBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Heute", style = MaterialTheme.typography.displaySmall.bold())
                    Text(
                        if (due == 1) "1 Karte ist fällig" else "$due Karten sind fällig",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurfaceVariant,
                    )
                    WavyProgressBar(goalProgress)
                    Text(
                        "Tagesziel ${stats.todayCount} / $goal  •  Serie ${stats.activeStreak} Tage  •  Level ${stats.level}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onStudy(StudyScope.All, 0L, StudyMode.FlashDue) }, enabled = due > 0) { Text("Lernen") }
                        OutlinedButton(onClick = onCreate) { Text("Neues Deck") }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }

            if (state.decks.isEmpty() && !state.loading) {
                item {
                    Text(
                        "Noch keine Decks. Lege über „Neues Deck“ dein erstes an – von Hand, per KI oder mit einem Foto.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                    )
                }
            }

            items(state.groups, key = { "g${it.id}" }) { group ->
                GroupSection(
                    group = group,
                    state = state,
                    onOpenDeck = onOpenDeck,
                    onStudyGroup = { onStudy(StudyScope.Group, group.id, StudyMode.FlashDue) },
                    onDeleteGroup = { groupToDelete = group },
                    onDeleteDeck = { deckToDelete = it },
                )
            }

            if (loose.isNotEmpty()) {
                item {
                    Text(
                        if (state.groups.isEmpty()) "Decks" else "Weitere Decks",
                        style = MaterialTheme.typography.titleSmall.bold(),
                        color = cs.primary,
                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
                    )
                }
                items(loose, key = { "d${it.id}" }) { deck ->
                    DeckItem(deck, state, onOpenDeck) { deckToDelete = deck }
                }
            }
        }
    }

    deckToDelete?.let { deck ->
        ConfirmDialog(
            title = "Deck löschen?",
            text = "„${deck.name}“ und alle ${state.cardsOf(deck.id).size} Karten werden gelöscht.",
            confirmLabel = "Löschen",
            onConfirm = { vm.deleteDeck(deck.id) },
            onDismiss = { deckToDelete = null },
        )
    }
    groupToDelete?.let { group ->
        ConfirmDialog(
            title = "Gruppe löschen?",
            text = "Die Gruppe „${group.name}“ wird gelöscht. Die Decks darin bleiben erhalten.",
            confirmLabel = "Löschen",
            onConfirm = { vm.deleteGroup(group.id, withDecks = false) },
            onDismiss = { groupToDelete = null },
        )
    }
}

@Composable
private fun GroupSection(
    group: DeckGroup,
    state: AppState,
    onOpenDeck: (Long) -> Unit,
    onStudyGroup: () -> Unit,
    onDeleteGroup: () -> Unit,
    onDeleteDeck: (Deck) -> Unit,
) {
    var expanded by rememberSaveable(group.id) { mutableStateOf(true) }
    val rotation by animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
    val decks = state.decksOf(group.id)
    Column(Modifier.fillMaxWidth().animateContentSize()) {
        ListItem(
            modifier = Modifier.clickable { expanded = !expanded },
            headlineContent = { Text(group.name, style = MaterialTheme.typography.titleMedium.bold()) },
            supportingContent = { Text("${decks.size} Decks • ${decks.sumOf { state.cardsOf(it.id).size }} Karten") },
            trailingContent = { Icon(Icons.Rounded.ExpandMore, null, Modifier.graphicsLayer { rotationZ = rotation }) },
        )
        AnimatedVisibility(expanded) {
            Column {
                Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onStudyGroup, enabled = decks.isNotEmpty()) { Text("Gruppe lernen") }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onDeleteGroup) { Icon(Icons.Rounded.Delete, "Gruppe löschen") }
                }
                decks.forEach { deck -> DeckItem(deck, state, onOpenDeck) { onDeleteDeck(deck) } }
            }
        }
        HorizontalDivider(Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun DeckItem(deck: Deck, state: AppState, onOpen: (Long) -> Unit, onDelete: () -> Unit) {
    val cards = state.cardsOf(deck.id)
    val due = cards.count { it.dueAt <= System.currentTimeMillis() }
    ListItem(
        modifier = Modifier.clickable { onOpen(deck.id) },
        headlineContent = { Text(deck.name) },
        supportingContent = {
            Text("${cards.size} Karten • ${languageName(deck.sourceLang)}" + if (due > 0) " • $due fällig" else "")
        },
        trailingContent = { IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Deck löschen") } },
    )
}
