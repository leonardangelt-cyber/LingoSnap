package com.lingosnap.ui.home

import com.lingosnap.util.tr
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.rounded.*

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import androidx.compose.ui.Alignment
import androidx.compose.material3.Surface
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import com.lingosnap.ui.components.LearnMethodSheet
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.data.model.languageName
import com.lingosnap.data.model.typeLabelFor
import com.lingosnap.container
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenDeck: (Long) -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onNewDeck: (deckId: Long, method: Int) -> Unit,
    onSettings: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    var deckToDelete by remember { mutableStateOf<Deck?>(null) }
    var deckToFolder by remember { mutableStateOf<Deck?>(null) }
    var newGroup by remember { mutableStateOf(false) }
    var groupToRename by remember { mutableStateOf<com.lingosnap.data.model.DeckGroup?>(null) }
    var groupToDelete by remember { mutableStateOf<com.lingosnap.data.model.DeckGroup?>(null) }
    // groups the learner closed (all are open at first)
    var collapsed by remember { mutableStateOf(setOf<Long>()) }
    var method by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var parsed by remember { mutableStateOf<com.lingosnap.util.ParsedImport?>(null) }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { com.lingosnap.util.ImportParsers.parse(ctx, uri) }
                .onSuccess { parsed = it }
                .onFailure { Toast.makeText(ctx, it.message ?: tr("Datei konnte nicht gelesen werden"), Toast.LENGTH_LONG).show() }
        }
    }
    val feedback = LocalContext.current.container.feedback
    var learnMode by remember { mutableStateOf(feedback.learnMode) }

    var importMenu by remember { mutableStateOf(false) }
    val incoming by com.lingosnap.util.PendingImport.state.collectAsStateWithLifecycle()
    androidx.compose.runtime.LaunchedEffect(incoming) {
        incoming?.let { parsed = it; com.lingosnap.util.PendingImport.state.value = null }
    }
    var searching by remember { mutableStateOf(false) }
    var pills by remember { mutableStateOf(false) }
    var newKind by remember { mutableStateOf<Boolean?>(null) }
    val pager = androidx.compose.foundation.pager.rememberPagerState { 1 }
    val tab = pager.currentPage
    val jobs by com.lingosnap.util.AiJobs.state.collectAsStateWithLifecycle()

    val blur by androidx.compose.animation.core.animateDpAsState(if (pills) 16.dp else 0.dp, androidx.compose.animation.core.spring(0.8f, 300f), label = "blur")
    Box(Modifier.fillMaxSize()) {
    Box(Modifier.fillMaxSize().blur(blur)) {
    LargeScreen(
        title = tr("Decks"),
        actions = {
            IconButton(onClick = { searching = true }) { Icon(Icons.Rounded.Search, tr("Suchen")) }
            IconButton(onClick = { newGroup = true }) { Icon(Icons.Rounded.CreateNewFolder, tr("Neue Gruppe")) }
            Box {
                IconButton(onClick = { importMenu = true }) { Icon(Icons.Rounded.FileDownload, tr("Importieren")) }
                com.lingosnap.ui.components.AppMenu(expanded = importMenu, onDismiss = { importMenu = false }) {
                    com.lingosnap.ui.components.AppMenuItem(tr("Datei wählen"), Icons.Rounded.UploadFile, supporting = tr("Backup, CSV, Anki, Quizlet"), onClick = { importMenu = false; importPicker.launch(com.lingosnap.util.ImportParsers.MIME_TYPES) })
                    com.lingosnap.ui.components.AppMenuItem(tr("Link aus Zwischenablage"), Icons.Rounded.ContentPaste, onClick = {
                        importMenu = false
                        val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                        val found = com.lingosnap.util.DeckLink.decode(text)
                        if (found != null) parsed = found
                        else Toast.makeText(ctx, tr("In der Zwischenablage ist kein LingoSnap-Link."), Toast.LENGTH_LONG).show()
                    })
                }
            }
            IconButton(onClick = { method = true }) { Icon(Icons.Rounded.School, tr("Lernmethode")) }
            IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, tr("Optionen")) }
        },
        floatingActionButton = {
            androidx.compose.animation.AnimatedVisibility(
                visible = !pills,
                enter = androidx.compose.animation.scaleIn(androidx.compose.animation.core.spring(0.6f, 400f)) + androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
            ) {
                androidx.compose.material3.ExtendedFloatingActionButton(
                    onClick = { newKind = true },
                    icon = { Icon(Icons.Rounded.Add, null) },
                    text = { Text(tr("Neues Deck")) },
                )
            }
        },
    ) { inner ->
        Column(Modifier.padding(inner)) {
            androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.weight(1f)) { page ->
            // one list: the learner's groups first (inside a group the decks are sorted by language), then the decks without a group by language
            val shownDecks = state.decks
            val labels = remember(shownDecks, state.cards) { shownDecks.associate { it.id to languageLabel(it, state.cardsOf(it.id)) } }
            fun byLanguage(decks: List<Deck>) = decks.groupBy { labels[it.id].orEmpty() }.toList()
                .sortedWith(compareBy({ it.first == tr("Sprache offen") }, { it.first }))
            val groupIds = state.groups.map { it.id }.toSet()
            val ungrouped = shownDecks.filter { it.groupId == null || it.groupId !in groupIds }

            val deckRow: @Composable (Deck, Int, Int, Modifier) -> Unit = { deck, i, count, mod ->
                val cards = state.cardsOf(deck.id)
                val due = cards.count { it.dueAt <= System.currentTimeMillis() }
                val job = jobs[deck.id]
                SegmentedItem(
                    index = i,
                    count = count,
                    headline = deck.name,
                    supporting = job?.let { "${it.percent} % • ${it.status}" } ?: tr("{0} • {1} Karten", deck.typeLabelFor(cards), cards.size),
                    progress = job?.let { it.percent / 100f },
                    leading = { com.lingosnap.ui.components.IconBadge(if (deck.isLanguage) Icons.Rounded.Translate else Icons.Rounded.Style, 44, cs.secondaryContainer, cs.onSecondaryContainer) },
                    onClick = { onOpenDeck(deck.id) },
                    trailing = {
                        if (job != null) IconButton(onClick = { com.lingosnap.util.AiJobs.cancel(deck.id) }) {
                            Icon(Icons.Rounded.Close, tr("KI-Vorgang abbrechen"))
                        } else Row(verticalAlignment = Alignment.CenterVertically) {
                            if (due > 0) {
                                Surface(shape = RoundedCornerShape(50), color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
                                    Text(tr("{0} fällig", due), Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            var menu by remember { mutableStateOf(false) }
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, tr("Mehr")) }
                                com.lingosnap.ui.components.AppMenu(expanded = menu, onDismiss = { menu = false }) {
                                    com.lingosnap.ui.components.AppMenuItem(tr("In Gruppe legen"), Icons.Rounded.Folder, onClick = { menu = false; deckToFolder = deck })
                                    com.lingosnap.ui.components.AppMenuItem(tr("Deck löschen"), Icons.Rounded.Delete, danger = true, onClick = { menu = false; deckToDelete = deck })
                                }
                            }
                        }
                    },
                    modifier = mod,
                )
            }

            LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (shownDecks.isEmpty() && state.groups.isEmpty() && !state.loading) {
                item {
                    Text(
                        tr("Noch keine Decks. Tippe auf „Neues Deck“, um loszulegen."),
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
            }
            // groups: a row like a normal list entry; opened, a box holds the group's lists, separated by language
            state.groups.forEach { g ->
                val inGroup = state.decksOf(g.id)
                val open = g.id !in collapsed
                item(key = "g-${g.id}") {
                    Column(Modifier.padding(top = 12.dp).animateItem()) {
                        GroupCard(
                            name = g.name,
                            decks = inGroup.size,
                            cards = inGroup.sumOf { state.cardsOf(it.id).size },
                            due = inGroup.sumOf { d -> state.cardsOf(d.id).count { it.dueAt <= System.currentTimeMillis() } },
                            open = open,
                            onToggle = { collapsed = if (open) collapsed + g.id else collapsed - g.id },
                            onStudy = { onStudy(StudyScope.Group, g.id, StudyMode.FlashDue) },
                            onRename = { groupToRename = g },
                            onDelete = { groupToDelete = g },
                        )
                        androidx.compose.animation.AnimatedVisibility(visible = open) {
                            Surface(
                                Modifier.fillMaxWidth().padding(top = 6.dp),
                                shape = RoundedCornerShape(28.dp),
                                color = cs.surfaceContainerHigh,
                            ) {
                                Column(Modifier.padding(horizontal = 8.dp, vertical = 10.dp)) {
                                    if (inGroup.isEmpty()) {
                                        Text(
                                            tr("Diese Gruppe ist leer. Lege Decks über das Menü (drei Punkte) eines Decks hinein."),
                                            style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        )
                                    }
                                    byLanguage(inGroup).forEachIndexed { n, (label, decks) ->
                                        Row(
                                            Modifier.padding(start = 12.dp, end = 12.dp, top = if (n == 0) 2.dp else 14.dp, bottom = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Icon(Icons.Rounded.Translate, null, Modifier.size(16.dp), tint = cs.primary)
                                            Spacer(Modifier.width(8.dp))
                                            Text(label, style = MaterialTheme.typography.labelLarge, color = cs.primary)
                                        }
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            decks.forEachIndexed { i, d -> deckRow(d, i, decks.size, Modifier) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // decks without a group, by language
            byLanguage(ungrouped).forEach { (label, decks) ->
                item(key = "h-${label}") { GroupHeader(label, icon = Icons.Rounded.Translate) }
                items(decks.size, key = { decks[it].id }) { i -> deckRow(decks[i], i, decks.size, Modifier.animateItem()) }
            }
        }
            }
        }
    }
    }
    com.lingosnap.ui.create.NewDeckOverlay(pills, onPick = { pills = false; newKind = it }, onDismiss = { pills = false })
    }

    newKind?.let { lang ->
        com.lingosnap.ui.create.NewDeckSheet(
            languageDeck = lang,
            existingSubjects = remember(state.decks) {
                state.decks.filter { !it.isLanguage }.map { it.description.substringBefore(',').substringBefore('\n').trim() }
                    .filter { it.isNotBlank() }.distinct().sorted().take(12)
            },
            onChosen = { id, method -> newKind = null; onNewDeck(id, method) },
            onDismiss = { newKind = null },
        )
    }
    if (searching) SearchOverlay(state.decks, state.cards, onOpenDeck = onOpenDeck, onDismiss = { searching = false })

    parsed?.let { p ->
        ImportDialog(p, onDismiss = { parsed = null })
    }

    if (method) {
        LearnMethodSheet(
            current = learnMode,
            onPick = { learnMode = it; feedback.learnMode = it; method = false },
            onDismiss = { method = false },
        )
    }

    if (newGroup) NameDialog(tr("Neue Gruppe"), tr("Name der Gruppe"), "", tr("Anlegen"), onConfirm = { vm.createGroup(it); newGroup = false }, onDismiss = { newGroup = false })
    groupToRename?.let { g ->
        NameDialog(tr("Gruppe umbenennen"), tr("Name der Gruppe"), g.name, tr("Speichern"), onConfirm = { vm.renameGroup(g.id, it); groupToRename = null }, onDismiss = { groupToRename = null })
    }
    groupToDelete?.let { g ->
        ConfirmDialog(
            title = tr("Gruppe löschen?"),
            text = tr("Die Gruppe „{0}“ wird gelöscht. Die Decks darin bleiben erhalten.", g.name),
            confirmLabel = tr("Löschen"),
            onConfirm = { vm.deleteGroup(g.id, false) },
            onDismiss = { groupToDelete = null },
        )
    }

    deckToFolder?.let { deck ->
        FolderDialog(
            folders = state.groups.map { it.id to it.name },
            current = deck.groupId,
            onPick = { vm.moveDeckToFolder(deck, it); deckToFolder = null },
            onCreate = { name -> vm.createFolderFor(deck, name); deckToFolder = null },
            onDismiss = { deckToFolder = null },
        )
    }

    deckToDelete?.let { deck ->
        ConfirmDialog(
            title = tr("Deck löschen?"),
            text = tr("„{0}“ und alle {1} Karten werden gelöscht.", deck.name, state.cardsOf(deck.id).size),
            confirmLabel = tr("Löschen"),
            onConfirm = { vm.deleteDeck(deck.id) },
            onDismiss = { deckToDelete = null },
        )
    }
}

/** Language a deck belongs to, for the headings; plain card decks (older versions) show their subject. */
private fun languageLabel(d: Deck, cards: List<com.lingosnap.data.model.Flashcard>): String = when {
    !d.isLanguage -> d.description.substringBefore(',').substringBefore('\n').trim().ifBlank { tr("Karteikarten") }
    d.sourceLang != "auto" -> languageName(d.sourceLang)
    else -> cards.groupingBy { it.sourceLang }.eachCount()
        .maxByOrNull { it.value }?.key?.takeIf { it.isNotBlank() }?.let { languageName(it) } ?: tr("Sprache offen")
}

@Composable
private fun NameDialog(title: String, label: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    com.lingosnap.ui.components.FormSheet(
        title = title,
        icon = Icons.Rounded.Folder,
        onDismiss = onDismiss,
        confirmLabel = confirm,
        confirmEnabled = name.isNotBlank(),
        onConfirm = { onConfirm(name.trim()) },
    ) {
        com.lingosnap.ui.components.AppTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true)
    }
}

/** A group looks like a normal list entry: folder badge, name, size, due badge, open/close and a menu. */
@Composable
private fun GroupCard(
    name: String, decks: Int, cards: Int, due: Int, open: Boolean,
    onToggle: () -> Unit, onStudy: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    SegmentedItem(
        index = 0,
        count = 1,
        headline = name,
        supporting = tr("{0} Decks • {1} Karten", decks, cards),
        modifier = modifier,
        onClick = onToggle,
        leading = {
            com.lingosnap.ui.components.IconBadge(
                if (open) Icons.Rounded.FolderOpen else Icons.Rounded.Folder, 44, cs.tertiaryContainer, cs.onTertiaryContainer,
            )
        },
        trailing = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (due > 0) {
                    Surface(shape = RoundedCornerShape(50), color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
                        Text(tr("{0} fällig", due), Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
                    }
                }
                Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, Modifier.padding(start = 4.dp))
                var menu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, tr("Mehr")) }
                    com.lingosnap.ui.components.AppMenu(expanded = menu, onDismiss = { menu = false }) {
                        if (due > 0) com.lingosnap.ui.components.AppMenuItem(tr("Fällige Karten lernen"), Icons.Rounded.PlayArrow, onClick = { menu = false; onStudy() })
                        com.lingosnap.ui.components.AppMenuItem(tr("Gruppe umbenennen"), Icons.Rounded.Edit, onClick = { menu = false; onRename() })
                        com.lingosnap.ui.components.AppMenuItem(tr("Gruppe löschen"), Icons.Rounded.Delete, danger = true, onClick = { menu = false; onDelete() })
                    }
                }
            }
        },
    )
}

@Composable
private fun FolderDialog(
    folders: List<Pair<Long, String>>,
    current: Long?,
    onPick: (Long?) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    com.lingosnap.ui.components.FormSheet(
        title = tr("In Gruppe legen"),
        icon = Icons.Rounded.Folder,
        onDismiss = onDismiss,
        confirmLabel = tr("Neu anlegen"),
        confirmEnabled = name.isNotBlank(),
        onConfirm = { onCreate(name.trim()) },
    ) {
        val all = listOf<Pair<Long?, String>>(null to tr("Ohne Gruppe")) + folders
        androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            all.forEachIndexed { i, (id, label) ->
                SegmentedItem(
                    index = i, count = all.size, headline = label,
                    onClick = { onPick(id) },
                    trailing = if (id == current) { { Icon(Icons.Rounded.Check, tr("Aktuell")) } } else null,
                )
            }
        }
        com.lingosnap.ui.components.AppTextField(
            name, { name = it }, Modifier.fillMaxWidth(),
            label = { Text(tr("Neue Gruppe")) }, singleLine = true,
        )
    }
}

/** Pill-shaped tab switch: the coloured pill slides along while the pages are swiped. */
@Composable
private fun HomeTabs(
    labels: List<String>,
    counts: List<Int>,
    icons: List<androidx.compose.ui.graphics.vector.ImageVector>,
    position: Float,
    onSelect: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    androidx.compose.foundation.layout.BoxWithConstraints(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(56.dp)
            .clip(RoundedCornerShape(28.dp)).background(cs.surfaceContainerHigh).padding(4.dp),
    ) {
        val w = maxWidth / labels.size
        Box(
            Modifier.offset(x = w * position).width(w).fillMaxHeight()
                .clip(RoundedCornerShape(24.dp)).background(cs.primary),
        )
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, label ->
                val t = (1f - kotlin.math.abs(position - i)).coerceIn(0f, 1f)
                val color = androidx.compose.ui.graphics.lerp(cs.onSurfaceVariant, cs.onPrimary, t)
                Row(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(24.dp)).clickable { onSelect(i) },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(icons[i], null, tint = color, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(label, color = color, style = MaterialTheme.typography.titleSmall)
                    if (counts[i] > 0) {
                        Spacer(Modifier.width(8.dp))
                        Text(counts[i].toString(), color = color.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
