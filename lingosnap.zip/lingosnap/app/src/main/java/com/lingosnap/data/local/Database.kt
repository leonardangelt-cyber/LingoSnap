package com.lingosnap.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.model.Flashcard
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM deck_groups ORDER BY name COLLATE NOCASE")
    fun observeGroups(): Flow<List<DeckGroup>>

    @Query("SELECT * FROM decks ORDER BY createdAt DESC")
    fun observeDecks(): Flow<List<Deck>>

    @Query("SELECT * FROM cards ORDER BY createdAt DESC, id DESC")
    fun observeCards(): Flow<List<Flashcard>>

    @Insert
    suspend fun insertGroup(group: DeckGroup): Long

    @Insert
    suspend fun insertDeck(deck: Deck): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCards(cards: List<Flashcard>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCard(card: Flashcard): Long

    @Update
    suspend fun updateCard(card: Flashcard)

    @Update
    suspend fun updateDeck(deck: Deck)

    @Delete
    suspend fun deleteCard(card: Flashcard)

    @Query("DELETE FROM cards WHERE deckId = :deckId")
    suspend fun deleteCardsOfDeck(deckId: Long)

    @Query("DELETE FROM decks WHERE id = :deckId")
    suspend fun deleteDeck(deckId: Long)

    @Query("UPDATE decks SET groupId = NULL WHERE groupId = :groupId")
    suspend fun ungroupDecks(groupId: Long)

    @Query("DELETE FROM deck_groups WHERE id = :groupId")
    suspend fun deleteGroup(groupId: Long)

    @Query("SELECT * FROM cards WHERE deckId = :deckId")
    suspend fun cardsOfDeck(deckId: Long): List<Flashcard>

    @Query("SELECT * FROM cards")
    suspend fun allCards(): List<Flashcard>

    @Query("SELECT * FROM decks WHERE groupId = :groupId")
    suspend fun decksOfGroup(groupId: Long): List<Deck>

    @Query("SELECT * FROM decks WHERE id = :deckId")
    suspend fun deckById(deckId: Long): Deck?

    @Query("DELETE FROM cards")
    suspend fun clearCards()

    @Query("DELETE FROM decks")
    suspend fun clearDecks()

    @Query("DELETE FROM deck_groups")
    suspend fun clearGroups()
}

@Database(entities = [DeckGroup::class, Deck::class, Flashcard::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
}
