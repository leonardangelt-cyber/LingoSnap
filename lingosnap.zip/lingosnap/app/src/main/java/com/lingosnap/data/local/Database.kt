package com.lingosnap.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.Update
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.model.Flashcard
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM deck_groups ORDER BY name COLLATE NOCASE")
    fun observeGroups(): Flow<List<DeckGroup>>

    @Query("SELECT * FROM decks ORDER BY createdAt DESC")
    fun observeDecks(): Flow<List<Deck>>

    @Query("SELECT * FROM cards ORDER BY createdAt DESC, id DESC")
    fun observeCards(): Flow<List<Flashcard>>

    @Insert
    suspend fun insertGroup(group: DeckGroup): Long

    @Insert
    suspend fun insertDeck(deck: Deck): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCards(cards: List<Flashcard>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCard(card: Flashcard): Long

    @Update
    suspend fun updateCard(card: Flashcard)

    @Update
    suspend fun updateDeck(deck: Deck)

    @Delete
    suspend fun deleteCard(card: Flashcard)

    @Query("DELETE FROM cards WHERE deckId = :deckId")
    suspend fun deleteCardsOfDeck(deckId: Long)

    @Query("DELETE FROM decks WHERE id = :deckId")
    suspend fun deleteDeck(deckId: Long)

    @Query("UPDATE decks SET groupId = NULL WHERE groupId = :groupId")
    suspend fun ungroupDecks(groupId: Long)

    @Query("DELETE FROM deck_groups WHERE id = :groupId")
    suspend fun deleteGroup(groupId: Long)

    @Query("SELECT * FROM cards WHERE deckId = :deckId")
    suspend fun cardsOfDeck(deckId: Long): List<Flashcard>

    @Query("UPDATE cards SET targetLang = :lang WHERE deckId = :deckId")
    suspend fun setTargetLang(deckId: Long, lang: String)

    @Query("UPDATE cards SET sourceLang = :lang WHERE deckId = :deckId")
    suspend fun setSourceLang(deckId: Long, lang: String)

    @Query("SELECT * FROM decks")
    suspend fun allDecks(): List<Deck>

    @Query("SELECT * FROM cards")
    suspend fun allCards(): List<Flashcard>

    @Query("SELECT * FROM decks WHERE groupId = :groupId")
    suspend fun decksOfGroup(groupId: Long): List<Deck>

    @Query("SELECT * FROM decks WHERE id = :deckId")
    suspend fun deckById(deckId: Long): Deck?

    @Query("DELETE FROM cards")
    suspend fun clearCards()

    @Query("DELETE FROM decks")
    suspend fun clearDecks()

    @Query("DELETE FROM deck_groups")
    suspend fun clearGroups()
}

@Database(entities = [DeckGroup::class, Deck::class, Flashcard::class], version = 5, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
}

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE cards ADD COLUMN lapses INTEGER NOT NULL DEFAULT 0")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE cards ADD COLUMN imagePath TEXT")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE cards ADD COLUMN ease REAL NOT NULL DEFAULT 2.5")
        db.execSQL("ALTER TABLE cards ADD COLUMN intervalDays INTEGER NOT NULL DEFAULT 0")
        // existing cards: derive a sensible interval from their old level
        db.execSQL("UPDATE cards SET intervalDays = CASE level WHEN 0 THEN 0 WHEN 1 THEN 1 WHEN 2 THEN 3 WHEN 3 THEN 7 WHEN 4 THEN 14 ELSE 30 END")
    }
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE decks ADD COLUMN kind TEXT NOT NULL DEFAULT 'language'")
    }
}
