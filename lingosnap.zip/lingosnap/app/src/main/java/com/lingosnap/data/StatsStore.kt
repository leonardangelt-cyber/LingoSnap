package com.lingosnap.data

import com.lingosnap.util.tr

import android.content.Context
import androidx.core.content.edit
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.levelForXp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max

data class Stats(
    val userName: String = tr("Lerner"),
    val xp: Int = 0,
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val lastDay: String = "",
    val dailyGoal: Int = 10,
    val totalReviews: Int = 0,
    val goalHits: Int = 0,
    val perfectSessions: Int = 0,
    /** ISO date -> reviews that day */
    val history: Map<String, Int> = emptyMap(),
    /** 0 = system, 1 = dark, 2 = light */
    val darkMode: Int = 0,
    /** 0 = Material You (wallpaper), 1..5 = fixed accent colours */
    val accent: Int = 0,
    /** Android theme style of the fixed accent colours (0 = Tonal Spot …) */
    val accentStyle: Int = 0,
    val streakFreeze: Boolean = true,
    /** daily learning reminder (notification) */
    val remindersOn: Boolean = false,
    val reminderHour: Int = 18,
    val reminderMinute: Int = 0,
    /** only remind when cards are due */
    val remindOnlyDue: Boolean = true,
    /** Remembered cards come back less and less often (Gut doubles the gap). Off = the fixed steps. */
    val growIntervals: Boolean = true,
) {
    val level: Int get() = levelForXp(xp)
    val todayCount: Int get() = history[LocalDate.now().toString()] ?: 0

    /** The streak that is still alive today (0 once it is broken). */
    val activeStreak: Int
        get() {
            val last = runCatching { LocalDate.parse(lastDay) }.getOrNull() ?: return 0
            val gap = ChronoUnit.DAYS.between(last, LocalDate.now())
            return when {
                gap <= 1L -> streak
                gap == 2L && streakFreeze -> streak
                else -> 0
            }
        }
}

/** Small SharedPreferences-backed store exposed as a StateFlow. */
class StatsStore(context: Context) {

    private val prefs = context.getSharedPreferences("lingosnap_stats", Context.MODE_PRIVATE)
    private val _stats = MutableStateFlow(load())
    val stats: StateFlow<Stats> = _stats.asStateFlow()

    private fun load(): Stats {
        val history = prefs.getString("history", "").orEmpty()
            .split(",")
            .mapNotNull { entry ->
                val parts = entry.split(":")
                val count = parts.getOrNull(1)?.toIntOrNull()
                if (parts.size == 2 && count != null) parts[0] to count else null
            }.toMap()
        return Stats(
            userName = prefs.getString("userName", tr("Lerner")).orEmpty().ifBlank { tr("Lerner") },
            xp = prefs.getInt("xp", 0),
            streak = prefs.getInt("streak", 0),
            bestStreak = prefs.getInt("bestStreak", 0),
            lastDay = prefs.getString("lastDay", "").orEmpty(),
            dailyGoal = prefs.getInt("dailyGoal", 10),
            totalReviews = prefs.getInt("totalReviews", 0),
            goalHits = prefs.getInt("goalHits", 0),
            perfectSessions = prefs.getInt("perfectSessions", 0),
            history = history,
            darkMode = prefs.getInt("darkMode", 0),
            accent = prefs.getInt("accent", 0),
            accentStyle = prefs.getInt("accentStyle", 0),
            streakFreeze = prefs.getBoolean("streakFreeze", true),
            remindersOn = prefs.getBoolean("remindersOn", false),
            reminderHour = prefs.getInt("reminderHour", 18),
            reminderMinute = prefs.getInt("reminderMinute", 0),
            remindOnlyDue = prefs.getBoolean("remindOnlyDue", true),
            growIntervals = prefs.getBoolean("growIntervals", true),
        )
    }

    private fun update(block: (Stats) -> Stats) {
        val s = block(_stats.value)
        _stats.value = s
        prefs.edit {
            putString("userName", s.userName)
            putInt("xp", s.xp)
            putInt("streak", s.streak)
            putInt("bestStreak", s.bestStreak)
            putString("lastDay", s.lastDay)
            putInt("dailyGoal", s.dailyGoal)
            putInt("totalReviews", s.totalReviews)
            putInt("goalHits", s.goalHits)
            putInt("perfectSessions", s.perfectSessions)
            putString("history", s.history.entries.joinToString(",") { "${it.key}:${it.value}" })
            putInt("darkMode", s.darkMode)
            putInt("accent", s.accent)
            putInt("accentStyle", s.accentStyle)
            putBoolean("streakFreeze", s.streakFreeze)
            putBoolean("remindersOn", s.remindersOn)
            putInt("reminderHour", s.reminderHour)
            putInt("reminderMinute", s.reminderMinute)
            putBoolean("remindOnlyDue", s.remindOnlyDue)
            putBoolean("growIntervals", s.growIntervals)
        }
    }

    fun recordReview(rating: Rating) = update { s ->
        val todayDate = LocalDate.now()
        val today = todayDate.toString()
        val before = s.history[today] ?: 0

        var streak = s.streak
        if (s.lastDay != today) {
            val last = runCatching { LocalDate.parse(s.lastDay) }.getOrNull()
            val gap = if (last == null) Long.MAX_VALUE else ChronoUnit.DAYS.between(last, todayDate)
            streak = when {
                gap == 1L -> s.streak + 1
                gap == 2L && s.streakFreeze -> s.streak + 1
                else -> 1
            }
        }
        val history = (s.history + (today to before + 1)).entries
            .sortedByDescending { it.key }
            .take(60)
            .associate { it.key to it.value }

        s.copy(
            xp = s.xp + rating.xp,
            streak = streak,
            bestStreak = max(s.bestStreak, streak),
            lastDay = today,
            totalReviews = s.totalReviews + 1,
            goalHits = s.goalHits + if (before + 1 == s.dailyGoal) 1 else 0,
            history = history,
        )
    }

    fun addXp(amount: Int) = update { it.copy(xp = it.xp + amount) }
    fun recordPerfectSession() = update { it.copy(perfectSessions = it.perfectSessions + 1) }

    fun setUserName(name: String) = update { it.copy(userName = name.trim().ifBlank { tr("Lerner") }) }
    fun setDarkMode(mode: Int) = update { it.copy(darkMode = mode) }
    fun setAccent(accent: Int) = update { it.copy(accent = accent) }
    fun setAccentStyle(style: Int) = update { it.copy(accentStyle = style) }
    fun setDailyGoal(goal: Int) = update { it.copy(dailyGoal = goal) }
    fun setReminders(on: Boolean) = update { it.copy(remindersOn = on) }
    fun setReminderTime(hour: Int, minute: Int) = update { it.copy(reminderHour = hour, reminderMinute = minute) }
    fun setRemindOnlyDue(on: Boolean) = update { it.copy(remindOnlyDue = on) }
    fun setStreakFreeze(on: Boolean) = update { it.copy(streakFreeze = on) }
    fun setGrowIntervals(on: Boolean) = update { it.copy(growIntervals = on) }
    fun resetAll() = update { Stats(darkMode = it.darkMode, accent = it.accent, accentStyle = it.accentStyle, userName = it.userName, remindersOn = it.remindersOn, reminderHour = it.reminderHour, reminderMinute = it.reminderMinute, remindOnlyDue = it.remindOnlyDue, growIntervals = it.growIntervals) }
}
