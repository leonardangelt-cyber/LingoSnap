package com.lingosnap.data

import android.content.Context
import androidx.core.content.edit
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.levelForXp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max

data class Stats(
    val userName: String = "Lerner",
    val xp: Int = 0,
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val lastDay: String = "",
    val dailyGoal: Int = 10,
    val totalReviews: Int = 0,
    val goalHits: Int = 0,
    val perfectSessions: Int = 0,
    /** ISO date -> reviews that day */
    val history: Map<String, Int> = emptyMap(),
    /** 0 = system, 1 = dark, 2 = light */
    val darkMode: Int = 0,
    /** 0 = Material You (wallpaper), 1..5 = fixed accent colours */
    val accent: Int = 0,
    val streakFreeze: Boolean = true,
) {
    val level: Int get() = levelForXp(xp)
    val todayCount: Int get() = history[LocalDate.now().toString()] ?: 0

    /** The streak that is still alive today (0 once it is broken). */
    val activeStreak: Int
        get() {
            val last = runCatching { LocalDate.parse(lastDay) }.getOrNull() ?: return 0
            val gap = ChronoUnit.DAYS.between(last, LocalDate.now())
            return when {
                gap <= 1L -> streak
                gap == 2L && streakFreeze -> streak
                else -> 0
            }
        }
}

/** Small SharedPreferences-backed store exposed as a StateFlow. */
class StatsStore(context: Context) {

    private val prefs = context.getSharedPreferences("lingosnap_stats", Context.MODE_PRIVATE)
    private val _stats = MutableStateFlow(load())
    val stats: StateFlow<Stats> = _stats.asStateFlow()

    private fun load(): Stats {
        val history = prefs.getString("history", "").orEmpty()
            .split(",")
            .mapNotNull { entry ->
                val parts = entry.split(":")
                val count = parts.getOrNull(1)?.toIntOrNull()
                if (parts.size == 2 && count != null) parts[0] to count else null
            }.toMap()
        return Stats(
            userName = prefs.getString("userName", "Lerner").orEmpty().ifBlank { "Lerner" },
            xp = prefs.getInt("xp", 0),
            streak = prefs.getInt("streak", 0),
            bestStreak = prefs.getInt("bestStreak", 0),
            lastDay = prefs.getString("lastDay", "").orEmpty(),
            dailyGoal = prefs.getInt("dailyGoal", 10),
            totalReviews = prefs.getInt("totalReviews", 0),
            goalHits = prefs.getInt("goalHits", 0),
            perfectSessions = prefs.getInt("perfectSessions", 0),
            history = history,
            darkMode = prefs.getInt("darkMode", 0),
            accent = prefs.getInt("accent", 0),
            streakFreeze = prefs.getBoolean("streakFreeze", true),
        )
    }

    private fun update(block: (Stats) -> Stats) {
        val s = block(_stats.value)
        _stats.value = s
        prefs.edit {
            putString("userName", s.userName)
            putInt("xp", s.xp)
            putInt("streak", s.streak)
            putInt("bestStreak", s.bestStreak)
            putString("lastDay", s.lastDay)
            putInt("dailyGoal", s.dailyGoal)
            putInt("totalReviews", s.totalReviews)
            putInt("goalHits", s.goalHits)
            putInt("perfectSessions", s.perfectSessions)
            putString("history", s.history.entries.joinToString(",") { "${it.key}:${it.value}" })
            putInt("darkMode", s.darkMode)
            putInt("accent", s.accent)
            putBoolean("streakFreeze", s.streakFreeze)
        }
    }

    fun recordReview(rating: Rating) = update { s ->
        val todayDate = LocalDate.now()
        val today = todayDate.toString()
        val before = s.history[today] ?: 0

        var streak = s.streak
        if (s.lastDay != today) {
            val last = runCatching { LocalDate.parse(s.lastDay) }.getOrNull()
            val gap = if (last == null) Long.MAX_VALUE else ChronoUnit.DAYS.between(last, todayDate)
            streak = when {
                gap == 1L -> s.streak + 1
                gap == 2L && s.streakFreeze -> s.streak + 1
                else -> 1
            }
        }
        val history = (s.history + (today to before + 1)).entries
            .sortedByDescending { it.key }
            .take(60)
            .associate { it.key to it.value }

        s.copy(
            xp = s.xp + rating.xp,
            streak = streak,
            bestStreak = max(s.bestStreak, streak),
            lastDay = today,
            totalReviews = s.totalReviews + 1,
            goalHits = s.goalHits + if (before + 1 == s.dailyGoal) 1 else 0,
            history = history,
        )
    }

    fun addXp(amount: Int) = update { it.copy(xp = it.xp + amount) }
    fun recordPerfectSession() = update { it.copy(perfectSessions = it.perfectSessions + 1) }

    fun setUserName(name: String) = update { it.copy(userName = name.trim().ifBlank { "Lerner" }) }
    fun setDarkMode(mode: Int) = update { it.copy(darkMode = mode) }
    fun setAccent(accent: Int) = update { it.copy(accent = accent) }
    fun setDailyGoal(goal: Int) = update { it.copy(dailyGoal = goal) }
    fun setStreakFreeze(on: Boolean) = update { it.copy(streakFreeze = on) }
    fun resetAll() = update { Stats(darkMode = it.darkMode, accent = it.accent, userName = it.userName) }
}
