package com.lingosnap.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/**
 * LingoSnap's own symbol set: solid, rounded shapes with cut-outs for the details (Material 3 Expressive feel).
 * Everything stays inside a safe area of the 24 grid so nothing is clipped at the edge. kind 0 = rounded line, 1 = solid shape.
 */
private fun icon(name: String, vararg layers: Pair<String, Int>): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
        for ((d, kind) in layers) {
            addPath(
                pathData = addPathNodes(d),
                fill = if (kind == 0) null else SolidColor(Color.Black),
                pathFillType = PathFillType.EvenOdd,
                stroke = if (kind == 1) null else SolidColor(Color.Black),
                strokeLineWidth = 2.4f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            )
        }
    }.build()

object AppIcon {
    val Add: ImageVector by lazy { icon("Add", "M12 5.5v13M5.5 12h13" to 0) }
    val Close: ImageVector by lazy { icon("Close", "M6.5 6.5l11 11M17.5 6.5l-11 11" to 0) }
    val Check: ImageVector by lazy { icon("Check", "M5.5 12.5l4.2 4.2L18.5 7.5" to 0) }
    val Done: ImageVector by lazy { icon("Done", "M3.5 12a8.5 8.5 0 1 0 17.0 0a8.5 8.5 0 1 0 -17.0 0ZM7.6 12.3l1.3-1.3 2.2 2.2 4.1-4.1 1.3 1.3-5.4 5.4Z" to 1) }
    val CheckCircle: ImageVector by lazy { icon("CheckCircle", "M3.6999999999999993 12a8.3 8.3 0 1 0 16.6 0a8.3 8.3 0 1 0 -16.6 0Z" to 0, "M8.2 12.3l2.6 2.6 5-5.4" to 0) }
    val ErrorOutline: ImageVector by lazy { icon("ErrorOutline", "M3.6999999999999993 12a8.3 8.3 0 1 0 16.6 0a8.3 8.3 0 1 0 -16.6 0Z" to 0, "M12 7.8v5" to 0, "M10.85 16.2a1.15 1.15 0 1 0 2.3 0a1.15 1.15 0 1 0 -2.3 0Z" to 1) }
    val WarningAmber: ImageVector by lazy { icon("WarningAmber", "M12 4.8L20 18.5H4Z" to 0, "M12 10.3v3.4" to 0, "M10.9 16.6a1.1 1.1 0 1 0 2.2 0a1.1 1.1 0 1 0 -2.2 0Z" to 1) }
    val ArrowBack: ImageVector by lazy { icon("ArrowBack", "M19 12H5.5M11.5 6l-6 6 6 6" to 0) }
    val ArrowForward: ImageVector by lazy { icon("ArrowForward", "M5 12h13.5M12.5 6l6 6-6 6" to 0) }
    val KeyboardArrowRight: ImageVector by lazy { icon("KeyboardArrowRight", "M9.5 6.5l5.5 5.5-5.5 5.5" to 0) }
    val KeyboardArrowDown: ImageVector by lazy { icon("KeyboardArrowDown", "M6.5 9.5l5.5 5.5 5.5-5.5" to 0) }
    val MoreVert: ImageVector by lazy { icon("MoreVert", "M10.1 5.8a1.9 1.9 0 1 0 3.8 0a1.9 1.9 0 1 0 -3.8 0Z" to 1, "M10.1 12a1.9 1.9 0 1 0 3.8 0a1.9 1.9 0 1 0 -3.8 0Z" to 1, "M10.1 18.2a1.9 1.9 0 1 0 3.8 0a1.9 1.9 0 1 0 -3.8 0Z" to 1) }
    val Search: ImageVector by lazy { icon("Search", "M4.5 10.5a6 6 0 1 0 12 0a6 6 0 1 0 -12 0Z" to 0, "M15.2 15.2l4.3 4.3" to 0) }
    val Edit: ImageVector by lazy { icon("Edit", "M4.5 19.5l1-4.2 9.3-9.3 3.2 3.2-9.3 9.3Z M16.2 4.6l1-1a1.6 1.6 0 012.3 0l.9.9a1.6 1.6 0 010 2.3l-1 1Z" to 1) }
    val EditNote: ImageVector by lazy { icon("EditNote", "M8 4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4v-8a4 4 0 0 1 4 -4ZM8.4 9h7.2a0.9 0.9 0 0 1 0.9 0.9v0.0a0.9 0.9 0 0 1 -0.9 0.9h-7.2a0.9 0.9 0 0 1 -0.9 -0.9v-0.0a0.9 0.9 0 0 1 0.9 -0.9ZM8.4 13h3.7a0.9 0.9 0 0 1 0.9 0.9v0.0a0.9 0.9 0 0 1 -0.9 0.9h-3.7a0.9 0.9 0 0 1 -0.9 -0.9v-0.0a0.9 0.9 0 0 1 0.9 -0.9Z" to 1) }
    val Delete: ImageVector by lazy { icon("Delete", "M6.5 8.5h11l-.9 10a2 2 0 01-2 1.8H9.4a2 2 0 01-2-1.8ZM10.4 11h0.0a0.8 0.8 0 0 1 0.8 0.8v4.4a0.8 0.8 0 0 1 -0.8 0.8h-0.0a0.8 0.8 0 0 1 -0.8 -0.8v-4.4a0.8 0.8 0 0 1 0.8 -0.8ZM13.600000000000001 11h0.0a0.8 0.8 0 0 1 0.8 0.8v4.4a0.8 0.8 0 0 1 -0.8 0.8h-0.0a0.8 0.8 0 0 1 -0.8 -0.8v-4.4a0.8 0.8 0 0 1 0.8 -0.8Z" to 1, "M5 6.2h14M9.6 6.2V5a1 1 0 011-1h2.8a1 1 0 011 1v1.2" to 0) }
    val DeleteForever: ImageVector by lazy { icon("DeleteForever", "M6.5 8.5h11l-.9 10a2 2 0 01-2 1.8H9.4a2 2 0 01-2-1.8ZM9.7 11.6l.9-.9 1.4 1.4 1.4-1.4.9.9-1.4 1.4 1.4 1.4-.9.9-1.4-1.4-1.4 1.4-.9-.9 1.4-1.4Z" to 1, "M5 6.2h14M9.6 6.2V5a1 1 0 011-1h2.8a1 1 0 011 1v1.2" to 0) }
    val Save: ImageVector by lazy { icon("Save", "M5.5 4h10.2L20 8.3V18a2 2 0 01-2 2H6a2 2 0 01-2-2V5.5A1.5 1.5 0 015.5 4ZM8.9 5.8h4.2a0.9 0.9 0 0 1 0.9 0.9v1.2a0.9 0.9 0 0 1 -0.9 0.9h-4.2a0.9 0.9 0 0 1 -0.9 -0.9v-1.2a0.9 0.9 0 0 1 0.9 -0.9ZM9.0 13h6.0a1.5 1.5 0 0 1 1.5 1.5v2.0a1.5 1.5 0 0 1 -1.5 1.5h-6.0a1.5 1.5 0 0 1 -1.5 -1.5v-2.0a1.5 1.5 0 0 1 1.5 -1.5Z" to 1) }
    val Share: ImageVector by lazy { icon("Share", "M3.9 12a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" to 1, "M14.9 6.5a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" to 1, "M14.9 17.5a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" to 1, "M8.7 10.9l6.6-3.2M8.7 13.1l6.6 3.2" to 0) }
    val FileDownload: ImageVector by lazy { icon("FileDownload", "M12 4.5v10M7.5 10.5l4.5 4.5 4.5-4.5M5.5 19.2h13" to 0) }
    val UploadFile: ImageVector by lazy { icon("UploadFile", "M6.5 3.5h7l5 5V19a1.5 1.5 0 01-1.5 1.5H6.5A1.5 1.5 0 015 19V5a1.5 1.5 0 011.5-1.5ZM12 10.2l3.2 3.2-1.1 1.1-1.3-1.3V17h-1.6v-3.8l-1.3 1.3-1.1-1.1Z" to 1) }
    val CloudUpload: ImageVector by lazy { icon("CloudUpload", "M7.5 18a4 4 0 01-.5-7.97A5.5 5.5 0 0117.5 9.6 4.2 4.2 0 0116.5 18ZM12 10.6l2.6 2.6-1 1-.9-.9V16.4h-1.4v-3.1l-.9.9-1-1Z" to 1) }
    val Sync: ImageVector by lazy { icon("Sync", "M18.5 12a6.5 6.5 0 00-11.2-4.5M5.5 12a6.5 6.5 0 0011.2 4.5M7 4.5V8h3.5M17 19.5V16h-3.5" to 0) }
    val Replay: ImageVector by lazy { icon("Replay", "M6 12a6 6 0 106-6H8.5M10.5 3.5L8 6l2.5 2.5" to 0) }
    val Shuffle: ImageVector by lazy { icon("Shuffle", "M4 7.5h2.8c4.4 0 4.8 9 9.2 9h2.5M4 16.5h2.8c1.3 0 2.3-.7 3-1.8M13.4 9.3c.8-1 1.7-1.8 2.8-1.8h2.3M16.5 5l2.5 2.5-2.5 2.5M16.5 14l2.5 2.5-2.5 2.5" to 0) }
    val SwapHoriz: ImageVector by lazy { icon("SwapHoriz", "M5 8h13M15 5l3 3-3 3M19 16H6M9 13l-3 3 3 3" to 0) }
    val Translate: ImageVector by lazy { icon("Translate", "M6.5 3.5h3.5a3 3 0 0 1 3 3v2.5a3 3 0 0 1 -3 3h-3.5a3 3 0 0 1 -3 -3v-2.5a3 3 0 0 1 3 -3ZM6.9 6.2h2.6999999999999997a0.7 0.7 0 0 1 0.7 0.7v0.0a0.7 0.7 0 0 1 -0.7 0.7h-2.6999999999999997a0.7 0.7 0 0 1 -0.7 -0.7v-0.0a0.7 0.7 0 0 1 0.7 -0.7ZM6.9 8.6h1.4a0.7 0.7 0 0 1 0.7 0.7v0.0a0.7 0.7 0 0 1 -0.7 0.7h-1.4a0.7 0.7 0 0 1 -0.7 -0.7v-0.0a0.7 0.7 0 0 1 0.7 -0.7Z" to 1, "M14 12h3.5a3 3 0 0 1 3 3v2.5a3 3 0 0 1 -3 3h-3.5a3 3 0 0 1 -3 -3v-2.5a3 3 0 0 1 3 -3ZM14.399999999999999 14.7h2.6999999999999997a0.7 0.7 0 0 1 0.7 0.7v0.0a0.7 0.7 0 0 1 -0.7 0.7h-2.6999999999999997a0.7 0.7 0 0 1 -0.7 -0.7v-0.0a0.7 0.7 0 0 1 0.7 -0.7ZM14.399999999999999 17.1h1.4a0.7 0.7 0 0 1 0.7 0.7v0.0a0.7 0.7 0 0 1 -0.7 0.7h-1.4a0.7 0.7 0 0 1 -0.7 -0.7v-0.0a0.7 0.7 0 0 1 0.7 -0.7Z" to 1) }
    val Style: ImageVector by lazy { icon("Style", "M9 4.8h8a2.7 2.7 0 012.7 2.7V16" to 0, "M6.8 8h6.4a3 3 0 0 1 3 3v6.199999999999999a3 3 0 0 1 -3 3h-6.4a3 3 0 0 1 -3 -3v-6.199999999999999a3 3 0 0 1 3 -3ZM7.8 12h4.4a0.8 0.8 0 0 1 0.8 0.8v0.0a0.8 0.8 0 0 1 -0.8 0.8h-4.4a0.8 0.8 0 0 1 -0.8 -0.8v-0.0a0.8 0.8 0 0 1 0.8 -0.8ZM7.8 15.2h2.1999999999999997a0.8 0.8 0 0 1 0.8 0.8v0.0a0.8 0.8 0 0 1 -0.8 0.8h-2.1999999999999997a0.8 0.8 0 0 1 -0.8 -0.8v-0.0a0.8 0.8 0 0 1 0.8 -0.8Z" to 1) }
    val School: ImageVector by lazy { icon("School", "M12 4L3 9l9 5 9-5Z M6.5 12.8v3c0 1.6 2.4 3.2 5.5 3.2s5.5-1.6 5.5-3.2v-3L12 15.6Z" to 1, "M20.5 9.5v5" to 0) }
    val Quiz: ImageVector by lazy { icon("Quiz", "M3.6999999999999993 12a8.3 8.3 0 1 0 16.6 0a8.3 8.3 0 1 0 -16.6 0Z" to 0, "M9.6 9.7a2.4 2.4 0 114 1.8c-.8.6-1.6 1-1.6 2.2" to 0, "M10.9 16.4a1.1 1.1 0 1 0 2.2 0a1.1 1.1 0 1 0 -2.2 0Z" to 1) }
    val Psychology: ImageVector by lazy { icon("Psychology", "M8 20v-3.4C6 15.4 4.5 13.4 4.5 11A7.5 7.5 0 0112 3.5c4.1 0 7.5 3.3 7.5 7.5 0 1.9-.8 3.3-2 4.3V20ZM9.7 10.6a2.3 2.3 0 1 0 4.6 0a2.3 2.3 0 1 0 -4.6 0Z" to 1) }
    val Person: ImageVector by lazy { icon("Person", "M8.2 8a3.8 3.8 0 1 0 7.6 0a3.8 3.8 0 1 0 -7.6 0Z" to 1, "M4.5 20a7.5 6.5 0 0115 0Z" to 1) }
    val Mic: ImageVector by lazy { icon("Mic", "M12.0 3.5h0.0a3.2 3.2 0 0 1 3.2 3.2v4.6a3.2 3.2 0 0 1 -3.2 3.2h-0.0a3.2 3.2 0 0 1 -3.2 -3.2v-4.6a3.2 3.2 0 0 1 3.2 -3.2Z" to 1, "M5.5 11.5a6.5 6.5 0 0013 0M12 18v2.3" to 0) }
    val Lightbulb: ImageVector by lazy { icon("Lightbulb", "M12 3.5a6 6 0 00-3.5 10.9c.5.4.8 1 .8 1.6v.5h5.4v-.5c0-.6.3-1.2.8-1.6A6 6 0 0012 3.5Z" to 1, "M10.100000000000001 17.2h3.8000000000000003a0.8 0.8 0 0 1 0.8 0.8v0.0a0.8 0.8 0 0 1 -0.8 0.8h-3.8000000000000003a0.8 0.8 0 0 1 -0.8 -0.8v-0.0a0.8 0.8 0 0 1 0.8 -0.8Z" to 1, "M11.0 19.6h2.0a0.7 0.7 0 0 1 0.7 0.7v0.0a0.7 0.7 0 0 1 -0.7 0.7h-2.0a0.7 0.7 0 0 1 -0.7 -0.7v-0.0a0.7 0.7 0 0 1 0.7 -0.7Z" to 1) }
    val Keyboard: ImageVector by lazy { icon("Keyboard", "M6 6.5h12a3 3 0 0 1 3 3v5a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3v-5a3 3 0 0 1 3 -3ZM6.15 10.2a0.85 0.85 0 1 0 1.7 0a0.85 0.85 0 1 0 -1.7 0ZM9.450000000000001 10.2a0.85 0.85 0 1 0 1.7 0a0.85 0.85 0 1 0 -1.7 0ZM12.85 10.2a0.85 0.85 0 1 0 1.7 0a0.85 0.85 0 1 0 -1.7 0ZM16.15 10.2a0.85 0.85 0 1 0 1.7 0a0.85 0.85 0 1 0 -1.7 0ZM8.75 13.4h6.5a0.75 0.75 0 0 1 0.75 0.75v0.0a0.75 0.75 0 0 1 -0.75 0.75h-6.5a0.75 0.75 0 0 1 -0.75 -0.75v-0.0a0.75 0.75 0 0 1 0.75 -0.75Z" to 1) }
    val Key: ImageVector by lazy { icon("Key", "M3.5 16a4.5 4.5 0 1 0 9.0 0a4.5 4.5 0 1 0 -9.0 0ZM6.2 16a1.8 1.8 0 1 0 3.6 0a1.8 1.8 0 1 0 -3.6 0Z" to 1, "M11.3 12.7L19.5 4.5M16 8l2.5 2.5" to 0) }
    val Image: ImageVector by lazy { icon("Image", "M7.0 4.5h10.0a3.5 3.5 0 0 1 3.5 3.5v8.0a3.5 3.5 0 0 1 -3.5 3.5h-10.0a3.5 3.5 0 0 1 -3.5 -3.5v-8.0a3.5 3.5 0 0 1 3.5 -3.5ZM6.999999999999999 9.5a1.7 1.7 0 1 0 3.4 0a1.7 1.7 0 1 0 -3.4 0ZM5.8 17.8l4-4.4 3 3 2.2-2.2 3.2 3.6Z" to 1) }
    val Folder: ImageVector by lazy { icon("Folder", "M3.5 7A2.5 2.5 0 016 4.5h3.4l2.3 2.5H18a2.5 2.5 0 012.5 2.5v8A2.5 2.5 0 0118 20H6a2.5 2.5 0 01-2.5-2.5Z" to 1) }
    val DriveFileMove: ImageVector by lazy { icon("DriveFileMove", "M3.5 7A2.5 2.5 0 016 4.5h3.4l2.3 2.5H18a2.5 2.5 0 012.5 2.5v8A2.5 2.5 0 0118 20H6a2.5 2.5 0 01-2.5-2.5ZM8 12.2h5.5v-2l3.5 3.3-3.5 3.3v-2H8Z" to 1) }
    val CallMerge: ImageVector by lazy { icon("CallMerge", "M6.5 4.5v3c0 3 2.5 4.5 5.5 4.5M17.5 4.5v3c0 3-2.5 4.5-5.5 4.5M12 12v7.5M9 16.5l3 3 3-3" to 0) }
    val Visibility: ImageVector by lazy { icon("Visibility", "M3 12c1.9-3.7 5-5.8 9-5.8s7.1 2.1 9 5.8c-1.9 3.7-5 5.8-9 5.8s-7.1-2.1-9-5.8ZM8.8 12a3.2 3.2 0 1 0 6.4 0a3.2 3.2 0 1 0 -6.4 0Z" to 1, "M10.6 12a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0Z" to 1) }
    val VisibilityOff: ImageVector by lazy { icon("VisibilityOff", "M3 12c1.9-3.7 5-5.8 9-5.8s7.1 2.1 9 5.8c-1.9 3.7-5 5.8-9 5.8s-7.1-2.1-9-5.8Z" to 0, "M4.5 4.5l15 15" to 0) }
    val Settings: ImageVector by lazy { icon("Settings", "M12 3.5l1.6 2.2 2.7-.5.9 2.6 2.4 1.3-.8 2.7.8 2.7-2.4 1.3-.9 2.6-2.7-.5L12 20.5l-1.6-2.2-2.7.5-.9-2.6-2.4-1.3.8-2.7-.8-2.7 2.4-1.3.9-2.6 2.7.5ZM9 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0Z" to 1) }
    val Schedule: ImageVector by lazy { icon("Schedule", "M3.5 12a8.5 8.5 0 1 0 17.0 0a8.5 8.5 0 1 0 -17.0 0ZM11 7.2h2v4.5l2.9 1.7-1 1.7L11 12.7Z" to 1) }
    val Palette: ImageVector by lazy { icon("Palette", "M12 3.5a8.5 8.5 0 100 17c1.5 0 2.1-1 1.5-2.1-.6-1.2.1-2.4 1.5-2.4h2a2.5 2.5 0 002.5-2.5C20.5 7 16.8 3.5 12 3.5ZM6.199999999999999 11.6a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0ZM9.0 7.4a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0ZM13.6 7.6a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0 -2.8 0Z" to 1) }
    val Notifications: ImageVector by lazy { icon("Notifications", "M12 3.5a5.5 5.5 0 00-5.5 5.5v3L4.8 15c-.5.9.1 2 1.2 2h12c1.1 0 1.7-1.1 1.2-2l-1.7-3V9A5.5 5.5 0 0012 3.5Z" to 1, "M9.5 19.2h5a2.5 2.5 0 01-5 0Z" to 1) }
    val Lock: ImageVector by lazy { icon("Lock", "M7.5 10h9a3 3 0 0 1 3 3v4.5a3 3 0 0 1 -3 3h-9a3 3 0 0 1 -3 -3v-4.5a3 3 0 0 1 3 -3ZM10.4 14.6a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0Z" to 1, "M8 10V7.5a4 4 0 018 0V10" to 0) }
    val LocalFireDepartment: ImageVector by lazy { icon("LocalFireDepartment", "M12 3c.6 3.2 3.8 4.8 5 7.6 1.3 3-.1 7-3.4 8.9a5.6 5.6 0 01-6.9-.7C4.9 16.6 5.2 13.2 7 11c.2 1.3.9 2 1.8 2.4C8.2 9.6 9.6 5.4 12 3ZM9.9 15.8a2.1 2.1 0 1 0 4.2 0a2.1 2.1 0 1 0 -4.2 0Z" to 1) }
    val Link: ImageVector by lazy { icon("Link", "M10.5 13.5a3.5 3.5 0 005 0l3-3a3.5 3.5 0 00-5-5l-1 1M13.5 10.5a3.5 3.5 0 00-5 0l-3 3a3.5 3.5 0 005 5l1-1" to 0) }
    val Layers: ImageVector by lazy { icon("Layers", "M12 3.5l8.5 4.6L12 12.7 3.5 8.1Z" to 1, "M3.5 11.9L12 16.4l8.5-4.5M3.5 15.4l8.5 4.5 8.5-4.5" to 0) }
    val Language: ImageVector by lazy { icon("Language", "M3.5 12a8.5 8.5 0 1 0 17.0 0a8.5 8.5 0 1 0 -17.0 0Z" to 0, "M3.5 12h17M12 3.5c2.3 2.4 3.4 5.2 3.4 8.5s-1.1 6.1-3.4 8.5c-2.3-2.4-3.4-5.2-3.4-8.5S9.7 5.9 12 3.5Z" to 0) }
    val FormatQuote: ImageVector by lazy { icon("FormatQuote", "M4 11.5C4 8.5 5.8 6.7 8.5 6.2l.5 1.7c-1.3.4-2 1.2-2.1 2.2H9.2V16H4ZM13.5 11.5c0-3 1.8-4.8 4.5-5.3l.5 1.7c-1.3.4-2 1.2-2.1 2.2h2.3V16h-5.2Z" to 1) }
    val FlashOn: ImageVector by lazy { icon("FlashOn", "M13.2 3.5L6.5 13h4.6l-.9 7.5 7.3-10h-4.7Z" to 1) }
    val Bolt: ImageVector by lazy { icon("Bolt", "M14 3.5L5.5 14h5.3L9.7 20.5 18.5 9.8h-5.3Z" to 1) }
    val FlashOff: ImageVector by lazy { icon("FlashOff", "M13.2 3.5L6.5 13h4.6l-.9 7.5 7.3-10h-4.7Z" to 0, "M4.5 4.5l15 15" to 0) }
    val FlashAuto: ImageVector by lazy { icon("FlashAuto", "M9.5 3.5L3.5 12h4l-.8 6.5 6.3-8.5H9Z" to 1, "M15 19.5l3-8h1l3 8h-1.5l-.6-1.7h-2.8l-.6 1.7ZM17.6 16.6h1.8L18.5 14Z" to 1) }
    val Flag: ImageVector by lazy { icon("Flag", "M5.5 4v16.5" to 0, "M5.5 5h12.5l-2.6 3.7 2.6 3.8H5.5Z" to 1) }
    val EmojiEvents: ImageVector by lazy { icon("EmojiEvents", "M7 3.5h10v6a5 5 0 01-10 0Z" to 1, "M7 5.5H4.5V7A3.5 3.5 0 008 10.5M17 5.5h2.5V7A3.5 3.5 0 0116 10.5" to 0, "M10.8 14.5h2.4v3h-2.4Z" to 1, "M9.4 17.5h5.2a1.4 1.4 0 0 1 1.4 1.4v0.0a1.4 1.4 0 0 1 -1.4 1.4h-5.2a1.4 1.4 0 0 1 -1.4 -1.4v-0.0a1.4 1.4 0 0 1 1.4 -1.4Z" to 1) }
    val AutoAwesome: ImageVector by lazy { icon("AutoAwesome", "M10 3.5l1.9 5.1 5.1 1.9-5.1 1.9L10 17.5l-1.9-5.1L3 10.5l5.1-1.9Z" to 1, "M18 13.5l.9 2.2 2.2.9-2.2.9-.9 2.2-.9-2.2-2.2-.9 2.2-.9Z" to 1) }
    val VolumeUp: ImageVector by lazy { icon("VolumeUp", "M4 9.5h3l4.5-4v13l-4.5-4H4Z" to 1, "M15 9.2a4 4 0 010 5.6M17.6 6.6a7.5 7.5 0 010 10.8" to 0) }
    val CameraAlt: ImageVector by lazy { icon("CameraAlt", "M3.5 8.5A2.5 2.5 0 016 6h1.4l1.2-2h6.8l1.2 2H18a2.5 2.5 0 012.5 2.5v9A2.5 2.5 0 0118 20H6a2.5 2.5 0 01-2.5-2.5ZM8 13a4 4 0 1 0 8 0a4 4 0 1 0 -8 0Z" to 1, "M9.8 13a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z" to 1) }
    val ContentPaste: ImageVector by lazy { icon("ContentPaste", "M8 5h8a3 3 0 0 1 3 3v9.5a3 3 0 0 1 -3 3h-8a3 3 0 0 1 -3 -3v-9.5a3 3 0 0 1 3 -3ZM8.8 11h6.4a0.8 0.8 0 0 1 0.8 0.8v0.0a0.8 0.8 0 0 1 -0.8 0.8h-6.4a0.8 0.8 0 0 1 -0.8 -0.8v-0.0a0.8 0.8 0 0 1 0.8 -0.8ZM8.8 14.5h3.4a0.8 0.8 0 0 1 0.8 0.8v0.0a0.8 0.8 0 0 1 -0.8 0.8h-3.4a0.8 0.8 0 0 1 -0.8 -0.8v-0.0a0.8 0.8 0 0 1 0.8 -0.8Z" to 1, "M10.5 3h3a2 2 0 0 1 2 2v0a2 2 0 0 1 -2 2h-3a2 2 0 0 1 -2 -2v0a2 2 0 0 1 2 -2Z" to 1) }
}
