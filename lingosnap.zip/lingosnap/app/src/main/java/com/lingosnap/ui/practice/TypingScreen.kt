package com.lingosnap.ui.practice

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.AnswerResult
import com.lingosnap.util.checkAnswer

@Composable
fun TypingScreen(scope: StudyScope, id: Long, onBack: () -> Unit) {
    val vm = rememberPractice(scope, id, "typing", 10)
    val cards = vm.cards
    var index by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<AnswerResult?>(null) }
    var hints by remember { mutableIntStateOf(0) }
    var correctCount by remember { mutableIntStateOf(0) }
    var awarded by remember { mutableIntStateOf(0) }
    var handled by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }

    val finished = !vm.loading && index >= cards.size
    val current = cards.getOrNull(index)

    LaunchedEffect(finished) {
        if (finished && !handled && cards.isNotEmpty()) {
            handled = true
            awarded = correctCount * 4
            vm.finish(perfect = correctCount == cards.size, bonusXp = awarded)
        }
    }
    LaunchedEffect(index, vm.loading) {
        if (!vm.loading && current != null) runCatching { focus.requestFocus() }
    }

    fun submit() {
        val c = current ?: return
        if (result != null || input.isBlank()) return
        val r = checkAnswer(input, c.target)
        result = r
        val ok = r != AnswerResult.Wrong && hints < 2
        vm.review(c, ok)
        if (r != AnswerResult.Wrong) correctCount++
    }

    fun next() {
        input = ""; result = null; hints = 0; index++
    }

    PracticeScaffold(
        title = "Schreibtrainer",
        progress = if (cards.isEmpty()) 0f else index / cards.size.toFloat(),
        loading = vm.loading,
        onBack = onBack,
    ) {
        if (cards.isEmpty()) {
            Text("Dieses Deck hat noch keine Karten.", style = MaterialTheme.typography.titleMedium)
        } else if (finished) {
            ResultPane(
                emoji = if (correctCount >= cards.size * 0.8) "" else "",
                headline = "$correctCount von ${cards.size} richtig",
                detail = "Übung macht den Meister.",
                xp = awarded,
                confetti = correctCount >= cards.size / 2,
                onBack = onBack,
            )
        } else if (current != null) {
            val cs = MaterialTheme.colorScheme
            val tint by animateColorAsState(
                when (result) {
                    AnswerResult.Correct -> cs.primaryContainer
                    AnswerResult.Close -> cs.tertiaryContainer
                    AnswerResult.Wrong -> cs.errorContainer
                    null -> cs.surfaceContainerHigh
                },
                label = "typingTint",
            )
            AnimatedContent(
                targetState = current,
                transitionSpec = {
                    (slideInHorizontally(spring(0.8f, 300f)) { it } + fadeIn()) togetherWith
                        (slideOutHorizontally { -it } + fadeOut())
                },
                label = "typingCard",
            ) { card ->
                Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainerLow, border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant)) {
                    Column(Modifier.padding(32.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (card.sourceLang.isBlank()) "Frage" else "Übersetze", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                        Text(card.source, style = MaterialTheme.typography.displaySmall.bold(), textAlign = TextAlign.Center)
                    }
                }
            }
            Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, color = tint, border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { if (result == null) input = it },
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        singleLine = true,
                        readOnly = result != null,
                        label = { Text("Deine Antwort") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { if (result == null) submit() else next() }),
                        shape = MaterialTheme.shapes.large,
                    )
                    val hint = if (hints > 0) current.target.take(hints) + "…" else null
                    if (result == null && hint != null) {
                        Text("Tipp: $hint", color = cs.onSurfaceVariant)
                    }
                    when (result) {
                        AnswerResult.Correct -> Text("Richtig!", style = MaterialTheme.typography.titleMedium.bold())
                        AnswerResult.Close -> Text("Fast! Richtig wäre: ${current.target}", style = MaterialTheme.typography.titleMedium.bold())
                        AnswerResult.Wrong -> Text("Leider falsch. Richtig: ${current.target}", style = MaterialTheme.typography.titleMedium.bold())
                        null -> {}
                    }
                }
            }
            Row(Modifier.fillMaxWidth().imePadding(), verticalAlignment = Alignment.CenterVertically) {
                if (result == null) {
                    FilledTonalButton(onClick = { hints = (hints + 1).coerceAtMost(current.target.length) }) {
                        Icon(Icons.Rounded.Lightbulb, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Tipp")
                    }
                    Spacer(Modifier.weight(1f))
                    BouncyButton(onClick = { submit() }, enabled = input.isNotBlank()) { Text("Prüfen") }
                } else {
                    Spacer(Modifier.weight(1f))
                    BouncyButton(onClick = { next() }) { Text("Weiter") }
                }
            }
        }
    }
}
