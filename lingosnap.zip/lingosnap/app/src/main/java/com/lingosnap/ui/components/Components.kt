package com.lingosnap.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Mastery
import com.lingosnap.data.model.Srs
import com.lingosnap.ui.theme.bold

/** Springy press micro-interaction. */
fun Modifier.pressScale(source: InteractionSource, pressedScale: Float = 0.93f): Modifier = composed {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    graphicsLayer { scaleX = scale; scaleY = scale }
}

/** Expressive button: squishes + morphs its corner radius while pressed. */
@Composable
fun BouncyButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    contentPadding: PaddingValues = PaddingValues(horizontal = 28.dp, vertical = 16.dp),
    content: @Composable RowScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val radius by animateDpAsState(
        targetValue = if (pressed) 14.dp else 30.dp,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 600f),
        label = "buttonRadius",
    )
    Button(
        onClick = onClick,
        modifier = modifier.pressScale(source, 0.95f),
        enabled = enabled,
        shape = RoundedCornerShape(radius),
        colors = colors,
        contentPadding = contentPadding,
        interactionSource = source,
        content = content,
    )
}

@Composable
fun masteryColors(m: Mastery): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (m) {
        Mastery.New -> cs.secondaryContainer to cs.onSecondaryContainer
        Mastery.Learning -> cs.tertiaryContainer to cs.onTertiaryContainer
        Mastery.Mastered -> cs.primary to cs.onPrimary
    }
}

@Composable
fun MasteryBadge(level: Int, modifier: Modifier = Modifier) {
    val m = Mastery.of(level)
    val (container, content) = masteryColors(m)
    val bg by animateColorAsState(container, label = "badgeBg")
    Surface(modifier, shape = CircleShape, color = bg, contentColor = content) {
        Text(
            m.label,
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelLarge.bold(),
        )
    }
}

/** Five little dots that pop in as the word gets mastered. */
@Composable
fun MasteryDots(level: Int, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(Srs.MAX_LEVEL) { i ->
            val filled = i < level
            val color by animateColorAsState(
                if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                label = "dot",
            )
            val scale by animateFloatAsState(
                if (filled) 1f else 0.7f,
                spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                label = "dotScale",
            )
            Box(
                Modifier
                    .size(9.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .background(color, CircleShape),
            )
        }
    }
}

/** "New / Learning / Mastered" chip + animated wavy 5-level progress bar. */
@Composable
fun MasteryIndicator(level: Int, modifier: Modifier = Modifier) {
    val progress by animateFloatAsState(
        targetValue = level / Srs.MAX_LEVEL.toFloat(),
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "masteryProgress",
    )
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            MasteryBadge(level)
            Text(
                "Level $level / ${Srs.MAX_LEVEL}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        WavyProgressBar(progress = progress)
    }
}
