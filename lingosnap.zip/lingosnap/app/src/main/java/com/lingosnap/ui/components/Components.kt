@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.lingosnap.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Mastery
import com.lingosnap.data.model.Srs

/** Gradient backdrop built from the dynamic colour scheme; cross-fades when the wallpaper/theme changes. */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val spec = tween<Color>(durationMillis = 700)
    val top by animateColorAsState(cs.surface, spec, label = "bgTop")
    val mid by animateColorAsState(cs.primaryContainer.copy(alpha = 0.40f), spec, label = "bgMid")
    val bottom by animateColorAsState(cs.tertiaryContainer.copy(alpha = 0.35f), spec, label = "bgBottom")
    Box(
        Modifier
            .fillMaxSize()
            .background(cs.surface)
            .background(Brush.verticalGradient(listOf(top, mid, bottom))),
        content = content,
    )
}

/** Springy press micro-interaction. */
fun Modifier.pressScale(source: InteractionSource, pressedScale: Float = 0.93f): Modifier = composed {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    graphicsLayer { scaleX = scale; scaleY = scale }
}

@Composable
fun BouncyButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: androidx.compose.material3.ButtonColors = ButtonDefaults.buttonColors(),
    contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
    content: @Composable RowScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    Button(
        onClick = onClick,
        modifier = modifier.pressScale(source),
        enabled = enabled,
        colors = colors,
        contentPadding = contentPadding,
        interactionSource = source,
        content = content,
    )
}

@Composable
fun masteryColors(m: Mastery): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (m) {
        Mastery.New -> cs.secondaryContainer to cs.onSecondaryContainer
        Mastery.Learning -> cs.tertiaryContainer to cs.onTertiaryContainer
        Mastery.Mastered -> cs.primary to cs.onPrimary
    }
}

@Composable
fun MasteryBadge(level: Int, modifier: Modifier = Modifier) {
    val m = Mastery.of(level)
    val (container, content) = masteryColors(m)
    val bg by animateColorAsState(container, label = "badgeBg")
    Surface(modifier, shape = MaterialTheme.shapes.large, color = bg, contentColor = content) {
        Text(
            m.label,
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelLargeEmphasized,
        )
    }
}

/** "New / Learning / Mastered" chip + wavy 5-level progress bar. */
@Composable
fun MasteryIndicator(level: Int, modifier: Modifier = Modifier) {
    val progress by animateFloatAsState(
        targetValue = level / Srs.MAX_LEVEL.toFloat(),
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "masteryProgress",
    )
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            MasteryBadge(level)
            Text("Level $level / ${Srs.MAX_LEVEL}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LinearWavyProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
    }
}
