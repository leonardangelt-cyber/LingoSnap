package com.lingosnap.ui.settings

import androidx.compose.material.icons.rounded.Key
import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import kotlinx.coroutines.launch
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lingosnap.container
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold
import com.lingosnap.data.remote.defaultModels
import com.lingosnap.data.remote.cleanKey
import com.lingosnap.data.remote.Verified
import com.lingosnap.data.remote.GeminiException
import com.lingosnap.data.remote.AiProvider
import kotlinx.coroutines.delay
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Color
import androidx.compose.animation.animateContentSize

private sealed interface KeyStatus {
    data object NoKey : KeyStatus
    data object Checking : KeyStatus
    data object Ok : KeyStatus
    data class Failed(val message: String) : KeyStatus
}

/** Shows which AI the key belongs to, which model is used and whether the key works. */
@Composable
fun AiSettingsScreen(onBack: () -> Unit, onChangeKey: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val gemini = context.container.gemini
    val keys = context.container.keyStore
    val provider by gemini.provider.collectAsStateWithLifecycle()

    var text by remember { mutableStateOf(keys.apiKey.orEmpty()) }
    var visible by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<KeyStatus>(if (keys.hasKey) KeyStatus.Checking else KeyStatus.NoKey) }
    var canForce by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var spareKey by remember { mutableStateOf(keys.backupKey.orEmpty()) }
    var spareStatus by remember { mutableStateOf<KeyStatus>(if (keys.backupKey != null) KeyStatus.Checking else KeyStatus.NoKey) }
    var spareRetry by remember { mutableIntStateOf(0) }
    var quality by remember { mutableStateOf(gemini.qualityCheck) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    // the model is always chosen automatically
    LaunchedEffect(Unit) { gemini.chooseModel(null) }

    // checks the key as soon as it is pasted or typed (and once when the screen opens)
    LaunchedEffect(text, retry) {
        val k = cleanKey(text)
        canForce = false
        when {
            k.isEmpty() -> {
                if (keys.hasKey) { keys.apiKey = null; keys.provider = null; keys.models = emptyList() }
                status = KeyStatus.NoKey
            }
            k.length < 16 -> status = KeyStatus.NoKey
            else -> {
                if (k != cleanKey(keys.apiKey.orEmpty())) delay(500) // typing pause
                status = KeyStatus.Checking
                gemini.validateKey(k)
                    .onSuccess { v ->
                        keys.apiKey = k; keys.setupDone = true; gemini.apply(v)
                        status = KeyStatus.Ok
                    }
                    .onFailure { e ->
                        canForce = !(e is GeminiException.Http && (e.code == 401 || e.code == 403 || e.code == 400))
                        status = KeyStatus.Failed(e.message ?: tr("Schlüssel konnte nicht geprüft werden"))
                    }
            }
        }
    }

    // reserve key: same live check, saved only when it works
    LaunchedEffect(spareKey, spareRetry) {
        val k = cleanKey(spareKey)
        when {
            k.isEmpty() -> { if (keys.backupKey != null) gemini.setBackupKey(null); spareStatus = KeyStatus.NoKey }
            k.length < 16 -> spareStatus = KeyStatus.NoKey
            else -> {
                if (k != cleanKey(keys.backupKey.orEmpty())) delay(500)
                spareStatus = KeyStatus.Checking
                gemini.setBackupKey(k)
                    .onSuccess { spareStatus = KeyStatus.Ok }
                    .onFailure { e -> spareStatus = KeyStatus.Failed(e.message ?: tr("Schlüssel konnte nicht geprüft werden")) }
            }
        }
    }

    val dark = cs.background.luminance() < 0.5f
    val okBg = if (dark) Color(0xFF1F3D2B) else Color(0xFFD5F0DC)
    val okFg = if (dark) Color(0xFFB9F0C8) else Color(0xFF0C3B1E)
    val okGlow = if (dark) Color(0xFF4CAF73) else Color(0xFF2E9E57)
    val targetBg = when (status) { KeyStatus.Ok -> okBg; is KeyStatus.Failed -> cs.errorContainer; else -> cs.surfaceContainer }
    val targetFg = when (status) { KeyStatus.Ok -> okFg; is KeyStatus.Failed -> cs.onErrorContainer; else -> cs.onSurface }
    val targetGlow = when (status) { KeyStatus.Ok -> okGlow; is KeyStatus.Failed -> cs.error; else -> Color.Transparent }
    val bg by androidx.compose.animation.animateColorAsState(targetBg, androidx.compose.animation.core.tween(400), label = "keyBg")
    val fg by androidx.compose.animation.animateColorAsState(targetFg, androidx.compose.animation.core.tween(400), label = "keyFg")
    val glow by androidx.compose.animation.animateColorAsState(targetGlow, androidx.compose.animation.core.tween(400), label = "keyGlow")

    LargeScreen(title = "KI", onBack = onBack) { inner ->
        Column(
            Modifier.padding(inner).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Surface(
                Modifier.fillMaxWidth().animateContentSize(),
                shape = MaterialTheme.shapes.extraLarge, color = bg, contentColor = fg,
                border = androidx.compose.foundation.BorderStroke(2.dp, glow),
                shadowElevation = if (glow == Color.Transparent) 0.dp else 6.dp,
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        when (status) {
                            KeyStatus.Checking -> CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp, color = fg)
                            KeyStatus.Ok -> Icon(Icons.Rounded.CheckCircle, null, Modifier.size(28.dp), tint = fg)
                            is KeyStatus.Failed -> Icon(Icons.Rounded.ErrorOutline, null, Modifier.size(28.dp), tint = fg)
                            KeyStatus.NoKey -> Icon(Icons.Rounded.Key, null, Modifier.size(28.dp), tint = cs.primary)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                when (status) {
                                    KeyStatus.Checking -> tr("Prüfe …")
                                    KeyStatus.Ok -> tr("Richtig, der Schlüssel ist gesichert")
                                    is KeyStatus.Failed -> tr("Schlüssel funktioniert nicht")
                                    KeyStatus.NoKey -> tr("Füge deinen API-Schlüssel ein")
                                },
                                style = MaterialTheme.typography.titleMedium.bold(),
                            )
                            val sub = when (val st = status) {
                                KeyStatus.Ok -> tr("Erkannt: {0}. Das Modell wird automatisch gewählt.", provider?.label ?: "")
                                is KeyStatus.Failed -> st.message
                                KeyStatus.NoKey -> tr("Funktioniert mit Google Gemini, OpenAI, Claude, OpenRouter, Groq und xAI.")
                                else -> null
                            }
                            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    com.lingosnap.ui.components.AppTextField(
                        value = text, onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(tr("API-Schlüssel")) },
                        singleLine = true,
                        visualTransformation = if (visible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon = {
                            androidx.compose.material3.IconButton(onClick = { visible = !visible }) {
                                Icon(if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, tr("Anzeigen/Verbergen"))
                            }
                        },
                    )
                    if (status is KeyStatus.Failed) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = { retry++ }) { Text(tr("Erneut prüfen")) }
                        if (canForce) androidx.compose.material3.TextButton(onClick = {
                            val k = cleanKey(text)
                            keys.apiKey = k; keys.setupDone = true
                            AiProvider.guess(k)?.let { gemini.apply(Verified(it, defaultModels(it))) }
                            status = KeyStatus.Ok
                        }) { Text(tr("Trotzdem speichern")) }
                    }
                }
            }

            if (keys.hasKey) {
                GroupHeader(tr("Reserve und Qualität"))
                val sOk = spareStatus == KeyStatus.Ok
                val sFail = spareStatus is KeyStatus.Failed
                val sBg by androidx.compose.animation.animateColorAsState(if (sOk) okBg else if (sFail) cs.errorContainer else cs.surfaceContainer, androidx.compose.animation.core.tween(400), label = "spBg")
                val sFg = if (sOk) okFg else if (sFail) cs.onErrorContainer else cs.onSurface
                val sGlow by androidx.compose.animation.animateColorAsState(if (sOk) okGlow else if (sFail) cs.error else Color.Transparent, androidx.compose.animation.core.tween(400), label = "spGlow")
                Surface(
                    Modifier.fillMaxWidth().animateContentSize(),
                    shape = MaterialTheme.shapes.large, color = sBg, contentColor = sFg,
                    border = androidx.compose.foundation.BorderStroke(2.dp, sGlow),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            when (spareStatus) {
                                KeyStatus.Checking -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp, color = sFg)
                                KeyStatus.Ok -> Icon(Icons.Rounded.CheckCircle, null, Modifier.size(24.dp), tint = sFg)
                                is KeyStatus.Failed -> Icon(Icons.Rounded.ErrorOutline, null, Modifier.size(24.dp), tint = sFg)
                                KeyStatus.NoKey -> Icon(Icons.Rounded.Key, null, Modifier.size(24.dp), tint = cs.primary)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    when (spareStatus) {
                                        KeyStatus.Checking -> tr("Reserve-Schlüssel wird geprüft …")
                                        KeyStatus.Ok -> tr("Reserve-Schlüssel akzeptiert und gesichert")
                                        is KeyStatus.Failed -> tr("Reserve-Schlüssel wird nicht akzeptiert")
                                        KeyStatus.NoKey -> tr("Reserve-Schlüssel (optional)")
                                    },
                                    style = MaterialTheme.typography.titleSmall.bold(),
                                )
                                val sub = when (val st = spareStatus) {
                                    KeyStatus.Ok -> tr("Springt ein, wenn der erste Schlüssel sein Limit erreicht.")
                                    is KeyStatus.Failed -> st.message
                                    KeyStatus.NoKey -> tr("Ein zweiter Schlüssel, z. B. von einem anderen Anbieter.")
                                    else -> null
                                }
                                if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        com.lingosnap.ui.components.AppTextField(
                            value = spareKey, onValueChange = { spareKey = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(tr("API-Schlüssel")) },
                            singleLine = true,
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        )
                        if (sFail) FilledTonalButton(onClick = { spareRetry++ }) { Text(tr("Erneut prüfen")) }
                    }
                }
                SegmentedItem(
                    index = 0, count = 1, headline = tr("Karten von der KI prüfen lassen"),
                    supporting = tr("Sucht nach dem Erzeugen falsche Übersetzungen (bis 80 Karten, kostet eine zusätzliche Anfrage)"),
                    onClick = { quality = !quality; gemini.qualityCheck = quality },
                    trailing = { androidx.compose.material3.Switch(checked = quality, onCheckedChange = { quality = it; gemini.qualityCheck = it }) },
                )
            }
        }
    }
}
