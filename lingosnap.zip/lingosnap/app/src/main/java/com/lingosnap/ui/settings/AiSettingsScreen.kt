package com.lingosnap.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lingosnap.container
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold

private sealed interface KeyStatus {
    data object NoKey : KeyStatus
    data object Checking : KeyStatus
    data object Ok : KeyStatus
    data class Failed(val message: String) : KeyStatus
}

/** Shows which AI the key belongs to, which model is used and whether the key works. */
@Composable
fun AiSettingsScreen(onBack: () -> Unit, onChangeKey: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val gemini = context.container.gemini
    val keys = context.container.keyStore
    val provider by gemini.provider.collectAsStateWithLifecycle()
    val active by gemini.activeModel.collectAsStateWithLifecycle()
    val models by gemini.models.collectAsStateWithLifecycle()

    var status by remember { mutableStateOf<KeyStatus>(if (keys.hasKey) KeyStatus.Checking else KeyStatus.NoKey) }
    var check by remember { mutableIntStateOf(0) }
    var pickModel by remember { mutableStateOf(false) }

    LaunchedEffect(check) {
        if (!keys.hasKey) { status = KeyStatus.NoKey; return@LaunchedEffect }
        status = KeyStatus.Checking
        gemini.refreshModels()
            .onSuccess { gemini.apply(it); status = KeyStatus.Ok }
            .onFailure { status = KeyStatus.Failed(it.message ?: "Keine Verbindung") }
    }

    LargeScreen(title = "KI", onBack = onBack) { inner ->
        Column(
            Modifier.padding(inner).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainer) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    when (status) {
                        KeyStatus.Checking -> CircularProgressIndicator(Modifier.size(32.dp), strokeWidth = 3.dp)
                        KeyStatus.Ok -> Icon(Icons.Rounded.CheckCircle, null, Modifier.size(32.dp), tint = cs.primary)
                        is KeyStatus.Failed -> Icon(Icons.Rounded.ErrorOutline, null, Modifier.size(32.dp), tint = cs.error)
                        KeyStatus.NoKey -> Icon(Icons.Rounded.HelpOutline, null, Modifier.size(32.dp), tint = cs.outline)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            when (status) {
                                KeyStatus.Checking -> "Schlüssel wird geprüft …"
                                KeyStatus.Ok -> "Schlüssel funktioniert"
                                is KeyStatus.Failed -> "Schlüssel funktioniert nicht"
                                KeyStatus.NoKey -> "Kein Schlüssel hinterlegt"
                            },
                            style = MaterialTheme.typography.titleMedium.bold(),
                        )
                        val detail = when (val s = status) {
                            is KeyStatus.Failed -> s.message
                            KeyStatus.NoKey -> "Ohne Schlüssel funktionieren Foto-Scan und KI-Karten nicht."
                            else -> null
                        }
                        if (detail != null) Text(detail, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
            }

            GroupHeader("Verbindung")
            val count = if (keys.hasKey) 3 else 1
            SegmentedItem(
                index = 0, count = count, headline = "API-Schlüssel",
                supporting = keys.apiKey?.let { "•••• ${it.takeLast(4)}" } ?: "Tippen zum Eintragen",
                onClick = onChangeKey,
            )
            if (keys.hasKey) {
                SegmentedItem(index = 1, count = count, headline = "Anbieter", supporting = provider?.label ?: "Wird erkannt …")
                SegmentedItem(
                    index = 2, count = count, headline = "Modell",
                    supporting = if (keys.chosenModel == null) "Automatisch: ${active ?: "–"}" else (active ?: "–"),
                    onClick = { pickModel = true },
                )
                FilledTonalButton(onClick = { check++ }, modifier = Modifier.padding(top = 16.dp)) { Text("Verbindung prüfen") }
            }
        }
    }

    if (pickModel) ModelDialog(onDismiss = { pickModel = false }, models = models, active = active)
}
