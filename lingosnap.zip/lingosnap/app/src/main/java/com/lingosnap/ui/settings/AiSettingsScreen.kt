package com.lingosnap.ui.settings

import androidx.compose.material.icons.rounded.Key
import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import kotlinx.coroutines.launch
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lingosnap.container
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold

private sealed interface KeyStatus {
    data object NoKey : KeyStatus
    data object Checking : KeyStatus
    data object Ok : KeyStatus
    data class Failed(val message: String) : KeyStatus
}

/** Shows which AI the key belongs to, which model is used and whether the key works. */
@Composable
fun AiSettingsScreen(onBack: () -> Unit, onChangeKey: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val gemini = context.container.gemini
    val keys = context.container.keyStore
    val provider by gemini.provider.collectAsStateWithLifecycle()
    val active by gemini.activeModel.collectAsStateWithLifecycle()
    val models by gemini.models.collectAsStateWithLifecycle()

    var status by remember { mutableStateOf<KeyStatus>(if (keys.hasKey) KeyStatus.Checking else KeyStatus.NoKey) }
    var check by remember { mutableIntStateOf(0) }
    var pickModel by remember { mutableStateOf(false) }
    var spareDialog by remember { mutableStateOf(false) }
    var spareKey by remember { mutableStateOf(keys.backupKey.orEmpty()) }
    var spareBusy by remember { mutableStateOf(false) }
    var spareError by remember { mutableStateOf<String?>(null) }
    var quality by remember { mutableStateOf(gemini.qualityCheck) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    LaunchedEffect(check) {
        if (!keys.hasKey) { status = KeyStatus.NoKey; return@LaunchedEffect }
        status = KeyStatus.Checking
        gemini.refreshModels()
            .onSuccess { gemini.apply(it); status = KeyStatus.Ok }
            .onFailure { status = KeyStatus.Failed(it.message ?: tr("Keine Verbindung")) }
    }

    LargeScreen(title = "KI", onBack = onBack) { inner ->
        Column(
            Modifier.padding(inner).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainer) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    when (status) {
                        KeyStatus.Checking -> CircularProgressIndicator(Modifier.size(32.dp), strokeWidth = 3.dp)
                        KeyStatus.Ok -> Icon(Icons.Rounded.CheckCircle, null, Modifier.size(32.dp), tint = cs.primary)
                        is KeyStatus.Failed -> Icon(Icons.Rounded.ErrorOutline, null, Modifier.size(32.dp), tint = cs.error)
                        KeyStatus.NoKey -> Icon(Icons.Rounded.HelpOutline, null, Modifier.size(32.dp), tint = cs.outline)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            when (status) {
                                KeyStatus.Checking -> tr("Schlüssel wird geprüft …")
                                KeyStatus.Ok -> tr("Schlüssel funktioniert")
                                is KeyStatus.Failed -> tr("Schlüssel funktioniert nicht")
                                KeyStatus.NoKey -> tr("Kein Schlüssel hinterlegt")
                            },
                            style = MaterialTheme.typography.titleMedium.bold(),
                        )
                        val detail = when (val s = status) {
                            is KeyStatus.Failed -> s.message
                            KeyStatus.NoKey -> tr("Ohne Schlüssel funktionieren Foto-Scan und KI-Karten nicht.")
                            else -> null
                        }
                        if (detail != null) Text(detail, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
            }

            GroupHeader(tr("Verbindung"))
            val count = if (keys.hasKey) 3 else 1
            SegmentedItem(
                index = 0, count = count, headline = tr("API-Schlüssel"),
                supporting = keys.apiKey?.let { "•••• ${it.takeLast(4)}" } ?: tr("Tippen zum Eintragen"),
                onClick = onChangeKey,
            )
            if (keys.hasKey) {
                SegmentedItem(index = 1, count = count, headline = tr("Anbieter"), supporting = provider?.label ?: tr("Wird erkannt …"))
                SegmentedItem(
                    index = 2, count = count, headline = tr("Modell"),
                    supporting = if (keys.chosenModel == null) tr("Automatisch: {0}", active ?: "–") else (active ?: "–"),
                    onClick = { pickModel = true },
                )
                FilledTonalButton(onClick = { check++ }, modifier = Modifier.padding(top = 16.dp)) { Text(tr("Verbindung prüfen")) }

                GroupHeader(tr("Reserve und Qualität"))
                SegmentedItem(
                    index = 0, count = 2, headline = tr("Reserve-Schlüssel"),
                    supporting = keys.backupKey?.let { tr("•••• {0} · {1} – springt ein, wenn der erste sein Limit erreicht", it.takeLast(4), keys.backupProvider.orEmpty()) }
                        ?: tr("Optional: ein zweiter Schlüssel, z. B. von einem anderen Anbieter"),
                    onClick = { spareDialog = true },
                )
                SegmentedItem(
                    index = 1, count = 2, headline = tr("Karten von der KI prüfen lassen"),
                    supporting = tr("Sucht nach dem Erzeugen falsche Übersetzungen (bis 80 Karten, kostet eine zusätzliche Anfrage)"),
                    onClick = { quality = !quality; gemini.qualityCheck = quality },
                    trailing = { androidx.compose.material3.Switch(checked = quality, onCheckedChange = { quality = it; gemini.qualityCheck = it }) },
                )
            }
        }
    }

    if (spareDialog) com.lingosnap.ui.components.FormSheet(
        title = tr("Reserve-Schlüssel"),
        icon = androidx.compose.material.icons.Icons.Rounded.Key,
        subtitle = tr("Wenn der Hauptschlüssel sein Limit erreicht, nutzt die App diesen Schlüssel. Er kann von einem anderen Anbieter sein."),
        onDismiss = { spareDialog = false },
        confirmLabel = tr("Speichern"),
        confirmEnabled = spareKey.isNotBlank(),
        busy = spareBusy,
        onConfirm = {
            spareBusy = true
            scope.launch {
                gemini.setBackupKey(spareKey)
                    .onSuccess { spareDialog = false }
                    .onFailure { spareError = it.message ?: tr("Der Schlüssel funktioniert nicht") }
                spareBusy = false
            }
        },
    ) {
        com.lingosnap.ui.components.AppTextField(
            spareKey, { spareKey = it; spareError = null }, Modifier.fillMaxWidth(),
            label = { Text(tr("API-Schlüssel")) }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
        )
        spareError?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
        if (spareBusy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
        if (keys.backupKey != null) {
            androidx.compose.material3.TextButton(enabled = !spareBusy, onClick = {
                scope.launch { gemini.setBackupKey(null); spareKey = ""; spareDialog = false }
            }) { Text(tr("Reserve-Schlüssel entfernen")) }
        }
    }

    if (pickModel) ModelDialog(onDismiss = { pickModel = false }, models = models, active = active)
}
