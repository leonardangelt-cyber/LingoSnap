package com.lingosnap.ui.create

import com.lingosnap.util.tr

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.remote.GeminiException
import com.lingosnap.data.remote.Progress
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.AiJobs
import com.lingosnap.util.Batch
import com.lingosnap.util.DocumentReader
import com.lingosnap.util.JobInfo
import com.lingosnap.util.Notifier
import com.lingosnap.util.PendingStore
import com.lingosnap.util.normalize
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.max

class Draft(pair: VocabPair, selected: Boolean = true) {
    var pair by mutableStateOf(pair)
    var selected by mutableStateOf(selected)
}

/**
 * Collects new cards for an existing deck (typed, from files or from the AI) and saves them at once.
 * AI jobs run in [appScope], so they keep going when the user leaves the screen.
 */
val DEFAULT_DECK_NAME: String get() = tr("Neues Deck")

class AddCardsViewModel(
    private val repo: CardRepository,
    private val deckId: Long,
    private val appScope: CoroutineScope,
    private val notifier: Notifier,
) : ViewModel() {

    var deck by mutableStateOf<Deck?>(null)
        private set

    val drafts = mutableStateListOf<Draft>()
    private val seen = HashSet<String>()

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** 0..1 while the AI works; status text says what it is doing right now. */
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf<String?>(null)
        private set

    /** Loading dialog: visible while the AI works and until the user confirms the result. */
    var showProgress by mutableStateOf(false)
        private set
    /** 0 prepare, 1 send, 2 read, 3 assemble, 4 check duplicates, 5 done */
    var step by mutableIntStateOf(0)
        private set
    var found by mutableIntStateOf(0)
        private set
    var scanning by mutableStateOf(false)
        private set
    private var aiJob: Job? = null
    private var waitingSince = 0L
    private var waitingModel: String? = null
    private var lastFailure: String? = null
    private var detached = false
    private var inBackground = false

    /** Files chosen for the scan: they only show as a preview until the learner starts the recognition. */
    val files = mutableStateListOf<Uri>()

    fun addFiles(uris: List<Uri>) { uris.forEach { if (it !in files) files.add(it) } }
    fun removeFile(uri: Uri) { files.remove(uri) }

    fun startScan(context: Context) {
        if (busy || files.isEmpty()) return
        val list = files.toList()
        files.clear()
        scan(context, list)
    }

    var topic by mutableStateOf("")
    var count by mutableStateOf(20)
    var level by mutableStateOf("A1")
    var hint by mutableStateOf("")

    init {
        viewModelScope.launch {
            deck = repo.deck(deckId)
            // results of a job that finished while the screen was closed
            PendingStore.take(deckId)?.forEach { addDraft(it) }
        }
    }

    override fun onCleared() { detached = true }

    fun dismissProgress() { if (!busy) showProgress = false }

    private var userCancelled = false

    /** Stops the AI job at once (the running request is aborted) and closes the progress sheet. */
    fun cancelAi() {
        userCancelled = true
        showProgress = false
        aiJob?.cancel()
    }

    /** "Im Hintergrund fortsetzen": hides the dialog, keeps working and notifies when done. */
    fun moveToBackground() {
        if (!busy) return
        inBackground = true
        showProgress = false
        notifier.startKeepAlive()
    }

    private fun addDraft(pair: VocabPair): Boolean {
        val key = pair.source.lowercase() + "|" + pair.target.lowercase()
        if (!seen.add(key)) return false
        drafts.add(0, Draft(pair))
        return true
    }

    fun addManual(source: String, target: String) {
        if (source.isBlank() || target.isBlank()) return
        addDraft(VocabPair(source.trim(), target.trim()))
    }

    fun addList(text: String): Int =
        com.lingosnap.util.parseVocabText(text).count { addDraft(it) }

    /* ── AI jobs ── */

    private var batchCount = 1
    private var completedBatches = 0
    private var receivedTotal = 0
    private var receivedAtComplete = 0

    private fun part() = if (batchCount > 1) tr(" (Teil {0} von {1} fertig)", completedBatches, batchCount) else ""

    /** Runs an AI job with live progress. [expected] = known number of entries, or 0 if unknown. */
    private fun runAi(expected: Int, scan: Boolean, prepare: suspend () -> Unit = {}, job: suspend (Progress) -> Result<List<VocabPair>>) {
        if (busy) return
        userCancelled = false
        busy = true; error = null; notice = null; showProgress = true; scanning = scan; inBackground = false
        step = 0; found = 0; progress = 0.1f
        batchCount = 1; completedBatches = 0; receivedTotal = 0; receivedAtComplete = 0
        windowLo = 0.12f; windowHi = 0.85f; waitingForAi = false
        status = if (scan) tr("Dateien werden vorbereitet") else tr("Anfrage wird vorbereitet")
        aiJob = appScope.launch {
            var ticker: Job? = null
            var failed: String? = null
            var cancelled = false
            // publishes percent + status for the deck list and the notification
            val reporter = launch {
                while (true) {
                    val pct = (progress * 100).toInt().coerceIn(0, 100)
                    val text = status ?: ""
                    AiJobs.set(deckId, JobInfo(pct, text))
                    if (inBackground || detached) notifier.progress(deckId, deck?.name ?: tr("Deck"), pct, text)
                    delay(400)
                }
            }
            try {
                prepare()
                step = 1; progress = max(progress, 0.12f)
                status = tr("Anfrage wird an die KI gesendet") + part()
                waitingSince = System.currentTimeMillis(); waitingModel = null; lastFailure = null; waitingForAi = true
                // Like the web app: while we wait, the bar counts up slowly (every 0.4 s) towards the end of its window (85 % for one request,
                // for several requests each one has its own part of the way). It never passes the end of its window.
                // The status line says honestly which model we wait for and why the previous one was given up.
                ticker = launch {
                    while (true) {
                        delay(400)
                        val cap = windowHi - 0.02f
                        if (progress < cap) progress += (cap - progress) * 0.02f
                        if (waitingForAi) {
                            val sec = ((System.currentTimeMillis() - waitingSince) / 1000).toInt()
                            val who = waitingModel
                            status = (if (who == null) tr("Anfrage wird an die KI gesendet") else tr("Warte auf {0} … {1} s", who, sec)) +
                                (lastFailure?.let { "\n" + it } ?: "") + part()
                        }
                    }
                }
                val p = Progress(
                    onModel = { m -> launch(Dispatchers.Main) { waitingModel = m; waitingSince = System.currentTimeMillis(); waitingForAi = true } },
                    onFailed = { m, why -> launch(Dispatchers.Main) { lastFailure = tr("{0}: {1} – das nächste Modell wird versucht", m, why) } },
                    onFirstText = {
                        launch(Dispatchers.Main) {
                            step = 2
                            waitingForAi = false
                            lastFailure = null
                            status = (if (scan) tr("KI liest den Text und erkennt Einträge") else tr("KI erzeugt Einträge")) + part()
                            if (!scan && progress < 0.35f) progress = 0.35f
                        }
                    },
                    onPair = { pair ->
                        launch(Dispatchers.Main) {
                            if (addDraft(pair)) receivedTotal++
                            found = receivedTotal
                            val f = if (expected > 0) (receivedTotal / expected.toFloat()).coerceAtMost(1f)
                            else (completedBatches + (1f - exp(-(receivedTotal - receivedAtComplete) / 12f))) / batchCount
                            progress = max(progress, 0.35f + 0.45f * f.coerceAtMost(1f))
                        }
                    },
                )
                job(p).onSuccess { list ->
                    waitingForAi = false
                    step = 3; status = tr("Liste wird zusammengestellt"); progress = max(progress, 0.85f)
                    // equal entries (front + back, any case) are kept once; every new card moves the bar from 85 % towards 99 %
                    list.forEachIndexed { i, pair ->
                        addDraft(pair)
                        progress = max(progress, 0.85f + 0.14f * (i + 1) / list.size)
                    }
                    found = drafts.size
                    progress = 1f
                    step = 4
                    status = tr("Fertig")
                }.onFailure {
                    if (userCancelled || it is kotlinx.coroutines.CancellationException) {
                        cancelled = true; status = null; showProgress = false
                    } else {
                        failed = it.message ?: tr("Unbekannter Fehler")
                        error = failed
                        status = null
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                cancelled = true
                status = null
                showProgress = false
                throw e
            } catch (e: Exception) {
                if (userCancelled) { cancelled = true; status = null; showProgress = false }
                else {
                    failed = e.message ?: tr("Unbekannter Fehler")
                    error = failed
                    status = null
                }
            } finally {
                ticker?.cancel()
                reporter.cancel()
                AiJobs.clear(deckId)
                waitingForAi = false
                busy = false
                if (cancelled) {
                    notifier.stopKeepAlive()
                    notifier.cancelProgress()
                } else if (inBackground || detached) {
                    notifier.stopKeepAlive()
                    // finished while the learner was elsewhere: the cards go straight into the deck, so the deck is full when it is opened
                    val saved = if (failed == null) runCatching { autoSave() }.getOrDefault(0) else 0
                    val title = if (failed == null) tr("LingoSnap: Fertig") else tr("LingoSnap: Das hat nicht geklappt")
                    val text = if (failed == null) tr("{0} Karten wurden zu „{1}“ hinzugefügt.", saved, deck?.name ?: tr("deinem Deck")) else failed.orEmpty()
                    notifier.done(deckId, title, text)
                }
            }
        }
        aiJob?.let { AiJobs.register(deckId, it) }
    }

    private var windowLo = 0.12f
    private var windowHi = 0.85f
    private var waitingForAi = false

    /** Saves every selected draft that is not already in the deck. Returns how many cards were added. */
    private suspend fun autoSave(): Int {
        val d = deck ?: return 0
        val existing = runCatching { repo.cardsOf(deckId) }.getOrDefault(emptyList())
        val known = existing.map { normalize(it.source) + "|" + normalize(it.target) }.toSet()
        val add = drafts.filter { it.selected && (normalize(it.pair.source) + "|" + normalize(it.pair.target)) !in known }
        if (add.isEmpty()) return 0
        repo.addCards(d, add.map { it.pair })
        drafts.clear()
        seen.clear()
        found = 0
        return add.size
    }

    /** As in the web app: a deck that still has no name takes the name of the first file (without the ending). */
    private fun nameFromFile(fileName: String) {
        val d = deck ?: return
        val name = fileName.trim().take(40)
        if (d.name != DEFAULT_DECK_NAME || name.length < 2) return
        // photos taken with the camera have no meaningful name
        if (Regex("^(scan_|img[_-]|pxl_|dsc|photo|image|\\d{4,})", RegexOption.IGNORE_CASE).containsMatchIn(name)) return
        appScope.launch {
            runCatching { repo.renameDeck(d, name) }.onSuccess { deck = d.copy(name = name) }
        }
    }

    fun generate() {
        val d = deck ?: return
        if (topic.isBlank()) return
        runAi(expected = count, scan = false) { p -> repo.generate(topic.trim(), d, count, "", hint, p) }
    }

    /**
     * The file recognition of the web app: the files are read, every block of text / every photo / every scan is one request, one after
     * another. A block that fails does not stop the others; equal cards are kept once.
     */
    fun scan(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (uris.isEmpty()) return
        var batches: List<Batch> = emptyList()
        runAi(
            expected = 0,
            scan = true,
            prepare = {
                status = if (uris.size > 1) tr("{0} Dateien werden vorbereitet …", uris.size) else tr("Datei wird vorbereitet …")
                val material = DocumentReader.read(context, uris)
                batches = material.batches
                batchCount = batches.size.coerceAtLeast(1)
                nameFromFile(material.firstFileName)
            },
        ) { p ->
            val all = ArrayList<VocabPair>()
            var firstError: Throwable? = null
            var failedParts = 0
            batches.forEachIndexed { i, batch ->
                windowLo = 0.12f + 0.73f * i / batches.size
                windowHi = 0.12f + 0.73f * (i + 1) / batches.size
                progress = max(progress, windowLo)
                val r = repo.recognize(batch, d, p)
                val e = r.exceptionOrNull()
                if (e is kotlinx.coroutines.CancellationException) throw e
                r.getOrNull()?.let { all += it }
                // a block without vocabulary (blank page, cover) is fine; real errors are counted
                if (e != null && e !is GeminiException.NoResult) { failedParts++; if (firstError == null) firstError = e }
                completedBatches++
                progress = max(progress, windowHi)
            }
            if (failedParts > 0 && all.isNotEmpty()) {
                notice = tr("{0} von {1} Teilen der Datei konnten nicht gelesen werden, die Einträge daraus fehlen. Starte den Import später noch einmal, um sie nachzuholen.", failedParts, batches.size)
            }
            when {
                all.isNotEmpty() -> Result.success(all)
                firstError != null -> Result.failure(firstError!!)
                else -> Result.failure(GeminiException.NoResult(""))
            }
        }
    }

    /** Shown above the list when part of a big file could not be read. */
    var notice by mutableStateOf<String?>(null)
        private set

    val selectedCount: Int get() = drafts.count { it.selected }

    /** Saves the selected cards (a card that is exactly the same as one in the deck is skipped). */
    fun save(onDone: () -> Unit) {
        val d = deck ?: return
        if (busy) return
        viewModelScope.launch {
            busy = true
            val known = repo.cardsOf(deckId).map { normalize(it.source) + "|" + normalize(it.target) }.toSet()
            val add = drafts.filter { it.selected && (normalize(it.pair.source) + "|" + normalize(it.pair.target)) !in known }
            if (add.isNotEmpty()) repo.addCards(d, add.map { it.pair })
            busy = false
            onDone()
        }
    }
}
