package com.lingosnap.ui.create

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.remote.Progress
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.exp

class Draft(val pair: VocabPair, selected: Boolean = true) {
    var selected by mutableStateOf(selected)
}

/** Collects new cards for an existing deck (typed, from photos or from the AI) and saves them at once. */
class AddCardsViewModel(private val repo: CardRepository, private val deckId: Long) : ViewModel() {

    var deck by mutableStateOf<Deck?>(null)
        private set

    val drafts = mutableStateListOf<Draft>()
    private val seen = HashSet<String>()

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** 0..1 while the AI works; status text says what it is doing right now. */
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf<String?>(null)
        private set

    var topic by mutableStateOf("")
    var count by mutableStateOf(15)
    var level by mutableStateOf("A1")
    var hint by mutableStateOf("")

    init {
        viewModelScope.launch { deck = repo.deck(deckId) }
    }

    private fun addDraft(pair: VocabPair): Boolean {
        val key = pair.source.lowercase() + "|" + pair.target.lowercase()
        if (!seen.add(key)) return false
        drafts.add(0, Draft(pair))
        return true
    }

    fun addManual(source: String, target: String) {
        if (source.isBlank() || target.isBlank()) return
        addDraft(VocabPair(source.trim(), target.trim()))
    }

    fun addList(text: String): Int =
        com.lingosnap.util.parseVocabText(text).count { addDraft(it) }

    /** Runs an AI job with live progress. [expected] = known number of entries, or 0 if unknown. */
    private fun runAi(expected: Int, prepare: suspend () -> Unit = {}, job: suspend (Progress) -> Result<List<VocabPair>>) {
        if (busy) return
        busy = true; error = null; progress = 0.03f; status = "Wird vorbereitet …"
        viewModelScope.launch {
            var ticker: Job? = null
            var received = 0
            try {
                prepare()
                progress = 0.15f
                status = "Anfrage wird gesendet …"
                // creeps forward while we wait for the first answer
                ticker = launch {
                    while (progress < 0.3f) { delay(250); progress += 0.01f }
                }
                val p = Progress(
                    onModel = { m -> launch(Dispatchers.Main) { status = "Anfrage an $m …" } },
                    onFirstText = {
                        launch(Dispatchers.Main) {
                            ticker?.cancel()
                            status = "KI liest Wörter …"
                            if (progress < 0.35f) progress = 0.35f
                        }
                    },
                    onPair = { pair ->
                        launch(Dispatchers.Main) {
                            if (addDraft(pair)) received++
                            val f = if (expected > 0) (received / expected.toFloat()).coerceAtMost(1f)
                            else 1f - exp(-received / 10f)
                            progress = 0.35f + 0.6f * f
                            status = "KI liest Wörter … $received gefunden"
                        }
                    },
                )
                job(p).onSuccess { list ->
                    list.forEach { addDraft(it) }
                    progress = 1f
                    status = "Fertig – ${drafts.size} Wörter in der Liste"
                }.onFailure {
                    error = it.message ?: "Unbekannter Fehler"
                    status = null
                }
            } catch (e: Exception) {
                error = e.message ?: "Unbekannter Fehler"
                status = null
            } finally {
                ticker?.cancel()
                busy = false
            }
        }
    }

    fun generate() {
        val d = deck ?: return
        if (topic.isBlank()) return
        runAi(expected = count) { p -> repo.generate(topic.trim(), d, count, level, hint, p) }
    }

    fun scan(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (uris.isEmpty()) return
        var images: List<ByteArray> = emptyList()
        runAi(
            expected = 0,
            prepare = {
                status = if (uris.size > 1) "${uris.size} Bilder werden vorbereitet …" else "Bild wird vorbereitet …"
                images = kotlinx.coroutines.coroutineScope { uris.map { async { ImageUtils.loadJpeg(context, it) } }.awaitAll() }
            },
        ) { p -> repo.extract(images, d, hint, p) }
    }

    val selectedCount: Int get() = drafts.count { it.selected }

    fun save(onDone: () -> Unit) {
        val d = deck ?: return
        if (busy) return
        viewModelScope.launch {
            busy = true
            val pairs = drafts.filter { it.selected }.map { it.pair }
            if (pairs.isNotEmpty()) repo.addCards(d, pairs)
            busy = false
            onDone()
        }
    }
}
