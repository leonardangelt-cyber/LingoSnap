package com.lingosnap.ui.create

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.ImageUtils
import com.lingosnap.util.parseVocabText
import kotlinx.coroutines.launch

class Draft(val pair: VocabPair, selected: Boolean = true) {
    var selected by mutableStateOf(selected)
}

class CreateViewModel(private val repo: CardRepository, val deckId: Long) : ViewModel() {

    var existing by mutableStateOf<Deck?>(null)
        private set

    var name by mutableStateOf("")
    var description by mutableStateOf("")
    var groupId by mutableStateOf<Long?>(null)
    var newGroupName by mutableStateOf("")
    var sourceLang by mutableStateOf("es")
    var targetLang by mutableStateOf("de")

    /** 0 = manuell/Text, 1 = KI-Assistent, 2 = Foto */
    var method by mutableStateOf(0)
    var manualText by mutableStateOf("")
    var topic by mutableStateOf("")
    var count by mutableStateOf(15)
    var level by mutableStateOf("A1")

    val drafts = mutableStateListOf<Draft>()
    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    init {
        if (deckId != 0L) viewModelScope.launch {
            repo.deck(deckId)?.let {
                existing = it
                name = it.name
                sourceLang = it.sourceLang
                targetLang = it.targetLang
            }
        }
    }

    fun swapLanguages() { val s = sourceLang; sourceLang = targetLang; targetLang = s }

    fun generate() {
        if (topic.isBlank() || busy) return
        busy = true; error = null
        viewModelScope.launch {
            repo.generate(topic.trim(), sourceLang, targetLang, count, level)
                .onSuccess { list -> drafts.addAll(list.map { Draft(it) }) }
                .onFailure { error = it.message ?: "Unbekannter Fehler" }
            busy = false
        }
    }

    fun scan(context: Context, uri: Uri) {
        if (busy) return
        busy = true; error = null
        viewModelScope.launch {
            runCatching { ImageUtils.loadJpeg(context, uri) }
                .mapCatching { bytes -> repo.extract(bytes, sourceLang, targetLang).getOrThrow() }
                .onSuccess { list -> drafts.addAll(list.map { Draft(it) }) }
                .onFailure { error = it.message ?: "Bild konnte nicht gelesen werden" }
            busy = false
        }
    }

    fun clearError() { error = null }

    val manualPairs: List<VocabPair> get() = parseVocabText(manualText)

    val selectedCount: Int get() = drafts.count { it.selected } + manualPairs.size

    val canSave: Boolean get() = !busy && selectedCount > 0 && (deckId != 0L || name.isNotBlank())

    fun save(onDone: (Long) -> Unit) {
        if (!canSave) return
        viewModelScope.launch {
            busy = true
            val pairs = (drafts.filter { it.selected }.map { it.pair } + manualPairs)
                .distinctBy { it.source.lowercase() to it.target.lowercase() }
            val deck: Deck = existing ?: run {
                var gid = groupId
                if (gid == null && newGroupName.isNotBlank()) gid = repo.createGroup(newGroupName)
                val id = repo.createDeck(name, gid, sourceLang, targetLang, description)
                repo.deck(id)!!
            }
            repo.addCards(deck, pairs)
            busy = false
            onDone(deck.id)
        }
    }

    val groups: kotlinx.coroutines.flow.Flow<List<DeckGroup>> get() = repo.groups
}
