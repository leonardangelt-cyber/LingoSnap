package com.lingosnap.ui.create

import com.lingosnap.util.tr

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.remote.GeminiException
import com.lingosnap.data.remote.Progress
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.AiJobs
import com.lingosnap.util.Batch
import com.lingosnap.util.DocumentReader
import com.lingosnap.util.JobInfo
import com.lingosnap.util.Notifier
import com.lingosnap.util.PendingStore
import com.lingosnap.util.baseForm
import com.lingosnap.util.levenshtein
import com.lingosnap.util.normalize
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlin.math.exp
import kotlin.math.max

class Draft(pair: VocabPair, selected: Boolean = true) {
    var pair by mutableStateOf(pair)
    var selected by mutableStateOf(selected)
    /** Set when the AI or the spelling check found a similar entry. */
    var note by mutableStateOf<String?>(null)
}

/** One choice in the duplicate pop-up. */
class Option(
    val kind: Int,
    val label: String,
    val pair: VocabPair,
    val existing: Flashcard? = null,
    val draft: Draft? = null,
) {
    companion object {
        const val EXISTING = 0
        const val DRAFT = 1
        const val MERGE = 2
        const val KEEP_ALL = 3
    }
}

class Conflict(val options: List<Option>) {
    var chosen by mutableIntStateOf(0)
}

/**
 * Collects new cards for an existing deck (typed, from files or from the AI) and saves them at once.
 * AI jobs run in [appScope], so they keep going when the user leaves the screen.
 */
val DEFAULT_DECK_NAME: String get() = tr("Neues Deck")

class AddCardsViewModel(
    private val repo: CardRepository,
    private val deckId: Long,
    private val appScope: CoroutineScope,
    private val notifier: Notifier,
) : ViewModel() {

    var deck by mutableStateOf<Deck?>(null)
        private set

    val drafts = mutableStateListOf<Draft>()
    private val seen = HashSet<String>()

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** 0..1 while the AI works; status text says what it is doing right now. */
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf<String?>(null)
        private set

    /** Loading dialog: visible while the AI works and until the user confirms the result. */
    var showProgress by mutableStateOf(false)
        private set
    /** 0 prepare, 1 send, 2 read, 3 assemble, 4 check duplicates, 5 done */
    var step by mutableIntStateOf(0)
        private set
    var found by mutableIntStateOf(0)
        private set
    var scanning by mutableStateOf(false)
        private set
    private var aiJob: Job? = null
    private var detached = false
    private var inBackground = false

    var topic by mutableStateOf("")
    var count by mutableStateOf(20)
    var level by mutableStateOf("A1")
    var hint by mutableStateOf("")

    init {
        viewModelScope.launch {
            deck = repo.deck(deckId)
            // results of a job that finished while the screen was closed
            PendingStore.take(deckId)?.forEach { addDraft(it) }
        }
    }

    override fun onCleared() { detached = true }

    fun dismissProgress() { if (!busy) showProgress = false }

    private var userCancelled = false

    /** Stops the AI job at once (the running request is aborted) and closes the progress sheet. */
    fun cancelAi() {
        userCancelled = true
        showProgress = false
        aiJob?.cancel()
    }

    /** "Im Hintergrund fortsetzen": hides the dialog, keeps working and notifies when done. */
    fun moveToBackground() {
        if (!busy) return
        inBackground = true
        showProgress = false
        notifier.startKeepAlive()
    }

    private fun addDraft(pair: VocabPair): Boolean {
        val key = pair.source.lowercase() + "|" + pair.target.lowercase()
        if (!seen.add(key)) return false
        drafts.add(0, Draft(pair))
        return true
    }

    fun addManual(source: String, target: String) {
        if (source.isBlank() || target.isBlank()) return
        addDraft(VocabPair(source.trim(), target.trim()))
    }

    fun addList(text: String): Int =
        com.lingosnap.util.parseVocabText(text).count { addDraft(it) }

    /* ── AI jobs ── */

    private var batchCount = 1
    private var completedBatches = 0
    private var receivedTotal = 0
    private var receivedAtComplete = 0

    private fun part() = if (batchCount > 1) tr(" (Teil {0} von {1} fertig)", completedBatches, batchCount) else ""

    /** Runs an AI job with live progress. [expected] = known number of entries, or 0 if unknown. */
    private fun runAi(expected: Int, scan: Boolean, prepare: suspend () -> Unit = {}, job: suspend (Progress) -> Result<List<VocabPair>>) {
        if (busy) return
        userCancelled = false
        busy = true; error = null; notice = null; showProgress = true; scanning = scan; inBackground = false
        step = 0; found = 0; progress = 0.03f
        batchCount = 1; completedBatches = 0; receivedTotal = 0; receivedAtComplete = 0
        status = if (scan) tr("Dateien werden vorbereitet") else tr("Anfrage wird vorbereitet")
        aiJob = appScope.launch {
            var ticker: Job? = null
            var failed: String? = null
            var cancelled = false
            // publishes percent + status for the deck list and the notification
            val reporter = launch {
                while (true) {
                    val pct = (progress * 100).toInt().coerceIn(0, 100)
                    val text = status ?: ""
                    AiJobs.set(deckId, JobInfo(pct, text))
                    if (inBackground || detached) notifier.progress(deckId, deck?.name ?: tr("Deck"), pct, text)
                    delay(400)
                }
            }
            try {
                prepare()
                step = 1; progress = 0.15f
                status = tr("Anfrage wird an die KI gesendet") + part()
                // creeps forward while we wait for the first answer
                ticker = launch {
                    while (progress < 0.3f) { delay(250); progress += 0.01f }
                }
                val p = Progress(
                    onModel = { m -> launch(Dispatchers.Main) { status = tr("Gesendet an {0} – warte auf Antwort", m) + part() } },
                    onFirstText = {
                        launch(Dispatchers.Main) {
                            ticker?.cancel()
                            step = 2
                            status = (if (scan) tr("KI liest den Text und erkennt Einträge") else tr("KI erzeugt Einträge")) + part()
                            if (progress < 0.35f) progress = 0.35f
                        }
                    },
                    onPair = { pair ->
                        launch(Dispatchers.Main) {
                            if (addDraft(pair)) receivedTotal++
                            found = receivedTotal
                            val f = if (expected > 0) (receivedTotal / expected.toFloat()).coerceAtMost(1f)
                            else (completedBatches + (1f - exp(-(receivedTotal - receivedAtComplete) / 12f))) / batchCount
                            progress = max(progress, 0.35f + 0.45f * f.coerceAtMost(1f))
                        }
                    },
                )
                job(p).onSuccess { list ->
                    step = 3; status = tr("Liste wird zusammengestellt"); progress = max(progress, 0.82f)
                    list.forEach { pair ->
                        if (!addDraft(pair) && pair.image != null) {
                            // the card was already shown while streaming: give it the picture cut out afterwards
                            val key = pair.source.lowercase() + "|" + pair.target.lowercase()
                            drafts.firstOrNull { it.pair.source.lowercase() + "|" + it.pair.target.lowercase() == key }
                                ?.let { it.pair = it.pair.copy(image = pair.image) }
                        }
                    }
                    found = drafts.size
                    if (repo.qualityCheck && drafts.size in 1..80) {
                        step = 4; status = tr("KI prüft die Karten auf Fehler"); progress = 0.85f
                        val d = deck
                        if (d != null) repo.reviewPairs(d, drafts.map { it.pair }).onSuccess { fixes ->
                            fixes.forEach { (i, fix) ->
                                val draft = drafts.getOrNull(i) ?: return@forEach
                                val before = draft.pair
                                if (before.source != fix.first || before.target != fix.second) {
                                    draft.pair = before.copy(source = fix.first, target = fix.second)
                                    draft.note = tr("Von der KI korrigiert (vorher: {0} – {1})", before.source, before.target)
                                }
                            }
                        }
                    }
                    step = 4; status = tr("KI prüft auf gleiche und ähnliche Vokabeln"); progress = 0.88f
                    checkDuplicates()
                    autoName()
                    progress = 1f
                    step = 5
                    status = tr("Fertig")
                }.onFailure {
                    if (userCancelled || it is kotlinx.coroutines.CancellationException) {
                        cancelled = true; status = null; showProgress = false
                    } else {
                        failed = it.message ?: tr("Unbekannter Fehler")
                        error = failed
                        status = null
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                cancelled = true
                status = null
                showProgress = false
                throw e
            } catch (e: Exception) {
                if (userCancelled) { cancelled = true; status = null; showProgress = false }
                else {
                    failed = e.message ?: tr("Unbekannter Fehler")
                    error = failed
                    status = null
                }
            } finally {
                ticker?.cancel()
                reporter.cancel()
                AiJobs.clear(deckId)
                busy = false
                if (cancelled) {
                    notifier.stopKeepAlive()
                    notifier.cancelProgress()
                } else if (inBackground || detached) {
                    notifier.stopKeepAlive()
                    // finished while the learner was elsewhere: the cards go straight into the deck, so the deck is full when it is opened
                    val saved = if (failed == null) runCatching { autoSave() }.getOrDefault(0) else 0
                    val title = if (failed == null) tr("LingoSnap: Fertig") else tr("LingoSnap: Das hat nicht geklappt")
                    val text = if (failed == null) tr("{0} Karten wurden zu „{1}“ hinzugefügt.", saved, deck?.name ?: tr("deinem Deck")) else failed.orEmpty()
                    notifier.done(deckId, title, text)
                }
            }
        }
        aiJob?.let { AiJobs.register(deckId, it) }
    }

    /** Saves every selected draft that is not already in the deck. Returns how many cards were added. */
    private suspend fun autoSave(): Int {
        val d = deck ?: return 0
        val existing = runCatching { repo.cardsOf(deckId) }.getOrDefault(emptyList())
        val known = existing.map { normalize(it.source) + "|" + normalize(it.target) }.toSet()
        val add = drafts.filter { it.selected && (normalize(it.pair.source) + "|" + normalize(it.pair.target)) !in known }
        if (add.isEmpty()) return 0
        repo.addCards(d, add.map { it.pair })
        drafts.clear()
        seen.clear()
        found = 0
        return add.size
    }

    /** A deck still called "Neues Deck" gets a fitting title once its first cards are there. */
    private suspend fun autoName() {
        val d = deck ?: return
        if (d.name != DEFAULT_DECK_NAME || drafts.isEmpty()) return
        status = tr("KI gibt dem Deck einen Namen")
        val name = repo.suggestDeckName(drafts.take(25).map { it.pair.source + " – " + it.pair.target }, d.isLanguage) ?: return
        repo.renameDeck(d, name)
        deck = d.copy(name = name)
    }

    /** Cuts the pictures the AI pointed out from the pages it was shown and attaches them to the cards. */
    private suspend fun attachFigures(images: List<ByteArray>, pairs: List<VocabPair>): List<VocabPair> =
        pairs.map { p ->
            val f = p.figure
            if (f == null || f.size != 5) p
            else {
                val bytes = images.getOrNull(f[0].toInt() - 1)
                val path = bytes?.let { kotlinx.coroutines.withContext(Dispatchers.Default) { com.lingosnap.util.CardImages.crop(it, f[1], f[2], f[3], f[4]) } }
                p.copy(figure = null, image = path)
            }
        }

    fun generate() {
        val d = deck ?: return
        if (topic.isBlank()) return
        runAi(expected = count, scan = false) { p -> repo.generate(topic.trim(), d, count, "", hint, p) }
    }

    fun scan(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (uris.isEmpty()) return
        var batches: List<Batch> = emptyList()
        runAi(
            expected = 0,
            scan = true,
            prepare = {
                status = if (uris.size > 1) tr("{0} Dateien werden vorbereitet …", uris.size) else tr("Datei wird vorbereitet …")
                batches = DocumentReader.read(context, uris).batches
                batchCount = batches.size.coerceAtLeast(1)
            },
        ) { p ->
            // small files: one request. Big files: several parts, up to three at the same time.
            val bulk = batches.size > 3
            val fullHint = if (minLevel.isBlank()) hint else hint + "\nOnly create cards for vocabulary at CEFR level ${minLevel} or higher. Skip easier everyday words that a learner at that level already knows."
            val results = coroutineScope {
                val gate = Semaphore(3)
                batches.map { batch ->
                    async {
                        gate.withPermit {
                            val imgs = batch.images?.invoke().orEmpty()
                            repo.extract(imgs, d, fullHint, p, batch.text, bulk).let { r -> r.map { attachFigures(imgs, it) } }.also {
                                receivedAtComplete = receivedTotal
                                completedBatches++
                                if (batchCount > 1) status = tr("KI liest den Inhalt") + part()
                            }
                        }
                    }
                }.awaitAll()
            }.toMutableList()
            // parts that failed for a real reason (limit, network) get two more tries, one after another and slowly
            fun failed(r: Result<List<VocabPair>>) = r.exceptionOrNull()?.let { it !is GeminiException.NoResult } == true
            var round = 0
            while (round < 2 && results.indices.any { failed(results[it]) }) {
                round++
                for (i in results.indices) {
                    if (!failed(results[i])) continue
                    status = tr("Fehlgeschlagene Teile werden wiederholt ({0}/2)", round)
                    val batch = batches[i]
                    val imgs = batch.images?.invoke().orEmpty()
                    results[i] = repo.extract(imgs, d, fullHint, p, batch.text, bulk).let { r -> r.map { attachFigures(imgs, it) } }
                }
            }
            val missing = results.count { failed(it) }
            if (missing > 0) notice = tr("{0} von {1} Teilen der Datei konnten nicht gelesen werden, die Einträge daraus fehlen. Starte den Import später noch einmal, um sie nachzuholen.", missing, results.size)
            val all = results.flatMap { it.getOrNull().orEmpty() }
            // a part without vocabulary (blank page, cover) is fine; real errors only count if nothing worked
            val realError = results.firstNotNullOfOrNull { r -> r.exceptionOrNull()?.takeIf { it !is GeminiException.NoResult } }
            when {
                all.isNotEmpty() -> Result.success(all)
                realError != null -> Result.failure(realError)
                else -> Result.failure(GeminiException.NoResult(""))
            }
        }
    }

    /** Only vocabulary from this CEFR level upwards ("" = everything). */
    var minLevel by mutableStateOf("")

    /** Shown above the list when part of a big file could not be read. */
    var notice by mutableStateOf<String?>(null)
        private set

    val selectedCount: Int get() = drafts.count { it.selected }

    /* ── duplicates: same or similar words, in the deck or in the new list ── */

    private class Item(val card: Flashcard? = null, val draft: Draft? = null) {
        val source get() = card?.source ?: draft!!.pair.source
        val target get() = card?.target ?: draft!!.pair.target
    }

    /** Groups the AI found, as lists of cards/drafts. */
    private var aiGroups: List<List<Any>> = emptyList()

    private suspend fun checkDuplicates() {
        val existing = runCatching { repo.cardsOf(deckId) }.getOrDefault(emptyList()).take(600)
        val fresh = drafts.toList()
        if (fresh.isEmpty() || (existing.isEmpty() && fresh.size < 2)) return
        // huge imports: only the spelling check (the AI list would be too long and slow)
        if (fresh.size > 300) { markSimilar(existing); return }
        repo.findDuplicates(
            existing.map { "${it.source} = ${it.target}" },
            fresh.map { "${it.pair.source} = ${it.pair.target}" },
        ).onSuccess { groups ->
            aiGroups = groups.mapNotNull { g ->
                val items = g.mapNotNull { id ->
                    val n = id.drop(1).toIntOrNull()?.minus(1) ?: return@mapNotNull null
                    when (id.firstOrNull()) {
                        'E' -> existing.getOrNull(n)
                        'N' -> fresh.getOrNull(n)
                        else -> null
                    }
                }
                items.takeIf { it.size >= 2 }
            }
        }
        markSimilar(existing)
    }

    /** Puts a short note on every new entry that has a twin. */
    private fun markSimilar(existing: List<Flashcard>) {
        groupsFor(existing, drafts.filter { it.selected }).forEach { g ->
            g.filter { it.draft != null }.forEach { dr ->
                val other = g.firstOrNull { it !== dr }
                if (other != null) dr.draft!!.note = tr("Ähnlich: {0} – {1}", other.source, other.target)
            }
        }
    }

    private fun similarKey(a: String, b: String): Boolean {
        val x = baseForm(a); val y = baseForm(b)
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        return x.length >= 5 && y.length >= 5 && x[0] == y[0] && kotlin.math.abs(x.length - y.length) <= 1 && levenshtein(x, y) <= 1
    }

    /** Spelling check plus the AI's groups, merged into connected groups that contain at least one new entry. */
    private fun groupsFor(existing: List<Flashcard>, selected: List<Draft>): List<List<Item>> {
        val items = existing.map { Item(card = it) } + selected.map { Item(draft = it) }
        val parent = IntArray(items.size) { it }
        fun find(i: Int): Int { var x = i; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }; return x }
        fun union(a: Int, b: Int) { parent[find(a)] = find(b) }
        // index by first letter so the pairwise check stays fast
        val byLetter = items.indices.groupBy { baseForm(items[it].source).firstOrNull() }
        byLetter.values.forEach { idx ->
            for (i in idx.indices) for (j in i + 1 until idx.size) {
                val a = idx[i]; val b = idx[j]
                if (items[a].card != null && items[b].card != null) continue
                if (similarKey(items[a].source, items[b].source)) union(a, b)
            }
        }
        aiGroups.forEach { g ->
            val idx = g.mapNotNull { m -> items.indexOfFirst { it.card === m || it.draft === m }.takeIf { it >= 0 } }
            for (k in 1 until idx.size) union(idx[0], idx[k])
        }
        return items.indices.groupBy { find(it) }.values
            .map { grp -> grp.map { items[it] } }
            .filter { g -> g.size >= 2 && g.any { it.draft != null } }
    }

    var conflicts by mutableStateOf<List<Conflict>>(emptyList())
        private set
    private var plainDrafts: List<Draft> = emptyList()
    private var pendingDone: (() -> Unit)? = null

    /** Both meanings in one card: translations are joined, the first example sentence is kept. */
    private fun merged(pairs: List<VocabPair>): VocabPair {
        val targets = pairs.flatMap { it.target.split(";") }.map { it.trim() }.filter { it.isNotEmpty() }
            .distinctBy { it.lowercase() }
        return VocabPair(
            pairs.first().source, targets.joinToString("; "),
            pairs.firstNotNullOfOrNull { it.example }, pairs.firstNotNullOfOrNull { it.lang },
        )
    }

    fun save(onDone: () -> Unit) {
        val d = deck ?: return
        if (busy) return
        viewModelScope.launch {
            busy = true
            val existing = repo.cardsOf(deckId)
            // exactly the same card is already there: nothing to decide
            val identical = existing.map { normalize(it.source) + "|" + normalize(it.target) }.toSet()
            val selected = drafts.filter { it.selected && (normalize(it.pair.source) + "|" + normalize(it.pair.target)) !in identical }
            val groups = groupsFor(existing, selected)
            val inGroup = groups.flatten().mapNotNull { it.draft }.toSet()
            val plain = selected.filter { it !in inGroup }
            if (groups.isEmpty()) {
                commit(d, plain, emptyList(), onDone)
                return@launch
            }
            conflicts = groups.map { g ->
                val options = g.map { item ->
                    if (item.card != null) Option(Option.EXISTING, tr("Bereits im Deck"), VocabPair(item.card.source, item.card.target, item.card.example), existing = item.card)
                    else Option(Option.DRAFT, tr("Neu"), item.draft!!.pair, draft = item.draft)
                }.sortedBy { it.kind }
                val all = options.map { it.pair }
                Conflict(
                    options +
                        Option(Option.MERGE, tr("Zusammenfügen"), merged(all)) +
                        Option(Option.KEEP_ALL, tr("Alle behalten"), all.first()),
                )
            }
            plainDrafts = plain
            pendingDone = onDone
            busy = false
        }
    }

    fun resolveConflicts() {
        val d = deck ?: return
        val done = pendingDone ?: return
        val add = plainDrafts.toMutableList()
        val delete = mutableListOf<Flashcard>()
        conflicts.forEach { c ->
            val keep = c.options[c.chosen]
            val existing = c.options.mapNotNull { it.existing }
            val drafts = c.options.mapNotNull { it.draft }
            when (keep.kind) {
                Option.DRAFT -> { keep.draft?.let { add += it }; delete += existing }
                Option.MERGE -> { add += Draft(keep.pair); delete += existing }
                Option.KEEP_ALL -> add += drafts
                else -> Unit // keep the card that is already in the deck
            }
        }
        conflicts = emptyList()
        viewModelScope.launch { busy = true; commit(d, add, delete, done) }
    }

    fun cancelConflicts() { conflicts = emptyList(); pendingDone = null }

    private suspend fun commit(d: Deck, add: List<Draft>, delete: List<Flashcard>, onDone: () -> Unit) {
        if (delete.isNotEmpty()) repo.deleteCards(delete)
        if (add.isNotEmpty()) repo.addCards(d, add.map { it.pair })
        busy = false
        onDone()
    }
}
