package com.lingosnap.ui.create

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.remote.Progress
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.exp

class Draft(val pair: VocabPair, selected: Boolean = true) {
    var selected by mutableStateOf(selected)
}

/** Collects new cards for an existing deck (typed, from photos or from the AI) and saves them at once. */
class AddCardsViewModel(private val repo: CardRepository, private val deckId: Long) : ViewModel() {

    var deck by mutableStateOf<Deck?>(null)
        private set

    val drafts = mutableStateListOf<Draft>()
    private val seen = HashSet<String>()

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** 0..1 while the AI works; status text says what it is doing right now. */
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf<String?>(null)
        private set

    /** Loading dialog: visible while the AI works and until the user confirms the result. */
    var showProgress by mutableStateOf(false)
        private set
    /** 0 = preparing, 1 = sending, 2 = reading, 3 = assembling, 4 = done */
    var step by mutableIntStateOf(0)
        private set
    var found by mutableIntStateOf(0)
        private set
    var modelName by mutableStateOf<String?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    private var aiJob: Job? = null

    fun dismissProgress() { if (!busy) showProgress = false }

    fun cancelAi() {
        aiJob?.cancel()
    }

    var topic by mutableStateOf("")
    var count by mutableStateOf(15)
    var level by mutableStateOf("A1")
    var hint by mutableStateOf("")

    init {
        viewModelScope.launch { deck = repo.deck(deckId) }
    }

    private fun addDraft(pair: VocabPair): Boolean {
        val key = pair.source.lowercase() + "|" + pair.target.lowercase()
        if (!seen.add(key)) return false
        drafts.add(0, Draft(pair))
        return true
    }

    fun addManual(source: String, target: String) {
        if (source.isBlank() || target.isBlank()) return
        addDraft(VocabPair(source.trim(), target.trim()))
    }

    fun addList(text: String): Int =
        com.lingosnap.util.parseVocabText(text).count { addDraft(it) }

    /** Runs an AI job with live progress. [expected] = known number of entries, or 0 if unknown. */
    private fun runAi(expected: Int, scan: Boolean, prepare: suspend () -> Unit = {}, job: suspend (Progress) -> Result<List<VocabPair>>) {
        if (busy) return
        busy = true; error = null; showProgress = true; scanning = scan
        step = 0; found = 0; modelName = null; progress = 0.03f
        status = if (scan) "Bilder werden vorbereitet" else "Anfrage wird vorbereitet"
        aiJob = viewModelScope.launch {
            var ticker: Job? = null
            var received = 0
            try {
                prepare()
                step = 1; progress = 0.15f
                status = "Anfrage wird an die KI gesendet"
                // creeps forward while we wait for the first answer
                ticker = launch {
                    while (progress < 0.3f) { delay(250); progress += 0.01f }
                }
                val p = Progress(
                    onModel = { m -> launch(Dispatchers.Main) { modelName = m; status = "Gesendet an $m – warte auf Antwort" } },
                    onFirstText = {
                        launch(Dispatchers.Main) {
                            ticker?.cancel()
                            step = 2
                            status = if (scan) "KI liest den Text und erkennt Einträge" else "KI erzeugt Einträge"
                            if (progress < 0.35f) progress = 0.35f
                        }
                    },
                    onPair = { pair ->
                        launch(Dispatchers.Main) {
                            if (addDraft(pair)) received++
                            found = received
                            val f = if (expected > 0) (received / expected.toFloat()).coerceAtMost(1f)
                            else 1f - exp(-received / 12f)
                            progress = 0.35f + 0.55f * f
                        }
                    },
                )
                job(p).onSuccess { list ->
                    step = 3; status = "Liste wird zusammengestellt"
                    list.forEach { addDraft(it) }
                    found = drafts.size
                    progress = 1f
                    step = 4
                    status = "Fertig"
                }.onFailure {
                    error = it.message ?: "Unbekannter Fehler"
                    status = null
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                status = null
                showProgress = false
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Unbekannter Fehler"
                status = null
            } finally {
                ticker?.cancel()
                busy = false
            }
        }
    }

    fun generate() {
        val d = deck ?: return
        if (topic.isBlank()) return
        runAi(expected = count, scan = false) { p -> repo.generate(topic.trim(), d, count, level, hint, p) }
    }

    fun scan(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (uris.isEmpty()) return
        var images: List<ByteArray> = emptyList()
        runAi(
            expected = 0,
            scan = true,
            prepare = {
                status = if (uris.size > 1) "${uris.size} Bilder werden vorbereitet …" else "Bild wird vorbereitet …"
                images = kotlinx.coroutines.coroutineScope { uris.map { async { ImageUtils.loadJpeg(context, it) } }.awaitAll() }
            },
        ) { p -> repo.extract(images, d, hint, p) }
    }

    val selectedCount: Int get() = drafts.count { it.selected }

    fun save(onDone: () -> Unit) {
        val d = deck ?: return
        if (busy) return
        viewModelScope.launch {
            busy = true
            val pairs = drafts.filter { it.selected }.map { it.pair }
            if (pairs.isNotEmpty()) repo.addCards(d, pairs)
            busy = false
            onDone()
        }
    }
}
