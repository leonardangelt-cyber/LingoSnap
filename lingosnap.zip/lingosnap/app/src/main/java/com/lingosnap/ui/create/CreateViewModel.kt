package com.lingosnap.ui.create

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.remote.Progress
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.DocumentReader
import com.lingosnap.util.Material
import com.lingosnap.data.model.Flashcard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.exp

class Draft(val pair: VocabPair, selected: Boolean = true) {
    var selected by mutableStateOf(selected)
}

/** Collects new cards for an existing deck (typed, from photos or from the AI) and saves them at once. */
class AddCardsViewModel(private val repo: CardRepository, private val deckId: Long) : ViewModel() {

    var deck by mutableStateOf<Deck?>(null)
        private set

    val drafts = mutableStateListOf<Draft>()
    private val seen = HashSet<String>()

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** 0..1 while the AI works; status text says what it is doing right now. */
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf<String?>(null)
        private set

    /** Loading dialog: visible while the AI works and until the user confirms the result. */
    var showProgress by mutableStateOf(false)
        private set
    /** 0 = preparing, 1 = sending, 2 = reading, 3 = assembling, 4 = done */
    var step by mutableIntStateOf(0)
        private set
    var found by mutableIntStateOf(0)
        private set
    var modelName by mutableStateOf<String?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    private var aiJob: Job? = null

    fun dismissProgress() { if (!busy) showProgress = false }

    fun cancelAi() {
        aiJob?.cancel()
    }

    var topic by mutableStateOf("")
    var count by mutableStateOf(15)
    var level by mutableStateOf("A1")
    var hint by mutableStateOf("")

    init {
        viewModelScope.launch { deck = repo.deck(deckId) }
    }

    private fun addDraft(pair: VocabPair): Boolean {
        val key = pair.source.lowercase() + "|" + pair.target.lowercase()
        if (!seen.add(key)) return false
        drafts.add(0, Draft(pair))
        return true
    }

    fun addManual(source: String, target: String) {
        if (source.isBlank() || target.isBlank()) return
        addDraft(VocabPair(source.trim(), target.trim()))
    }

    fun addList(text: String): Int =
        com.lingosnap.util.parseVocabText(text).count { addDraft(it) }

    /** Runs an AI job with live progress. [expected] = known number of entries, or 0 if unknown. */
    private var batchIndex = 0
    private var batchCount = 1
    private var batchStart = 0
    private var receivedTotal = 0
    private fun part() = if (batchCount > 1) " (Teil ${batchIndex + 1} von $batchCount)" else ""

    private fun runAi(expected: Int, scan: Boolean, prepare: suspend () -> Unit = {}, job: suspend (Progress) -> Result<List<VocabPair>>) {
        if (busy) return
        busy = true; error = null; showProgress = true; scanning = scan
        step = 0; found = 0; modelName = null; progress = 0.03f
        status = if (scan) "Bilder werden vorbereitet" else "Anfrage wird vorbereitet"
        aiJob = viewModelScope.launch {
            var ticker: Job? = null
            receivedTotal = 0; batchIndex = 0; batchCount = 1; batchStart = 0
            try {
                prepare()
                step = 1; progress = 0.15f
                status = "Anfrage wird an die KI gesendet"
                // creeps forward while we wait for the first answer
                ticker = launch {
                    while (progress < 0.3f) { delay(250); progress += 0.01f }
                }
                val p = Progress(
                    onModel = { m -> launch(Dispatchers.Main) { modelName = m; status = "Gesendet an $m – warte auf Antwort" + part() } },
                    onFirstText = {
                        launch(Dispatchers.Main) {
                            ticker?.cancel()
                            step = 2
                            status = (if (scan) "KI liest den Text und erkennt Einträge" else "KI erzeugt Einträge") + part()
                            if (progress < 0.35f) progress = 0.35f
                        }
                    },
                    onPair = { pair ->
                        launch(Dispatchers.Main) {
                            if (addDraft(pair)) receivedTotal++
                            found = receivedTotal
                            val f = if (expected > 0) (receivedTotal / expected.toFloat()).coerceAtMost(1f)
                            else (batchIndex + (1f - exp(-(receivedTotal - batchStart) / 12f))) / batchCount
                            progress = 0.35f + 0.55f * f
                        }
                    },
                )
                job(p).onSuccess { list ->
                    step = 3; status = "Liste wird zusammengestellt"
                    list.forEach { addDraft(it) }
                    found = drafts.size
                    progress = 1f
                    step = 4
                    status = "Fertig"
                }.onFailure {
                    error = it.message ?: "Unbekannter Fehler"
                    status = null
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                status = null
                showProgress = false
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Unbekannter Fehler"
                status = null
            } finally {
                ticker?.cancel()
                busy = false
            }
        }
    }

    fun generate() {
        val d = deck ?: return
        if (topic.isBlank()) return
        runAi(expected = count, scan = false) { p -> repo.generate(topic.trim(), d, count, level, hint, p) }
    }

    fun scan(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (uris.isEmpty()) return
        var batches: List<Pair<List<ByteArray>, String>> = emptyList()
        runAi(
            expected = 0,
            scan = true,
            prepare = {
                status = if (uris.size > 1) "${uris.size} Dateien werden vorbereitet …" else "Datei wird vorbereitet …"
                batches = DocumentReader.read(context, uris).batches()
                batchCount = batches.size.coerceAtLeast(1)
            },
        ) { p ->
            // big documents are read in parts so that every page is covered
            val all = ArrayList<VocabPair>()
            var lastError: Throwable? = null
            batches.forEachIndexed { i, (imgs, txt) ->
                batchIndex = i
                batchStart = receivedTotal
                if (batchCount > 1) status = "KI liest Teil ${i + 1} von $batchCount"
                repo.extract(imgs, d, hint, p, txt)
                    .onSuccess { all += it }
                    .onFailure { e ->
                        // a part without vocabulary (blank page, cover) is fine; other errors are reported if nothing worked at all
                        if (e !is com.lingosnap.data.remote.GeminiException.NoResult) lastError = e
                    }
            }
            if (all.isEmpty()) Result.failure(lastError ?: com.lingosnap.data.remote.GeminiException.NoResult(""))
            else Result.success(all)
        }
    }

    val selectedCount: Int get() = drafts.count { it.selected }

    /* ── duplicates: same word already in the deck, or twice in the new list ── */

    class Option(
        val label: String,
        val pair: VocabPair,
        val existing: Flashcard? = null,
        val draft: Draft? = null,
        val merge: Boolean = false,
    )

    /** Both meanings in one card: translations are joined, the first example sentence is kept. */
    private fun merged(pairs: List<VocabPair>): VocabPair {
        val targets = pairs.flatMap { it.target.split(";") }.map { it.trim() }.filter { it.isNotEmpty() }
            .distinctBy { it.lowercase() }
        return VocabPair(
            pairs.first().source, targets.joinToString("; "),
            pairs.firstNotNullOfOrNull { it.example }, pairs.firstNotNullOfOrNull { it.lang },
        )
    }

    private fun withMerge(options: List<Option>): List<Option> =
        options + Option("Zusammenfügen", merged(options.map { it.pair }), merge = true)

    class Conflict(val options: List<Option>) {
        var chosen by mutableIntStateOf(0)
    }

    var conflicts by mutableStateOf<List<Conflict>>(emptyList())
        private set
    private var plainDrafts: List<Draft> = emptyList()
    private var pendingDone: (() -> Unit)? = null

    private fun norm(s: String) = s.trim().lowercase()

    fun save(onDone: () -> Unit) {
        val d = deck ?: return
        if (busy) return
        viewModelScope.launch {
            busy = true
            val existing = repo.cardsOf(deckId)
            val found = mutableListOf<Conflict>()
            val remaining = mutableListOf<Draft>()
            for (draft in drafts.filter { it.selected }) {
                val same = existing.filter { norm(it.source) == norm(draft.pair.source) }
                when {
                    // exactly the same card is already there: nothing to decide
                    same.any { norm(it.target) == norm(draft.pair.target) } -> Unit
                    same.isNotEmpty() -> {
                        val e = same.first()
                        found += Conflict(
                            withMerge(
                                listOf(
                                    Option("Bereits im Deck", VocabPair(e.source, e.target, e.example), existing = e),
                                    Option("Neu", draft.pair, draft = draft),
                                ),
                            ),
                        )
                    }
                    else -> remaining += draft
                }
            }
            val plain = mutableListOf<Draft>()
            remaining.groupBy { norm(it.pair.source) }.values.forEach { group ->
                if (group.size > 1) found += Conflict(withMerge(group.mapIndexed { i, dr -> Option("Neu ${i + 1}", dr.pair, draft = dr) }))
                else plain += group
            }
            if (found.isEmpty()) {
                commit(d, plain, emptyList(), onDone)
            } else {
                plainDrafts = plain
                pendingDone = onDone
                conflicts = found
                busy = false
            }
        }
    }

    fun resolveConflicts() {
        val d = deck ?: return
        val done = pendingDone ?: return
        val add = plainDrafts.toMutableList()
        val delete = mutableListOf<Flashcard>()
        conflicts.forEach { c ->
            val keep = c.options[c.chosen]
            if (keep.merge) add += Draft(keep.pair) else keep.draft?.let { add += it }
            c.options.forEach { o -> if (o !== keep && o.existing != null) delete += o.existing }
        }
        conflicts = emptyList()
        viewModelScope.launch { busy = true; commit(d, add, delete, done) }
    }

    fun cancelConflicts() { conflicts = emptyList(); pendingDone = null }

    private suspend fun commit(d: Deck, add: List<Draft>, delete: List<Flashcard>, onDone: () -> Unit) {
        if (delete.isNotEmpty()) repo.deleteCards(delete)
        if (add.isNotEmpty()) repo.addCards(d, add.map { it.pair })
        busy = false
        onDone()
    }
}
