package com.lingosnap.ui.create

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lingosnap.data.CardRepository
import com.lingosnap.data.model.Deck
import com.lingosnap.data.remote.VocabPair
import com.lingosnap.util.ImageUtils
import com.lingosnap.util.parseVocabText
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch

class Draft(val pair: VocabPair, selected: Boolean = true) {
    var selected by mutableStateOf(selected)
}

/** Collects new cards for an existing deck (typed, from photos or from the AI) and saves them at once. */
class AddCardsViewModel(private val repo: CardRepository, private val deckId: Long) : ViewModel() {

    var deck by mutableStateOf<Deck?>(null)
        private set

    val drafts = mutableStateListOf<Draft>()
    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var topic by mutableStateOf("")
    var count by mutableStateOf(15)
    var level by mutableStateOf("A1")

    init {
        viewModelScope.launch { deck = repo.deck(deckId) }
    }

    fun addManual(source: String, target: String) {
        if (source.isBlank() || target.isBlank()) return
        drafts.add(0, Draft(VocabPair(source.trim(), target.trim())))
    }

    fun addList(text: String): Int {
        val pairs = parseVocabText(text)
        drafts.addAll(0, pairs.map { Draft(it) })
        return pairs.size
    }

    fun generate() {
        val d = deck ?: return
        if (topic.isBlank() || busy) return
        busy = true; error = null
        viewModelScope.launch {
            repo.generate(topic.trim(), d.sourceLang, d.targetLang, count, level)
                .onSuccess { list -> drafts.addAll(0, list.map { Draft(it) }) }
                .onFailure { error = it.message ?: "Unbekannter Fehler" }
            busy = false
        }
    }

    fun scan(context: Context, uris: List<Uri>) {
        val d = deck ?: return
        if (busy || uris.isEmpty()) return
        busy = true; error = null
        viewModelScope.launch {
            runCatching {
                val images = uris.map { async { ImageUtils.loadJpeg(context, it) } }.awaitAll()
                repo.extract(images, d.sourceLang, d.targetLang).getOrThrow()
            }.onSuccess { list -> drafts.addAll(0, list.map { Draft(it) }) }
                .onFailure { error = it.message ?: "Bild konnte nicht gelesen werden" }
            busy = false
        }
    }

    val selectedCount: Int get() = drafts.count { it.selected }

    fun save(onDone: () -> Unit) {
        val d = deck ?: return
        if (busy) return
        viewModelScope.launch {
            busy = true
            val pairs = drafts.filter { it.selected }.map { it.pair }
                .distinctBy { it.source.lowercase() to it.target.lowercase() }
            if (pairs.isNotEmpty()) repo.addCards(d, pairs)
            busy = false
            onDone()
        }
    }
}
