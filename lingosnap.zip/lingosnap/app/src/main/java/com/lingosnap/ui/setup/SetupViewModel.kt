package com.lingosnap.ui.setup

import com.lingosnap.util.tr

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.data.SecureKeyStore
import com.lingosnap.data.remote.AiProvider
import com.lingosnap.data.remote.GeminiClient
import com.lingosnap.data.remote.GeminiException
import com.lingosnap.data.remote.Verified
import com.lingosnap.data.remote.cleanKey
import com.lingosnap.data.remote.defaultModels
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SetupUiState(
    val key: String = "",
    val visible: Boolean = false,
    val validating: Boolean = false,
    val error: String? = null,
    val saved: Boolean = false,
    /** the check failed for a reason other than a rejected key (offline, server problem): saving anyway makes sense */
    val canForce: Boolean = false,
)

class SetupViewModel(
    private val keyStore: SecureKeyStore,
    private val gemini: GeminiClient,
) : ViewModel() {

    private val _ui = MutableStateFlow(SetupUiState())
    val ui: StateFlow<SetupUiState> = _ui.asStateFlow()

    fun onKeyChange(value: String) = _ui.update { it.copy(key = cleanKey(value), error = null, canForce = false) }
    fun skip() {
        keyStore.setupDone = true
        _ui.update { it.copy(saved = true) }
    }

    fun toggleVisible() = _ui.update { it.copy(visible = !it.visible) }

    fun saveAndVerify() {
        val key = _ui.value.key
        if (key.isBlank()) return
        viewModelScope.launch {
            _ui.update { it.copy(validating = true, error = null) }
            gemini.validateKey(key).fold(
                onSuccess = { verified ->
                    keyStore.apiKey = key
                    keyStore.setupDone = true
                    gemini.apply(verified)
                    _ui.update { it.copy(validating = false, saved = true, key = "") }
                },
                onFailure = { e ->
                    val rejected = e is GeminiException.Http && (e.code == 401 || e.code == 403 || e.code == 400)
                    _ui.update { it.copy(validating = false, error = e.message ?: tr("Schlüssel konnte nicht geprüft werden"), canForce = !rejected) }
                },
            )
        }
    }

    /** Saves the key although it could not be checked (e.g. no connection right now). */
    fun saveAnyway() {
        val key = _ui.value.key
        if (key.isBlank()) return
        keyStore.apiKey = key
        keyStore.setupDone = true
        AiProvider.guess(key)?.let { gemini.apply(Verified(it, defaultModels(it))) }
        _ui.update { it.copy(saved = true, key = "") }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer { SetupViewModel(app().container.keyStore, app().container.gemini) }
        }
    }
}
