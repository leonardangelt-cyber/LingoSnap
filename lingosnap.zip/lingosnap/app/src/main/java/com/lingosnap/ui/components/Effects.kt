package com.lingosnap.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/* ─────────────────── Expressive "cookie" shape (scalloped circle) ─────────────────── */

class CookieShape(private val lobes: Int = 9, private val amplitude: Float = 0.07f) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path()
        val cx = size.width / 2f
        val cy = size.height / 2f
        val base = min(cx, cy) / (1f + amplitude)
        val steps = 180
        for (i in 0..steps) {
            val a = (i / steps.toFloat()) * 2f * PI.toFloat()
            val r = base * (1f + amplitude * cos(lobes * a))
            val x = cx + r * cos(a)
            val y = cy + r * sin(a)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}

@Composable
fun rememberInfiniteRotation(durationMillis: Int = 20000): State<Float> {
    val t = rememberInfiniteTransition(label = "rotation")
    return t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(durationMillis, easing = LinearEasing)),
        label = "angle",
    )
}

@Composable
fun CookieBadge(
    size: Dp,
    color: Color,
    modifier: Modifier = Modifier,
    lobes: Int = 9,
    spinMillis: Int = 24000,
    content: @Composable BoxScope.() -> Unit = {},
) {
    Box(modifier.size(size).background(color, CircleShape), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun MorphLoader(
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    androidx.compose.material3.CircularProgressIndicator(modifier.size(size / 1.6f), color = color)
}

/* ─────────────────── Wavy progress bar (Material 3 Expressive look) ─────────────────── */

@Composable
fun WavyProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant,
) {
    androidx.compose.material3.LinearProgressIndicator(
        progress = { progress.coerceIn(0f, 1f) },
        modifier = modifier.fillMaxWidth().height(8.dp),
        color = color,
        trackColor = trackColor,
        gapSize = 4.dp,
        drawStopIndicator = {},
    )
}

/* ─────────────────── Living background ─────────────────── */

@Composable
fun AnimatedBackdrop(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val c1 by animateColorAsState(cs.primary, tween(700), label = "c1")
    val c2 by animateColorAsState(cs.tertiary, tween(700), label = "c2")
    val c3 by animateColorAsState(cs.secondary, tween(700), label = "c3")
    val t = rememberInfiniteTransition(label = "blobs")
    val a by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(14000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "a",
    )
    val b by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(19000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b",
    )
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        val center1 = Offset(w * (0.10f + 0.55f * a), h * (0.08f + 0.10f * b))
        val r1 = w * 0.95f
        drawCircle(
            brush = Brush.radialGradient(listOf(c1.copy(alpha = 0.30f), Color.Transparent), center = center1, radius = r1),
            radius = r1,
            center = center1,
        )

        val center2 = Offset(w * (0.95f - 0.55f * b), h * (0.92f - 0.12f * a))
        val r2 = w * 1.0f
        drawCircle(
            brush = Brush.radialGradient(listOf(c2.copy(alpha = 0.28f), Color.Transparent), center = center2, radius = r2),
            radius = r2,
            center = center2,
        )

        val center3 = Offset(w * (0.80f - 0.5f * a), h * (0.48f + 0.10f * b))
        val r3 = w * 0.7f
        drawCircle(
            brush = Brush.radialGradient(listOf(c3.copy(alpha = 0.18f), Color.Transparent), center = center3, radius = r3),
            radius = r3,
            center = center3,
        )
    }
}

/** Root of every screen: adaptive surface + drifting colour blobs + correct text colour. */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(cs.surface, tween(600), label = "bg")
    CompositionLocalProvider(LocalContentColor provides cs.onSurface) {
        Box(Modifier.fillMaxSize().background(bg)) {
            content()
        }
    }
}

/* ─────────────────── Motion helpers ─────────────────── */

/** Kept for call-sites; screens no longer animate in (calm, simple look). */
@Suppress("UNUSED_PARAMETER")
fun Modifier.entrance(index: Int = 0, delayPerItem: Long = 70L): Modifier = this

/** Gentle hovering. */
fun Modifier.floating(amplitude: Dp = 6.dp, durationMillis: Int = 2600): Modifier = composed {
    val t = rememberInfiniteTransition(label = "float")
    val dy by t.animateFloat(
        -1f, 1f, infiniteRepeatable(tween(durationMillis, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy",
    )
    val px = with(LocalDensity.current) { amplitude.toPx() }
    graphicsLayer { translationY = dy * px }
}

/* ─────────────────── Confetti ─────────────────── */

private class Particle(
    val angle: Float,
    val speed: Float,
    val dim: Float,
    val colorIdx: Int,
    val spin: Float,
    val square: Boolean,
)

@Composable
fun ConfettiBurst(modifier: Modifier = Modifier) {}

@Composable
private fun ConfettiBurstUnused(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val colors = listOf(cs.primary, cs.tertiary, cs.secondary, cs.primaryContainer, cs.tertiaryContainer)
    val particles = remember {
        List(80) {
            Particle(
                angle = Random.nextFloat() * 2f * PI.toFloat(),
                speed = 0.3f + Random.nextFloat() * 0.7f,
                dim = 8f + Random.nextFloat() * 10f,
                colorIdx = Random.nextInt(5),
                spin = Random.nextFloat() * 4f,
                square = Random.nextBoolean(),
            )
        }
    }
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(2400, easing = LinearOutSlowInEasing)) }

    Canvas(modifier.fillMaxSize()) {
        val t = progress.value
        val origin = Offset(size.width / 2f, size.height * 0.36f)
        val alpha = (1f - t * t).coerceIn(0f, 1f)
        particles.forEach { p ->
            val dist = p.speed * size.minDimension * 0.8f * t
            val x = origin.x + cos(p.angle) * dist
            val y = origin.y + sin(p.angle) * dist + 600f * t * t
            val c = colors[p.colorIdx].copy(alpha = alpha)
            if (p.square) {
                rotate(degrees = p.spin * t * 360f, pivot = Offset(x, y)) {
                    drawRect(c, topLeft = Offset(x - p.dim, y - p.dim / 2f), size = Size(p.dim * 2f, p.dim))
                }
            } else {
                drawCircle(c, radius = p.dim / 2f, center = Offset(x, y))
            }
        }
    }
}
