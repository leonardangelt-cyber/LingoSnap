package com.lingosnap.ui.components

import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RangeSlider
import kotlin.math.roundToInt
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.material3.Surface
import androidx.compose.material3.IconButton
import androidx.compose.material3.AssistChip
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Add
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.StudyDir
import com.lingosnap.ui.StudyMode

private class StartMode(val icon: ImageVector, val title: String, val desc: String, val mode: String)

private val StartModes get() = listOf(
    StartMode(Icons.Rounded.Style, tr("Karteikarten"), tr("Umdrehen und selbst bewerten"), StudyMode.FlashDue),
    StartMode(Icons.Rounded.Quiz, tr("Multiple Choice"), tr("Vier Antworten, eine ist richtig"), StudyMode.Choice),
    StartMode(Icons.Rounded.Keyboard, tr("Schreiben"), tr("Die Antwort eintippen"), StudyMode.Typing),
    StartMode(Icons.Rounded.EditNote, tr("Lückentext"), tr("Das Wort im Beispielsatz ergänzen"), StudyMode.Cloze),
    StartMode(Icons.Rounded.Mic, tr("Hören und Sprechen"), tr("Die App liest das Wort vor, du sprichst es nach"), StudyMode.Speak),
)
private val LanguageOnly = setOf(StudyMode.Typing, StudyMode.Cloze, StudyMode.Listen, StudyMode.Speak)
private val NeedsDirection = setOf(StudyMode.FlashDue, StudyMode.Choice, StudyMode.Typing)

/** What happens after "Lernen": first how to learn, then which way round. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StartSheet(deck: Deck, cardCount: Int, weakCount: Int, onPick: (mode: String, dir: String, from: Int, to: Int) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var mode by remember { mutableStateOf<StartMode?>(null) }
    var weakOnly by remember { mutableStateOf(false) }
    var range by remember(cardCount) { mutableStateOf(1f..maxOf(cardCount, 1).toFloat()) }
    val from = range.start.roundToInt()
    val to = range.endInclusive.roundToInt()
    val all = from <= 1 && to >= cardCount
    val modes = if (deck.isLanguage) StartModes else StartModes.filter { it.mode !in LanguageOnly }
    val a = if (!deck.isLanguage) tr("Frage") else if (deck.sourceLang == "auto") tr("Wort") else languageName(deck.sourceLang)
    val b = if (!deck.isLanguage) tr("Antwort") else languageName(deck.targetLang)
    // while a finger is on the slider the sheet must not follow the drag up or down
    var touching by remember { mutableStateOf(false) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        sheetGesturesEnabled = !touching,
    ) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
            val m = mode
            if (m == null) {
                Text(tr("Wie möchtest du lernen?"), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 16.dp))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    modes.forEachIndexed { i, item ->
                        SegmentedItem(
                            i, modes.size, item.title, supporting = item.desc,
                            onClick = { mode = item },
                            leading = { Icon(item.icon, null, tint = cs.primary) },
                        )
                    }
                }
            } else {
                Text(if (m.mode in NeedsDirection) tr("Wie herum?") else m.title, style = MaterialTheme.typography.headlineSmall)
                Text(if (m.mode in NeedsDirection) m.title else m.desc, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
                if (weakCount > 0) {
                    androidx.compose.material3.FilterChip(
                        selected = weakOnly,
                        onClick = { weakOnly = !weakOnly },
                        label = { Text(tr("Nur schwierige Karten ({0})", weakCount)) },
                        modifier = Modifier.padding(bottom = 12.dp),
                    )
                }
                if (cardCount > 1 && !weakOnly) {
                    fun snap(v: Float): Int {
                        val r = v.roundToInt()
                        val tenth = ((r + 5) / 10) * 10
                        return if (tenth >= 10 && kotlin.math.abs(r - tenth) <= 2) tenth else r
                    }
                    fun setRange(f: Int, t: Int) {
                        val a = f.coerceIn(1, cardCount)
                        val b = t.coerceIn(a, cardCount)
                        range = a.toFloat()..b.toFloat()
                    }
                    Text(
                        if (all) tr("Alle {0} Karten", cardCount) else tr("Karte {0} bis {1}", from, to),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        if (all) tr("Ziehe die Punkte, um nur einen Teil zu lernen")
                        else tr("{0} von {1} Karten", to - from + 1, cardCount),
                        style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
                    )
                    RangeSlider(
                        modifier = Modifier.pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val e = awaitPointerEvent(PointerEventPass.Initial)
                                    touching = e.changes.any { it.pressed }
                                }
                            }
                        },
                        value = range,
                        // whole cards, with a light magnet on every tenth (10, 20, 30 …)
                        onValueChange = { setRange(snap(it.start), snap(it.endInclusive)) },
                        valueRange = 1f..cardCount.toFloat(),
                    )
                    Spacer(Modifier.padding(bottom = 12.dp))
                }
                if (m.mode !in NeedsDirection) {
                    androidx.compose.material3.Button(
                        onClick = { onPick(m.mode, StudyDir.Forward, if (weakOnly) -1 else if (all) 0 else from, if (weakOnly || all) 0 else to) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                    ) { Text(tr("Starten")) }
                } else {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    SegmentedItem(
                        0, 3, "${a} → ${b}",
                        supporting = if (deck.isLanguage) tr("Du siehst das Wort, du nennst die Übersetzung") else tr("Du siehst die Frage, du nennst die Antwort"),
                        onClick = { onPick(m.mode, StudyDir.Forward, if (weakOnly) -1 else if (all) 0 else from, if (weakOnly || all) 0 else to) },
                        leading = { Icon(Icons.Rounded.ArrowForward, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        1, 3, "${b} → ${a}",
                        supporting = if (deck.isLanguage) tr("Du siehst die Übersetzung, du nennst das Wort") else tr("Du siehst die Antwort, du nennst die Frage"),
                        onClick = { onPick(m.mode, StudyDir.Reverse, if (weakOnly) -1 else if (all) 0 else from, if (weakOnly || all) 0 else to) },
                        leading = { Icon(Icons.Rounded.SwapHoriz, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        2, 3, tr("Gemischt"),
                        supporting = tr("Die Richtung wechselt von Karte zu Karte"),
                        onClick = { onPick(m.mode, StudyDir.Mixed, if (weakOnly) -1 else if (all) 0 else from, if (weakOnly || all) 0 else to) },
                        leading = { Icon(Icons.Rounded.Shuffle, null, tint = cs.primary) },
                    )
                }
                }
                TextButton(onClick = { mode = null }, modifier = Modifier.padding(top = 8.dp)) { Text(tr("Zurück")) }
            }
        }
    }
}
