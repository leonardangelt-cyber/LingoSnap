package com.lingosnap.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RangeSlider
import kotlin.math.roundToInt
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.StudyDir
import com.lingosnap.ui.StudyMode

private class StartMode(val icon: ImageVector, val title: String, val desc: String, val mode: String)

private val StartModes = listOf(
    StartMode(Icons.Rounded.Style, "Karteikarten", "Umdrehen und selbst bewerten", StudyMode.FlashDue),
    StartMode(Icons.Rounded.Quiz, "Multiple Choice", "Vier Antworten, eine ist richtig", StudyMode.Choice),
    StartMode(Icons.Rounded.Keyboard, "Schreiben", "Die Antwort eintippen", StudyMode.Typing),
    StartMode(Icons.Rounded.Extension, "Zuordnen", "Paare gegen die Uhr verbinden", StudyMode.Match),
)

/** What happens after "Lernen": first how to learn, then which way round. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StartSheet(deck: Deck, cardCount: Int, onPick: (mode: String, dir: String, from: Int, to: Int) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var mode by remember { mutableStateOf<StartMode?>(null) }
    var range by remember(cardCount) { mutableStateOf(1f..maxOf(cardCount, 1).toFloat()) }
    val from = range.start.roundToInt()
    val to = range.endInclusive.roundToInt()
    val all = from <= 1 && to >= cardCount
    val modes = if (deck.isLanguage) StartModes else StartModes.filter { it.mode != StudyMode.Typing }
    val a = if (!deck.isLanguage) "Frage" else if (deck.sourceLang == "auto") "Wort" else languageName(deck.sourceLang)
    val b = if (!deck.isLanguage) "Antwort" else languageName(deck.targetLang)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
            val m = mode
            if (m == null) {
                Text("Wie möchtest du lernen?", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 16.dp))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    modes.forEachIndexed { i, item ->
                        SegmentedItem(
                            i, modes.size, item.title, supporting = item.desc,
                            onClick = { mode = item },
                            leading = { Icon(item.icon, null, tint = cs.primary) },
                        )
                    }
                }
            } else {
                Text("Wie herum?", style = MaterialTheme.typography.headlineSmall)
                Text(m.title, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
                if (cardCount > 1) {
                    Text(
                        if (all) "Alle $cardCount Karten" else "Karten $from – $to  (${to - from + 1} von $cardCount)",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    RangeSlider(value = range, onValueChange = { range = it }, valueRange = 1f..cardCount.toFloat())
                    Text(
                        "Reihenfolge, in der die Karten hinzugefügt wurden",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 12.dp),
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    SegmentedItem(
                        0, 3, "$a → $b",
                        supporting = if (deck.isLanguage) "Du siehst das Wort, du nennst die Übersetzung" else "Du siehst die Frage, du nennst die Antwort",
                        onClick = { onPick(m.mode, StudyDir.Forward, if (all) 0 else from, if (all) 0 else to) },
                        leading = { Icon(Icons.Rounded.ArrowForward, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        1, 3, "$b → $a",
                        supporting = if (deck.isLanguage) "Du siehst die Übersetzung, du nennst das Wort" else "Du siehst die Antwort, du nennst die Frage",
                        onClick = { onPick(m.mode, StudyDir.Reverse, if (all) 0 else from, if (all) 0 else to) },
                        leading = { Icon(Icons.Rounded.SwapHoriz, null, tint = cs.primary) },
                    )
                    SegmentedItem(
                        2, 3, "Gemischt",
                        supporting = "Die Richtung wechselt von Karte zu Karte",
                        onClick = { onPick(m.mode, StudyDir.Mixed, if (all) 0 else from, if (all) 0 else to) },
                        leading = { Icon(Icons.Rounded.Shuffle, null, tint = cs.primary) },
                    )
                }
                TextButton(onClick = { mode = null }, modifier = Modifier.padding(top = 8.dp)) { Text("Zurück") }
            }
        }
    }
}
