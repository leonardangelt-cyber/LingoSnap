package com.lingosnap.data

import com.lingosnap.data.local.CardDao
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.languageName
import com.lingosnap.data.remote.GeminiClient
import com.lingosnap.data.remote.VocabPair
import kotlinx.coroutines.flow.Flow

/** Single source of truth for cards; ViewModels never touch Room or Gemini directly. */
class CardRepository(
    private val dao: CardDao,
    private val gemini: GeminiClient,
) {
    fun observeCards(): Flow<List<Flashcard>> = dao.observeAll()

    suspend fun dueCards(limit: Int = 20): List<Flashcard> =
        dao.due(System.currentTimeMillis(), limit)

    suspend fun extract(jpeg: ByteArray, sourceTag: String, targetTag: String): Result<List<VocabPair>> =
        gemini.extractVocabulary(jpeg, languageName(sourceTag), languageName(targetTag))

    suspend fun save(pairs: List<VocabPair>, sourceTag: String, targetTag: String) {
        dao.insertAll(pairs.map { Flashcard(source = it.source, target = it.target, sourceLang = sourceTag, targetLang = targetTag) })
    }

    suspend fun review(card: Flashcard, rating: Rating): Flashcard =
        Srs.review(card, rating).also { dao.update(it) }

    /** Returns the cached mnemonic unless [force] is set; stores new ones on the card. */
    suspend fun mnemonicFor(card: Flashcard, force: Boolean = false): Result<Flashcard> {
        if (!force && card.mnemonic != null) return Result.success(card)
        return gemini.generateMnemonic(
            card.source, languageName(card.sourceLang),
            card.target, languageName(card.targetLang),
        ).map { text -> card.copy(mnemonic = text).also { dao.update(it) } }
    }

    suspend fun delete(card: Flashcard) = dao.delete(card)
}
