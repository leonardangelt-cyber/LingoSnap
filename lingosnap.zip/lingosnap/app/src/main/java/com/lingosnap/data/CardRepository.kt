package com.lingosnap.data

import com.lingosnap.data.local.AppDao
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageNameEn
import com.lingosnap.data.remote.GeminiClient
import com.lingosnap.data.remote.VocabPair
import kotlinx.coroutines.flow.Flow

/** Single source of truth; ViewModels never touch Room or Gemini directly. */
class CardRepository(
    private val dao: AppDao,
    private val gemini: GeminiClient,
    val stats: StatsStore,
) {
    val groups: Flow<List<DeckGroup>> = dao.observeGroups()
    val decks: Flow<List<Deck>> = dao.observeDecks()
    val cards: Flow<List<Flashcard>> = dao.observeCards()

    /* ── structure ── */

    suspend fun createGroup(name: String): Long = dao.insertGroup(DeckGroup(name = name.trim()))

    suspend fun createDeck(
        name: String, groupId: Long?, sourceLang: String, targetLang: String, description: String,
    ): Long = dao.insertDeck(
        Deck(name = name.trim(), groupId = groupId, sourceLang = sourceLang, targetLang = targetLang, description = description.trim()),
    )

    suspend fun deck(id: Long): Deck? = dao.deckById(id)

    suspend fun deleteDeck(id: Long) {
        dao.deleteCardsOfDeck(id)
        dao.deleteDeck(id)
    }

    suspend fun deleteGroup(id: Long, withDecks: Boolean) {
        if (withDecks) dao.decksOfGroup(id).forEach { deleteDeck(it.id) } else dao.ungroupDecks(id)
        dao.deleteGroup(id)
    }

    suspend fun clearEverything() {
        dao.clearCards()
        dao.clearDecks()
        dao.clearGroups()
        stats.resetAll()
    }

    /* ── cards ── */

    suspend fun addCards(deck: Deck, pairs: List<VocabPair>) {
        dao.insertCards(
            pairs.map {
                Flashcard(
                    deckId = deck.id, source = it.source, target = it.target, example = it.example,
                    sourceLang = deck.sourceLang, targetLang = deck.targetLang,
                )
            },
        )
    }

    suspend fun addCard(deck: Deck, source: String, target: String, example: String?) {
        addCards(deck, listOf(VocabPair(source.trim(), target.trim(), example?.trim()?.takeIf { it.isNotEmpty() })))
    }

    suspend fun updateCard(card: Flashcard) = dao.updateCard(card)
    suspend fun deleteCard(card: Flashcard) = dao.deleteCard(card)

    suspend fun cardsFor(scope: StudyScope, id: Long): List<Flashcard> = when (scope) {
        StudyScope.Deck -> dao.cardsOfDeck(id)
        StudyScope.Group -> dao.decksOfGroup(id).flatMap { dao.cardsOfDeck(it.id) }
        StudyScope.All -> dao.allCards()
    }

    suspend fun dueCards(scope: StudyScope, id: Long, limit: Int = 20): List<Flashcard> {
        val now = System.currentTimeMillis()
        return cardsFor(scope, id).filter { it.dueAt <= now }.sortedWith(compareBy({ it.level }, { it.dueAt })).take(limit)
    }

    suspend fun review(card: Flashcard, rating: Rating): Flashcard {
        val updated = Srs.review(card, rating)
        dao.updateCard(updated)
        stats.recordReview(rating)
        return updated
    }

    /** Returns the cached mnemonic unless [force] is set; stores new ones on the card. */
    suspend fun mnemonicFor(card: Flashcard, force: Boolean = false): Result<Flashcard> {
        if (!force && card.mnemonic != null) return Result.success(card)
        return gemini.generateMnemonic(
            card.source, languageNameEn(card.sourceLang),
            card.target, languageNameEn(card.targetLang),
        ).map { text -> card.copy(mnemonic = text).also { dao.updateCard(it) } }
    }

    /* ── AI ── */

    suspend fun extract(jpeg: ByteArray, sourceLang: String, targetLang: String): Result<List<VocabPair>> =
        gemini.extractVocabulary(jpeg, languageNameEn(sourceLang), languageNameEn(targetLang))

    suspend fun generate(topic: String, sourceLang: String, targetLang: String, count: Int, level: String): Result<List<VocabPair>> =
        gemini.generateVocabulary(topic, languageNameEn(sourceLang), languageNameEn(targetLang), count, level)
}
