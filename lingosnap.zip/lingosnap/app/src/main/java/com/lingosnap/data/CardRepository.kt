package com.lingosnap.data

import com.lingosnap.data.local.AppDao
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.DeckGroup
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageNameEn
import com.lingosnap.data.remote.GeminiClient
import com.lingosnap.data.remote.Progress
import com.lingosnap.data.remote.VocabPair
import kotlinx.coroutines.flow.Flow

/** Single source of truth; ViewModels never touch Room or Gemini directly. */
class CardRepository(
    private val dao: AppDao,
    private val gemini: GeminiClient,
    val stats: StatsStore,
) {
    val groups: Flow<List<DeckGroup>> = dao.observeGroups()
    val decks: Flow<List<Deck>> = dao.observeDecks()
    val cards: Flow<List<Flashcard>> = dao.observeCards()

    /* ── structure ── */

    suspend fun createGroup(name: String): Long = dao.insertGroup(DeckGroup(name = name.trim()))

    suspend fun createDeck(
        name: String, groupId: Long?, sourceLang: String, targetLang: String, description: String,
        kind: String = "language",
    ): Long = dao.insertDeck(
        Deck(
            name = name.trim(), groupId = groupId, sourceLang = sourceLang, targetLang = targetLang,
            description = description.trim(), kind = kind,
        ),
    )

    suspend fun deck(id: Long): Deck? = dao.deckById(id)

    suspend fun deleteDeck(id: Long) {
        dao.deleteCardsOfDeck(id)
        dao.deleteDeck(id)
    }

    suspend fun deleteGroup(id: Long, withDecks: Boolean) {
        if (withDecks) dao.decksOfGroup(id).forEach { deleteDeck(it.id) } else dao.ungroupDecks(id)
        dao.deleteGroup(id)
    }

    suspend fun clearEverything() {
        dao.clearCards()
        dao.clearDecks()
        dao.clearGroups()
        stats.resetAll()
    }

    /* ── cards ── */

    suspend fun addCards(deck: Deck, pairs: List<VocabPair>) {
        // decks set to "auto" take the language the AI detected for every word
        val fallback = if (deck.sourceLang != "auto") deck.sourceLang
        else dao.cardsOfDeck(deck.id).groupingBy { it.sourceLang }.eachCount().maxByOrNull { it.value }?.key ?: "en"
        dao.insertCards(
            pairs.map {
                val lang = when {
                    !deck.isLanguage -> ""
                    deck.sourceLang != "auto" -> deck.sourceLang
                    else -> it.lang?.lowercase()?.take(2) ?: fallback
                }
                Flashcard(
                    deckId = deck.id, source = it.source, target = it.target, example = it.example,
                    sourceLang = lang, targetLang = deck.targetLang,
                )
            },
        )
    }

    suspend fun addCard(deck: Deck, source: String, target: String, example: String?) {
        addCards(deck, listOf(VocabPair(source.trim(), target.trim(), example?.trim()?.takeIf { it.isNotEmpty() })))
    }

    suspend fun updateCard(card: Flashcard) = dao.updateCard(card)
    suspend fun deleteCard(card: Flashcard) = dao.deleteCard(card)

    suspend fun cardsFor(scope: StudyScope, id: Long): List<Flashcard> = when (scope) {
        StudyScope.Deck -> dao.cardsOfDeck(id)
        StudyScope.Group -> dao.decksOfGroup(id).flatMap { dao.cardsOfDeck(it.id) }
        StudyScope.All -> dao.allCards()
    }

    suspend fun dueCards(scope: StudyScope, id: Long, limit: Int = 20): List<Flashcard> {
        val now = System.currentTimeMillis()
        return cardsFor(scope, id).filter { it.dueAt <= now }.sortedWith(compareBy({ it.dueAt }, { it.level })).take(limit)
    }

    suspend fun review(card: Flashcard, rating: Rating): Flashcard {
        val updated = Srs.review(card, rating)
        dao.updateCard(updated)
        stats.recordReview(rating)
        return updated
    }

    /** Returns the cached mnemonic unless [force] is set; stores new ones on the card. */
    suspend fun mnemonicFor(card: Flashcard, force: Boolean = false): Result<Flashcard> {
        if (!force && card.mnemonic != null) return Result.success(card)
        return gemini.generateMnemonic(
            card.source, languageNameEn(card.sourceLang),
            card.target, languageNameEn(card.targetLang),
        ).map { text -> card.copy(mnemonic = text).also { dao.updateCard(it) } }
    }

    /** Adds an AI written example sentence to a card that has none (context for learning). */
    suspend fun exampleFor(card: Flashcard): Result<Flashcard> {
        if (!card.example.isNullOrBlank()) return Result.success(card)
        return gemini.generateExample(
            card.source, if (card.sourceLang.isBlank()) "" else languageNameEn(card.sourceLang),
            card.target, if (card.targetLang.isBlank()) "" else languageNameEn(card.targetLang),
        ).map { text -> card.copy(example = text).also { dao.updateCard(it) } }
    }

    /* ── AI ── */

    suspend fun extract(
        images: List<ByteArray>, deck: Deck, hint: String, progress: Progress = Progress(), material: String = "", bulk: Boolean = false,
    ): Result<List<VocabPair>> =
        gemini.extractVocabulary(images, langName(deck.sourceLang), langName(deck.targetLang), context(deck, hint), progress, material, bulk)

    /** Renames a deck and changes its languages / subject; cards follow the new languages. */
    suspend fun updateDeck(deck: Deck, name: String, sourceLang: String, targetLang: String, description: String) {
        dao.updateDeck(deck.copy(name = name.trim(), sourceLang = sourceLang, targetLang = targetLang, description = description.trim()))
        if (deck.isLanguage) {
            dao.setTargetLang(deck.id, targetLang)
            if (sourceLang != "auto") dao.setSourceLang(deck.id, sourceLang)
        }
    }

    /** Creates the decks of an import. Unknown deck type / languages come from [fallback]. */
    suspend fun importDecks(decks: List<ImportedDeck>, fallbackKind: String, fallbackSource: String, fallbackTarget: String, names: Map<Int, String> = emptyMap()): Int {
        val taken = dao.allDecks().map { it.name.lowercase() }.toMutableSet()
        var total = 0
        decks.forEachIndexed { i, d ->
            val kind = d.kind ?: fallbackKind
            val lang = kind != "cards"
            val src = if (lang) (d.sourceLang ?: fallbackSource) else ""
            val tgt = if (lang) (d.targetLang ?: fallbackTarget) else ""
            var name = (names[i] ?: d.name).trim().ifBlank { "Import" }
            if (name.lowercase() in taken) {
                var n = 1
                var candidate = "$name (Import)"
                while (candidate.lowercase() in taken) { n++; candidate = "$name (Import $n)" }
                name = candidate
            }
            taken += name.lowercase()
            val id = dao.insertDeck(Deck(name = name, sourceLang = src, targetLang = tgt, description = d.description, kind = kind))
            dao.insertCards(
                d.cards.distinctBy { it.source.lowercase() to it.target.lowercase() }.map {
                    Flashcard(
                        deckId = id, source = it.source, target = it.target, example = it.example,
                        sourceLang = if (!lang) "" else (it.sourceLang?.takeIf { l -> l.isNotBlank() } ?: src.takeIf { s -> s != "auto" } ?: "en"),
                        targetLang = tgt,
                        level = it.level, dueAt = it.dueAt, mnemonic = it.mnemonic, ease = it.ease, intervalDays = it.intervalDays,
                    )
                },
            )
            total += d.cards.size
        }
        return total
    }

    suspend fun findDuplicates(existing: List<String>, fresh: List<String>) = gemini.findDuplicates(existing, fresh)

    suspend fun cardsOf(deckId: Long): List<Flashcard> = dao.cardsOfDeck(deckId)

    suspend fun deleteCards(cards: List<Flashcard>) = cards.forEach { dao.deleteCard(it) }

    suspend fun generate(topic: String, deck: Deck, count: Int, level: String, hint: String, progress: Progress = Progress()): Result<List<VocabPair>> =
        gemini.generateVocabulary(topic, langName(deck.sourceLang), langName(deck.targetLang), count, level, context(deck, hint), progress)

    /** Empty language name = plain question/answer deck. */
    private fun langName(tag: String) = when (tag) {
        "" -> ""
        "auto" -> "AUTO"
        else -> languageNameEn(tag)
    }

    private fun context(deck: Deck, hint: String) =
        listOf(
            deck.description.takeIf { it.isNotBlank() }?.let { "Deck subject: $it" },
            hint.takeIf { it.isNotBlank() }?.let { "Extra instructions from the user: $it" },
        ).filterNotNull().joinToString("\n")
}
