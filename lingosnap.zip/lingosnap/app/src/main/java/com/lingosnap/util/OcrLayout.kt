package com.lingosnap.util

/** One recognised word with its box on the page (pixels). */
class OcrWord(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val midY get() = (top + bottom) / 2f
    val midX get() = (left + right) / 2f
    val height get() = (bottom - top).coerceAtLeast(1)
}

/** A row that has been split into columns: word, translation and (optional) example. */
class OcrRow(val first: String, val second: String, val example: String?)

class OcrLayoutResult(val rows: List<OcrRow>, val loose: List<String>)

/**
 * Turns the words of a page into vocabulary rows without any AI. Instead of guessing the split per line it looks for vertical
 * "gutters" over the whole page: strips that (almost) no word crosses and that have words on both sides in most rows.
 * That is what a two-column vocabulary list looks like, and it keeps working when single rows are crowded or uneven.
 * Rows without a column structure are returned as loose lines (they may contain a separator like "casa - Haus").
 */
object OcrLayout {
    fun layout(words: List<OcrWord>): OcrLayoutResult {
        val clean = words.filter { it.text.isNotBlank() }
        if (clean.isEmpty()) return OcrLayoutResult(emptyList(), emptyList())
        val rows = groupRows(clean)
        val gutters = findGutters(rows)
        val out = ArrayList<OcrRow>()
        val loose = ArrayList<String>()
        var lastBottom = 0f; var lastHeight = 1f
        for (row in rows) {
            val text = row.joinToString(" ") { it.text }
            val rowTop = row.minOf { it.top }.toFloat()
            if (gutters.isEmpty()) { if (!junk(text)) loose += text; continue }
            val cells = Array(gutters.size + 1) { StringBuilder() }
            for (w in row) {
                val col = gutters.count { w.midX > it }
                if (cells[col].isNotEmpty()) cells[col].append(' ')
                cells[col].append(w.text)
            }
            val a = strip(cells[0].toString()); val b = cells[1].toString().trim()
            val ex = if (cells.size > 2) cells.drop(2).joinToString(" ").trim().ifBlank { null } else null
            // a word that crosses a gutter was split by its centre: such a row is not a clean column row
            val crosses = gutters.any { g -> row.any { it.left < g && it.right > g } }
            when {
                crosses -> if (!junk(text)) loose += text
                a.isNotBlank() && b.isNotBlank() && (a.none { it.isLetter() } || b.none { it.isLetter() }) -> if (!junk(text)) loose += text
                a.isNotBlank() && b.isNotBlank() -> out += OcrRow(a, b, ex)
                a.isBlank() && b.isNotBlank() && out.isNotEmpty() && rowTop - lastBottom < lastHeight * 1.2f ->
                    // second line of a long translation: belongs to the row above
                    out[out.lastIndex] = out.last().let { OcrRow(it.first, it.second + " " + b, it.example) }
                a.isNotBlank() && !junk(a) -> loose += a
            }
            if (a.isNotBlank() && b.isNotBlank() || (a.isBlank() && b.isNotBlank())) {
                lastBottom = row.maxOf { it.bottom }.toFloat(); lastHeight = row.map { it.height }.average().toFloat()
            }
        }
        return OcrLayoutResult(out, loose)
    }

    private fun junk(s: String) = s.trim().let { it.length < 2 || it.all { c -> c.isDigit() || !c.isLetterOrDigit() } }

    /** Removes list numbers and bullets in front of the word. */
    fun strip(s: String): String = s.trim().replace(Regex("""^\(?\d{1,3}[.)]\s+"""), "").replace(Regex("""^[•·*▪●-]\s+"""), "").trim()

    fun groupRows(words: List<OcrWord>): List<List<OcrWord>> {
        val sorted = words.sortedBy { it.midY }
        val groups = ArrayList<MutableList<OcrWord>>()
        for (w in sorted) {
            val g = groups.lastOrNull()
            if (g != null) {
                val h = g.map { it.height }.sorted().let { it[it.size / 2] }
                val y = g.map { it.midY }.average()
                if (kotlin.math.abs(w.midY - y) <= h * 0.55) { g.add(w); continue }
            }
            groups.add(mutableListOf(w))
        }
        return groups.map { g -> g.sortedBy { it.left } }
    }

    /** x positions of up to two gutters, ascending. */
    fun findGutters(rows: List<List<OcrWord>>): List<Float> {
        if (rows.size < 2) return emptyList()
        val all = rows.flatten()
        val minX = all.minOf { it.left }.toFloat(); val maxX = all.maxOf { it.right }.toFloat()
        val span = maxX - minX
        if (span <= 0f) return emptyList()
        val steps = 240
        val cover = IntArray(steps + 1)
        for (row in rows) {
            val seen = BooleanArray(steps + 1)
            for (w in row) {
                val from = (((w.left - minX) / span) * steps).toInt().coerceIn(0, steps)
                val to = (((w.right - minX) / span) * steps).toInt().coerceIn(0, steps)
                for (i in from..to) seen[i] = true
            }
            for (i in 0..steps) if (seen[i]) cover[i]++
        }
        val limit = (rows.size * 0.08).toInt()
        // a real gutter is clearly wider than a space between two words
        val medianH = all.map { it.height }.sorted().let { it[it.size / 2] }
        val minWidth = maxOf((steps * 0.02).toInt(), kotlin.math.ceil(medianH * 1.5f / span * steps).toInt(), 2)
        val found = ArrayList<Triple<Int, Int, Int>>() // from, to, rows with words on both sides
        var i = (steps * 0.12).toInt()
        val end = (steps * 0.92).toInt()
        while (i <= end) {
            if (cover[i] <= limit) {
                var j = i
                while (j + 1 <= end && cover[j + 1] <= limit) j++
                if (j - i + 1 >= minWidth) {
                    val x = minX + span * ((i + j) / 2f) / steps
                    val both = rows.count { r -> r.any { it.right < minX + span * i / steps } && r.any { it.left > minX + span * j / steps } }
                    if (both >= maxOf(2, (rows.size * 0.5).toInt())) found += Triple(i, j, both)
                }
                i = j + 1
            } else i++
        }
        val ranked = found.sortedByDescending { it.third * 1000 + (it.second - it.first) }
            .map { minX + span * ((it.first + it.second) / 2f) / steps }
        // take the best gutter first; another one only when every column it creates is filled in at least half of the rows
        var chosen = emptyList<Float>()
        for (c in ranked) {
            val trial = (chosen + c).sorted()
            val filled = (0..trial.size).all { col -> rows.count { r -> r.any { w -> trial.count { w.midX > it } == col } } >= rows.size * 0.5 }
            if (filled) chosen = trial
            if (chosen.size == 2) break
        }
        return chosen
    }
}
