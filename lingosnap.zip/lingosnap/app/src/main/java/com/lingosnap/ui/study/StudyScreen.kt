@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package com.lingosnap.ui.study

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.MasteryIndicator
import com.lingosnap.ui.components.pressScale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun StudyScreen(onBack: () -> Unit, vm: StudyViewModel = viewModel(factory = StudyViewModel.Factory)) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val card = ui.current

    val speak: (String, String) -> Unit = { text, tag ->
        if (!tts.speak(text, tag)) Toast.makeText(context, "No ${languageName(tag)} voice installed", Toast.LENGTH_SHORT).show()
    }

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text("Learn") },
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                )
            },
        ) { pad ->
            Column(
                Modifier.padding(pad).padding(horizontal = 20.dp).navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                DirectionPicker(ui.direction, card, vm::setDirection)

                val sessionProgress by animateFloatAsState(ui.progress, spring(0.8f, 300f), label = "session")
                LinearWavyProgressIndicator(progress = { sessionProgress }, modifier = Modifier.fillMaxWidth())

                when {
                    ui.loading -> Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) { LoadingIndicator() }
                    ui.finished -> FinishedPane(ui.reviewed, onBack, Modifier.weight(1f))
                    card != null -> {
                        MasteryIndicator(card.level)

                        val sourceFirst = ui.sourceFirst
                        SwipeableFlashcard(
                            // new key => fresh drag/flip state for every card (also for re-queued "Hard" cards)
                            cardKey = card.id to ui.reviewed,
                            card = card,
                            sourceFirst = sourceFirst,
                            flipped = ui.flipped,
                            onFlip = vm::flip,
                            onSwipe = vm::rate,
                            onSpeak = speak,
                            onMnemonic = { vm.requestMnemonic() },
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                        )

                        RatingBar(enabled = ui.flipped, onRate = vm::rate)
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }

        FeedbackPill(ui.feedback, Modifier.align(Alignment.TopCenter).padding(top = 120.dp))
    }

    if (ui.mnemonic != MnemonicState.Idle && card != null) {
        MnemonicSheet(card, ui.mnemonic, onRegenerate = { vm.requestMnemonic(force = true) }, onDismiss = vm::dismissMnemonic)
    }
}

/* ───────────────────────── direction toggle ───────────────────────── */

@Composable
private fun DirectionPicker(selected: Direction, card: Flashcard?, onSelect: (Direction) -> Unit) {
    val a = card?.sourceLang?.uppercase() ?: "A"
    val b = card?.targetLang?.uppercase() ?: "B"
    val labels = mapOf(Direction.Forward to "$a → $b", Direction.Reverse to "$b → $a", Direction.Mixed to "Mixed")
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        Direction.entries.forEachIndexed { i, d ->
            SegmentedButton(
                selected = d == selected,
                onClick = { onSelect(d) },
                shape = SegmentedButtonDefaults.itemShape(i, Direction.entries.size),
                label = { Text(labels.getValue(d)) },
            )
        }
    }
}

/* ───────────────────────── swipe + flip card ───────────────────────── */

private fun decide(x: Float, y: Float, t: Float): Rating? = when {
    y < -t && abs(y) > abs(x) -> Rating.Easy
    x > t -> Rating.Good
    x < -t -> Rating.Hard
    else -> null
}

@Composable
private fun SwipeableFlashcard(
    cardKey: Any,
    card: Flashcard,
    sourceFirst: Boolean,
    flipped: Boolean,
    onFlip: () -> Unit,
    onSwipe: (Rating) -> Unit,
    onSpeak: (String, String) -> Unit,
    onMnemonic: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val threshold = with(LocalDensity.current) { 110.dp.toPx() }
    val x = remember(cardKey) { Animatable(0f) }
    val y = remember(cardKey) { Animatable(0f) }

    val hint = decide(x.value, y.value, threshold * 0.5f)
    val flip by animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 120f), // springy expressive flip
        label = "flip",
    )

    val frontText = if (sourceFirst) card.source else card.target
    val frontLang = if (sourceFirst) card.sourceLang else card.targetLang
    val backText = if (sourceFirst) card.target else card.source
    val backLang = if (sourceFirst) card.targetLang else card.sourceLang

    Box(
        modifier
            .offset { IntOffset(x.value.roundToInt(), y.value.roundToInt()) }
            .graphicsLayer { rotationZ = (x.value / 40f).coerceIn(-12f, 12f) }
            .pointerInput(cardKey, flipped) {
                if (!flipped) return@pointerInput // you must peek at the answer before judging yourself
                detectDragGestures(
                    onDrag = { change, drag ->
                        change.consume()
                        scope.launch { x.snapTo(x.value + drag.x); y.snapTo(y.value + drag.y) }
                    },
                    onDragEnd = {
                        val rating = decide(x.value, y.value, threshold)
                        scope.launch {
                            if (rating == null) {
                                launch { x.animateTo(0f, spring(0.55f, 400f)) }
                                launch { y.animateTo(0f, spring(0.55f, 400f)) }
                            } else {
                                val fly = tween<Float>(220)
                                when (rating) {
                                    Rating.Good -> x.animateTo(1600f, fly)
                                    Rating.Hard -> x.animateTo(-1600f, fly)
                                    Rating.Easy -> y.animateTo(-2000f, fly)
                                }
                                onSwipe(rating)
                            }
                        }
                    },
                    onDragCancel = { scope.launch { x.animateTo(0f); y.animateTo(0f) } },
                )
            },
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { rotationY = flip; cameraDistance = 16f * density }
                .clip(MaterialTheme.shapes.extraLarge)
                .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { onFlip() },
        ) {
            if (flip <= 90f) {
                CardFace(
                    text = frontText, langTag = frontLang, footer = "Tap to reveal",
                    brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer)),
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    onSpeak = onSpeak, onMnemonic = null,
                )
            } else {
                Box(Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }) {
                    CardFace(
                        text = backText, langTag = backLang, footer = "Swipe: ← hard · → good · ↑ easy",
                        brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.primaryContainer)),
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        onSpeak = onSpeak, onMnemonic = onMnemonic,
                    )
                }
            }
        }

        // Live swipe hint while dragging
        val hintAlpha by animateFloatAsState(if (hint != null) 1f else 0f, label = "hintAlpha")
        hint?.let { r ->
            RatingPill(r, Modifier.align(Alignment.TopCenter).padding(top = 20.dp).alpha(hintAlpha))
        }
    }
}

@Composable
private fun CardFace(
    text: String, langTag: String, footer: String, brush: Brush, contentColor: Color,
    onSpeak: (String, String) -> Unit, onMnemonic: (() -> Unit)?,
) {
    Box(Modifier.fillMaxSize().background(brush).padding(28.dp)) {
        Text(
            languageName(langTag).uppercase(),
            Modifier.align(Alignment.TopStart),
            style = MaterialTheme.typography.labelLarge, color = contentColor.copy(alpha = .7f),
        )
        Text(
            text, Modifier.align(Alignment.Center), color = contentColor, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.displayMediumEmphasized,
        )
        Row(Modifier.align(Alignment.TopEnd), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            onMnemonic?.let {
                FilledTonalIconButton(onClick = it) { Icon(Icons.Rounded.Lightbulb, "Memory trick") }
            }
            FilledIconButton(
                onClick = { onSpeak(text, langTag) },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = contentColor, contentColor = MaterialTheme.colorScheme.surface),
            ) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Pronounce") }
        }
        Text(footer, Modifier.align(Alignment.BottomCenter), style = MaterialTheme.typography.labelLarge, color = contentColor.copy(alpha = .65f))
    }
}

/* ───────────────────────── rating + feedback ───────────────────────── */

@Composable
private fun ratingColors(r: Rating): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (r) {
        Rating.Hard -> cs.errorContainer to cs.onErrorContainer
        Rating.Good -> cs.secondaryContainer to cs.onSecondaryContainer
        Rating.Easy -> cs.tertiaryContainer to cs.onTertiaryContainer
    }
}

@Composable
private fun RatingPill(r: Rating, modifier: Modifier = Modifier) {
    val (bg, fg) = ratingColors(r)
    Surface(modifier, shape = MaterialTheme.shapes.large, color = bg, contentColor = fg, shadowElevation = 6.dp) {
        Text(r.label, Modifier.padding(horizontal = 18.dp, vertical = 8.dp), style = MaterialTheme.typography.titleMediumEmphasized)
    }
}

@Composable
private fun RatingBar(enabled: Boolean, onRate: (Rating) -> Unit) {
    AnimatedContent(
        targetState = enabled,
        transitionSpec = { (slideInVertically(spring(0.7f, 400f)) { it / 2 } + fadeIn()) togetherWith (fadeOut(tween(100))) },
        label = "ratingBar",
    ) { show ->
        if (show) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Rating.entries.forEach { r ->
                    val (bg, fg) = ratingColors(r)
                    val source = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                    Button(
                        onClick = { onRate(r) },
                        modifier = Modifier.weight(1f).height(56.dp).pressScale(source),
                        interactionSource = source,
                        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor = fg),
                    ) { Text(r.label, style = MaterialTheme.typography.titleMedium) }
                }
            }
        } else {
            Box(Modifier.fillMaxWidth().height(56.dp), Alignment.Center) {
                Text("Flip the card to rate yourself", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** "Easy · Level 3/5" bubble that pops in after every swipe and fades away. */
@Composable
private fun FeedbackPill(feedback: Feedback?, modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(feedback?.nonce) {
        if (feedback != null) { visible = true; delay(950); visible = false }
    }
    AnimatedVisibility(
        visible = visible && feedback != null,
        modifier = modifier,
        enter = scaleIn(spring(Spring_Bouncy, 500f)) + fadeIn(),
        exit = scaleOut() + fadeOut(),
    ) {
        feedback?.let { f ->
            val (bg, fg) = ratingColors(f.rating)
            Surface(shape = MaterialTheme.shapes.extraLarge, color = bg, contentColor = fg, shadowElevation = 8.dp) {
                Text(
                    "${f.rating.label} · Level ${f.newLevel}/5",
                    Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    style = MaterialTheme.typography.titleLargeEmphasized,
                )
            }
        }
    }
}

private const val Spring_Bouncy = 0.5f

/* ───────────────────────── mnemonic sheet ───────────────────────── */

@Composable
private fun MnemonicSheet(card: Flashcard, state: MnemonicState, onRegenerate: () -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 24.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("💡 Eselsbrücke", style = MaterialTheme.typography.headlineSmallEmphasized)
            Text("${card.source}  ↔  ${card.target}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)

            AnimatedContent(state, label = "mnemonic", transitionSpec = { fadeIn(spring()) togetherWith fadeOut() }) { s ->
                when (s) {
                    MnemonicState.Loading -> Row(Modifier.fillMaxWidth().height(96.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        LoadingIndicator(Modifier.size(56.dp))
                        Text("Cooking up a memory trick…")
                    }
                    is MnemonicState.Ready -> Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.tertiaryContainer) {
                        Text(s.text, Modifier.padding(22.dp), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
                    }
                    is MnemonicState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
                    MnemonicState.Idle -> Unit
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onRegenerate, enabled = state !is MnemonicState.Loading) { Text("Another one") }
                Button(onClick = onDismiss) { Text("Got it") }
            }
        }
    }
}

/* ───────────────────────── finished ───────────────────────── */

@Composable
private fun FinishedPane(reviewed: Int, onBack: () -> Unit, modifier: Modifier = Modifier) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { show = true }
    val scale by animateFloatAsState(if (show) 1f else 0f, spring(0.4f, 200f), label = "party")
    Column(modifier.fillMaxWidth(), Arrangement.spacedBy(16.dp, Alignment.CenterVertically), Alignment.CenterHorizontally) {
        Text("🎉", Modifier.graphicsLayer { scaleX = scale; scaleY = scale }, style = MaterialTheme.typography.displayLarge)
        Text(if (reviewed == 0) "Nothing due right now" else "Session complete!", style = MaterialTheme.typography.headlineMediumEmphasized)
        if (reviewed > 0) Text("$reviewed reviews done", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = onBack) { Text("Back home") }
    }
}
