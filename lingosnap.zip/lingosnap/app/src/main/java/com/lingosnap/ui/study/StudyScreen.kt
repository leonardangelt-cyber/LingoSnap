package com.lingosnap.ui.study

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.container
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.theme.bold

@Composable
fun StudyScreen(
    scope: StudyScope,
    id: Long,
    onlyDue: Boolean,
    onBack: () -> Unit,
    vm: StudyViewModel = viewModel(
        key = "study-$scope-$id-$onlyDue",
        factory = viewModelFactory { initializer { StudyViewModel(app().container.repository, scope, id, onlyDue) } },
    ),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val cs = MaterialTheme.colorScheme
    val card = ui.current

    val progress by animateFloatAsState(ui.progress, spring(0.9f, 300f), label = "session")
    val isLanguage = card?.sourceLang?.isNotBlank() == true

    AppBackground {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.Close, "Schließen") }
                Text("Karteikarten", style = MaterialTheme.typography.titleLarge.bold(), modifier = Modifier.weight(1f))
                if (!ui.loading && ui.sessionSize > 0) {
                    Text(
                        "${(ui.sessionSize - ui.queue.size).coerceAtLeast(0)} / ${ui.sessionSize}",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(end = 12.dp),
                    )
                }
            }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())

            when {
                ui.loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                ui.finished -> Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        if (ui.reviewed == 0) "Gerade nichts fällig" else "Runde geschafft",
                        style = MaterialTheme.typography.headlineMedium.bold(),
                    )
                    if (ui.reviewed > 0) {
                        Text("${ui.reviewed} Karten bearbeitet", color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                    }
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = onBack) { Text("Fertig") }
                }
                card != null -> {
                    // direction
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val a = if (isLanguage) card.sourceLang.uppercase() else "Frage"
                        val b = if (isLanguage) card.targetLang.uppercase() else "Antwort"
                        FilterChip(ui.direction == Direction.Forward, { vm.setDirection(Direction.Forward) }, { Text("$a → $b") })
                        FilterChip(ui.direction == Direction.Reverse, { vm.setDirection(Direction.Reverse) }, { Text("$b → $a") })
                        FilterChip(ui.direction == Direction.Mixed, { vm.setDirection(Direction.Mixed) }, { Text("Gemischt") })
                    }

                    val front = if (ui.sourceFirst) card.source else card.target
                    val back = if (ui.sourceFirst) card.target else card.source
                    val frontLang = if (ui.sourceFirst) card.sourceLang else card.targetLang
                    val backLang = if (ui.sourceFirst) card.targetLang else card.sourceLang
                    val shownLang = if (ui.flipped) backLang else frontLang
                    val speak = {
                        val text = if (ui.flipped) back else front
                        if (!tts.speak(text, shownLang)) {
                            Toast.makeText(context, "Keine ${languageName(shownLang)}-Stimme installiert", Toast.LENGTH_SHORT).show()
                        }
                    }

                    val src = remember { MutableInteractionSource() }
                    val rotation by animateFloatAsState(if (ui.flipped) 180f else 0f, spring(0.8f, 250f), label = "flip")
                    Surface(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .graphicsLayer { rotationY = rotation; cameraDistance = 14f * density }
                            .clickable(interactionSource = src, indication = null) { vm.flip() },
                        shape = MaterialTheme.shapes.extraLarge,
                        color = if (ui.flipped) cs.secondaryContainer else cs.surfaceContainerLow,
                        contentColor = if (ui.flipped) cs.onSecondaryContainer else cs.onSurface,
                        border = BorderStroke(1.dp, cs.outlineVariant),
                    ) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                // keep the text readable while the card is rotated
                                .graphicsLayer { rotationY = if (rotation > 90f) 180f else 0f }
                                .padding(24.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Column(
                                Modifier.verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Text(
                                    if (rotation > 90f) (if (isLanguage) "Übersetzung" else "Antwort") else (if (isLanguage) "Wort" else "Frage"),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = LocalContentColorFaded(),
                                )
                                Text(
                                    if (rotation > 90f) back else front,
                                    style = MaterialTheme.typography.headlineLarge.bold(),
                                    textAlign = TextAlign.Center,
                                )
                                if (!ui.flipped) {
                                    Text("Tippen zum Umdrehen", style = MaterialTheme.typography.bodySmall, color = LocalContentColorFaded())
                                }
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isLanguage) {
                            IconButton(onClick = speak) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Vorlesen") }
                        }
                        TextButton(onClick = { vm.requestMnemonic() }) {
                            Icon(Icons.Rounded.Lightbulb, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Merkhilfe")
                        }
                    }

                    if (!ui.flipped) {
                        Button(onClick = { vm.flip() }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                            Text("Antwort zeigen")
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = { vm.rate(Rating.Hard) },
                                modifier = Modifier.weight(1f).heightIn(min = 56.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
                            ) { Text("Nochmal") }
                            FilledTonalButton(onClick = { vm.rate(Rating.Good) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) {
                                Text("Gut")
                            }
                            Button(onClick = { vm.rate(Rating.Easy) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) {
                                Text("Leicht")
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }

    when (val m = ui.mnemonic) {
        MnemonicState.Idle -> Unit
        else -> AlertDialog(
            onDismissRequest = vm::dismissMnemonic,
            title = { Text("Merkhilfe") },
            text = {
                when (m) {
                    MnemonicState.Loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.padding(4.dp).width(24.dp).height(24.dp), strokeWidth = 3.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Wird erstellt …")
                    }
                    is MnemonicState.Ready -> Text(m.text)
                    is MnemonicState.Error -> Text(m.message, color = MaterialTheme.colorScheme.error)
                    MnemonicState.Idle -> Unit
                }
            },
            confirmButton = { TextButton(onClick = vm::dismissMnemonic) { Text("Schließen") } },
            dismissButton = {
                TextButton(onClick = { vm.requestMnemonic(force = true) }, enabled = m !is MnemonicState.Loading) { Text("Andere") }
            },
        )
    }
}

@Composable
private fun LocalContentColorFaded() = androidx.compose.material3.LocalContentColor.current.copy(alpha = 0.7f)
