package com.lingosnap.ui.study

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.theme.bold
import com.lingosnap.ui.practice.SessionTopBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyScreen(
    scope: StudyScope,
    id: Long,
    dir: String,
    onlyDue: Boolean,
    onBack: () -> Unit,
    vm: StudyViewModel = viewModel(
        key = "study-$scope-$id-$onlyDue-$dir",
        factory = viewModelFactory {
            initializer {
                StudyViewModel(app().container.repository, scope, id, onlyDue, dir, app().container.feedback.learnMode == "rounds")
            }
        },
    ),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val feedback = context.container.feedback
    val cs = MaterialTheme.colorScheme
    val card = ui.current

    val progress by animateFloatAsState(ui.progress, spring(0.9f, 300f), label = "session")
    val isLanguage = card?.sourceLang?.isNotBlank() == true

    Scaffold(
        containerColor = cs.surface,
        topBar = {
            SessionTopBar(
                title = if (ui.rounds) "Runde ${ui.roundNumber}" else "Lernen",
                progress = progress,
                counter = if (!ui.loading && ui.sessionSize > 0) "${(ui.sessionSize - ui.queue.size).coerceAtLeast(0)} / ${ui.sessionSize}" else null,
                confirm = !ui.loading && !ui.finished && !ui.roundSummary && ui.sessionSize > 0,
                onExit = onBack,
            )
        },
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).navigationBarsPadding().padding(horizontal = 20.dp).padding(top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when {
                ui.loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                ui.roundSummary -> Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text("Runde ${ui.roundNumber} geschafft", style = MaterialTheme.typography.headlineMedium.bold())
                    Text(
                        "${ui.roundCorrect} richtig, ${ui.roundWrong.size} falsch",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Text(
                        "Möchtest du die falschen Karten noch einmal wiederholen?",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 24.dp, start = 16.dp, end = 16.dp),
                    )
                    Button(onClick = { vm.nextRound() }, modifier = Modifier.padding(top = 24.dp)) { Text("Falsche wiederholen") }
                    TextButton(onClick = onBack) { Text("Beenden") }
                }
                ui.finished -> Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        if (ui.reviewed == 0) "Keine Karten" else if (ui.rounds) "Alles richtig" else "Runde geschafft",
                        style = MaterialTheme.typography.headlineMedium.bold(),
                    )
                    if (ui.reviewed > 0) {
                        Text(
                            if (ui.rounds) "Geschafft in ${ui.roundNumber} ${if (ui.roundNumber == 1) "Runde" else "Runden"}."
                            else "${ui.reviewed} Karten wiederholt. Die nächsten Termine hat das Wiederholungssystem schon geplant.",
                            color = cs.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 8.dp, start = 16.dp, end = 16.dp),
                        )
                    }
                    Button(onClick = onBack, modifier = Modifier.padding(top = 24.dp)) { Text("Fertig") }
                }
                card != null -> {
                    val front = if (ui.sourceFirst) card.source else card.target
                    val back = if (ui.sourceFirst) card.target else card.source
                    val frontLang = if (ui.sourceFirst) card.sourceLang else card.targetLang
                    val backLang = if (ui.sourceFirst) card.targetLang else card.sourceLang
                    val shownLang = if (ui.flipped) backLang else frontLang
                    val speak = {
                        val text = if (ui.flipped) back else front
                        if (!tts.speak(text, shownLang)) {
                            Toast.makeText(context, "Keine ${languageName(shownLang)}-Stimme installiert", Toast.LENGTH_SHORT).show()
                        }
                    }

                    val src = remember { MutableInteractionSource() }
                    val rotation by animateFloatAsState(if (ui.flipped) 180f else 0f, spring(0.8f, 250f), label = "flip")
                    Surface(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .graphicsLayer { rotationY = rotation; cameraDistance = 14f * density }
                            .clickable(interactionSource = src, indication = null) { feedback.tap(); vm.flip() },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp),
                        color = if (ui.flipped) cs.primaryContainer else cs.surfaceContainerHigh,
                        contentColor = if (ui.flipped) cs.onPrimaryContainer else cs.onSurface,
                    ) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                // keep the text readable while the card is rotated
                                .graphicsLayer { rotationY = if (rotation > 90f) 180f else 0f }
                                .padding(24.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Column(
                                Modifier.verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                val showingBack = rotation > 90f
                                Surface(shape = androidx.compose.foundation.shape.CircleShape, color = LocalContentColor.current.copy(alpha = 0.10f)) {
                                Text(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    text = when {
                                        showingBack && ui.sourceFirst -> if (isLanguage) "Übersetzung" else "Antwort"
                                        showingBack -> if (isLanguage) "Wort" else "Frage"
                                        ui.sourceFirst -> if (isLanguage) "Wort" else "Frage"
                                        else -> if (isLanguage) "Übersetzung" else "Antwort"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                )
                                }
                                Text(
                                    if (showingBack) back else front,
                                    style = MaterialTheme.typography.displaySmall.bold(),
                                    textAlign = TextAlign.Center,
                                )
                                if (showingBack) {
                                    ExampleBlock(
                                        card = card,
                                        loading = ui.exampleLoading,
                                        error = ui.exampleError,
                                        language = isLanguage,
                                        onSpeak = { card.example?.let { tts.speak(it, card.sourceLang) } },
                                        onGenerate = { vm.requestExample() },
                                    )
                                } else {
                                    Text(
                                        "Tippen zum Umdrehen",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = LocalContentColor.current.copy(alpha = 0.7f),
                                    )
                                }
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (isLanguage) {
                            FilledTonalIconButton(onClick = speak) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Vorlesen") }
                        }
                        androidx.compose.material3.OutlinedButton(onClick = { vm.requestMnemonic() }) {
                            Icon(Icons.Rounded.Lightbulb, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Merkhilfe")
                        }
                    }

                    if (!ui.flipped) {
                        Button(
                            onClick = { feedback.tap(); vm.flip() },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp),
                        ) { Text("Antwort zeigen", style = MaterialTheme.typography.titleMedium) }
                    } else if (ui.rounds) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { feedback.wrong(); vm.rate(Rating.Hard) },
                                modifier = Modifier.weight(1f).heightIn(min = 60.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
                            ) { Text("Falsch") }
                            Button(
                                onClick = { feedback.correct(); vm.rate(Rating.Good) },
                                modifier = Modifier.weight(1f).heightIn(min = 60.dp),
                            ) { Text("Richtig") }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            RateButton(
                                "Nochmal", Srs.preview(card, Rating.Hard), Modifier.weight(1f),
                                container = cs.errorContainer, content = cs.onErrorContainer,
                            ) { feedback.wrong(); vm.rate(Rating.Hard) }
                            RateButton(
                                "Gut", Srs.preview(card, Rating.Good), Modifier.weight(1f),
                                container = cs.secondaryContainer, content = cs.onSecondaryContainer,
                            ) { feedback.correct(); vm.rate(Rating.Good) }
                            RateButton(
                                "Leicht", Srs.preview(card, Rating.Easy), Modifier.weight(1f),
                                container = cs.primary, content = cs.onPrimary,
                            ) { feedback.correct(); vm.rate(Rating.Easy) }
                        }
                    }
                }
            }
        }
    }

    when (val m = ui.mnemonic) {
        MnemonicState.Idle -> Unit
        else -> AlertDialog(
            onDismissRequest = vm::dismissMnemonic,
            shape = MaterialTheme.shapes.extraLarge,
            title = { Text("Merkhilfe") },
            text = {
                when (m) {
                    MnemonicState.Loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Wird erstellt …")
                    }
                    is MnemonicState.Ready -> Text(m.text)
                    is MnemonicState.Error -> Text(m.message, color = MaterialTheme.colorScheme.error)
                    MnemonicState.Idle -> Unit
                }
            },
            confirmButton = { TextButton(onClick = vm::dismissMnemonic) { Text("Schließen") } },
            dismissButton = {
                TextButton(onClick = { vm.requestMnemonic(force = true) }, enabled = m !is MnemonicState.Loading) { Text("Andere") }
            },
        )
    }
}

@Composable
private fun RateButton(
    label: String,
    interval: String,
    modifier: Modifier,
    container: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 64.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.titleMedium.bold())
            Text(interval, style = MaterialTheme.typography.labelSmall)
        }
    }
}

/** Context for the card: an example sentence (from the material or written by the AI). */
@Composable
private fun ExampleBlock(
    card: Flashcard,
    loading: Boolean,
    error: String?,
    language: Boolean,
    onSpeak: () -> Unit,
    onGenerate: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HorizontalDivider(Modifier.padding(vertical = 4.dp).width(48.dp))
        val example = card.example
        if (!example.isNullOrBlank()) {
            Text("Im Satz", style = MaterialTheme.typography.labelLarge, color = LocalContentColor.current.copy(alpha = 0.7f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(example, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, modifier = Modifier.weight(1f, fill = false))
                if (language) IconButton(onClick = onSpeak) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Satz vorlesen") }
            }
        } else if (loading) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
        } else {
            TextButton(onClick = onGenerate) {
                Text("Beispielsatz erzeugen")
            }
            if (error != null) Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
        }
    }
}
