package com.lingosnap.ui.study

import com.lingosnap.ui.practice.ResultScreen
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.rounded.*
import com.lingosnap.util.tr

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.theme.bold
import com.lingosnap.ui.practice.SessionTopBar
import com.lingosnap.util.CardImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyScreen(
    scope: StudyScope,
    id: Long,
    dir: String,
    onlyDue: Boolean,
    onBack: () -> Unit,
    from: Int = 0,
    to: Int = 0,
    vm: StudyViewModel = viewModel(
        key = "study-${scope}-${id}-${onlyDue}-${dir}-${from}-${to}",
        factory = viewModelFactory {
            initializer {
                StudyViewModel(app().container.repository, scope, id, onlyDue, dir, app().container.feedback.learnMode == "rounds", from, to)
            }
        },
    ),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val feedback = context.container.feedback
    val cs = MaterialTheme.colorScheme
    val card = ui.current

    val progress by animateFloatAsState(ui.progress, spring(0.9f, 300f), label = "session")
    val isLanguage = card?.sourceLang?.isNotBlank() == true

    Scaffold(
        containerColor = cs.surface,
        topBar = {
            SessionTopBar(
                title = if (ui.rounds) tr("Runde {0}", ui.roundNumber) else tr("Lernen"),
                progress = progress,
                counter = if (!ui.loading && ui.sessionSize > 0) "${(ui.sessionSize - ui.queue.size).coerceAtLeast(0)} / ${ui.sessionSize}" else null,
                confirm = !ui.loading && !ui.finished && !ui.roundSummary && ui.sessionSize > 0,
                onExit = onBack,
            )
        },
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).navigationBarsPadding().padding(horizontal = 20.dp).padding(top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when {
                ui.loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                ui.roundSummary -> {
                    val total = (ui.roundCorrect + ui.roundWrong.size).coerceAtLeast(1)
                    ResultScreen(
                        headline = tr("Runde {0} geschafft", ui.roundNumber),
                        detail = tr("Möchtest du die falschen Karten noch einmal wiederholen?"),
                        ratio = ui.roundCorrect / total.toFloat(),
                        stats = listOf(
                            com.lingosnap.ui.practice.ResultStat(Icons.Rounded.Check, tr("{0} richtig", ui.roundCorrect)),
                            com.lingosnap.ui.practice.ResultStat(Icons.Rounded.Close, tr("{0} falsch", ui.roundWrong.size)),
                        ),
                        wrong = ui.roundWrong,
                        primaryLabel = tr("Falsche wiederholen"), onPrimary = { vm.nextRound() },
                        doneLabel = tr("Beenden"), onDone = onBack,
                    )
                }
                ui.finished -> ResultScreen(
                    headline = if (ui.reviewed == 0) tr("Keine Karten") else if (ui.rounds) tr("Alles richtig") else tr("Runde geschafft"),
                    detail = if (ui.reviewed == 0) "" else if (ui.rounds)
                        tr("Geschafft in {0} {1}.", ui.roundNumber, if (ui.roundNumber == 1) tr("Runde") else tr("Runden"))
                    else tr("{0} Karten wiederholt. Die nächsten Termine hat das Wiederholungssystem schon geplant.", ui.reviewed),
                    ratio = -1f,
                    stats = if (ui.reviewed > 0) listOf(
                        com.lingosnap.ui.practice.ResultStat(Icons.Rounded.Style, tr("{0} Karten", ui.reviewed)),
                    ) else emptyList(),
                    doneLabel = tr("Fertig"), onDone = onBack,
                )
                card != null -> {
                    val front = if (ui.sourceFirst) card.source else card.target
                    val back = if (ui.sourceFirst) card.target else card.source
                    val frontLang = if (ui.sourceFirst) card.sourceLang else card.targetLang
                    val backLang = if (ui.sourceFirst) card.targetLang else card.sourceLang
                    val shownLang = if (ui.flipped) backLang else frontLang
                    val speak = {
                        val text = if (ui.flipped) back else front
                        if (!tts.speak(text, shownLang)) {
                            Toast.makeText(context, tr("Keine {0}-Stimme installiert", languageName(shownLang)), Toast.LENGTH_SHORT).show()
                        }
                    }

                    var panel by remember(card.id) { mutableStateOf<String?>(null) }
                    val src = remember { MutableInteractionSource() }
                    // No turning. The question glides up and gets smaller and lighter while the answer fades in below it.
                    // Everything moves through graphicsLayer (no re-layout per frame), so the motion stays smooth; a new card starts at rest.
                    val revealAnim = remember(card.id) { androidx.compose.animation.core.Animatable(if (ui.flipped) 1f else 0f) }
                    androidx.compose.runtime.LaunchedEffect(ui.flipped, card.id) {
                        revealAnim.animateTo(
                            if (ui.flipped) 1f else 0f,
                            androidx.compose.animation.core.tween(380, easing = androidx.compose.animation.core.FastOutSlowInEasing),
                        )
                    }
                    val reveal = revealAnim.value
                    val density = androidx.compose.ui.platform.LocalDensity.current
                    Surface(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clickable(interactionSource = src, indication = null) { feedback.tap(); vm.flip() },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp),
                        color = cs.surfaceContainerHigh,
                        contentColor = cs.onSurface,
                    ) {
                        androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize()) {
                            val showingBack = ui.flipped
                            val h = with(density) { maxHeight.toPx() }
                            val labelPx = with(density) { 64.dp.toPx() }
                            var frontH by remember(card.id) { androidx.compose.runtime.mutableIntStateOf(0) }
                            val endScale = 0.62f
                            val scaledH = frontH * endScale
                            // where the middle of the question ends up, and where the answer starts below it
                            val endCenter = maxOf(h * 0.24f, labelPx + scaledH / 2f)
                            val shift = (h / 2f - endCenter).coerceAtLeast(0f)
                            val backTop = with(density) { (endCenter + scaledH / 2f).toDp() } + 18.dp
                            Box(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
                                // the question
                                Column(
                                    Modifier
                                        .align(Alignment.Center)
                                        .fillMaxWidth()
                                        .onSizeChanged { frontH = it.height }
                                        .graphicsLayer {
                                            translationY = -shift * reveal
                                            val sc = 1f - (1f - endScale) * reveal
                                            scaleX = sc; scaleY = sc
                                            alpha = 1f - 0.45f * reveal
                                        },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    CardImage(card.imagePath, Modifier.fillMaxWidth(), maxHeight = 160.dp)
                                    Text(front, style = cardTextStyle(front), textAlign = TextAlign.Center)
                                }
                                // the hint before the answer is shown
                                if (reveal < 0.99f) Column(
                                    Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp).graphicsLayer { alpha = 1f - reveal },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    if (isLanguage) SymbolBar(listen = true, onListen = speak, panel = null, onSentence = null, onMnemonic = null, sentenceLabel = "")
                                    Text(
                                        if (isLanguage) tr("Erst laut sagen, dann aufdecken") else tr("Erst selbst antworten, dann aufdecken"),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = cs.onSurfaceVariant,
                                    )
                                }
                                // the answer
                                if (reveal > 0.01f) Column(
                                    Modifier
                                        .align(Alignment.TopCenter)
                                        .fillMaxWidth()
                                        .padding(top = backTop, bottom = 16.dp)
                                        .verticalScroll(rememberScrollState())
                                        .graphicsLayer {
                                            alpha = reveal
                                            translationY = (1f - reveal) * 28.dp.toPx()
                                        },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp),
                                ) {
                                    HorizontalDivider(Modifier.width(56.dp), color = cs.outlineVariant)
                                    Text(back, style = cardTextStyle(back), color = cs.primary, textAlign = TextAlign.Center)
                                    SymbolBar(
                                        listen = isLanguage, onListen = speak,
                                        panel = panel,
                                        onSentence = {
                                            panel = if (panel == "ex") null else "ex"
                                            if (panel == "ex" && card.example.isNullOrBlank()) vm.requestExample()
                                        },
                                        onMnemonic = {
                                            panel = if (panel == "mn") null else "mn"
                                            if (panel == "mn" && card.mnemonic.isNullOrBlank()) vm.requestMnemonic(false)
                                        },
                                        sentenceLabel = if (isLanguage) tr("Beispielsatz") else tr("Erklärung"),
                                    )
                                    HelpPanel(
                                        panel = panel, card = card, language = isLanguage,
                                        exampleLoading = ui.exampleLoading, exampleError = ui.exampleError, mnemonic = ui.mnemonic,
                                        onSpeakExample = { card.example?.let { tts.speak(it, card.sourceLang) } },
                                        onExample = { vm.requestExample() },
                                        onMnemonic = { force -> vm.requestMnemonic(force) },
                                    )
                                }
                            }
                            // label top left, listen button top right – both always visible
                            Surface(
                                Modifier.align(Alignment.TopStart).padding(16.dp),
                                shape = androidx.compose.foundation.shape.CircleShape,
                                color = cs.surfaceContainerHighest,
                            ) {
                                Text(
                                    when {
                                        showingBack && ui.sourceFirst -> if (isLanguage) tr("Übersetzung") else tr("Antwort")
                                        showingBack -> if (isLanguage) tr("Wort") else tr("Frage")
                                        ui.sourceFirst -> if (isLanguage) tr("Wort") else tr("Frage")
                                        else -> if (isLanguage) tr("Übersetzung") else tr("Antwort")
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                )
                            }
                        }
                    }

                    if (!ui.flipped) {
                        Button(
                            onClick = { feedback.tap(); vm.flip() },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp),
                        ) { Text(tr("Antwort zeigen"), style = MaterialTheme.typography.titleMedium) }
                    } else if (ui.rounds) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { feedback.wrong(); vm.rate(Rating.Again) },
                                modifier = Modifier.weight(1f).heightIn(min = 60.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
                            ) { Text(tr("Falsch")) }
                            Button(
                                onClick = { feedback.correct(); vm.rate(Rating.Good) },
                                modifier = Modifier.weight(1f).heightIn(min = 60.dp),
                            ) { Text(tr("Richtig")) }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            RateButton(
                                tr("Nochmal"), Srs.preview(Rating.Again), Modifier.weight(1f),
                                container = cs.errorContainer, content = cs.onErrorContainer,
                            ) { feedback.wrong(); vm.rate(Rating.Again) }
                            RateButton(
                                tr("Schwer"), Srs.preview(Rating.Hard), Modifier.weight(1f),
                                container = cs.tertiaryContainer, content = cs.onTertiaryContainer,
                            ) { feedback.wrong(); vm.rate(Rating.Hard) }
                            RateButton(
                                tr("Gut"), Srs.preview(Rating.Good), Modifier.weight(1f),
                                container = cs.secondaryContainer, content = cs.onSecondaryContainer,
                            ) { feedback.correct(); vm.rate(Rating.Good) }
                            RateButton(
                                tr("Einfach"), Srs.preview(Rating.Easy), Modifier.weight(1f),
                                container = cs.primary, content = cs.onPrimary,
                            ) { feedback.correct(); vm.rate(Rating.Easy) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RateButton(
    label: String,
    interval: String,
    modifier: Modifier,
    container: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 64.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.titleSmall.bold(), maxLines = 1)
            Text(interval, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun cardTextStyle(text: String) = when {
    text.length > 120 -> MaterialTheme.typography.titleLarge
    text.length > 50 -> MaterialTheme.typography.headlineSmall.bold()
    else -> MaterialTheme.typography.displaySmall.bold()
}

/** Three small symbols under the word: pronunciation, example sentence (or explanation), mnemonic. */
@Composable
private fun SymbolBar(
    listen: Boolean,
    onListen: () -> Unit,
    panel: String?,
    onSentence: (() -> Unit)?,
    onMnemonic: (() -> Unit)?,
    sentenceLabel: String,
) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (listen) SymbolButton(Icons.AutoMirrored.Rounded.VolumeUp, tr("Aussprache"), false, onListen)
        if (onSentence != null) SymbolButton(Icons.Rounded.FormatQuote, sentenceLabel, panel == "ex", onSentence)
        if (onMnemonic != null) SymbolButton(Icons.Rounded.Lightbulb, tr("Eselsbrücke"), panel == "mn", onMnemonic)
    }
}

@Composable
private fun SymbolButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = androidx.compose.foundation.shape.CircleShape,
        color = if (active) cs.primary else cs.surfaceContainerHighest,
        contentColor = if (active) cs.onPrimary else cs.onSurfaceVariant,
    ) {
        Icon(icon, label, Modifier.padding(10.dp).size(22.dp))
    }
}

/** The text behind the sentence / mnemonic symbol, shown below the answer. */
@Composable
private fun HelpPanel(
    panel: String?,
    card: Flashcard,
    language: Boolean,
    exampleLoading: Boolean,
    exampleError: String?,
    mnemonic: MnemonicState,
    onSpeakExample: () -> Unit,
    onExample: () -> Unit,
    onMnemonic: (Boolean) -> Unit,
) {
    if (panel == null) return
    val cs = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = cs.surfaceContainerHighest) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (panel == "ex") {
                Text(if (language) tr("Im Satz") else tr("Erklärung"), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                val example = card.example
                when {
                    !example.isNullOrBlank() -> Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(example, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                        if (language) IconButton(onClick = onSpeakExample) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, tr("Satz anhören")) }
                    }
                    exampleLoading -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                    else -> {
                        if (exampleError != null) Text(exampleError, style = MaterialTheme.typography.bodySmall, color = cs.error)
                        TextButton(onClick = onExample) { Text(tr("Erneut versuchen")) }
                    }
                }
            } else {
                Text(tr("Eselsbrücke"), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                val saved = card.mnemonic
                when {
                    mnemonic is MnemonicState.Loading -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                    !saved.isNullOrBlank() -> {
                        Text(saved, style = MaterialTheme.typography.bodyLarge)
                        TextButton(onClick = { onMnemonic(true) }) { Text(tr("Andere")) }
                    }
                    else -> {
                        if (mnemonic is MnemonicState.Error) Text(mnemonic.message, style = MaterialTheme.typography.bodySmall, color = cs.error)
                        TextButton(onClick = { onMnemonic(false) }) { Text(tr("Erneut versuchen")) }
                    }
                }
            }
        }
    }
}
