@file:OptIn(ExperimentalMaterial3Api::class)

package com.lingosnap.ui.study

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.ConfettiBurst
import com.lingosnap.ui.components.CookieBadge
import com.lingosnap.ui.components.MasteryIndicator
import com.lingosnap.ui.components.MorphLoader
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold
import com.lingosnap.app
import com.lingosnap.data.model.StudyScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun StudyScreen(
    scope: StudyScope,
    id: Long,
    onlyDue: Boolean,
    onBack: () -> Unit,
    vm: StudyViewModel = viewModel(
        key = "study-$scope-$id-$onlyDue",
        factory = viewModelFactory { initializer { StudyViewModel(app().container.repository, scope, id, onlyDue) } },
    ),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val card = ui.current

    val speak: (String, String) -> Unit = { text, tag ->
        if (!tts.speak(text, tag)) {
            Toast.makeText(context, "Keine ${languageName(tag)}-Stimme installiert", Toast.LENGTH_SHORT).show()
        }
    }

    AppBackground {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            StudyHeader(onBack, ui)
            DirectionPicker(ui.direction, card, vm::setDirection)

            val sessionProgress by animateFloatAsState(ui.progress, spring(0.8f, 300f), label = "session")
            WavyProgressBar(progress = sessionProgress)

            when {
                ui.loading -> Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) { MorphLoader(size = 80.dp) }
                ui.finished -> FinishedPane(ui.reviewed, onBack, Modifier.weight(1f))
                card != null -> {
                    MasteryIndicator(card.level)

                    // Room below the card so the stacked cards underneath peek out
                    Box(Modifier.weight(1f).fillMaxWidth().padding(bottom = 30.dp)) {
                        if (ui.queue.size > 2) StackLayer(depth = 2)
                        if (ui.queue.size > 1) StackLayer(depth = 1)

                        SwipeableFlashcard(
                            // new key => fresh drag/flip state for every card (also for re-queued "Hard" cards)
                            cardKey = card.id to ui.reviewed,
                            card = card,
                            sourceFirst = ui.sourceFirst,
                            flipped = ui.flipped,
                            onFlip = vm::flip,
                            onSwipe = vm::rate,
                            onSpeak = speak,
                            onMnemonic = { vm.requestMnemonic() },
                            modifier = Modifier.fillMaxSize(),
                        )
                    }

                    RatingBar(enabled = ui.flipped, onRate = vm::rate)
                    Spacer(Modifier.height(4.dp))
                }
            }
        }

        FeedbackPill(ui.feedback, Modifier.align(Alignment.TopCenter).padding(top = 150.dp))
    }

    if (ui.mnemonic != MnemonicState.Idle && card != null) {
        MnemonicSheet(card, ui.mnemonic, onRegenerate = { vm.requestMnemonic(force = true) }, onDismiss = vm::dismissMnemonic)
    }
}

/* ───────────────────────── header + direction ───────────────────────── */

@Composable
private fun StudyHeader(onBack: () -> Unit, ui: StudyUiState) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().entrance(0), verticalAlignment = Alignment.CenterVertically) {
        FilledTonalIconButton(onClick = onBack) { Icon(Icons.Rounded.Close, "Schließen") }
        Text(
            "Lernen",
            Modifier.weight(1f),
            style = MaterialTheme.typography.titleLarge.bold(),
            textAlign = TextAlign.Center,
        )
        Surface(shape = MaterialTheme.shapes.large, color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer) {
            AnimatedContent(
                targetState = ui.reviewed,
                transitionSpec = {
                    (slideInVertically(spring(stiffness = 400f)) { it } + fadeIn()) togetherWith
                        (slideOutVertically { -it } + fadeOut())
                },
                label = "counter",
            ) { n ->
                Text(
                    "$n / ${ui.sessionSize}",
                    Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge.bold(),
                )
            }
        }
    }
}

@Composable
private fun DirectionPicker(selected: Direction, card: Flashcard?, onSelect: (Direction) -> Unit) {
    val a = card?.sourceLang?.uppercase() ?: "A"
    val b = card?.targetLang?.uppercase() ?: "B"
    val labels = mapOf(Direction.Forward to "$a → $b", Direction.Reverse to "$b → $a", Direction.Mixed to "Gemischt")
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().entrance(1)) {
        Direction.entries.forEachIndexed { i, d ->
            SegmentedButton(
                selected = d == selected,
                onClick = { onSelect(d) },
                shape = SegmentedButtonDefaults.itemShape(i, Direction.entries.size),
                label = { Text(labels.getValue(d)) },
            )
        }
    }
}

/* ───────────────────────── stacked cards behind ───────────────────────── */

@Composable
private fun StackLayer(depth: Int) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxSize()
            .padding(horizontal = (14 * depth).dp)
            .offset(y = (14 * depth).dp)
            .clip(MaterialTheme.shapes.extraLarge)
            .background(cs.surfaceContainerHigh.copy(alpha = 1f - 0.22f * depth)),
    )
}

/* ───────────────────────── swipe + flip card ───────────────────────── */

private fun decide(x: Float, y: Float, t: Float): Rating? = when {
    y < -t && abs(y) > abs(x) -> Rating.Easy
    x > t -> Rating.Good
    x < -t -> Rating.Hard
    else -> null
}

private fun emojiFor(r: Rating) = when (r) {
    Rating.Hard -> "😵"
    Rating.Good -> "🙂"
    Rating.Easy -> "🤩"
}

@Composable
private fun SwipeableFlashcard(
    cardKey: Any,
    card: Flashcard,
    sourceFirst: Boolean,
    flipped: Boolean,
    onFlip: () -> Unit,
    onSwipe: (Rating) -> Unit,
    onSpeak: (String, String) -> Unit,
    onMnemonic: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val cs = MaterialTheme.colorScheme
    val threshold = with(LocalDensity.current) { 110.dp.toPx() }
    val x = remember(cardKey) { Animatable(0f) }
    val y = remember(cardKey) { Animatable(0f) }

    // New card pops in from slightly smaller (the stack behind it "moves up")
    val appear = remember(cardKey) { Animatable(0.93f) }
    LaunchedEffect(cardKey) { appear.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 350f)) }

    val flip by animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 120f),
        label = "flip",
    )

    val frontText = if (sourceFirst) card.source else card.target
    val frontLang = if (sourceFirst) card.sourceLang else card.targetLang
    val backText = if (sourceFirst) card.target else card.source
    val backLang = if (sourceFirst) card.targetLang else card.sourceLang

    val dragFraction = (max(abs(x.value), abs(y.value)) / threshold).coerceIn(0f, 1f)
    val direction = decide(x.value, y.value, 1f)
    val overlayColor = if (direction != null) ratingColors(direction).first else Color.Transparent
    val shape = MaterialTheme.shapes.extraLarge

    Box(
        modifier
            .offset { IntOffset(x.value.roundToInt(), y.value.roundToInt()) }
            .graphicsLayer {
                rotationZ = (x.value / 40f).coerceIn(-12f, 12f)
                scaleX = appear.value
                scaleY = appear.value
            }
            .pointerInput(cardKey, flipped) {
                if (!flipped) return@pointerInput // you must peek at the answer before judging yourself
                detectDragGestures(
                    onDrag = { change, drag ->
                        change.consume()
                        scope.launch {
                            x.snapTo(x.value + drag.x)
                            y.snapTo(y.value + drag.y)
                        }
                    },
                    onDragEnd = {
                        val rating = decide(x.value, y.value, threshold)
                        scope.launch {
                            if (rating == null) {
                                launch { x.animateTo(0f, spring(0.55f, 400f)) }
                                launch { y.animateTo(0f, spring(0.55f, 400f)) }
                            } else {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                val fly = tween<Float>(220)
                                when (rating) {
                                    Rating.Good -> x.animateTo(1600f, fly)
                                    Rating.Hard -> x.animateTo(-1600f, fly)
                                    Rating.Easy -> y.animateTo(-2000f, fly)
                                }
                                onSwipe(rating)
                            }
                        }
                    },
                    onDragCancel = { scope.launch { x.animateTo(0f); y.animateTo(0f) } },
                )
            },
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { rotationY = flip; cameraDistance = 16f * density }
                .shadow(18.dp, shape)
                .clip(shape)
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onFlip()
                },
        ) {
            if (flip <= 90f) {
                CardFace(
                    text = frontText, langTag = frontLang, footer = "Tippen zum Umdrehen",
                    brush = Brush.linearGradient(listOf(cs.primaryContainer, cs.tertiaryContainer)),
                    contentColor = cs.onPrimaryContainer,
                    onSpeak = onSpeak, onMnemonic = null,
                )
            } else {
                Box(Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }) {
                    CardFace(
                        text = backText, langTag = backLang, footer = "← hard   ·   ↑ easy   ·   good →",
                        brush = Brush.linearGradient(listOf(cs.secondaryContainer, cs.primaryContainer)),
                        contentColor = cs.onSecondaryContainer,
                        onSpeak = onSpeak, onMnemonic = onMnemonic,
                    )
                }
            }
        }

        // Live swipe feedback: colour wash + big emoji
        Box(
            Modifier
                .matchParentSize()
                .clip(shape)
                .background(overlayColor.copy(alpha = 0.6f * dragFraction)),
            contentAlignment = Alignment.Center,
        ) {
            if (direction != null) {
                Column(
                    Modifier.graphicsLayer {
                        alpha = dragFraction
                        scaleX = 0.6f + 0.6f * dragFraction
                        scaleY = 0.6f + 0.6f * dragFraction
                    },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(emojiFor(direction), fontSize = 80.sp)
                    Text(direction.label, style = MaterialTheme.typography.headlineSmall.bold(), color = ratingColors(direction).second)
                }
            }
        }
    }
}

@Composable
private fun CardFace(
    text: String,
    langTag: String,
    footer: String,
    brush: Brush,
    contentColor: Color,
    onSpeak: (String, String) -> Unit,
    onMnemonic: (() -> Unit)?,
) {
    val textStyle = if (text.length > 14) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.displayMedium
    Box(Modifier.fillMaxSize().background(brush).padding(24.dp)) {
        CookieBadge(
            size = 280.dp,
            color = contentColor.copy(alpha = 0.07f),
            lobes = 9,
            spinMillis = 50000,
            modifier = Modifier.align(Alignment.BottomEnd).offset(x = 90.dp, y = 90.dp),
        )
        Surface(
            Modifier.align(Alignment.TopStart),
            shape = MaterialTheme.shapes.large,
            color = contentColor.copy(alpha = 0.12f),
            contentColor = contentColor,
        ) {
            Text(
                languageName(langTag).uppercase(),
                Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelLarge.bold(),
            )
        }
        Text(
            text,
            Modifier.align(Alignment.Center).padding(horizontal = 8.dp),
            color = contentColor,
            textAlign = TextAlign.Center,
            style = textStyle.bold(),
        )
        Row(Modifier.align(Alignment.TopEnd), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            onMnemonic?.let {
                FilledTonalIconButton(onClick = it) { Icon(Icons.Rounded.Lightbulb, "Eselsbrücke") }
            }
            FilledIconButton(
                onClick = { onSpeak(text, langTag) },
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = contentColor,
                    contentColor = MaterialTheme.colorScheme.surface,
                ),
            ) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Vorlesen") }
        }
        Text(
            footer,
            Modifier.align(Alignment.BottomCenter),
            style = MaterialTheme.typography.labelLarge,
            color = contentColor.copy(alpha = 0.65f),
        )
    }
}

/* ───────────────────────── rating + feedback ───────────────────────── */

@Composable
private fun ratingColors(r: Rating): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (r) {
        Rating.Hard -> cs.errorContainer to cs.onErrorContainer
        Rating.Good -> cs.secondaryContainer to cs.onSecondaryContainer
        Rating.Easy -> cs.tertiaryContainer to cs.onTertiaryContainer
    }
}

@Composable
private fun RatingBar(enabled: Boolean, onRate: (Rating) -> Unit) {
    AnimatedContent(
        targetState = enabled,
        transitionSpec = {
            (slideInVertically(spring(0.7f, 400f)) { it / 2 } + fadeIn()) togetherWith fadeOut(tween(100))
        },
        label = "ratingBar",
    ) { show ->
        if (show) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Rating.entries.forEach { r ->
                    val (bg, fg) = ratingColors(r)
                    BouncyButton(
                        onClick = { onRate(r) },
                        modifier = Modifier.weight(1f).height(60.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor = fg),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp),
                    ) {
                        Text("${emojiFor(r)} ${r.label}", style = MaterialTheme.typography.titleMedium.bold(), maxLines = 1)
                    }
                }
            }
        } else {
            Box(Modifier.fillMaxWidth().height(60.dp), Alignment.Center) {
                Text("Dreh die Karte um und bewerte dich", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** "🤩 Easy · Level 3/5" bubble that pops in after every swipe and fades away. */
@Composable
private fun FeedbackPill(feedback: Feedback?, modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(feedback?.nonce) {
        if (feedback != null) {
            visible = true
            delay(950)
            visible = false
        }
    }
    AnimatedVisibility(
        visible = visible && feedback != null,
        modifier = modifier,
        enter = scaleIn(spring(0.45f, 500f)) + fadeIn(),
        exit = scaleOut() + fadeOut(),
    ) {
        feedback?.let { f ->
            val (bg, fg) = ratingColors(f.rating)
            Surface(shape = MaterialTheme.shapes.extraLarge, color = bg, contentColor = fg, shadowElevation = 10.dp) {
                Text(
                    "${emojiFor(f.rating)}  ${f.rating.label} · Level ${f.newLevel}/5",
                    Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    style = MaterialTheme.typography.titleLarge.bold(),
                )
            }
        }
    }
}

/* ───────────────────────── mnemonic sheet ───────────────────────── */

@Composable
private fun MnemonicSheet(card: Flashcard, state: MnemonicState, onRegenerate: () -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.padding(horizontal = 24.dp).padding(bottom = 24.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Text("💡 Eselsbrücke", style = MaterialTheme.typography.headlineSmall.bold())
            Text(
                "${card.source}  ↔  ${card.target}",
                style = MaterialTheme.typography.titleMedium.bold(),
                color = cs.primary,
            )

            AnimatedContent(
                targetState = state,
                label = "mnemonic",
                transitionSpec = { (fadeIn(spring()) + scaleIn(initialScale = 0.95f)) togetherWith fadeOut() },
            ) { s ->
                when (s) {
                    MnemonicState.Loading -> Row(
                        Modifier.fillMaxWidth().height(96.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        MorphLoader(size = 52.dp, color = cs.tertiary)
                        Text("Eselsbrücke wird gezaubert …", style = MaterialTheme.typography.titleMedium)
                    }
                    is MnemonicState.Ready -> Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.extraLarge)
                            .background(Brush.linearGradient(listOf(cs.tertiaryContainer, cs.secondaryContainer))),
                    ) {
                        Text(
                            s.text,
                            Modifier.padding(22.dp),
                            style = MaterialTheme.typography.titleMedium,
                            color = cs.onTertiaryContainer,
                        )
                    }
                    is MnemonicState.Error -> Text(s.message, color = cs.error)
                    MnemonicState.Idle -> Unit
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onRegenerate, enabled = state !is MnemonicState.Loading) { Text("Noch eine") }
                Button(onClick = onDismiss) { Text("Verstanden") }
            }
        }
    }
}

/* ───────────────────────── finished ───────────────────────── */

@Composable
private fun FinishedPane(reviewed: Int, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { show = true }
    val scale by animateFloatAsState(if (show) 1f else 0f, spring(dampingRatio = 0.4f, stiffness = 200f), label = "trophy")

    Box(modifier.fillMaxWidth()) {
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.graphicsLayer { scaleX = scale; scaleY = scale }) {
                CookieBadge(size = 170.dp, color = cs.primaryContainer, lobes = 10) {
                    Text(if (reviewed == 0) "😴" else "🏆", fontSize = 72.sp)
                }
            }
            Text(
                if (reviewed == 0) "Gerade nichts fällig" else "Runde geschafft!",
                style = MaterialTheme.typography.headlineMedium.bold(),
                textAlign = TextAlign.Center,
                modifier = Modifier.entrance(2),
            )
            if (reviewed > 0) {
                Text(
                    "$reviewed reviews done",
                    color = cs.onSurfaceVariant,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.entrance(3),
                )
            }
            BouncyButton(onClick = onBack, modifier = Modifier.entrance(4)) {
                Text("Zurück", style = MaterialTheme.typography.titleMedium.bold())
            }
        }
        if (reviewed > 0) ConfettiBurst()
    }
}
