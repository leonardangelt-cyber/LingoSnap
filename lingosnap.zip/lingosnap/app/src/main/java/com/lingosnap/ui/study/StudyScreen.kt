package com.lingosnap.ui.study

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lingosnap.app
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.theme.bold
import com.lingosnap.ui.practice.SessionTopBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyScreen(
    scope: StudyScope,
    id: Long,
    dir: String,
    onlyDue: Boolean,
    onBack: () -> Unit,
    vm: StudyViewModel = viewModel(
        key = "study-$scope-$id-$onlyDue-$dir",
        factory = viewModelFactory {
            initializer {
                StudyViewModel(app().container.repository, scope, id, onlyDue, dir, app().container.feedback.learnMode == "rounds")
            }
        },
    ),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val feedback = context.container.feedback
    val cs = MaterialTheme.colorScheme
    val card = ui.current

    val progress by animateFloatAsState(ui.progress, spring(0.9f, 300f), label = "session")
    val isLanguage = card?.sourceLang?.isNotBlank() == true

    Scaffold(
        containerColor = cs.surface,
        topBar = {
            SessionTopBar(
                title = if (ui.rounds) "Runde ${ui.roundNumber}" else "Lernen",
                progress = progress,
                counter = if (!ui.loading && ui.sessionSize > 0) "${(ui.sessionSize - ui.queue.size).coerceAtLeast(0)} / ${ui.sessionSize}" else null,
                confirm = !ui.loading && !ui.finished && !ui.roundSummary && ui.sessionSize > 0,
                onExit = onBack,
            )
        },
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).navigationBarsPadding().padding(horizontal = 20.dp).padding(top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when {
                ui.loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                ui.roundSummary -> Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text("Runde ${ui.roundNumber} geschafft", style = MaterialTheme.typography.headlineMedium.bold())
                    Text(
                        "${ui.roundCorrect} richtig, ${ui.roundWrong.size} falsch",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Text(
                        "Möchtest du die falschen Karten noch einmal wiederholen?",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 24.dp, start = 16.dp, end = 16.dp),
                    )
                    Button(onClick = { vm.nextRound() }, modifier = Modifier.padding(top = 24.dp)) { Text("Falsche wiederholen") }
                    TextButton(onClick = onBack) { Text("Beenden") }
                }
                ui.finished -> Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        if (ui.reviewed == 0) "Keine Karten" else if (ui.rounds) "Alles richtig" else "Runde geschafft",
                        style = MaterialTheme.typography.headlineMedium.bold(),
                    )
                    if (ui.reviewed > 0) {
                        Text(
                            if (ui.rounds) "Geschafft in ${ui.roundNumber} ${if (ui.roundNumber == 1) "Runde" else "Runden"}."
                            else "${ui.reviewed} Karten wiederholt. Die nächsten Termine hat das Wiederholungssystem schon geplant.",
                            color = cs.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 8.dp, start = 16.dp, end = 16.dp),
                        )
                    }
                    Button(onClick = onBack, modifier = Modifier.padding(top = 24.dp)) { Text("Fertig") }
                }
                card != null -> {
                    val front = if (ui.sourceFirst) card.source else card.target
                    val back = if (ui.sourceFirst) card.target else card.source
                    val frontLang = if (ui.sourceFirst) card.sourceLang else card.targetLang
                    val backLang = if (ui.sourceFirst) card.targetLang else card.sourceLang
                    val shownLang = if (ui.flipped) backLang else frontLang
                    val speak = {
                        val text = if (ui.flipped) back else front
                        if (!tts.speak(text, shownLang)) {
                            Toast.makeText(context, "Keine ${languageName(shownLang)}-Stimme installiert", Toast.LENGTH_SHORT).show()
                        }
                    }

                    val src = remember { MutableInteractionSource() }
                    val rotation by animateFloatAsState(if (ui.flipped) 180f else 0f, spring(0.8f, 250f), label = "flip")
                    Surface(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .graphicsLayer { rotationY = rotation; cameraDistance = 14f * density }
                            .clickable(interactionSource = src, indication = null) { feedback.tap(); vm.flip() },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp),
                        color = cs.surfaceContainerHigh,
                        contentColor = cs.onSurface,
                        border = if (ui.flipped) androidx.compose.foundation.BorderStroke(2.dp, cs.primary) else null,
                    ) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                // keep the text readable while the card is rotated
                                .graphicsLayer { rotationY = if (rotation > 90f) 180f else 0f },
                        ) {
                            val showingBack = rotation > 90f
                            Box(
                                Modifier.fillMaxSize().padding(horizontal = 24.dp).padding(top = 64.dp, bottom = 24.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                            Column(
                                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp),
                            ) {
                                if (showingBack) {
                                    Text(
                                        front,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = cs.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                    )
                                    HorizontalDivider(Modifier.width(56.dp), color = cs.outlineVariant)
                                    Text(
                                        back,
                                        style = cardTextStyle(back),
                                        color = cs.primary,
                                        textAlign = TextAlign.Center,
                                    )
                                    HelpSection(
                                        card = card,
                                        language = isLanguage,
                                        exampleLoading = ui.exampleLoading,
                                        exampleError = ui.exampleError,
                                        mnemonic = ui.mnemonic,
                                        onSpeakExample = { card.example?.let { tts.speak(it, card.sourceLang) } },
                                        onExample = { vm.requestExample() },
                                        onMnemonic = { force -> vm.requestMnemonic(force) },
                                    )
                                } else {
                                    Text(
                                        front,
                                        style = cardTextStyle(front),
                                        textAlign = TextAlign.Center,
                                    )
                                    Text(
                                        "Tippen zum Umdrehen",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = cs.onSurfaceVariant,
                                    )
                                }
                            }
                            }
                            // label top left, listen button top right – both always visible
                            Surface(
                                Modifier.align(Alignment.TopStart).padding(16.dp),
                                shape = androidx.compose.foundation.shape.CircleShape,
                                color = cs.surfaceContainerHighest,
                            ) {
                                Text(
                                    when {
                                        showingBack && ui.sourceFirst -> if (isLanguage) "Übersetzung" else "Antwort"
                                        showingBack -> if (isLanguage) "Wort" else "Frage"
                                        ui.sourceFirst -> if (isLanguage) "Wort" else "Frage"
                                        else -> if (isLanguage) "Übersetzung" else "Antwort"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                )
                            }
                            if (isLanguage) {
                                FilledTonalIconButton(onClick = speak, modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                                    Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Anhören")
                                }
                            }
                        }
                    }

                    if (!ui.flipped) {
                        Button(
                            onClick = { feedback.tap(); vm.flip() },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp),
                        ) { Text("Antwort zeigen", style = MaterialTheme.typography.titleMedium) }
                    } else if (ui.rounds) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { feedback.wrong(); vm.rate(Rating.Hard) },
                                modifier = Modifier.weight(1f).heightIn(min = 60.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
                            ) { Text("Falsch") }
                            Button(
                                onClick = { feedback.correct(); vm.rate(Rating.Good) },
                                modifier = Modifier.weight(1f).heightIn(min = 60.dp),
                            ) { Text("Richtig") }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            RateButton(
                                "Nochmal", Srs.preview(card, Rating.Hard), Modifier.weight(1f),
                                container = cs.errorContainer, content = cs.onErrorContainer,
                            ) { feedback.wrong(); vm.rate(Rating.Hard) }
                            RateButton(
                                "Gut", Srs.preview(card, Rating.Good), Modifier.weight(1f),
                                container = cs.secondaryContainer, content = cs.onSecondaryContainer,
                            ) { feedback.correct(); vm.rate(Rating.Good) }
                            RateButton(
                                "Leicht", Srs.preview(card, Rating.Easy), Modifier.weight(1f),
                                container = cs.primary, content = cs.onPrimary,
                            ) { feedback.correct(); vm.rate(Rating.Easy) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RateButton(
    label: String,
    interval: String,
    modifier: Modifier,
    container: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 64.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.titleMedium.bold())
            Text(interval, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun cardTextStyle(text: String) = when {
    text.length > 120 -> MaterialTheme.typography.titleLarge
    text.length > 50 -> MaterialTheme.typography.headlineSmall.bold()
    else -> MaterialTheme.typography.displaySmall.bold()
}

/** Everything that helps remembering lives on the solution side: example (or explanation) and mnemonic. */
@Composable
private fun HelpSection(
    card: Flashcard,
    language: Boolean,
    exampleLoading: Boolean,
    exampleError: String?,
    mnemonic: MnemonicState,
    onSpeakExample: () -> Unit,
    onExample: () -> Unit,
    onMnemonic: (Boolean) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        HelpBox(if (language) "Im Satz" else "Erklärung") {
            val example = card.example
            when {
                !example.isNullOrBlank() -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(example, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    if (language) IconButton(onClick = onSpeakExample) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Satz anhören") }
                }
                exampleLoading -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                else -> {
                    TextButton(onClick = onExample) { Text(if (language) "Beispielsatz erzeugen" else "Erklärung erzeugen") }
                    if (exampleError != null) Text(exampleError, style = MaterialTheme.typography.bodySmall, color = cs.error)
                }
            }
        }
        HelpBox("Eselsbrücke") {
            val saved = card.mnemonic
            when {
                mnemonic is MnemonicState.Loading -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                !saved.isNullOrBlank() -> Column {
                    Text(saved, style = MaterialTheme.typography.bodyLarge)
                    TextButton(onClick = { onMnemonic(true) }) { Text("Andere") }
                }
                else -> {
                    TextButton(onClick = { onMnemonic(false) }) { Text("Eselsbrücke erzeugen") }
                    if (mnemonic is MnemonicState.Error) Text(mnemonic.message, style = MaterialTheme.typography.bodySmall, color = cs.error)
                }
            }
        }
    }
}

@Composable
private fun HelpBox(label: String, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        Modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        color = cs.surfaceContainerHighest,
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            content()
        }
    }
}
