package com.lingosnap.ui.library

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Mastery
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.InfoChip
import com.lingosnap.ui.components.MasteryDots
import com.lingosnap.ui.components.ScreenTitle
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.masteryColors
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource

@Composable
fun LibraryScreen(
    onOpenDeck: (Long) -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val tts = LocalContext.current.container.tts
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(-1) } // -1 = alle

    val all = state.cards
    fun count(m: Mastery) = all.count { Mastery.of(it.level) == m }
    val q = query.trim().lowercase()
    val shown = all.filter { c ->
        (filter < 0 || Mastery.of(c.level).ordinal == filter) &&
            (q.isEmpty() || c.source.lowercase().contains(q) || c.target.lowercase().contains(q))
    }.sortedBy { it.source.lowercase() }

    AppBackground {
        LazyColumn(
            Modifier.statusBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { ScreenTitle("Bibliothek", Modifier.entrance(0), "${all.size} Karten in ${state.decks.size} Decks") }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().entrance(1),
                    singleLine = true,
                    shape = MaterialTheme.shapes.extraLarge,
                    placeholder = { Text("Wörter suchen …") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Leeren") }
                    },
                )
            }
            item {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).entrance(2),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(selected = filter < 0, onClick = { filter = -1 }, label = { Text("Alle ${all.size}") })
                    Mastery.entries.forEach { m ->
                        FilterChip(
                            selected = filter == m.ordinal,
                            onClick = { filter = if (filter == m.ordinal) -1 else m.ordinal },
                            label = { Text("${m.label} ${count(m)}") },
                        )
                    }
                }
            }
            if (shown.isEmpty()) {
                item {
                    Text(
                        if (all.isEmpty()) "Noch keine Karten – erstelle dein erstes Deck." else "Keine Treffer.",
                        Modifier.padding(top = 24.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(shown, key = { it.id }) { card ->
                val cs = MaterialTheme.colorScheme
                val deck = state.deck(card.deckId)
                val src = remember { MutableInteractionSource() }
                val (mc, _) = masteryColors(Mastery.of(card.level))
                Surface(
                    Modifier.fillMaxWidth().animateItem().pressScale(src, 0.98f),
                    shape = MaterialTheme.shapes.large,
                    color = cs.surfaceContainerHigh,
                ) {
                    Row(
                        Modifier
                            .clickable(interactionSource = src, indication = null) { deck?.let { onOpenDeck(it.id) } }
                            .padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp)
                            .animateContentSize(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(card.source, style = MaterialTheme.typography.titleMedium.bold())
                            Text(card.target, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MasteryDots(card.level)
                                if (deck != null) InfoChip(deck.name)
                            }
                        }
                        IconButton(onClick = { tts.speak(card.source, card.sourceLang) }) {
                            Icon(Icons.Rounded.VolumeUp, "Vorlesen", tint = mc)
                        }
                    }
                }
            }
        }
    }
}
