package com.lingosnap.data.model

import com.lingosnap.util.tr

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.Locale
import java.util.concurrent.TimeUnit

@Entity(tableName = "deck_groups")
data class DeckGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "decks")
data class Deck(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val groupId: Long? = null,
    /** BCP-47 tags, e.g. "es", "de" (also used for text-to-speech) */
    val sourceLang: String,
    val targetLang: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** "language" = vocabulary deck, "cards" = plain question/answer flashcards */
    @ColumnInfo(defaultValue = "language") val kind: String = "language",
) {
    val isLanguage: Boolean get() = kind != "cards"

    /** Short grey line used in lists. */
    val typeLabel: String
        get() = if (isLanguage) "${languageName(sourceLang)} → ${languageName(targetLang)}" else tr("Karteikarten")
}

/** Language label for lists: for "auto" decks the languages the AI actually detected in the cards. */
fun Deck.typeLabelFor(cards: List<Flashcard>): String {
    if (!isLanguage || sourceLang != "auto") return typeLabel
    val langs = cards.filter { it.sourceLang.isNotBlank() }.groupingBy { it.sourceLang }.eachCount()
        .entries.sortedByDescending { it.value }.take(2).map { languageName(it.key) }
    return if (langs.isEmpty()) tr("Sprache wird erkannt") else "${langs.joinToString(", ")} → ${languageName(targetLang)}"
}

@Entity(
    tableName = "cards",
    indices = [Index(value = ["deckId", "source", "target"], unique = true)],
)
data class Flashcard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val source: String,
    val target: String,
    val example: String? = null,
    val sourceLang: String,
    val targetLang: String,
    /** 0 = new … 5 = mastered */
    val level: Int = 0,
    val dueAt: Long = 0L,
    val mnemonic: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    /** SM-2 style ease factor: how fast the review interval grows. */
    @ColumnInfo(defaultValue = "2.5") val ease: Double = 2.5,
    /** Current review interval in days (0 = relearning / new). */
    @ColumnInfo(defaultValue = "0") val intervalDays: Int = 0,
    /** Optional picture (plain question/answer cards), path in the app's private storage. */
    val imagePath: String? = null,
    /** How often the card was answered wrong – drives "difficult cards only". */
    @ColumnInfo(defaultValue = "0") val lapses: Int = 0,
    /** FSRS memory state: days until recall drops to 90 %, difficulty 1–10, number of reviews, time of the last one. */
    @ColumnInfo(defaultValue = "0") val stability: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val difficulty: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val reps: Int = 0,
    @ColumnInfo(defaultValue = "0") val lastReviewAt: Long = 0L,
)

/** Learning stage shown on decks and in the library. */
enum class Stage(val label: String) {
    New(tr("Neu")), Beginner(tr("Anfänger")), Practiced(tr("Geübt")), Master(tr("Meister"));

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level <= 2 -> Beginner
            level < Srs.MAX_LEVEL -> Practiced
            else -> Master
        }
    }
}

enum class Mastery(val label: String) {
    New(tr("Neu")), Learning(tr("Lernen")), Mastered(tr("Gemeistert"));

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level >= Srs.MAX_LEVEL -> Mastered
            else -> Learning
        }
    }
}

enum class Rating(val label: String, val delta: Int, val xp: Int) {
    Again(tr("Nochmal"), -1, 1), Hard(tr("Schwer"), 0, 3), Good(tr("Gut"), 1, 5), Easy(tr("Einfach"), 2, 8)
}

/**
 * Repetition steps. By default Nochmal comes back after 1 minute, Schwer after 6 minutes, Gut after 10 minutes and
 * Einfach after 3 days. With "growing intervals" (setting, on by default) cards that are remembered come back less and less
 * often: Gut doubles and Einfach triples the gap, Schwer keeps it, Nochmal starts again with the short steps.
 * [Flashcard.level] (0..5) is only the progress display: Einfach raises it, Nochmal lowers it, and a long gap raises it too.
 * Cards answered before they are due (quizzes, extra practice) keep their schedule in growing mode, so practising never pushes cards away.
 */
object Srs {
    const val MAX_LEVEL = 5

    /** Due date of a paused card: never. */
    const val PAUSED = Long.MAX_VALUE

    /** From this many wrong answers a card counts as stubborn (Anki calls it a leech). Only a hint, nothing happens by itself. */
    const val STUBBORN = 8

    /** Longest gap of the growing intervals. */
    const val MAX_DAYS = 180

    private val MIN = TimeUnit.MINUTES.toMillis(1)

    fun delayMs(r: Rating): Long = when (r) {
        Rating.Again -> MIN
        Rating.Hard -> 6 * MIN
        Rating.Good -> 10 * MIN
        Rating.Easy -> TimeUnit.DAYS.toMillis(3)
    }

    /**
     * Days until the next review in growing mode, 0 = a short step in minutes. A card that is still in the minute steps
     * moves on to one day with its second successful answer; from there Gut doubles and Einfach triples the gap.
     */
    fun growDays(card: Flashcard, rating: Rating): Int {
        val gap = card.intervalDays
        val days = when (rating) {
            Rating.Again -> 0
            Rating.Hard -> if (gap <= 0) 0 else gap
            Rating.Good -> if (gap > 0) gap * 2 else if (card.reps >= 1 && card.level >= 1) 1 else 0
            Rating.Easy -> if (gap > 0) gap * 3 else 3
        }
        return days.coerceIn(0, MAX_DAYS)
    }

    /** Progress level that belongs to a gap: a card that is only asked after three weeks counts as mastered. */
    fun levelForDays(days: Int): Int = when {
        days >= 21 -> MAX_LEVEL
        days >= 8 -> 4
        days >= 4 -> 3
        days >= 1 -> 2
        else -> 0
    }

    /** The moment a new day starts (4:00 local time) – [plusDays] days after the next one. Cards due "tomorrow" are asked from then on. */
    fun nextDayStart(now: Long, plusDays: Int = 0): Long {
        val zone = java.time.ZoneId.systemDefault()
        val at = java.time.Instant.ofEpochMilli(now).atZone(zone)
        var start = at.toLocalDate().atTime(4, 0).atZone(zone)
        if (!start.isAfter(at)) start = start.plusDays(1)
        return start.plusDays(plusDays.toLong()).toInstant().toEpochMilli()
    }

    /** Answered before the card was due (extra practice, quizzes): growing intervals then leave the schedule alone. */
    fun isEarly(card: Flashcard, rating: Rating, now: Long): Boolean = rating != Rating.Again && card.dueAt > now

    /** The card after answering with [rating]; nothing is saved. */
    fun review(card: Flashcard, rating: Rating, now: Long = System.currentTimeMillis(), grow: Boolean = false): Flashcard {
        if (grow && isEarly(card, rating, now)) return card.copy(reps = card.reps + 1, lastReviewAt = now)
        val base = when (rating) {
            Rating.Again -> (card.level - 1).coerceAtLeast(0)
            Rating.Hard, Rating.Good -> maxOf(card.level, 1)
            Rating.Easy -> (maxOf(card.level, 1) + 1).coerceAtMost(MAX_LEVEL)
        }
        val days = if (grow) growDays(card, rating) else if (rating == Rating.Easy) 3 else 0
        val level = if (grow) maxOf(base, levelForDays(days)) else base
        val due = when {
            days <= 0 -> now + delayMs(rating)
            grow -> nextDayStart(now, days - 1)
            else -> now + TimeUnit.DAYS.toMillis(days.toLong())
        }
        return card.copy(
            level = level, dueAt = due, intervalDays = days,
            reps = card.reps + 1, lastReviewAt = now,
            lapses = card.lapses + if (rating == Rating.Again) 1 else 0,
        )
    }

    /** Label under a rating button for the minute steps. */
    fun preview(rating: Rating): String = when (rating) {
        Rating.Again -> tr("1 Min.")
        Rating.Hard -> tr("6 Min.")
        Rating.Good -> tr("10 Min.")
        Rating.Easy -> tr("3 Tage")
    }

    /** Label under a rating button for this very card: when it would come back. */
    fun preview(card: Flashcard, rating: Rating, grow: Boolean, now: Long = System.currentTimeMillis()): String {
        if (grow && isEarly(card, rating, now)) return waitLabel(card.dueAt - now)
        val days = if (grow) growDays(card, rating) else if (rating == Rating.Easy) 3 else 0
        return if (days > 0) daysLabel(days) else preview(rating)
    }

    /** Time that is left until a card is due, for cards answered early. */
    private fun waitLabel(left: Long): String {
        val ms = left.coerceIn(0L, MAX_DAYS * TimeUnit.DAYS.toMillis(1))
        val minutes = (ms + 59_999L) / 60_000L
        return when {
            minutes < 60 -> tr("{0} Min.", minutes.coerceAtLeast(1L))
            minutes < 24 * 60 -> tr("{0} Std.", (minutes + 59) / 60)
            else -> daysLabel(((minutes + 1_439) / 1_440).toInt())
        }
    }

    /** "1 Tag", "5 Tage", "3 Wochen", "4 Monate". */
    fun daysLabel(days: Int): String = when {
        days <= 1 -> tr("1 Tag")
        days < 14 -> tr("{0} Tage", days)
        days < 60 -> tr("{0} Wochen", Math.round(days / 7f))
        else -> tr("{0} Monate", Math.round(days / 30f))
    }
}

/** A paused card is never asked: its due date is "never". */
val Flashcard.paused: Boolean get() = dueAt == Srs.PAUSED

/** Wrong so often that it is worth rewording or pausing. */
val Flashcard.stubborn: Boolean get() = lapses >= Srs.STUBBORN

data class Language(val tag: String) {
    /** Name in the phone's language (German phone: "Spanisch", English phone: "Spanish" …). */
    val label: String get() = com.lingosnap.util.Lang.displayName(tag)
}

val SupportedLanguages = listOf("de", "en", "es", "fr", "it", "pt", "nl", "pl", "tr", "ru", "ja", "zh", "la").map { Language(it) }

fun languageName(tag: String): String =
    if (tag == "auto") tr("Automatisch erkannt") else com.lingosnap.util.Lang.displayName(tag)

/** English name used inside Gemini prompts. */
fun languageNameEn(tag: String): String =
    Locale.forLanguageTag(tag).getDisplayLanguage(Locale.ENGLISH).ifBlank { tag }

enum class StudyScope { Deck, Group, All }

/**
 * Picks the cards of a learning session. from/to are 1-based and inclusive in the order the cards were added;
 * both 0 = all cards, from = -1 = only the difficult ones (answered wrong before), worst first.
 * Paused cards are left out after the range was applied, so the numbers still match the list the person sees.
 */
fun selectCards(cards: List<Flashcard>, from: Int, to: Int): List<Flashcard> = pickRange(cards, from, to).filter { !it.paused }

private fun pickRange(cards: List<Flashcard>, from: Int, to: Int): List<Flashcard> {
    if (from < 0) return cards.filter { it.lapses > 0 }.sortedByDescending { it.lapses }
    if (from == 0 && to <= 0) return cards
    val sorted = cards.sortedBy { it.id }
    val start = (from - 1).coerceAtLeast(0)
    val count = if (to <= 0) Int.MAX_VALUE else (to - maxOf(from, 1) + 1).coerceAtLeast(0)
    return sorted.drop(start).take(count)
}
