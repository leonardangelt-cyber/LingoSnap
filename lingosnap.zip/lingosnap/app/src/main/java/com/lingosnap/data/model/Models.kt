package com.lingosnap.data.model

import com.lingosnap.util.tr

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.Locale
import java.util.concurrent.TimeUnit

@Entity(tableName = "deck_groups")
data class DeckGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "decks")
data class Deck(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val groupId: Long? = null,
    /** BCP-47 tags, e.g. "es", "de" (also used for text-to-speech) */
    val sourceLang: String,
    val targetLang: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** "language" = vocabulary deck, "cards" = plain question/answer flashcards */
    @ColumnInfo(defaultValue = "language") val kind: String = "language",
) {
    val isLanguage: Boolean get() = kind != "cards"

    /** Short grey line used in lists. */
    val typeLabel: String
        get() = if (isLanguage) "${languageName(sourceLang)} → ${languageName(targetLang)}" else tr("Karteikarten")
}

/** Language label for lists: for "auto" decks the languages the AI actually detected in the cards. */
fun Deck.typeLabelFor(cards: List<Flashcard>): String {
    if (!isLanguage || sourceLang != "auto") return typeLabel
    val langs = cards.filter { it.sourceLang.isNotBlank() }.groupingBy { it.sourceLang }.eachCount()
        .entries.sortedByDescending { it.value }.take(2).map { languageName(it.key) }
    return if (langs.isEmpty()) tr("Sprache wird erkannt") else "${langs.joinToString(", ")} → ${languageName(targetLang)}"
}

@Entity(
    tableName = "cards",
    indices = [Index(value = ["deckId", "source", "target"], unique = true)],
)
data class Flashcard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val source: String,
    val target: String,
    val example: String? = null,
    val sourceLang: String,
    val targetLang: String,
    /** 0 = new … 5 = mastered */
    val level: Int = 0,
    val dueAt: Long = 0L,
    val mnemonic: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    /** SM-2 style ease factor: how fast the review interval grows. */
    @ColumnInfo(defaultValue = "2.5") val ease: Double = 2.5,
    /** Current review interval in days (0 = relearning / new). */
    @ColumnInfo(defaultValue = "0") val intervalDays: Int = 0,
    /** Optional picture (plain question/answer cards), path in the app's private storage. */
    val imagePath: String? = null,
    /** How often the card was answered wrong – drives "difficult cards only". */
    @ColumnInfo(defaultValue = "0") val lapses: Int = 0,
    /** FSRS memory state: days until recall drops to 90 %, difficulty 1–10, number of reviews, time of the last one. */
    @ColumnInfo(defaultValue = "0") val stability: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val difficulty: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val reps: Int = 0,
    @ColumnInfo(defaultValue = "0") val lastReviewAt: Long = 0L,
)

/** Learning stage shown on decks and in the library. */
enum class Stage(val label: String) {
    New(tr("Neu")), Beginner(tr("Anfänger")), Practiced(tr("Geübt")), Master(tr("Meister"));

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level <= 2 -> Beginner
            level < Srs.MAX_LEVEL -> Practiced
            else -> Master
        }
    }
}

enum class Mastery(val label: String) {
    New(tr("Neu")), Learning(tr("Lernen")), Mastered(tr("Gemeistert"));

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level >= Srs.MAX_LEVEL -> Mastered
            else -> Learning
        }
    }
}

enum class Rating(val label: String, val delta: Int, val xp: Int) {
    Hard(tr("Schwer"), -1, 2), Good(tr("Gut"), 1, 5), Easy(tr("Leicht"), 2, 8)
}

/**
 * Spaced repetition (SM-2 variant). Every card has an ease factor and an interval.
 * "Nochmal" resets the interval and lowers the ease, "Gut" grows the interval by the ease factor,
 * "Leicht" grows it faster and raises the ease. [level] only drives the progress display.
 */
/**
 * Spaced repetition with the FSRS model (free spaced repetition scheduler, v4.5 forgetting curve) and its default
 * parameters. Every card keeps a stability (how long the memory lasts) and a difficulty; the next interval is the
 * time at which the chance of remembering drops to [RETENTION]. The three buttons map to Again / Good / Easy.
 */
object Srs {
    const val MAX_LEVEL = 5
    const val RETENTION = 0.9
    private const val MAX_INTERVAL = 365
    private const val DECAY = -0.5
    private const val FACTOR = 19.0 / 81.0
    private const val DAY = 86_400_000.0
    private val W = doubleArrayOf(
        0.4872, 1.4003, 3.7145, 13.8206, 5.1618, 1.2298, 0.8975, 0.031, 1.6474,
        0.1367, 1.0461, 2.1072, 0.0793, 0.3246, 1.587, 0.2272, 2.8755,
    )

    private fun grade(r: Rating) = when (r) { Rating.Hard -> 1; Rating.Good -> 3; Rating.Easy -> 4 }
    private fun initialDifficulty(g: Int) = (W[4] - W[5] * (g - 3)).coerceIn(1.0, 10.0)
    private fun recall(elapsedDays: Double, s: Double) = Math.pow(1 + FACTOR * elapsedDays / s, DECAY)
    private fun intervalFor(s: Double) =
        Math.round(s / FACTOR * (Math.pow(RETENTION, 1 / DECAY) - 1)).toInt().coerceIn(1, MAX_INTERVAL)

    private fun levelFor(s: Double) = when {
        s < 1.5 -> 1
        s < 6 -> 2
        s < 20 -> 3
        s < 60 -> 4
        else -> 5
    }

    /** The card after answering with [rating]; nothing is saved. */
    fun review(card: Flashcard, rating: Rating, now: Long = System.currentTimeMillis()): Flashcard {
        val g = grade(rating)
        val first = card.reps <= 0 || card.stability <= 0.0
        val s: Double
        val d: Double
        if (first) {
            s = W[if (g == 1) 0 else g - 1]
            d = initialDifficulty(g)
        } else {
            val last = if (card.lastReviewAt > 0) card.lastReviewAt else now - card.intervalDays * DAY.toLong()
            val elapsed = maxOf(0.0, (now - last) / DAY)
            val r = recall(elapsed, card.stability)
            d = (W[7] * W[4] + (1 - W[7]) * (card.difficulty - W[6] * (g - 3))).coerceIn(1.0, 10.0)
            s = if (g == 1) {
                minOf(card.stability, W[11] * Math.pow(d, -W[12]) * (Math.pow(card.stability + 1, W[13]) - 1) * Math.exp(W[14] * (1 - r)))
            } else {
                val easy = if (g == 4) W[16] else 1.0
                card.stability * (1 + Math.exp(W[8]) * (11 - d) * Math.pow(card.stability, -W[9]) * (Math.exp(W[10] * (1 - r)) - 1) * easy)
            }
        }
        val stability = s.coerceAtLeast(0.1)
        val days = if (g == 1) 0 else intervalFor(stability)
        val derived = levelFor(stability)
        val level = when {
            g == 1 && first -> 0
            g == 1 -> minOf(derived, (card.level - 1).coerceAtLeast(0))
            else -> maxOf(derived, if (first) 1 else 0)
        }.coerceIn(0, MAX_LEVEL)
        val due = if (days == 0) now + TimeUnit.MINUTES.toMillis(10) else now + TimeUnit.DAYS.toMillis(days.toLong())
        return card.copy(
            level = level, dueAt = due, intervalDays = days,
            stability = stability, difficulty = d, reps = card.reps + 1, lastReviewAt = now,
            lapses = card.lapses + if (g == 1) 1 else 0,
        )
    }

    fun nextInterval(card: Flashcard, rating: Rating): Int = review(card, rating).intervalDays

    /** Short label for the rating buttons, e.g. "1 Tag" or "3 Wochen". */
    fun preview(card: Flashcard, rating: Rating): String {
        val d = nextInterval(card, rating)
        return when {
            d == 0 -> tr("10 Min.")
            d == 1 -> tr("1 Tag")
            d < 14 -> tr("{0} Tage", d)
            d < 60 -> tr("{0} Wochen", d / 7)
            else -> tr("{0} Monate", d / 30)
        }
    }
}

data class Language(val tag: String) {
    /** Name in the phone's language (German phone: "Spanisch", English phone: "Spanish" …). */
    val label: String get() = com.lingosnap.util.Lang.displayName(tag)
}

val SupportedLanguages = listOf("de", "en", "es", "fr", "it", "pt", "nl", "pl", "tr", "ru", "ja", "zh", "la").map { Language(it) }

fun languageName(tag: String): String =
    if (tag == "auto") tr("Automatisch erkannt") else com.lingosnap.util.Lang.displayName(tag)

/** English name used inside Gemini prompts. */
fun languageNameEn(tag: String): String =
    Locale.forLanguageTag(tag).getDisplayLanguage(Locale.ENGLISH).ifBlank { tag }

enum class StudyScope { Deck, Group, All }

/**
 * Picks the cards of a learning session. from/to are 1-based and inclusive in the order the cards were added;
 * both 0 = all cards, from = -1 = only the difficult ones (answered wrong before), worst first.
 */
fun selectCards(cards: List<Flashcard>, from: Int, to: Int): List<Flashcard> {
    if (from < 0) return cards.filter { it.lapses > 0 }.sortedByDescending { it.lapses }
    if (from == 0 && to <= 0) return cards
    val sorted = cards.sortedBy { it.id }
    val start = (from - 1).coerceAtLeast(0)
    val count = if (to <= 0) Int.MAX_VALUE else (to - maxOf(from, 1) + 1).coerceAtLeast(0)
    return sorted.drop(start).take(count)
}
