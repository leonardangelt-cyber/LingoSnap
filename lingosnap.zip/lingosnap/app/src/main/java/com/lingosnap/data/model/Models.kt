package com.lingosnap.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.Locale
import java.util.concurrent.TimeUnit

@Entity(tableName = "deck_groups")
data class DeckGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "decks")
data class Deck(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val groupId: Long? = null,
    /** BCP-47 tags, e.g. "es", "de" (also used for text-to-speech) */
    val sourceLang: String,
    val targetLang: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "cards",
    indices = [Index(value = ["deckId", "source", "target"], unique = true)],
)
data class Flashcard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val source: String,
    val target: String,
    val example: String? = null,
    val sourceLang: String,
    val targetLang: String,
    /** 0 = new … 5 = mastered */
    val level: Int = 0,
    val dueAt: Long = 0L,
    val mnemonic: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

/** Learning stage shown on decks and in the library. */
enum class Stage(val label: String) {
    New("Neu"), Beginner("Anfänger"), Practiced("Geübt"), Master("Meister");

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level <= 2 -> Beginner
            level < Srs.MAX_LEVEL -> Practiced
            else -> Master
        }
    }
}

enum class Mastery(val label: String) {
    New("Neu"), Learning("Lernen"), Mastered("Gemeistert");

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level >= Srs.MAX_LEVEL -> Mastered
            else -> Learning
        }
    }
}

enum class Rating(val label: String, val delta: Int, val xp: Int) {
    Hard("Schwer", -1, 2), Good("Gut", 1, 5), Easy("Leicht", 2, 8)
}

/** Tiny Leitner-style spaced repetition: 5 levels, growing intervals. */
object Srs {
    const val MAX_LEVEL = 5
    private val intervalDays = longArrayOf(0, 1, 3, 7, 14, 30)

    fun review(card: Flashcard, rating: Rating, now: Long = System.currentTimeMillis()): Flashcard {
        val level = (card.level + rating.delta).coerceIn(0, MAX_LEVEL)
        val due = if (rating == Rating.Hard) now + TimeUnit.MINUTES.toMillis(10)
        else now + TimeUnit.DAYS.toMillis(intervalDays[level])
        return card.copy(level = level, dueAt = due)
    }
}

data class Language(val tag: String, val label: String)

val SupportedLanguages = listOf(
    Language("de", "Deutsch"), Language("en", "Englisch"), Language("es", "Spanisch"),
    Language("fr", "Französisch"), Language("it", "Italienisch"), Language("pt", "Portugiesisch"),
    Language("nl", "Niederländisch"), Language("pl", "Polnisch"), Language("tr", "Türkisch"),
    Language("ru", "Russisch"), Language("ja", "Japanisch"), Language("zh", "Chinesisch"),
    Language("la", "Latein"),
)

fun languageName(tag: String): String =
    SupportedLanguages.firstOrNull { it.tag == tag }?.label
        ?: Locale.forLanguageTag(tag).getDisplayLanguage(Locale.GERMAN)

/** English name used inside Gemini prompts. */
fun languageNameEn(tag: String): String =
    Locale.forLanguageTag(tag).getDisplayLanguage(Locale.ENGLISH).ifBlank { tag }

enum class StudyScope { Deck, Group, All }
