package com.lingosnap.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.Locale
import java.util.concurrent.TimeUnit

@Entity(tableName = "deck_groups")
data class DeckGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "decks")
data class Deck(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val groupId: Long? = null,
    /** BCP-47 tags, e.g. "es", "de" (also used for text-to-speech) */
    val sourceLang: String,
    val targetLang: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** "language" = vocabulary deck, "cards" = plain question/answer flashcards */
    @ColumnInfo(defaultValue = "language") val kind: String = "language",
) {
    val isLanguage: Boolean get() = kind != "cards"

    /** Short grey line used in lists. */
    val typeLabel: String
        get() = if (isLanguage) "${languageName(sourceLang)} → ${languageName(targetLang)}" else "Karteikarten"
}

/** Language label for lists: for "auto" decks the languages the AI actually detected in the cards. */
fun Deck.typeLabelFor(cards: List<Flashcard>): String {
    if (!isLanguage || sourceLang != "auto") return typeLabel
    val langs = cards.filter { it.sourceLang.isNotBlank() }.groupingBy { it.sourceLang }.eachCount()
        .entries.sortedByDescending { it.value }.take(2).map { languageName(it.key) }
    return if (langs.isEmpty()) "Sprache wird erkannt" else "${langs.joinToString(", ")} → ${languageName(targetLang)}"
}

@Entity(
    tableName = "cards",
    indices = [Index(value = ["deckId", "source", "target"], unique = true)],
)
data class Flashcard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val source: String,
    val target: String,
    val example: String? = null,
    val sourceLang: String,
    val targetLang: String,
    /** 0 = new … 5 = mastered */
    val level: Int = 0,
    val dueAt: Long = 0L,
    val mnemonic: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    /** SM-2 style ease factor: how fast the review interval grows. */
    @ColumnInfo(defaultValue = "2.5") val ease: Double = 2.5,
    /** Current review interval in days (0 = relearning / new). */
    @ColumnInfo(defaultValue = "0") val intervalDays: Int = 0,
)

/** Learning stage shown on decks and in the library. */
enum class Stage(val label: String) {
    New("Neu"), Beginner("Anfänger"), Practiced("Geübt"), Master("Meister");

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level <= 2 -> Beginner
            level < Srs.MAX_LEVEL -> Practiced
            else -> Master
        }
    }
}

enum class Mastery(val label: String) {
    New("Neu"), Learning("Lernen"), Mastered("Gemeistert");

    companion object {
        fun of(level: Int) = when {
            level <= 0 -> New
            level >= Srs.MAX_LEVEL -> Mastered
            else -> Learning
        }
    }
}

enum class Rating(val label: String, val delta: Int, val xp: Int) {
    Hard("Schwer", -1, 2), Good("Gut", 1, 5), Easy("Leicht", 2, 8)
}

/**
 * Spaced repetition (SM-2 variant). Every card has an ease factor and an interval.
 * "Nochmal" resets the interval and lowers the ease, "Gut" grows the interval by the ease factor,
 * "Leicht" grows it faster and raises the ease. [level] only drives the progress display.
 */
object Srs {
    const val MAX_LEVEL = 5
    private const val MAX_INTERVAL = 365

    fun nextInterval(card: Flashcard, rating: Rating): Int = when (rating) {
        Rating.Hard -> 0
        Rating.Good -> if (card.intervalDays <= 0) 1
        else maxOf(card.intervalDays + 1, Math.round(card.intervalDays * card.ease).toInt())
        Rating.Easy -> if (card.intervalDays <= 0) 3
        else maxOf(card.intervalDays + 2, Math.round(card.intervalDays * card.ease * 1.3).toInt())
    }.coerceAtMost(MAX_INTERVAL)

    fun review(card: Flashcard, rating: Rating, now: Long = System.currentTimeMillis()): Flashcard {
        val level = (card.level + rating.delta).coerceIn(0, MAX_LEVEL)
        val days = nextInterval(card, rating)
        val ease = when (rating) {
            Rating.Hard -> card.ease - 0.2
            Rating.Good -> card.ease
            Rating.Easy -> card.ease + 0.1
        }.coerceIn(1.3, 3.0)
        val due = if (days == 0) now + TimeUnit.MINUTES.toMillis(10) else now + TimeUnit.DAYS.toMillis(days.toLong())
        return card.copy(level = level, dueAt = due, ease = ease, intervalDays = days)
    }

    /** Short label for the rating buttons, e.g. "1 Tag" or "3 Wochen". */
    fun preview(card: Flashcard, rating: Rating): String {
        val d = nextInterval(card, rating)
        return when {
            d == 0 -> "10 Min."
            d == 1 -> "1 Tag"
            d < 14 -> "$d Tage"
            d < 60 -> "${d / 7} Wochen"
            else -> "${d / 30} Monate"
        }
    }
}

data class Language(val tag: String, val label: String)

val SupportedLanguages = listOf(
    Language("de", "Deutsch"), Language("en", "Englisch"), Language("es", "Spanisch"),
    Language("fr", "Französisch"), Language("it", "Italienisch"), Language("pt", "Portugiesisch"),
    Language("nl", "Niederländisch"), Language("pl", "Polnisch"), Language("tr", "Türkisch"),
    Language("ru", "Russisch"), Language("ja", "Japanisch"), Language("zh", "Chinesisch"),
    Language("la", "Latein"),
)

fun languageName(tag: String): String =
    if (tag == "auto") "Automatisch erkannt" else SupportedLanguages.firstOrNull { it.tag == tag }?.label
        ?: Locale.forLanguageTag(tag).getDisplayLanguage(Locale.GERMAN)

/** English name used inside Gemini prompts. */
fun languageNameEn(tag: String): String =
    Locale.forLanguageTag(tag).getDisplayLanguage(Locale.ENGLISH).ifBlank { tag }

enum class StudyScope { Deck, Group, All }
