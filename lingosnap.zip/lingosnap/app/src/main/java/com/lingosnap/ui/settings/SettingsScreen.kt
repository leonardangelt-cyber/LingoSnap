package com.lingosnap.ui.settings

import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.ScreenTitle
import com.lingosnap.ui.components.SectionLabel
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.theme.AccentHues
import com.lingosnap.ui.theme.AccentNames
import com.lingosnap.ui.theme.accentScheme
import com.lingosnap.ui.theme.bold

@Composable
fun SettingsScreen(
    onChangeKey: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(stats.userName) }
    var confirmReset by remember { mutableStateOf(false) }
    val hasKey = context.container.keyStore.hasKey

    LaunchedEffect(name) { if (name.isNotBlank() && name != stats.userName) vm.setUserName(name.trim()) }

    AppBackground {
        LazyColumn(
            Modifier.statusBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item { ScreenTitle("Optionen", Modifier.entrance(0), "Mach LingoSnap zu deiner App") }

            item {
                Card("Profil", Modifier.entrance(1)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(24) },
                        label = { Text("Dein Name") },
                        singleLine = true,
                        shape = MaterialTheme.shapes.large,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            item {
                Card("Design", Modifier.entrance(2)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("System", "Dunkel", "Hell").forEachIndexed { i, label ->
                            FilterChip(selected = stats.darkMode == i, onClick = { vm.setDarkMode(i) }, label = { Text(label) })
                        }
                    }
                    Text("Akzentfarbe", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AccentHues.indices.forEach { i ->
                            val selected = stats.accent == i
                            val color = if (i == 0) cs.primary else accentScheme(AccentHues[i], false).primary
                            val scale by animateFloatAsState(
                                if (selected) 1.15f else 1f,
                                spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                                label = "swatch",
                            )
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .graphicsLayer { scaleX = scale; scaleY = scale }
                                    .background(color, CircleShape)
                                    .clickable { vm.setAccent(i) },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (selected) Icon(Icons.Rounded.Check, null, tint = Color.White)
                            }
                        }
                    }
                    Text(
                        AccentNames.getOrElse(stats.accent) { "" } +
                            if (stats.accent == 0) " – Farben deines Hintergrundbilds" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
            }

            item {
                Card("Lernen", Modifier.entrance(3)) {
                    Text("Tagesziel (Karten pro Tag)", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 20, 30, 50).forEach { g ->
                            FilterChip(selected = stats.dailyGoal == g, onClick = { vm.setDailyGoal(g) }, label = { Text("$g") })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Serien-Schutz", style = MaterialTheme.typography.titleMedium.bold())
                            Text("Ein verpasster Tag bricht deine Serie nicht.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                        }
                        Switch(checked = stats.streakFreeze, onCheckedChange = { vm.setStreakFreeze(it) })
                    }
                }
            }

            item {
                Card("KI-Anbindung", Modifier.entrance(4)) {
                    Text(
                        if (hasKey) "Gemini API-Schlüssel ist gespeichert (verschlüsselt auf dem Gerät)."
                        else "Noch kein API-Schlüssel hinterlegt.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                    FilledTonalButton(onClick = onChangeKey) { Text(if (hasKey) "Schlüssel ändern" else "Schlüssel eingeben") }
                }
            }

            item {
                Card("Daten", Modifier.entrance(5)) {
                    Text(
                        "${state.cards.size} Karten • ${state.decks.size} Decks • ${state.groups.size} Gruppen",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                    FilledTonalButton(
                        enabled = state.cards.isNotEmpty(),
                        onClick = {
                            val text = buildString {
                                state.decks.forEach { d ->
                                    appendLine("# ${d.name} (${languageName(d.sourceLang)} → ${languageName(d.targetLang)})")
                                    state.cardsOf(d.id).forEach { appendLine("${it.source};${it.target}" + (it.example?.let { e -> ";$e" } ?: "")) }
                                    appendLine()
                                }
                            }
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            context.startActivity(Intent.createChooser(send, "Vokabeln exportieren"))
                        },
                    ) { Text("Alle Vokabeln exportieren") }
                    OutlinedButton(
                        onClick = { confirmReset = true },
                        border = BorderStroke(1.dp, cs.error),
                    ) { Text("Alle Daten löschen", color = cs.error) }
                }
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "Alles löschen?",
            text = "Alle Decks, Karten, Gruppen, XP und Serien werden unwiderruflich gelöscht.",
            confirmLabel = "Alles löschen",
            onConfirm = { vm.clearEverything() },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
private fun Card(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionLabel(title)
            content()
        }
    }
}
