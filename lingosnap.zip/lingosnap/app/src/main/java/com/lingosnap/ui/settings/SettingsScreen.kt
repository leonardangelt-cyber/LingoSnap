package com.lingosnap.ui.settings

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.components.segmentShape
import androidx.compose.material3.Surface
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onChangeKey: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val gemini = context.container.gemini
    val provider by gemini.provider.collectAsStateWithLifecycle()
    val active by gemini.activeModel.collectAsStateWithLifecycle()
    val models by gemini.models.collectAsStateWithLifecycle()
    val hasKey = context.container.keyStore.hasKey

    var confirmReset by remember { mutableStateOf(false) }
    var pickModel by remember { mutableStateOf(false) }

    LargeScreen(title = "Optionen", onBack = onBack) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item { GroupHeader("Darstellung") }
            item {
                Surface(Modifier.fillMaxWidth(), shape = segmentShape(0, 1), color = cs.surfaceContainer) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Farbschema", style = MaterialTheme.typography.bodyLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("System", "Hell", "Dunkel").forEachIndexed { i, label ->
                                // internal values: 0 = system, 2 = light, 1 = dark
                                val mode = when (i) { 0 -> 0; 1 -> 2; else -> 1 }
                                FilterChip(selected = stats.darkMode == mode, onClick = { vm.setDarkMode(mode) }, label = { Text(label) })
                            }
                        }
                    }
                }
            }

            item { GroupHeader("KI") }
            item {
                SegmentedItem(
                    index = 0,
                    count = if (hasKey) 2 else 1,
                    headline = "API-Schlüssel",
                    supporting = if (hasKey) (provider?.label ?: "Gespeichert") else "Nicht hinterlegt",
                    onClick = onChangeKey,
                )
            }
            if (hasKey) {
                item {
                    SegmentedItem(
                        index = 1,
                        count = 2,
                        headline = "Modell",
                        supporting = if (context.container.keyStore.chosenModel == null) "Automatisch: ${active ?: "–"}" else (active ?: "–"),
                        onClick = { pickModel = true },
                    )
                }
            }

            item { GroupHeader("Daten") }
            item {
                SegmentedItem(
                    index = 0,
                    count = 2,
                    headline = "Vokabeln exportieren",
                    supporting = "${state.cards.size} Karten in ${state.decks.size} Decks",
                    enabled = state.cards.isNotEmpty(),
                    onClick = {
                        val text = buildString {
                            state.decks.forEach { d ->
                                appendLine("# ${d.name} (${d.typeLabel})")
                                state.cardsOf(d.id).forEach { appendLine("${it.source};${it.target}") }
                                appendLine()
                            }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, "Vokabeln exportieren"))
                    },
                )
            }
            item {
                SegmentedItem(
                    index = 1,
                    count = 2,
                    headline = "Alle Daten löschen",
                    headlineColor = cs.error,
                    onClick = { confirmReset = true },
                )
            }
        }
    }

    if (pickModel) ModelDialog(onDismiss = { pickModel = false }, models = models, active = active)

    if (confirmReset) {
        ConfirmDialog(
            title = "Alles löschen?",
            text = "Alle Decks, Karten, XP und Serien werden unwiderruflich gelöscht.",
            confirmLabel = "Alles löschen",
            onConfirm = { vm.clearEverything() },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
private fun ModelDialog(onDismiss: () -> Unit, models: List<String>, active: String?) {
    val context = LocalContext.current
    val gemini = context.container.gemini
    val keys = context.container.keyStore
    val scope = rememberCoroutineScope()
    var chosen by remember { mutableStateOf(keys.chosenModel) }
    var refreshing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modell wählen") },
        text = {
            Column {
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    item {
                        ModelRow("Automatisch (empfohlen)", chosen == null) { chosen = null; gemini.chooseModel(null) }
                    }
                    items(models.take(15)) { m ->
                        ModelRow(m, chosen == m) { chosen = m; gemini.chooseModel(m) }
                    }
                }
                message?.let { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fertig") } },
        dismissButton = {
            TextButton(
                enabled = !refreshing,
                onClick = {
                    refreshing = true
                    scope.launch {
                        gemini.refreshModels()
                            .onSuccess { message = "${it.models.size} Modelle gefunden" }
                            .onFailure { message = it.message }
                        refreshing = false
                    }
                },
            ) { Text(if (refreshing) "Suche …" else "Aktualisieren") }
        },
    )
}

@Composable
private fun ModelRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}
