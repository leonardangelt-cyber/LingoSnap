package com.lingosnap.ui.settings

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.material3.Switch
import androidx.compose.material3.Icon
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.Icons
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.OptionSheet
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.components.segmentShape
import androidx.compose.material3.Surface
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenAi: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val gemini = context.container.gemini
    val provider by gemini.provider.collectAsStateWithLifecycle()
    val hasKey = context.container.keyStore.hasKey

    val feedback = context.container.feedback
    var haptics by remember { mutableStateOf(feedback.haptics) }
    var sounds by remember { mutableStateOf(feedback.sounds) }
    var confirmReset by remember { mutableStateOf(false) }

    LargeScreen(title = "Optionen", onBack = onBack) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item { GroupHeader("Darstellung") }
            item {
                Surface(Modifier.fillMaxWidth(), shape = segmentShape(0, 1), color = cs.surfaceContainer) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Farbschema", style = MaterialTheme.typography.bodyLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("System", "Hell", "Dunkel").forEachIndexed { i, label ->
                                // internal values: 0 = system, 2 = light, 1 = dark
                                val mode = when (i) { 0 -> 0; 1 -> 2; else -> 1 }
                                FilterChip(selected = stats.darkMode == mode, onClick = { vm.setDarkMode(mode) }, label = { Text(label) })
                            }
                        }
                    }
                }
            }

            item { GroupHeader("Rückmeldung") }
            item {
                SegmentedItem(
                    index = 0, count = 2, headline = "Haptik",
                    supporting = "Ganz leichtes Vibrieren beim Lernen",
                    trailing = { Switch(checked = haptics, onCheckedChange = { haptics = it; feedback.haptics = it; if (it) feedback.tap() }) },
                    onClick = { haptics = !haptics; feedback.haptics = haptics; if (haptics) feedback.tap() },
                )
            }
            item {
                SegmentedItem(
                    index = 1, count = 2, headline = "Töne",
                    supporting = "Kurzer Klang bei richtig und falsch",
                    trailing = { Switch(checked = sounds, onCheckedChange = { sounds = it; feedback.sounds = it; if (it) feedback.correct() }) },
                    onClick = { sounds = !sounds; feedback.sounds = sounds; if (sounds) feedback.correct() },
                )
            }

            item { GroupHeader("KI") }
            item {
                SegmentedItem(
                    index = 0,
                    count = 1,
                    headline = "KI",
                    supporting = if (hasKey) "${provider?.label ?: "Schlüssel"} • Details und Status" else "Nicht eingerichtet",
                    onClick = onOpenAi,
                    leading = { Icon(Icons.Rounded.AutoAwesome, null, tint = cs.primary) },
                    trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
                )
            }

            item { GroupHeader("Daten") }
            item {
                SegmentedItem(
                    index = 0,
                    count = 2,
                    headline = "Vokabeln exportieren",
                    supporting = "${state.cards.size} Karten in ${state.decks.size} Decks",
                    enabled = state.cards.isNotEmpty(),
                    onClick = {
                        val text = buildString {
                            state.decks.forEach { d ->
                                appendLine("# ${d.name} (${d.typeLabel})")
                                state.cardsOf(d.id).forEach { appendLine("${it.source};${it.target}") }
                                appendLine()
                            }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, "Vokabeln exportieren"))
                    },
                )
            }
            item {
                SegmentedItem(
                    index = 1,
                    count = 2,
                    headline = "Alle Daten löschen",
                    headlineColor = cs.error,
                    onClick = { confirmReset = true },
                )
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "Alles löschen?",
            text = "Alle Decks, Karten, XP und Serien werden unwiderruflich gelöscht.",
            confirmLabel = "Alles löschen",
            onConfirm = { vm.clearEverything() },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
internal fun ModelDialog(onDismiss: () -> Unit, models: List<String>, active: String?) {
    val context = LocalContext.current
    val gemini = context.container.gemini
    val keys = context.container.keyStore
    val scope = rememberCoroutineScope()
    var chosen by remember { mutableStateOf(keys.chosenModel) }
    var refreshing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    OptionSheet(
        title = "Modell wählen",
        options = listOf("" to "Automatisch (empfohlen)") + models.take(15).map { it to it },
        selected = chosen ?: "",
        onPick = { key ->
            val model = key.ifEmpty { null }
            chosen = model
            gemini.chooseModel(model)
        },
        onDismiss = onDismiss,
        footer = {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(message.orEmpty(), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(
                    enabled = !refreshing,
                    onClick = {
                        refreshing = true
                        scope.launch {
                            gemini.refreshModels()
                                .onSuccess { gemini.apply(it); message = "${it.models.size} Modelle gefunden" }
                                .onFailure { message = it.message }
                            refreshing = false
                        }
                    },
                ) { Text(if (refreshing) "Suche …" else "Aktualisieren") }
            }
        },
    )
}
