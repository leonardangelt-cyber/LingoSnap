package com.lingosnap.ui.settings

import com.lingosnap.util.tr
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Person

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.material3.Switch
import androidx.compose.material3.Icon
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.Icons
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.languageName
import com.lingosnap.data.model.typeLabelFor
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.OptionSheet
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.components.segmentShape
import androidx.compose.material3.Surface
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenAi: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val stats = state.stats
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val gemini = context.container.gemini
    val provider by gemini.provider.collectAsStateWithLifecycle()
    val hasKey = context.container.keyStore.hasKey

    val feedback = context.container.feedback
    var haptics by remember { mutableStateOf(feedback.haptics) }
    var sounds by remember { mutableStateOf(feedback.sounds) }
    var confirmReset by remember { mutableStateOf(false) }
    val autoBackup = context.container.autoBackup
    var backupFolder by remember { mutableStateOf(autoBackup.folder) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val folderPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            autoBackup.setFolder(uri)
            backupFolder = autoBackup.folder
            scope.launch {
                val ok = autoBackup.run(force = true)
                android.widget.Toast.makeText(context, if (ok) tr("Backup geschrieben") else tr("Ordner gespeichert"), android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    val lead: (androidx.compose.ui.graphics.vector.ImageVector) -> (@Composable () -> Unit) = { ic ->
        { com.lingosnap.ui.components.IconBadge(ic, 40, cs.secondaryContainer, cs.onSecondaryContainer) }
    }
    var langSheet by remember { mutableStateOf(false) }
    var nameSheet by remember { mutableStateOf(false) }
    var methodSheet by remember { mutableStateOf(false) }
    var learnMode by remember { mutableStateOf(feedback.learnMode) }
    val notifPermission = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { vm.setReminders(true); com.lingosnap.util.Reminders.apply(context) }
        else android.widget.Toast.makeText(context, tr("Ohne Erlaubnis kann die App keine Erinnerung senden."), android.widget.Toast.LENGTH_LONG).show()
    }
    fun setReminders(on: Boolean) {
        if (on && android.os.Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) { notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS); return }
        vm.setReminders(on); com.lingosnap.util.Reminders.apply(context)
    }
    val timeLabel = "%02d:%02d".format(stats.reminderHour, stats.reminderMinute)

    LargeScreen(title = tr("Optionen"), onBack = onBack) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item { GroupHeader(tr("Profil und Sprache")) }
            item {
                SegmentedItem(
                    index = 0, count = 2, headline = tr("Dein Name"),
                    supporting = stats.userName.ifBlank { tr("Nicht festgelegt") },
                    leading = lead(Icons.Rounded.Person), onClick = { nameSheet = true },
                    trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
                )
            }
            item {
                SegmentedItem(
                    index = 1, count = 2, headline = tr("Muttersprache und App-Sprache"),
                    supporting = com.lingosnap.util.Lang.override?.let { t -> com.lingosnap.util.Lang.appLanguages.first { it.first == t }.second } ?: tr("Wie das Handy"),
                    leading = lead(Icons.Rounded.Language), onClick = { langSheet = true },
                    trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
                )
            }

            item { GroupHeader(tr("Darstellung")) }
            item {
                Surface(Modifier.fillMaxWidth(), shape = segmentShape(0, 1), color = cs.surfaceContainer) {
                    Row(Modifier.padding(16.dp), verticalAlignment = androidx.compose.ui.Alignment.Top) {
                        com.lingosnap.ui.components.IconBadge(Icons.Rounded.Palette, 40, cs.secondaryContainer, cs.onSecondaryContainer)
                        Column(Modifier.padding(start = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(tr("Farbschema"), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(tr("System"), tr("Hell"), tr("Dunkel")).forEachIndexed { i, label ->
                                    // internal values: 0 = system, 2 = light, 1 = dark
                                    val mode = when (i) { 0 -> 0; 1 -> 2; else -> 1 }
                                    com.lingosnap.ui.components.AppChip(stats.darkMode == mode, { vm.setDarkMode(mode) }, label)
                                }
                            }
                        }
                    }
                }
            }

            item { GroupHeader(tr("Lernen")) }
            item {
                SegmentedItem(
                    index = 0, count = 3, headline = tr("Lernmethode"),
                    supporting = tr("Gilt für den Modus „Karteikarten“."),
                    leading = lead(Icons.Rounded.School), onClick = { methodSheet = true },
                    trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
                )
            }
            item {
                Surface(Modifier.fillMaxWidth(), shape = segmentShape(1, 3), color = cs.surfaceContainer) {
                    Row(Modifier.padding(16.dp), verticalAlignment = androidx.compose.ui.Alignment.Top) {
                        com.lingosnap.ui.components.IconBadge(Icons.Rounded.Flag, 40, cs.secondaryContainer, cs.onSecondaryContainer)
                        Column(Modifier.padding(start = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Column(Modifier.padding(top = 2.dp)) {
                                Text(tr("Tagesziel"), style = MaterialTheme.typography.bodyLarge)
                                Text(tr("Heute: {0} von {1} Karten", stats.todayCount, stats.dailyGoal), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                            }
                            Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(5, 10, 20, 30, 50).forEach { g ->
                                    com.lingosnap.ui.components.AppChip(stats.dailyGoal == g, { vm.setDailyGoalValue(g) }, g.toString())
                                }
                            }
                        }
                    }
                }
            }
            item {
                SegmentedItem(
                    index = 2, count = 3, headline = tr("Serien-Schutz"),
                    supporting = tr("Ein verpasster Tag unterbricht deine Serie nicht sofort"),
                    leading = lead(Icons.Rounded.LocalFireDepartment),
                    trailing = { Switch(checked = stats.streakFreeze, onCheckedChange = { vm.setStreakFreezeOn(it) }) },
                    onClick = { vm.setStreakFreezeOn(!stats.streakFreeze) },
                )
            }

            item { GroupHeader(tr("Erinnerungen")) }
            item {
                SegmentedItem(
                    index = 0, count = if (stats.remindersOn) 3 else 1, headline = tr("Tägliche Erinnerung"),
                    supporting = tr("Eine Benachrichtigung, wenn es Zeit zum Lernen ist"),
                    leading = lead(Icons.Rounded.Notifications),
                    trailing = { Switch(checked = stats.remindersOn, onCheckedChange = { setReminders(it) }) },
                    onClick = { setReminders(!stats.remindersOn) },
                )
            }
            if (stats.remindersOn) {
                item {
                    SegmentedItem(
                        index = 1, count = 3, headline = tr("Uhrzeit"), supporting = timeLabel,
                        leading = lead(Icons.Rounded.Schedule),
                        onClick = {
                            android.app.TimePickerDialog(context, { _, h, m -> vm.setReminderTime(h, m); com.lingosnap.util.Reminders.apply(context) }, stats.reminderHour, stats.reminderMinute, true).show()
                        },
                        trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
                    )
                }
                item {
                    SegmentedItem(
                        index = 2, count = 3, headline = tr("Nur bei fälligen Karten"),
                        supporting = tr("Keine Erinnerung, wenn nichts zu wiederholen ist"),
                        leading = lead(Icons.Rounded.NotificationsActive),
                        trailing = { Switch(checked = stats.remindOnlyDue, onCheckedChange = { vm.setRemindOnlyDue(it) }) },
                        onClick = { vm.setRemindOnlyDue(!stats.remindOnlyDue) },
                    )
                }
            }

            item { GroupHeader(tr("Rückmeldung")) }
            item {
                SegmentedItem(
                    index = 0, count = 2, headline = tr("Haptik"),
                    leading = lead(Icons.Rounded.Vibration),
                    supporting = tr("Ganz leichtes Vibrieren beim Lernen"),
                    trailing = { Switch(checked = haptics, onCheckedChange = { haptics = it; feedback.haptics = it; if (it) feedback.tap() }) },
                    onClick = { haptics = !haptics; feedback.haptics = haptics; if (haptics) feedback.tap() },
                )
            }
            item {
                SegmentedItem(
                    index = 1, count = 2, headline = tr("Töne"),
                    leading = lead(Icons.Rounded.VolumeUp),
                    supporting = tr("Kurzer Klang bei richtig und falsch"),
                    trailing = { Switch(checked = sounds, onCheckedChange = { sounds = it; feedback.sounds = it; if (it) feedback.correct() }) },
                    onClick = { sounds = !sounds; feedback.sounds = sounds; if (sounds) feedback.correct() },
                )
            }

            item { GroupHeader("KI") }
            item {
                SegmentedItem(
                    index = 0,
                    count = 1,
                    headline = "KI",
                    leading = lead(Icons.Rounded.AutoAwesome),
                    supporting = if (hasKey) tr("{0} • Details und Status", provider?.label ?: tr("Schlüssel")) else tr("Nicht eingerichtet"),
                    onClick = onOpenAi,
                    trailing = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
                )
            }

            item { GroupHeader(tr("Daten")) }
            item {
                SegmentedItem(
                    index = 0,
                    count = 5,
                    headline = tr("Backup sichern (Datei)"),
                    leading = lead(Icons.Rounded.CloudUpload),
                    supporting = tr("Alle Decks mit Lernstand. Zum Wiederherstellen über das Import-Symbol laden."),
                    enabled = state.decks.isNotEmpty(),
                    onClick = { shareBackup(context, state.decks, state.cards, "lingosnap-backup") },
                )
            }
            item {
                SegmentedItem(
                    index = 1,
                    count = 5,
                    headline = tr("Vokabeln als Text exportieren"),
                    leading = lead(Icons.Rounded.IosShare),
                    supporting = tr("{0} Karten in {1} Decks", state.cards.size, state.decks.size),
                    enabled = state.cards.isNotEmpty(),
                    onClick = {
                        val text = buildString {
                            state.decks.forEach { d ->
                                appendLine("# ${d.name} (${d.typeLabelFor(state.cardsOf(d.id))})")
                                state.cardsOf(d.id).forEach { appendLine("${it.source};${it.target}") }
                                appendLine()
                            }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, tr("Vokabeln exportieren")))
                    },
                )
            }
            item {
                SegmentedItem(
                    index = 2,
                    count = 5,
                    headline = tr("Automatisches Backup"),
                    leading = lead(Icons.Rounded.Sync),
                    supporting = if (backupFolder == null) tr("Aus. Wähle einen Ordner, z. B. in Google Drive – die App sichert dort höchstens einmal am Tag.")
                    else tr("An") + (autoBackup.lastRun.takeIf { it > 0 }?.let { tr(" · zuletzt ") + java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(it)) } ?: ""),
                    onClick = { folderPicker.launch(null) },
                    trailing = if (backupFolder != null) { {
                        androidx.compose.material3.TextButton(onClick = { autoBackup.setFolder(null); backupFolder = null }) { Text(tr("Aus")) }
                    } } else null,
                )
            }
            item {
                SegmentedItem(
                    index = 3,
                    count = 5,
                    headline = tr("Fehlerbericht kopieren"),
                    leading = lead(Icons.Rounded.BugReport),
                    supporting = tr("Letzter Absturz und Gerätedaten – zum Einfügen in eine Nachricht"),
                    onClick = {
                        val cm = context.getSystemService(android.content.ClipboardManager::class.java)
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("LingoSnap", com.lingosnap.util.CrashLog.report(context)))
                        android.widget.Toast.makeText(context, tr("Kopiert"), android.widget.Toast.LENGTH_SHORT).show()
                    },
                )
            }
            item {
                SegmentedItem(
                    index = 4,
                    count = 5,
                    headline = tr("Alle Daten löschen"),
                    leading = lead(Icons.Rounded.DeleteForever),
                    headlineColor = cs.error,
                    onClick = { confirmReset = true },
                )
            }
        }
    }

    if (langSheet) {
        OptionSheet(
            title = tr("Muttersprache und App-Sprache"),
            options = listOf("" to tr("Wie das Handy")) + com.lingosnap.util.Lang.appLanguages,
            selected = com.lingosnap.util.Lang.override ?: "",
            onPick = { pick ->
                langSheet = false
                if ((pick.ifEmpty { null }) != com.lingosnap.util.Lang.override) {
                    com.lingosnap.util.Lang.override = pick.ifEmpty { null }
                    var c: android.content.Context = context
                    while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
                    (c as? android.app.Activity)?.recreate()
                }
            },
            onDismiss = { langSheet = false },
        )
    }
    if (nameSheet) {
        var n by remember { mutableStateOf(stats.userName) }
        com.lingosnap.ui.components.FormSheet(
            title = tr("Dein Name"), icon = Icons.Rounded.Person, onDismiss = { nameSheet = false },
            confirmLabel = tr("Speichern"), onConfirm = { vm.setUserName(n.trim()); nameSheet = false },
        ) {
            com.lingosnap.ui.components.AppTextField(n, { n = it }, Modifier.fillMaxWidth(), label = { Text(tr("Name")) }, singleLine = true)
        }
    }
    if (methodSheet) {
        com.lingosnap.ui.components.LearnMethodSheet(
            current = learnMode,
            onPick = { learnMode = it; feedback.learnMode = it; methodSheet = false },
            onDismiss = { methodSheet = false },
        )
    }
    if (confirmReset) {
        ConfirmDialog(
            title = tr("Alles löschen?"),
            text = tr("Alle Decks, Karten, XP und Serien werden unwiderruflich gelöscht."),
            confirmLabel = tr("Alles löschen"),
            onConfirm = { vm.clearEverything() },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
internal fun ModelDialog(onDismiss: () -> Unit, models: List<String>, active: String?) {
    val context = LocalContext.current
    val gemini = context.container.gemini
    val keys = context.container.keyStore
    val scope = rememberCoroutineScope()
    var chosen by remember { mutableStateOf(keys.chosenModel) }
    var refreshing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    OptionSheet(
        title = tr("Modell wählen"),
        options = listOf("" to tr("Automatisch (empfohlen)")) + models.take(15).map { it to it },
        selected = chosen ?: "",
        onPick = { key ->
            val model = key.ifEmpty { null }
            chosen = model
            gemini.chooseModel(model)
        },
        onDismiss = onDismiss,
        footer = {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(message.orEmpty(), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(
                    enabled = !refreshing,
                    onClick = {
                        refreshing = true
                        scope.launch {
                            gemini.refreshModels()
                                .onSuccess { gemini.apply(it); message = tr("{0} Modelle gefunden", it.models.size) }
                                .onFailure { message = it.message }
                            refreshing = false
                        }
                    },
                ) { Text(if (refreshing) tr("Suche …") else tr("Aktualisieren")) }
            }
        },
    )
}

/** Shares decks as one JSON file (lossless, can be imported again). */
fun shareBackup(
    context: android.content.Context,
    decks: List<com.lingosnap.data.model.Deck>,
    cards: List<com.lingosnap.data.model.Flashcard>,
    fileName: String,
) {
    val uri = com.lingosnap.data.Backup.writeFile(context, fileName, com.lingosnap.data.Backup.toJson(decks, cards))
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/json"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, tr("Datei sichern")))
}
