package com.lingosnap.ui.deck

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import com.lingosnap.util.CardImage
import kotlinx.coroutines.launch
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material3.Surface
import androidx.compose.material3.OutlinedButton
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import com.lingosnap.ui.components.StartSheet
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.Add
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.typeLabelFor
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold

private class ModeSpec(val icon: ImageVector, val title: String, val desc: String, val mode: String)

private val AllModes = listOf(
    ModeSpec(Icons.Rounded.Style, "Karteikarten", "Umdrehen und bewerten", StudyMode.FlashDue),
    ModeSpec(Icons.Rounded.Quiz, "Multiple Choice", "Vier Antworten, eine richtig", StudyMode.Choice),
    ModeSpec(Icons.Rounded.Keyboard, "Schreiben", "Antwort eintippen", StudyMode.Typing),
    ModeSpec(Icons.Rounded.Extension, "Zuordnen", "Paare gegen die Uhr verbinden", StudyMode.Match),
)

@Composable
fun DeckScreen(
    deckId: Long,
    onBack: () -> Unit,
    onStudy: (StudyScope, Long, String, String) -> Unit,
    onAddMore: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val feedback = context.container.feedback
    val cs = MaterialTheme.colorScheme
    val deck = state.deck(deckId)
    val cards = state.cardsOf(deckId).sortedBy { it.source.lowercase() }

    var editing by remember { mutableStateOf<Flashcard?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var editingDeck by remember { mutableStateOf(false) }
    // learning mode waiting for the user to pick a direction
    var starting by remember { mutableStateOf(false) }
    var editMode by remember { mutableStateOf(false) }
    var listOpen by remember { mutableStateOf(false) }
    var cardToDelete by remember { mutableStateOf<Flashcard?>(null) }

    if (deck == null) {
        LargeScreen(title = "Deck", onBack = onBack) { inner ->
            Text("Dieses Deck existiert nicht mehr.", Modifier.padding(inner).padding(16.dp))
        }
        return
    }

    val due = cards.count { it.dueAt <= System.currentTimeMillis() }
    val avg = if (cards.isEmpty()) 0f else cards.sumOf { it.level }.toFloat() / (cards.size * Srs.MAX_LEVEL)

    LargeScreen(
        title = deck.name,
        onBack = onBack,
        actions = {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Mehr") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Deck bearbeiten") }, onClick = { menu = false; editingDeck = true })
                DropdownMenuItem(
                    text = { Text("Deck teilen") },
                    onClick = {
                        menu = false
                        val text = buildString {
                            appendLine(deck.name)
                            cards.forEach { appendLine("${it.source};${it.target}") }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, "Deck teilen"))
                    },
                )
                DropdownMenuItem(
                    text = { Text("Als Datei sichern") },
                    onClick = {
                        menu = false
                        com.lingosnap.ui.settings.shareBackup(context, listOf(deck), cards, deck.name)
                    },
                )
                DropdownMenuItem(text = { Text("Deck löschen") }, onClick = { menu = false; deleting = true })
            }
        },
    ) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item {
                val learned = cards.count { it.level >= Srs.MAX_LEVEL }
                Column(Modifier.padding(horizontal = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(deck.typeLabelFor(cards), style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(
                            "${(avg * 100).toInt()} % gelernt · $due fällig",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        Text("$learned / ${cards.size}", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    }
                    LinearProgressIndicator(progress = { avg }, modifier = Modifier.fillMaxWidth().height(4.dp))
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Button(
                            onClick = { feedback.tap(); starting = true },
                            enabled = cards.isNotEmpty(),
                            modifier = Modifier.weight(1f).heightIn(min = 56.dp),
                        ) { Text("Lernen", style = MaterialTheme.typography.titleMedium) }
                        androidx.compose.material3.FilledTonalIconButton(
                            onClick = onAddMore,
                            modifier = Modifier.size(56.dp),
                        ) { Icon(Icons.Rounded.Add, "Karten hinzufügen") }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 0.dp, top = 20.dp, bottom = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(if (deck.isLanguage) "Deine Vokabeln" else "Deine Karten", style = MaterialTheme.typography.titleMedium)
                    Text("  ${cards.size}", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                    if (cards.isNotEmpty()) IconButton(onClick = { editMode = !editMode }) {
                        Icon(if (editMode) Icons.Rounded.Done else Icons.Rounded.Edit, if (editMode) "Fertig" else "Bearbeiten")
                    }
                }
            }
            if (cards.isEmpty()) item { Text("Noch keine Karten. Tippe auf das Plus.", color = cs.onSurfaceVariant, modifier = Modifier.padding(4.dp)) }
            val shown = if (listOpen) cards else cards.take(3)
            items(shown.size, key = { "c${shown[it].id}" }) { i ->
                val card = shown[i]
                SegmentedItem(
                    index = i,
                    count = shown.size,
                    headline = card.source,
                    supporting = card.target,
                    modifier = Modifier.animateItem(),
                    leading = if (card.imagePath != null) { { CardImage(card.imagePath, Modifier.size(48.dp), maxHeight = 48.dp, maxPx = 160, crop = true) } } else null,
                    trailing = if (editMode) { {
                        Row {
                            if (deck.isLanguage) {
                                IconButton(onClick = { tts.speak(card.source, card.sourceLang) }) {
                                    Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Vorlesen")
                                }
                            }
                            IconButton(onClick = { editing = card }) { Icon(Icons.Rounded.Edit, "Bearbeiten") }
                            IconButton(onClick = { cardToDelete = card }) { Icon(Icons.Rounded.Delete, "Löschen") }
                        }
                    } } else null,
                )
            }
            if (cards.size > 3) item(key = "more") {
                Surface(
                    onClick = { listOpen = !listOpen },
                    shape = RoundedCornerShape(22.dp),
                    color = cs.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp).animateItem(),
                ) {
                    Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (listOpen) "Weniger anzeigen" else "Alle ${cards.size} anzeigen", style = MaterialTheme.typography.titleSmall)
                            if (!listOpen) Text(
                                cards.drop(3).take(3).joinToString(" · ") { it.source } + " …",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            )
                        }
                        Icon(if (listOpen) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null)
                    }
                }
            }
            item { TextButton(onClick = { adding = true }) { Text("Einzelne Karte hinzufügen") } }
        }
    }

    val sheetDeck = if (deck.sourceLang == "auto") {
        cards.groupingBy { it.sourceLang }.eachCount().maxByOrNull { it.value }?.key
            ?.takeIf { it.isNotBlank() }?.let { deck.copy(sourceLang = it) } ?: deck
    } else deck
    if (starting) {
        StartSheet(
            deck = sheetDeck,
            onPick = { mode, dir -> starting = false; onStudy(StudyScope.Deck, deckId, mode, dir) },
            onDismiss = { starting = false },
        )
    }

    if (editingDeck) EditDeckDialog(deck, onDismiss = { editingDeck = false })

    if (adding) {
        CardDialog(
            language = deck.isLanguage,
            title = "Neue Karte",
            initial = null,
            onSave = { s, t, e, img -> vm.addCard(deck, s, t, e, img) },
            onDismiss = { adding = false },
        )
    }
    editing?.let { card ->
        CardDialog(
            language = deck.isLanguage,
            title = "Karte bearbeiten",
            initial = card,
            onSave = { s, t, e, img -> vm.updateCard(card.copy(source = s.trim(), target = t.trim(), example = e?.trim()?.takeIf { it.isNotEmpty() }, imagePath = img)) },
            onDismiss = { editing = null },
        )
    }
    cardToDelete?.let { card ->
        ConfirmDialog("Karte löschen?", "„${card.source}“ wird gelöscht.", "Löschen", { vm.deleteCard(card) }, { cardToDelete = null })
    }
    if (deleting) {
        ConfirmDialog(
            "Deck löschen?", "„${deck.name}“ und alle Karten werden gelöscht.", "Löschen",
            onConfirm = { vm.deleteDeck(deck.id); onBack() },
            onDismiss = { deleting = false },
        )
    }
}

@Composable
private fun CardDialog(
    language: Boolean,
    title: String,
    initial: Flashcard?,
    onSave: (String, String, String?, String?) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var source by remember { mutableStateOf(initial?.source.orEmpty()) }
    var target by remember { mutableStateOf(initial?.target.orEmpty()) }
    var example by remember { mutableStateOf(initial?.example.orEmpty()) }
    var image by remember { mutableStateOf(initial?.imagePath) }
    var saved by remember { mutableStateOf(false) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val path = com.lingosnap.util.CardImages.import(context, uri)
            if (path != null) {
                if (image != initial?.imagePath) com.lingosnap.util.CardImages.delete(image)
                image = path
            }
        }
    }
    fun close() {
        // a picture picked but never saved must not stay on disk
        if (!saved && image != initial?.imagePath) com.lingosnap.util.CardImages.delete(image)
        onDismiss()
    }
    AlertDialog(
        onDismissRequest = { close() },
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text(title, style = MaterialTheme.typography.headlineSmall.bold()) },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AppTextField(source, { source = it }, label = { Text(if (language) "Wort / Phrase" else "Frage") }, modifier = Modifier.fillMaxWidth())
                AppTextField(target, { target = it }, label = { Text(if (language) "Übersetzung" else "Antwort") }, modifier = Modifier.fillMaxWidth())
                if (language) AppTextField(example, { example = it }, label = { Text("Beispielsatz (optional)") }, modifier = Modifier.fillMaxWidth())
                else {
                    AppTextField(example, { example = it }, label = { Text("Erklärung (optional)") }, modifier = Modifier.fillMaxWidth())
                    if (image != null) {
                        com.lingosnap.util.CardImage(image, Modifier.fillMaxWidth(), maxHeight = 160.dp)
                        TextButton(onClick = {
                            if (image != initial?.imagePath) com.lingosnap.util.CardImages.delete(image)
                            image = null
                        }) { Text("Bild entfernen") }
                    } else {
                        androidx.compose.material3.FilledTonalButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Image, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Bild hinzufügen")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = source.isNotBlank() && target.isNotBlank(),
                onClick = {
                    // replaced or removed picture: the old file is no longer needed
                    if (initial?.imagePath != null && initial.imagePath != image) com.lingosnap.util.CardImages.delete(initial.imagePath)
                    saved = true
                    onSave(source.trim(), target.trim(), example.ifBlank { null }, image)
                    onDismiss()
                },
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = { close() }) { Text("Abbrechen") } },
    )
}
