package com.lingosnap.ui.deck

import android.content.Intent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.Stage
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.InfoChip
import com.lingosnap.ui.components.LangBadge
import com.lingosnap.ui.components.MasteryDots
import com.lingosnap.ui.components.SectionLabel
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold

private class ModeSpec(val emoji: String, val title: String, val desc: String, val mode: String)

private val AllModes = listOf(
    ModeSpec("", "Karteikarten", "Umdrehen und bewerten", StudyMode.FlashDue),
    ModeSpec("", "Alle Karten durchgehen", "Auch nicht fällige Karten", StudyMode.FlashAll),
    ModeSpec("", "Multiple Choice", "Vier Antworten, eine richtig", StudyMode.Choice),
    ModeSpec("", "Schreiben", "Antwort eintippen", StudyMode.Typing),
    ModeSpec("", "Zuordnen", "Paare gegen die Uhr verbinden", StudyMode.Match),
)

@Composable
fun DeckScreen(
    deckId: Long,
    onBack: () -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onAddMore: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val cs = MaterialTheme.colorScheme
    val deck = state.deck(deckId)
    val cards = state.cardsOf(deckId).sortedBy { it.source.lowercase() }

    var modeTab by rememberSaveable { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Flashcard?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var cardToDelete by remember { mutableStateOf<Flashcard?>(null) }

    if (deck == null) {
        AppBackground {
            Column(Modifier.statusBarsPadding().padding(20.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
                Text("Dieses Deck existiert nicht mehr.", style = MaterialTheme.typography.titleMedium)
            }
        }
        return
    }

    val now = System.currentTimeMillis()
    val due = cards.count { it.dueAt <= now }
    val avg = if (cards.isEmpty()) 0f else cards.sumOf { it.level }.toFloat() / (cards.size * Srs.MAX_LEVEL)

    AppBackground {
        LazyColumn(
            Modifier.statusBarsPadding(),
            contentPadding = PaddingValues(bottom = 32.dp),
        ) {
            item {
                Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = {
                        val text = buildString {
                            appendLine(deck.name)
                            cards.forEach { appendLine("${it.source};${it.target}") }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, "Deck teilen"))
                    }) { Icon(Icons.Rounded.Share, "Teilen") }
                    IconButton(onClick = { deleting = true }) { Icon(Icons.Rounded.Delete, "Löschen") }
                }
            }
            item {
                Surface(
                    Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = cs.surfaceContainerLow,
                    border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(deck.name, style = MaterialTheme.typography.headlineMedium.bold())
                        Text(
                            "${deck.typeLabel} • ${cards.size} Karten",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { avg }, modifier = Modifier.fillMaxWidth())
                        Text(
                            "${(avg * 100).toInt()} % gelernt • $due fällig",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onStudy(StudyScope.Deck, deckId, StudyMode.FlashDue) },
                                enabled = due > 0,
                            ) { Text(if (due > 0) "Lernen ($due)" else "Alles gelernt") }
                            OutlinedButton(onClick = onAddMore) { Text("Karten hinzufügen") }
                        }
                    }
                }
            }
            item {
                Text(
                    "Lernmodi",
                    style = MaterialTheme.typography.titleSmall.bold(),
                    color = cs.primary,
                    modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 4.dp),
                )
            }
            items(AllModes, key = { it.mode }) { m ->
                ListItem(
                    modifier = Modifier.clickable(enabled = cards.isNotEmpty()) { onStudy(StudyScope.Deck, deckId, m.mode) },
                    headlineContent = { Text(m.title) },
                    supportingContent = { Text(m.desc) },
                )
                HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = cs.outlineVariant)
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 24.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Karten (${cards.size})", style = MaterialTheme.typography.titleSmall.bold(), color = cs.primary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { adding = true }) { Text("Einzelne Karte") }
                }
            }
            items(cards, key = { "c${it.id}" }) { card ->
                ListItem(
                    headlineContent = { Text(card.source) },
                    supportingContent = { Text(card.target) },
                    trailingContent = {
                        Row {
                            if (deck.isLanguage) {
                                IconButton(onClick = { tts.speak(card.source, card.sourceLang) }) { Icon(Icons.Rounded.VolumeUp, "Vorlesen") }
                            }
                            IconButton(onClick = { editing = card }) { Icon(Icons.Rounded.Edit, "Bearbeiten") }
                            IconButton(onClick = { cardToDelete = card }) { Icon(Icons.Rounded.Delete, "Löschen") }
                        }
                    },
                )
                HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = cs.outlineVariant)
            }
        }
    }

    if (adding) {
        CardDialog(
            language = deck.isLanguage,
            title = "Neue Karte",
            initial = null,
            onSave = { s, t, e -> vm.addCard(deck, s, t, e) },
            onDismiss = { adding = false },
        )
    }
    editing?.let { card ->
        CardDialog(
            language = deck.isLanguage,
            title = "Karte bearbeiten",
            initial = card,
            onSave = { s, t, e -> vm.updateCard(card.copy(source = s.trim(), target = t.trim(), example = e?.trim()?.takeIf { it.isNotEmpty() })) },
            onDismiss = { editing = null },
        )
    }
    cardToDelete?.let { card ->
        ConfirmDialog("Karte löschen?", "„${card.source}“ wird gelöscht.", "Löschen", { vm.deleteCard(card) }, { cardToDelete = null })
    }
    if (deleting) {
        ConfirmDialog(
            "Deck löschen?", "„${deck.name}“ und alle Karten werden gelöscht.", "Löschen",
            onConfirm = { vm.deleteDeck(deck.id); onBack() },
            onDismiss = { deleting = false },
        )
    }
}

@Composable
private fun CardDialog(
    language: Boolean,
    title: String,
    initial: Flashcard?,
    onSave: (String, String, String?) -> Unit,
    onDismiss: () -> Unit,
) {
    var source by remember { mutableStateOf(initial?.source.orEmpty()) }
    var target by remember { mutableStateOf(initial?.target.orEmpty()) }
    var example by remember { mutableStateOf(initial?.example.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.large,
        title = { Text(title, style = MaterialTheme.typography.headlineSmall.bold()) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(source, { source = it }, label = { Text(if (language) "Wort / Phrase" else "Frage") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(target, { target = it }, label = { Text(if (language) "Übersetzung" else "Antwort") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (language) OutlinedTextField(example, { example = it }, label = { Text("Beispielsatz (optional)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(
                enabled = source.isNotBlank() && target.isNotBlank(),
                onClick = { onSave(source.trim(), target.trim(), example.ifBlank { null }); onDismiss() },
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
