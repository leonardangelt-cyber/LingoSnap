package com.lingosnap.ui.deck

import com.lingosnap.util.tr

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.CallMerge
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import com.lingosnap.data.model.Deck
import androidx.compose.material3.Checkbox
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import com.lingosnap.util.CardImage
import kotlinx.coroutines.launch
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material3.Surface
import androidx.compose.material3.OutlinedButton
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import com.lingosnap.ui.components.StartSheet
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.Add
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.typeLabelFor
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold

private class ModeSpec(val icon: ImageVector, val title: String, val desc: String, val mode: String)

private val AllModes get() = listOf(
    ModeSpec(Icons.Rounded.Style, tr("Karteikarten"), tr("Umdrehen und bewerten"), StudyMode.FlashDue),
    ModeSpec(Icons.Rounded.Quiz, tr("Multiple Choice"), tr("Vier Antworten, eine richtig"), StudyMode.Choice),
    ModeSpec(Icons.Rounded.Keyboard, tr("Schreiben"), tr("Antwort eintippen"), StudyMode.Typing),
)

@Composable
fun DeckScreen(
    deckId: Long,
    onBack: () -> Unit,
    onStudy: (StudyScope, Long, String, String, Int, Int) -> Unit,
    onAddMore: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val feedback = context.container.feedback
    val cs = MaterialTheme.colorScheme
    val deck = state.deck(deckId)
    val cards = state.cardsOf(deckId).sortedBy { it.source.lowercase() }

    var editing by remember { mutableStateOf<Flashcard?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var editingDeck by remember { mutableStateOf(false) }
    // learning mode waiting for the user to pick a direction
    var starting by remember { mutableStateOf(false) }
    var editMode by remember { mutableStateOf(false) }
    var listOpen by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val selected = remember { androidx.compose.runtime.mutableStateListOf<Long>() }
    var moving by remember { mutableStateOf(false) }
    var merging by remember { mutableStateOf(false) }
    var deletingSelected by remember { mutableStateOf(false) }
    fun toggle(id: Long) { if (id in selected) selected.remove(id) else selected.add(id) }
    var cardToDelete by remember { mutableStateOf<Flashcard?>(null) }
    var undo by remember { mutableStateOf<List<Flashcard>?>(null) }
    androidx.compose.runtime.LaunchedEffect(undo) {
        val gone = undo ?: return@LaunchedEffect
        kotlinx.coroutines.delay(6000)
        vm.purgeImages(gone)
        undo = null
    }

    if (deck == null) {
        LargeScreen(title = tr("Deck"), onBack = onBack) { inner ->
            Text(tr("Dieses Deck existiert nicht mehr."), Modifier.padding(inner).padding(16.dp))
        }
        return
    }

    val visible = if (query.isBlank()) cards else cards.filter { it.source.contains(query.trim(), true) || it.target.contains(query.trim(), true) }
    val due = cards.count { it.dueAt <= System.currentTimeMillis() }
    val avg = if (cards.isEmpty()) 0f else cards.sumOf { it.level }.toFloat() / (cards.size * Srs.MAX_LEVEL)

    LargeScreen(
        title = deck.name,
        onBack = onBack,
        bottomBar = {
            undo?.let { gone ->
                Surface(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(20.dp), color = cs.inverseSurface, contentColor = cs.inverseOnSurface) {
                    Row(Modifier.padding(start = 20.dp, end = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(if (gone.size == 1) tr("Karte gelöscht") else tr("{0} Karten gelöscht", gone.size), Modifier.weight(1f))
                        TextButton(onClick = { vm.restoreCards(gone); undo = null }) { Text(tr("Rückgängig"), color = cs.inversePrimary) }
                    }
                }
            }
        },
        actions = {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, tr("Mehr")) }
            com.lingosnap.ui.components.AppMenu(expanded = menu, onDismiss = { menu = false }) {
                com.lingosnap.ui.components.AppMenuItem(tr("Deck bearbeiten"), Icons.Rounded.Edit, onClick = { menu = false; editingDeck = true })
                com.lingosnap.ui.components.AppMenuItem(tr("Zusammenführen"), Icons.Rounded.CallMerge, supporting = tr("Mit einem anderen Deck"), onClick = { menu = false; merging = true })
                com.lingosnap.ui.components.AppMenuDivider()
                com.lingosnap.ui.components.AppMenuItem(
                    tr("Als Text teilen"), Icons.Rounded.Share,
                    onClick = {
                        menu = false
                        val text = buildString {
                            appendLine(deck.name)
                            cards.forEach { appendLine("${it.source};${it.target}") }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, tr("Deck teilen")))
                    },
                )
                com.lingosnap.ui.components.AppMenuItem(
                    tr("Als Link teilen"), Icons.Rounded.Link,
                    onClick = {
                        menu = false
                        val link = com.lingosnap.util.DeckLink.encode(deck, cards)
                        if (link == null) {
                            android.widget.Toast.makeText(context, tr("Das Deck ist für einen Link zu groß. Nimm „Als Datei sichern“."), android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, tr("Mein LingoSnap-Deck „{0}“. Kopiere diese Nachricht und wähle in LingoSnap Importieren → Link aus Zwischenablage:\n{1}", deck.name, link))
                            }
                            context.startActivity(Intent.createChooser(send, tr("Deck als Link teilen")))
                        }
                    },
                )
                com.lingosnap.ui.components.AppMenuItem(
                    tr("Als Datei sichern"), Icons.Rounded.Save,
                    onClick = {
                        menu = false
                        com.lingosnap.ui.settings.shareBackup(context, listOf(deck), cards, deck.name)
                    },
                )
                com.lingosnap.ui.components.AppMenuDivider()
                com.lingosnap.ui.components.AppMenuItem(tr("Deck löschen"), Icons.Rounded.Delete, danger = true, onClick = { menu = false; deleting = true })
            }
        },
    ) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item {
                val learned = cards.count { it.level >= Srs.MAX_LEVEL }
                Column(Modifier.padding(horizontal = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(deck.typeLabelFor(cards), style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(
                            tr("{0} % gelernt · {1} fällig", (avg * 100).toInt(), due),
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        Text("${learned} / ${cards.size}", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    }
                    LinearProgressIndicator(progress = { avg }, modifier = Modifier.fillMaxWidth().height(4.dp))
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Button(
                            onClick = { feedback.tap(); starting = true },
                            enabled = cards.isNotEmpty(),
                            modifier = Modifier.weight(1f).heightIn(min = 56.dp),
                        ) { Text(tr("Lernen"), style = MaterialTheme.typography.titleMedium) }
                        androidx.compose.material3.FilledTonalIconButton(
                            onClick = onAddMore,
                            modifier = Modifier.size(56.dp),
                        ) { Icon(Icons.Rounded.Add, tr("Karten hinzufügen")) }
                    }
                }
            }

            if (cards.isNotEmpty()) item(key = "goal") { GoalCard(deck, cards, Modifier.padding(top = 12.dp)) }

            item {
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 0.dp, top = 20.dp, bottom = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(if (deck.isLanguage) tr("Deine Vokabeln") else tr("Deine Karten"), style = MaterialTheme.typography.titleMedium)
                    Text("  ${cards.size}", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                    if (cards.size > 3) IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                        Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, if (searching) tr("Suche schließen") else tr("Suchen"))
                    }
                    if (cards.isNotEmpty()) IconButton(onClick = { editMode = !editMode; selected.clear() }) {
                        Icon(if (editMode) Icons.Rounded.Done else Icons.Rounded.Edit, if (editMode) tr("Fertig") else tr("Bearbeiten"))
                    }
                }
            }
            if (searching) item(key = "search") {
                AppTextField(
                    query, { query = it }, Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    placeholder = { Text(tr("Wort oder Übersetzung suchen")) }, singleLine = true,
                )
            }
            if (editMode && cards.isNotEmpty()) item(key = "selbar") {
                Surface(shape = RoundedCornerShape(20.dp), color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(if (selected.isEmpty()) tr("Karten auswählen") else tr("{0} ausgewählt", selected.size), modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            if (selected.size == visible.size) selected.clear() else { selected.clear(); selected.addAll(visible.map { it.id }) }
                        }) { Text(if (selected.size == visible.size) tr("Keine") else tr("Alle")) }
                        IconButton(enabled = selected.isNotEmpty(), onClick = { moving = true }) { Icon(Icons.Rounded.DriveFileMove, tr("Verschieben")) }
                        IconButton(enabled = selected.isNotEmpty(), onClick = { deletingSelected = true }) { Icon(Icons.Rounded.Delete, tr("Löschen")) }
                    }
                }
            }
            if (cards.isEmpty()) item { Text(tr("Noch keine Karten. Tippe auf das Plus."), color = cs.onSurfaceVariant, modifier = Modifier.padding(4.dp)) }
            else if (visible.isEmpty()) item { Text(tr("Nichts gefunden."), color = cs.onSurfaceVariant, modifier = Modifier.padding(4.dp)) }
            val searchMode = query.isNotBlank()
            val showBlock = !searchMode && visible.size > 3
            val total = if (!showBlock || listOpen) visible.size else 4
            val rowCount = if (!showBlock) visible.size else 3
            items(rowCount, key = { "c${visible[it].id}" }) { i ->
                val c = visible[i]
                VocabRow(c, i, total, deck.isLanguage, editMode, if (editMode) c.id in selected else null, { toggle(c.id) }, Modifier.animateItem(), tts, { editing = it }, { cardToDelete = it })
            }
            if (showBlock) item(key = "block") {
                val c = visible[3]
                val bias by androidx.compose.animation.core.animateFloatAsState(if (listOpen) 1f else 0f, androidx.compose.animation.core.spring(0.8f, 380f), label = "arrowSlide")
                val turn by androidx.compose.animation.core.animateFloatAsState(if (listOpen) 180f else 0f, androidx.compose.animation.core.spring(0.8f, 380f), label = "arrowTurn")
                Surface(
                    onClick = { listOpen = !listOpen },
                    shape = com.lingosnap.ui.components.segmentShape(3, total),
                    color = cs.surfaceContainer,
                    modifier = Modifier.fillMaxWidth().animateItem(),
                ) {
                    Box(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 16.dp, vertical = 8.dp)) {
                        androidx.compose.animation.AnimatedVisibility(listOpen, Modifier.align(androidx.compose.ui.Alignment.CenterStart).padding(end = 56.dp)) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                if (editMode) Checkbox(checked = c.id in selected, onCheckedChange = { toggle(c.id) })
                                Column {
                                    Text(c.source, style = MaterialTheme.typography.titleMedium.bold(), maxLines = 3)
                                    Text(c.target, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 3)
                                }
                            }
                        }
                        if (listOpen && editMode) Row(Modifier.align(androidx.compose.ui.Alignment.CenterEnd).padding(end = 44.dp)) {
                            IconButton(onClick = { editing = c }) { Icon(Icons.Rounded.Edit, tr("Bearbeiten")) }
                            IconButton(onClick = { cardToDelete = c }) { Icon(Icons.Rounded.Delete, tr("Löschen")) }
                        }
                        Icon(
                            Icons.Rounded.KeyboardArrowDown,
                            if (listOpen) tr("Einklappen") else tr("Aufklappen"),
                            Modifier.align(androidx.compose.ui.BiasAlignment(bias, 0f)).graphicsLayer { rotationZ = turn },
                        )
                    }
                }
            }
            if (showBlock && listOpen) items(visible.size - 4, key = { "c${visible[it + 4].id}" }) { i ->
                val c = visible[i + 4]
                VocabRow(c, i + 4, total, deck.isLanguage, editMode, if (editMode) c.id in selected else null, { toggle(c.id) }, Modifier.animateItem(), tts, { editing = it }, { cardToDelete = it })
            }
            item { TextButton(onClick = { adding = true }) { Text(tr("Einzelne Karte hinzufügen")) } }
        }
    }

    val sheetDeck = if (deck.sourceLang == "auto") {
        cards.groupingBy { it.sourceLang }.eachCount().maxByOrNull { it.value }?.key
            ?.takeIf { it.isNotBlank() }?.let { deck.copy(sourceLang = it) } ?: deck
    } else deck
    if (starting) {
        StartSheet(
            deck = sheetDeck,
            cardCount = cards.size,
            weakCount = cards.count { it.lapses > 0 },
            onPick = { mode, dir, from, to -> starting = false; onStudy(StudyScope.Deck, deckId, mode, dir, from, to) },
            onDismiss = { starting = false },
        )
    }

    val others = state.decks.filter { it.id != deck.id && it.isLanguage == deck.isLanguage }
    if (moving) DeckPickDialog(
        title = tr("In welches Deck verschieben?"), decks = others,
        onPick = { target -> vm.moveCards(cards.filter { it.id in selected }, target); selected.clear(); moving = false; editMode = false },
        onDismiss = { moving = false },
    )
    if (merging) DeckPickDialog(
        title = tr("Alle Karten in welches Deck?"), decks = others,
        onPick = { target -> merging = false; vm.mergeDecks(deck, target); onBack() },
        onDismiss = { merging = false },
    )
    if (deletingSelected) ConfirmDialog(
        title = tr("{0} Karten löschen?", selected.size),
        text = tr("Die ausgewählten Karten werden endgültig gelöscht."),
        confirmLabel = tr("Löschen"),
        onConfirm = { val gone = cards.filter { it.id in selected }; vm.deleteCardsSoft(gone); undo = gone; selected.clear(); deletingSelected = false },
        onDismiss = { deletingSelected = false },
    )

    if (editingDeck) EditDeckDialog(deck, onDismiss = { editingDeck = false })

    if (adding) {
        CardDialog(
            language = deck.isLanguage,
            title = tr("Neue Karte"),
            initial = null,
            onSave = { s, t, e, img -> vm.addCard(deck, s, t, e, img) },
            onDismiss = { adding = false },
        )
    }
    editing?.let { card ->
        CardDialog(
            language = deck.isLanguage,
            title = tr("Karte bearbeiten"),
            initial = card,
            onSave = { s, t, e, img -> vm.updateCard(card.copy(source = s.trim(), target = t.trim(), example = e?.trim()?.takeIf { it.isNotEmpty() }, imagePath = img)) },
            onDismiss = { editing = null },
        )
    }
    cardToDelete?.let { card ->
        ConfirmDialog(tr("Karte löschen?"), tr("„{0}“ wird gelöscht.", card.source), tr("Löschen"), { vm.deleteCardsSoft(listOf(card)); undo = listOf(card); cardToDelete = null }, { cardToDelete = null })
    }
    if (deleting) {
        ConfirmDialog(
            tr("Deck löschen?"), tr("„{0}“ und alle Karten werden gelöscht.", deck.name), tr("Löschen"),
            onConfirm = { vm.deleteDeck(deck.id); onBack() },
            onDismiss = { deleting = false },
        )
    }
}

@Composable
private fun CardDialog(
    language: Boolean,
    title: String,
    initial: Flashcard?,
    onSave: (String, String, String?, String?) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var source by remember { mutableStateOf(initial?.source.orEmpty()) }
    var target by remember { mutableStateOf(initial?.target.orEmpty()) }
    var example by remember { mutableStateOf(initial?.example.orEmpty()) }
    var image by remember { mutableStateOf(initial?.imagePath) }
    var saved by remember { mutableStateOf(false) }
    var finder by remember { mutableStateOf(false) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val path = com.lingosnap.util.CardImages.import(context, uri)
            if (path != null) {
                if (image != initial?.imagePath) com.lingosnap.util.CardImages.delete(image)
                image = path
            }
        }
    }
    fun close() {
        // a picture picked but never saved must not stay on disk
        if (!saved && image != initial?.imagePath) com.lingosnap.util.CardImages.delete(image)
        onDismiss()
    }
    if (finder) {
        com.lingosnap.ui.create.ImageFinderDialog(
            question = source, answer = target,
            onPicked = { path ->
                if (image != initial?.imagePath) com.lingosnap.util.CardImages.delete(image)
                image = path
                finder = false
            },
            onDismiss = { finder = false },
        )
    }
    com.lingosnap.ui.components.FormSheet(
        title = title,
        onDismiss = { close() },
        confirmLabel = tr("Speichern"),
        confirmEnabled = source.isNotBlank() && target.isNotBlank(),
        onConfirm = {
            // replaced or removed picture: the old file is no longer needed
            if (initial?.imagePath != null && initial.imagePath != image) com.lingosnap.util.CardImages.delete(initial.imagePath)
            saved = true
            onSave(source.trim(), target.trim(), example.ifBlank { null }, image)
            onDismiss()
        },
    ) {
                AppTextField(source, { source = it }, label = { Text(if (language) tr("Wort / Phrase") else tr("Frage")) }, modifier = Modifier.fillMaxWidth())
                AppTextField(target, { target = it }, label = { Text(if (language) tr("Übersetzung") else tr("Antwort")) }, modifier = Modifier.fillMaxWidth())
                if (language) AppTextField(example, { example = it }, label = { Text(tr("Beispielsatz (optional)")) }, modifier = Modifier.fillMaxWidth())
                else {
                    AppTextField(example, { example = it }, label = { Text(tr("Erklärung (optional)")) }, modifier = Modifier.fillMaxWidth())
                    val cs = MaterialTheme.colorScheme
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp), color = cs.surfaceContainerHighest, modifier = Modifier.fillMaxWidth()) {
                        if (image != null) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                com.lingosnap.util.CardImage(image, Modifier.fillMaxWidth(), maxHeight = 180.dp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    androidx.compose.material3.FilledTonalButton(onClick = { finder = true }, enabled = source.isNotBlank(), modifier = Modifier.weight(1f)) { Text(tr("Anderes Bild")) }
                                    androidx.compose.material3.OutlinedButton(onClick = {
                                        if (image != initial?.imagePath) com.lingosnap.util.CardImages.delete(image)
                                        image = null
                                    }, modifier = Modifier.weight(1f)) { Text(tr("Entfernen")) }
                                }
                            }
                        } else {
                            Column(
                                Modifier.fillMaxWidth().padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Icon(Icons.Rounded.Image, null, tint = cs.primary, modifier = Modifier.size(32.dp))
                                Text(tr("Bild zur Karte"), style = MaterialTheme.typography.titleSmall)
                                Text(
                                    tr("Ein Bild macht Karten leichter merkbar."),
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    androidx.compose.material3.FilledTonalButton(onClick = { picker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text(tr("Galerie")) }
                                    androidx.compose.material3.FilledTonalButton(
                                        enabled = source.isNotBlank(),
                                        onClick = { finder = true },
                                        modifier = Modifier.weight(1f),
                                    ) { Text(tr("Suchen")) }
                                }
                            }
                        }
                    }
                }
    }
}

@Composable
private fun VocabRow(
    card: Flashcard,
    index: Int,
    count: Int,
    language: Boolean,
    editMode: Boolean,
    selected: Boolean?,
    onToggle: () -> Unit,
    modifier: Modifier,
    tts: com.lingosnap.util.TtsManager,
    onEdit: (Flashcard) -> Unit,
    onDelete: (Flashcard) -> Unit,
) {
    SegmentedItem(
        index = index,
        count = count,
        headline = card.source,
        supporting = card.target,
        modifier = modifier,
        onClick = if (selected != null) onToggle else null,
        leading = if (selected != null) { { Checkbox(checked = selected, onCheckedChange = { onToggle() }) } } else if (card.imagePath != null) { { CardImage(card.imagePath, Modifier.size(48.dp), maxHeight = 48.dp, maxPx = 160, crop = true) } } else null,
        trailing = if (editMode) { {
            Row {
                if (language) IconButton(onClick = { tts.speak(card.source, card.sourceLang) }) { Icon(Icons.AutoMirrored.Rounded.VolumeUp, tr("Vorlesen")) }
                IconButton(onClick = { onEdit(card) }) { Icon(Icons.Rounded.Edit, tr("Bearbeiten")) }
                IconButton(onClick = { onDelete(card) }) { Icon(Icons.Rounded.Delete, tr("Löschen")) }
            }
        } } else null,
    )
}

@Composable
private fun DeckPickDialog(title: String, decks: List<Deck>, onPick: (Deck) -> Unit, onDismiss: () -> Unit) {
    com.lingosnap.ui.components.FormSheet(title = title, onDismiss = onDismiss) {
        if (decks.isEmpty()) Text(tr("Es gibt kein anderes Deck dieser Art."))
        else Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            decks.forEachIndexed { i, d -> SegmentedItem(i, decks.size, d.name, onClick = { onPick(d) }) }
        }
    }
}
