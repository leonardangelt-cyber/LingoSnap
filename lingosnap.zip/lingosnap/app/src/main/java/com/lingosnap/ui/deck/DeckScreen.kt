package com.lingosnap.ui.deck

import android.content.Intent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.Stage
import com.lingosnap.data.model.StudyScope
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.AppBackground
import com.lingosnap.ui.components.BouncyButton
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.InfoChip
import com.lingosnap.ui.components.LangBadge
import com.lingosnap.ui.components.MasteryDots
import com.lingosnap.ui.components.SectionLabel
import com.lingosnap.ui.components.WavyProgressBar
import com.lingosnap.ui.components.entrance
import com.lingosnap.ui.components.pressScale
import com.lingosnap.ui.theme.bold

private class ModeSpec(val emoji: String, val title: String, val desc: String, val mode: String)

private val FocusModes = listOf(
    ModeSpec("🃏", "Karteikarten", "Wischen & umdrehen", StudyMode.FlashDue),
    ModeSpec("✅", "Multiple Choice", "4 Antworten, 1 richtig", StudyMode.Choice),
    ModeSpec("⌨️", "Schreibtrainer", "Tippe die Übersetzung", StudyMode.Typing),
)
private val CreativeModes = listOf(
    ModeSpec("", "Speed Match", "Paare gegen die Uhr", StudyMode.Match),
    ModeSpec("🔁", "Alle durchgehen", "Auch nicht fällige Karten", StudyMode.FlashAll),
)

@Composable
fun DeckScreen(
    deckId: Long,
    onBack: () -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onAddMore: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val cs = MaterialTheme.colorScheme
    val deck = state.deck(deckId)
    val cards = state.cardsOf(deckId).sortedBy { it.source.lowercase() }

    var modeTab by rememberSaveable { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Flashcard?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var cardToDelete by remember { mutableStateOf<Flashcard?>(null) }

    if (deck == null) {
        AppBackground {
            Column(Modifier.statusBarsPadding().padding(20.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
                Text("Dieses Deck existiert nicht mehr.", style = MaterialTheme.typography.titleMedium)
            }
        }
        return
    }

    val now = System.currentTimeMillis()
    val due = cards.count { it.dueAt <= now }
    val avg = if (cards.isEmpty()) 0f else cards.sumOf { it.level }.toFloat() / (cards.size * Srs.MAX_LEVEL)

    AppBackground {
        LazyColumn(
            Modifier.statusBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(Modifier.entrance(0), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Zurück") }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = {
                        val text = buildString {
                            appendLine(deck.name)
                            cards.forEach { appendLine("${it.source};${it.target}") }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, "Deck teilen"))
                    }) { Icon(Icons.Rounded.Share, "Teilen") }
                    IconButton(onClick = { deleting = true }) { Icon(Icons.Rounded.Delete, "Löschen") }
                }
            }
            item {
                Row(Modifier.entrance(1), verticalAlignment = Alignment.CenterVertically) {
                    LangBadge(deck.sourceLang)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(deck.name, style = MaterialTheme.typography.headlineMedium.bold())
                        Text(
                            "${languageName(deck.sourceLang)} → ${languageName(deck.targetLang)} • ${cards.size} Karten",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
            }
            if (deck.description.isNotBlank()) {
                item { Text(deck.description, color = cs.onSurfaceVariant, modifier = Modifier.entrance(1)) }
            }
            item {
                Surface(Modifier.fillMaxWidth().entrance(2), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainer) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        SectionLabel("Lernstatus", trailing = "${(avg * 100).toInt()} %")
                        WavyProgressBar(avg)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            listOf(Stage.Master, Stage.Practiced, Stage.Beginner, Stage.New).forEach { st ->
                                val n = cards.count { Stage.of(it.level) == st }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("$n", style = MaterialTheme.typography.headlineSmall.bold())
                                    Text(st.label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
            item {
                BouncyButton(
                    onClick = { onStudy(StudyScope.Deck, deckId, StudyMode.FlashDue) },
                    enabled = due > 0,
                    modifier = Modifier.fillMaxWidth().entrance(3),
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (due > 0) "$due fällig • Üben" else "Alles erledigt", style = MaterialTheme.typography.titleMedium.bold())
                }
            }
            item {
                Surface(Modifier.fillMaxWidth().entrance(4), shape = MaterialTheme.shapes.extraLarge, color = cs.surfaceContainer) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionLabel("Spiel- & Lernmodi")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = modeTab == 0, onClick = { modeTab = 0 }, label = { Text("Fokus") })
                            FilterChip(selected = modeTab == 1, onClick = { modeTab = 1 }, label = { Text("Kreativ") })
                        }
                        AnimatedContent(
                            targetState = modeTab,
                            transitionSpec = { fadeIn(spring()) togetherWith fadeOut() },
                            label = "modes",
                        ) { t ->
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                (if (t == 0) FocusModes else CreativeModes).forEach { m ->
                                    ModeRow(m, enabled = cards.isNotEmpty()) { onStudy(StudyScope.Deck, deckId, m.mode) }
                                }
                            }
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Karten", style = MaterialTheme.typography.titleLarge.bold(), modifier = Modifier.weight(1f))
                    FilledTonalButton(onClick = { adding = true }) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Karte")
                    }
                    Spacer(Modifier.width(8.dp))
                    FilledTonalButton(onClick = onAddMore) { Text("KI / Import") }
                }
            }
            items(cards, key = { it.id }) { card ->
                Surface(Modifier.fillMaxWidth().animateItem(), shape = MaterialTheme.shapes.large, color = cs.surfaceContainerHigh) {
                    Row(Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 0.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(card.source, style = MaterialTheme.typography.titleMedium.bold())
                            Text(card.target, color = cs.onSurfaceVariant)
                            MasteryDots(card.level, Modifier.padding(top = 4.dp))
                        }
                        IconButton(onClick = { tts.speak(card.source, card.sourceLang) }) { Icon(Icons.Rounded.VolumeUp, "Vorlesen") }
                        IconButton(onClick = { editing = card }) { Icon(Icons.Rounded.Edit, "Bearbeiten") }
                        IconButton(onClick = { cardToDelete = card }) { Icon(Icons.Rounded.Delete, "Löschen") }
                    }
                }
            }
        }
    }

    if (adding) {
        CardDialog(
            title = "Neue Karte",
            initial = null,
            onSave = { s, t, e -> vm.addCard(deck, s, t, e) },
            onDismiss = { adding = false },
        )
    }
    editing?.let { card ->
        CardDialog(
            title = "Karte bearbeiten",
            initial = card,
            onSave = { s, t, e -> vm.updateCard(card.copy(source = s.trim(), target = t.trim(), example = e?.trim()?.takeIf { it.isNotEmpty() })) },
            onDismiss = { editing = null },
        )
    }
    cardToDelete?.let { card ->
        ConfirmDialog("Karte löschen?", "„${card.source}“ wird gelöscht.", "Löschen", { vm.deleteCard(card) }, { cardToDelete = null })
    }
    if (deleting) {
        ConfirmDialog(
            "Deck löschen?", "„${deck.name}“ und alle Karten werden gelöscht.", "Löschen",
            onConfirm = { vm.deleteDeck(deck.id); onBack() },
            onDismiss = { deleting = false },
        )
    }
}

@Composable
private fun ModeRow(m: ModeSpec, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    Surface(
        Modifier.fillMaxWidth().pressScale(src, 0.97f),
        shape = MaterialTheme.shapes.large,
        color = cs.surfaceContainerHigh,
        contentColor = if (enabled) cs.onSurface else cs.onSurfaceVariant,
    ) {
        Row(
            Modifier
                .clickable(enabled = enabled, interactionSource = src, indication = null, onClick = onClick)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(m.title, style = MaterialTheme.typography.titleMedium.bold())
                Text(m.desc, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun CardDialog(
    title: String,
    initial: Flashcard?,
    onSave: (String, String, String?) -> Unit,
    onDismiss: () -> Unit,
) {
    var source by remember { mutableStateOf(initial?.source.orEmpty()) }
    var target by remember { mutableStateOf(initial?.target.orEmpty()) }
    var example by remember { mutableStateOf(initial?.example.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text(title, style = MaterialTheme.typography.headlineSmall.bold()) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(source, { source = it }, label = { Text("Wort / Phrase") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(target, { target = it }, label = { Text("Übersetzung") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(example, { example = it }, label = { Text("Beispielsatz (optional)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(
                enabled = source.isNotBlank() && target.isNotBlank(),
                onClick = { onSave(source.trim(), target.trim(), example.ifBlank { null }); onDismiss() },
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
