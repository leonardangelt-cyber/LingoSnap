package com.lingosnap.ui.deck

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.StudyScope
import com.lingosnap.ui.AppViewModel
import com.lingosnap.ui.StudyMode
import com.lingosnap.ui.components.ConfirmDialog
import com.lingosnap.ui.components.GroupHeader
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.components.SegmentedItem
import com.lingosnap.ui.theme.bold

private class ModeSpec(val icon: ImageVector, val title: String, val desc: String, val mode: String)

private val AllModes = listOf(
    ModeSpec(Icons.Rounded.Style, "Karteikarten", "Umdrehen und bewerten", StudyMode.FlashDue),
    ModeSpec(Icons.Rounded.Quiz, "Multiple Choice", "Vier Antworten, eine richtig", StudyMode.Choice),
    ModeSpec(Icons.Rounded.Keyboard, "Schreiben", "Antwort eintippen", StudyMode.Typing),
    ModeSpec(Icons.Rounded.Extension, "Zuordnen", "Paare gegen die Uhr verbinden", StudyMode.Match),
)

@Composable
fun DeckScreen(
    deckId: Long,
    onBack: () -> Unit,
    onStudy: (StudyScope, Long, String) -> Unit,
    onAddMore: () -> Unit,
    vm: AppViewModel = viewModel(factory = AppViewModel.Factory),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val tts = context.container.tts
    val cs = MaterialTheme.colorScheme
    val deck = state.deck(deckId)
    val cards = state.cardsOf(deckId).sortedBy { it.source.lowercase() }

    var editing by remember { mutableStateOf<Flashcard?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var cardToDelete by remember { mutableStateOf<Flashcard?>(null) }

    if (deck == null) {
        LargeScreen(title = "Deck", onBack = onBack) { inner ->
            Text("Dieses Deck existiert nicht mehr.", Modifier.padding(inner).padding(16.dp))
        }
        return
    }

    val due = cards.count { it.dueAt <= System.currentTimeMillis() }
    val avg = if (cards.isEmpty()) 0f else cards.sumOf { it.level }.toFloat() / (cards.size * Srs.MAX_LEVEL)

    LargeScreen(
        title = deck.name,
        onBack = onBack,
        actions = {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Mehr") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Deck teilen") },
                    onClick = {
                        menu = false
                        val text = buildString {
                            appendLine(deck.name)
                            cards.forEach { appendLine("${it.source};${it.target}") }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        context.startActivity(Intent.createChooser(send, "Deck teilen"))
                    },
                )
                DropdownMenuItem(text = { Text("Deck löschen") }, onClick = { menu = false; deleting = true })
            }
        },
    ) { inner ->
        LazyColumn(
            Modifier.padding(inner),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "${deck.typeLabel} • ${cards.size} Karten",
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                    )
                    LinearProgressIndicator(progress = { avg }, modifier = Modifier.fillMaxWidth())
                    Text(
                        "${(avg * 100).toInt()} % gelernt • $due fällig",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onStudy(StudyScope.Deck, deckId, StudyMode.FlashDue) },
                            enabled = cards.isNotEmpty(),
                        ) { Text("Lernen") }
                        FilledTonalButton(onClick = onAddMore) { Text("Karten hinzufügen") }
                    }
                }
            }

            item { GroupHeader("Lernmodi", Modifier.padding(start = 0.dp)) }
            items(AllModes.size, key = { AllModes[it].mode }) { i ->
                val m = AllModes[i]
                SegmentedItem(
                    index = i,
                    count = AllModes.size,
                    headline = m.title,
                    supporting = m.desc,
                    enabled = cards.isNotEmpty(),
                    onClick = { onStudy(StudyScope.Deck, deckId, m.mode) },
                    leading = { Icon(m.icon, null, tint = cs.primary) },
                )
            }

            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    GroupHeader("Karten (${cards.size})", Modifier.weight(1f).padding(start = 0.dp))
                    TextButton(onClick = { adding = true }) { Text("Einzelne Karte") }
                }
            }
            items(cards.size, key = { "c${cards[it].id}" }) { i ->
                val card = cards[i]
                SegmentedItem(
                    index = i,
                    count = cards.size,
                    headline = card.source,
                    supporting = card.target,
                    modifier = Modifier.animateItem(),
                    trailing = {
                        Row {
                            if (deck.isLanguage) {
                                IconButton(onClick = { tts.speak(card.source, card.sourceLang) }) {
                                    Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Vorlesen")
                                }
                            }
                            IconButton(onClick = { editing = card }) { Icon(Icons.Rounded.Edit, "Bearbeiten") }
                            IconButton(onClick = { cardToDelete = card }) { Icon(Icons.Rounded.Delete, "Löschen") }
                        }
                    },
                )
            }
        }
    }

    if (adding) {
        CardDialog(
            language = deck.isLanguage,
            title = "Neue Karte",
            initial = null,
            onSave = { s, t, e -> vm.addCard(deck, s, t, e) },
            onDismiss = { adding = false },
        )
    }
    editing?.let { card ->
        CardDialog(
            language = deck.isLanguage,
            title = "Karte bearbeiten",
            initial = card,
            onSave = { s, t, e -> vm.updateCard(card.copy(source = s.trim(), target = t.trim(), example = e?.trim()?.takeIf { it.isNotEmpty() })) },
            onDismiss = { editing = null },
        )
    }
    cardToDelete?.let { card ->
        ConfirmDialog("Karte löschen?", "„${card.source}“ wird gelöscht.", "Löschen", { vm.deleteCard(card) }, { cardToDelete = null })
    }
    if (deleting) {
        ConfirmDialog(
            "Deck löschen?", "„${deck.name}“ und alle Karten werden gelöscht.", "Löschen",
            onConfirm = { vm.deleteDeck(deck.id); onBack() },
            onDismiss = { deleting = false },
        )
    }
}

@Composable
private fun CardDialog(
    language: Boolean,
    title: String,
    initial: Flashcard?,
    onSave: (String, String, String?) -> Unit,
    onDismiss: () -> Unit,
) {
    var source by remember { mutableStateOf(initial?.source.orEmpty()) }
    var target by remember { mutableStateOf(initial?.target.orEmpty()) }
    var example by remember { mutableStateOf(initial?.example.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text(title, style = MaterialTheme.typography.headlineSmall.bold()) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(source, { source = it }, label = { Text(if (language) "Wort / Phrase" else "Frage") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(target, { target = it }, label = { Text(if (language) "Übersetzung" else "Antwort") }, modifier = Modifier.fillMaxWidth())
                if (language) OutlinedTextField(example, { example = it }, label = { Text("Beispielsatz (optional)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(
                enabled = source.isNotBlank() && target.isNotBlank(),
                onClick = { onSave(source.trim(), target.trim(), example.ifBlank { null }); onDismiss() },
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
