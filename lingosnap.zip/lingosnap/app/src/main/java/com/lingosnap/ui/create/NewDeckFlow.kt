@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.lingosnap.ui.create

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.togetherWith
import com.lingosnap.ui.components.SegmentedItem
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.components.IconBadge
import com.lingosnap.ui.components.SheetHandle
import com.lingosnap.util.tr
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * The "+" menu: the two pills flow up from the corner (springy), the screen behind is blurred (see HomeScreen) and
 * everything springs back when it is closed.
 */
@Composable
fun NewDeckOverlay(visible: Boolean, onPick: (languageDeck: Boolean) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    androidx.activity.compose.BackHandler(enabled = visible, onBack = onDismiss)
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(220)), exit = fadeOut(tween(260))) {
            Box(
                Modifier.fillMaxSize().background(cs.surface.copy(alpha = 0.55f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            )
        }
        Column(
            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            listOf(
                Triple(tr("Karteikarten"), Icons.Rounded.Style, false),
                Triple(tr("Vokabeln"), Icons.Rounded.Translate, true),
            ).forEachIndexed { i, (label, icon, lang) ->
                var show by remember { mutableStateOf(false) }
                LaunchedEffect(visible) { delay(if (visible) 40L + i * 70L else (1 - i) * 50L); show = visible }
                AnimatedVisibility(
                    visible = show,
                    enter = fadeIn(tween(160)) + slideInVertically(spring(dampingRatio = 0.62f, stiffness = 320f)) { it * 3 } +
                        scaleIn(spring(dampingRatio = 0.7f, stiffness = 380f), initialScale = 0.6f, transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 1f)),
                    exit = fadeOut(tween(160)) + slideOutVertically(spring(dampingRatio = 0.75f, stiffness = 420f)) { it * 3 } +
                        scaleOut(spring(stiffness = 420f), targetScale = 0.6f, transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 1f)),
                ) {
                    Surface(
                        onClick = { onPick(lang) },
                        shape = CircleShape, color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer, shadowElevation = 3.dp,
                    ) {
                        Row(Modifier.heightIn(min = 56.dp).padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, null, Modifier.size(24.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(label, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
            AnimatedVisibility(
                visible,
                enter = scaleIn(spring(dampingRatio = 0.6f, stiffness = 380f)) + fadeIn(),
                exit = scaleOut(spring(stiffness = 500f)) + fadeOut(),
            ) {
                FloatingActionButton(onClick = onDismiss, containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
                    Icon(Icons.Rounded.Close, tr("Schließen"))
                }
            }
        }
    }
}

/**
 * The short naming sheet at the bottom: only the name (plus languages for vocabulary, the subject for flashcards).
 * "Jetzt hinzufügen" keeps the sheet and shows the ways to add cards right below; [onChosen] gets the deck id and the method
 * (1 = scan, 2 = AI, 0 = type).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewDeckSheet(languageDeck: Boolean, existingSubjects: List<String>, onChosen: (Long, Int) -> Unit, onDismiss: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = com.lingosnap.util.Lang.code
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "en")
    }
    var busy by remember { mutableStateOf(false) }
    var createdId by rememberSaveable { mutableStateOf<Long?>(null) }
    val canCreate = !busy && (languageDeck || subject.isNotBlank())

    fun create(now: Boolean) {
        if (!canCreate) return
        busy = true
        scope.launch {
            val finalName = name.trim().ifBlank { DEFAULT_DECK_NAME }
            val id = if (languageDeck) repo.createDeck(finalName, null, source, target, "")
            else repo.createDeck(finalName, null, "", "", subject.trim(), kind = "cards")
            if (now) { createdId = id; busy = false } else onDismiss()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerLow,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
        dragHandle = { SheetHandle() },
    ) {
        androidx.compose.animation.AnimatedContent(
            targetState = createdId,
            transitionSpec = { (fadeIn(tween(220, 90)) + slideInVertically(tween(300)) { it / 6 }) togetherWith fadeOut(tween(120)) },
            label = "newDeckStep",
        ) { id ->
            if (id == null) Column(
                Modifier.fillMaxWidth().imePadding().navigationBarsPadding().verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp).padding(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(if (languageDeck) Icons.Rounded.Translate else Icons.Rounded.Style, container = cs.primaryContainer, content = cs.onPrimaryContainer)
                    Spacer(Modifier.width(14.dp))
                    Text(if (languageDeck) tr("Neues Vokabel-Deck") else tr("Neues Karteikarten-Deck"), style = MaterialTheme.typography.titleLarge)
                }
                AppTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text(tr("Name des Decks einfügen")) },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                if (languageDeck) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LanguageField(tr("Ich lerne"), source, Modifier.weight(1f), allowAuto = true) { source = it }
                        IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                            Icon(Icons.Rounded.SwapHoriz, tr("Tauschen"))
                        }
                        LanguageField(tr("Meine Sprache"), target, Modifier.weight(1f)) { target = it }
                    }
                } else {
                    AppTextField(
                        value = subject, onValueChange = { subject = it },
                        label = { Text(tr("Fach")) },
                        placeholder = { Text(tr("z. B. Biologie")) },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    if (existingSubjects.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            existingSubjects.forEach { s ->
                                androidx.compose.material3.FilterChip(selected = subject.trim() == s, onClick = { subject = s }, label = { Text(s) })
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilledTonalButton(
                        onClick = { create(false) }, enabled = canCreate,
                        modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                    ) { Text(if (languageDeck) tr("Später Vokabeln hinzufügen") else tr("Später Karten hinzufügen"), maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
                    Button(
                        onClick = { create(true) }, enabled = canCreate,
                        modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                    ) { Text(if (languageDeck) tr("Jetzt Vokabeln hinzufügen") else tr("Jetzt Karten hinzufügen"), maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
                }
            } else Column(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(tr("Wie möchtest du Karten hinzufügen?"), style = MaterialTheme.typography.titleLarge)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    SegmentedItem(
                        0, 3, tr("Foto oder Datei scannen"), supporting = tr("Kamera, Bild, PDF, Word oder PowerPoint"),
                        onClick = { onChosen(id, 1) },
                        leading = { IconBadge(Icons.Rounded.CameraAlt, 40, cs.primaryContainer, cs.onPrimaryContainer) },
                    )
                    SegmentedItem(
                        1, 3, tr("Mit KI erzeugen"), supporting = tr("Thema eingeben, Karten generieren lassen"),
                        onClick = { onChosen(id, 2) },
                        leading = { IconBadge(Icons.Rounded.Psychology, 40, cs.primaryContainer, cs.onPrimaryContainer) },
                    )
                    SegmentedItem(
                        2, 3, tr("Selbst eintippen"), supporting = tr("Einzeln oder als Liste einfügen"),
                        onClick = { onChosen(id, 0) },
                        leading = { IconBadge(Icons.Rounded.Edit, 40, cs.primaryContainer, cs.onPrimaryContainer) },
                    )
                }
                androidx.compose.material3.TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text(tr("Später hinzufügen")) }
            }
        }
    }
}
