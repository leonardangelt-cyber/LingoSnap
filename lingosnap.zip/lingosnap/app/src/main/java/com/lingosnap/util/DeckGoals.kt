package com.lingosnap.util

import android.content.Context
import android.content.SharedPreferences
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Srs
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** What to do today to reach a deck's goal date. */
data class DayPlan(
    val daysLeft: Int,
    /** cards not yet mastered */
    val remaining: Int,
    /** how many unseen cards to start today */
    val newToday: Int,
    /** cards due for review right now */
    val due: Int,
    /** the unseen cards chosen for today */
    val words: List<Flashcard>,
    val overdue: Boolean,
)

/** Optional "I want to know all cards by …" date per deck (kept in preferences) and the AI's plan text of the day. */
object DeckGoals {
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences("lingosnap_goals", Context.MODE_PRIVATE)
    }

    fun get(deckId: Long): LocalDate? =
        prefs?.getString("goal_$deckId", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

    fun set(deckId: Long, date: LocalDate?) {
        prefs?.edit()?.apply {
            if (date == null) { remove("goal_$deckId"); remove("plan_$deckId") } else putString("goal_$deckId", date.toString())
        }?.apply()
    }

    fun allGoals(): Map<Long, LocalDate> =
        prefs?.all.orEmpty().mapNotNull { (k, v) ->
            if (k.startsWith("goal_") && v is String) k.removePrefix("goal_").toLongOrNull()?.let { id -> runCatching { LocalDate.parse(v) }.getOrNull()?.let { id to it } } else null
        }.toMap()

    /** The AI text saved for today, if any. */
    fun planText(deckId: Long, today: LocalDate = LocalDate.now()): String? =
        prefs?.getString("plan_$deckId", null)?.takeIf { it.startsWith("$today|") }?.substringAfter('|')

    fun savePlanText(deckId: Long, text: String, today: LocalDate = LocalDate.now()) {
        prefs?.edit()?.putString("plan_$deckId", "$today|$text")?.apply()
    }

    fun plan(cards: List<Flashcard>, goal: LocalDate, today: LocalDate = LocalDate.now(), now: Long = System.currentTimeMillis()): DayPlan {
        val daysLeft = (ChronoUnit.DAYS.between(today, goal).toInt() + 1).coerceAtLeast(1)
        val unseen = cards.filter { it.reps == 0 && it.level == 0 }.sortedBy { it.createdAt }
        val quota = if (unseen.isEmpty()) 0 else (unseen.size + daysLeft - 1) / daysLeft
        return DayPlan(
            daysLeft = daysLeft,
            remaining = cards.count { it.level < Srs.MAX_LEVEL },
            newToday = quota,
            due = cards.count { it.dueAt <= now && !(it.reps == 0 && it.level == 0) },
            words = unseen.take(quota),
            overdue = goal.isBefore(today),
        )
    }
}
