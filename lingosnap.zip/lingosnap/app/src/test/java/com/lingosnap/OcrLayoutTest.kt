package com.lingosnap

import com.lingosnap.util.ManualLines
import com.lingosnap.util.OcrLayout
import com.lingosnap.util.OcrWord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OcrLayoutTest {
    private fun w(t: String, l: Int, top: Int) = OcrWord(t, l, top, l + t.length * 12, top + 30)

    @Test fun twoColumnListBecomesPairs() {
        val words = ArrayList<OcrWord>()
        listOf("casa" to "das Haus", "el perro" to "der Hund", "la mesa" to "der Tisch", "gato" to "die Katze").forEachIndexed { i, (a, b) ->
            var x = 100
            a.split(" ").forEach { words += w(it, x, 100 + i * 50); x += it.length * 12 + 10 }
            x = 600
            b.split(" ").forEach { words += w(it, x, 100 + i * 50); x += it.length * 12 + 10 }
        }
        val r = OcrLayout.layout(words)
        assertEquals(4, r.rows.size)
        assertEquals("el perro", r.rows[1].first)
        assertEquals("der Hund", r.rows[1].second)
    }

    @Test fun separatorLinesStayLooseAndAreParsedAsText() {
        val words = ArrayList<OcrWord>()
        repeat(5) { i -> var x = 100; listOf("casa", "-", "Haus").forEach { words += w(it, x, 100 + i * 50); x += it.length * 12 + 8 } }
        val r = OcrLayout.layout(words)
        assertTrue(r.rows.isEmpty())
        assertEquals("casa - Haus", r.loose[0])
        assertEquals("Haus", ManualLines.parse(r.loose[0])[0].second)
    }

    @Test fun listNumbersAreRemoved() {
        assertEquals("casa", OcrLayout.strip("12. casa"))
        assertEquals("casa", OcrLayout.strip("• casa"))
    }
}
