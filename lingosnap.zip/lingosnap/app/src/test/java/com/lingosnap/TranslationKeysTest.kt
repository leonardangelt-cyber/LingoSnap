package com.lingosnap

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/** Every text in the code that goes through tr("…") must exist in all language files, otherwise that language silently shows German. */
class TranslationKeysTest {
    private val keyPattern = Regex("""\btr\(\s*"((?:[^"\\]|\\.)*)"""")

    private fun keys(): Set<String> =
        File("src/main/java").walkTopDown().filter { it.extension == "kt" }
            .flatMap { f -> keyPattern.findAll(f.readText()).map { it.groupValues[1].replace("\\n", "\n").replace("\\\"", "\"").replace("\\$", "$") } }
            .toSet()

    @Test fun everyKeyExistsInEveryLanguage() {
        val keys = keys()
        assertTrue(keys.size > 100)
        val dir = File("src/main/assets/i18n")
        val problems = ArrayList<String>()
        for (f in dir.listFiles { x -> x.extension == "json" }.orEmpty()) {
            val text = f.readText()
            for (k in keys) {
                val quoted = "\"" + k.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""
                if (!text.contains(quoted)) problems += f.name + ": " + k.take(50)
            }
        }
        assertTrue("Missing translations:\n" + problems.take(30).joinToString("\n"), problems.isEmpty())
    }
}
