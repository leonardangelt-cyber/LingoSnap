package com.lingosnap

import com.lingosnap.data.Backup
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.selectCards
import com.lingosnap.util.AnswerResult
import com.lingosnap.util.checkAnswer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreLogicTest {
    private fun card(id: Long, lapses: Int = 0) =
        Flashcard(id = id, deckId = 1, source = "w$id", target = "t$id", sourceLang = "en", targetLang = "de", lapses = lapses)

    @Test fun hardAnswerCountsALapseAndComesBackSoon() {
        val c = Srs.review(card(1).copy(level = 3, intervalDays = 7), Rating.Hard, now = 0L)
        assertEquals(1, c.lapses)
        assertEquals(0, c.intervalDays)
        assertEquals(2, c.level)
    }

    @Test fun goodAnswerGrowsTheInterval() {
        val first = Srs.review(card(1), Rating.Good, now = 0L)
        assertEquals(1, first.intervalDays)
        val second = Srs.review(first, Rating.Good, now = 0L)
        assertTrue(second.intervalDays > first.intervalDays)
        assertEquals(0, second.lapses)
    }

    @Test fun rangeSelectionIsOneBasedAndInclusive() {
        val cards = (1L..30L).map { card(it) }.shuffled()
        assertEquals(30, selectCards(cards, 0, 0).size)
        assertEquals((1L..10L).toList(), selectCards(cards, 1, 10).map { it.id })
        assertEquals((11L..20L).toList(), selectCards(cards, 11, 20).map { it.id })
        assertEquals(listOf(30L), selectCards(cards, 30, 30).map { it.id })
    }

    @Test fun difficultCardsAreTheOnesWithLapses() {
        val cards = listOf(card(1), card(2, lapses = 1), card(3, lapses = 4))
        assertEquals(listOf(3L, 2L), selectCards(cards, -1, 0).map { it.id })
    }

    @Test fun typedAnswersTolerateTyposAndArticles() {
        assertEquals(AnswerResult.Correct, checkAnswer("Haus", "das Haus"))
        assertEquals(AnswerResult.Close, checkAnswer("Hous", "Haus"))
        assertEquals(AnswerResult.Wrong, checkAnswer("Baum", "Haus"))
    }

    @Test fun backupSurvivesARoundTrip() {
        val deck = Deck(id = 1, name = "Englisch", sourceLang = "en", targetLang = "de")
        val json = Backup.toJson(listOf(deck), listOf(card(1, lapses = 2).copy(level = 3)))
        val parsed = Backup.parse(json)
        assertNotNull(parsed)
        val c = parsed!!.single().cards.single()
        assertEquals("w1", c.source)
        assertEquals(3, c.level)
        assertEquals(2, c.lapses)
    }
}
