package com.lingosnap

import com.lingosnap.data.Backup
import com.lingosnap.data.model.Deck
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.Rating
import com.lingosnap.data.model.Srs
import com.lingosnap.data.model.paused
import com.lingosnap.data.model.selectCards
import com.lingosnap.data.model.stubborn
import com.lingosnap.util.AnswerResult
import com.lingosnap.util.checkAnswer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreLogicTest {
    private fun card(id: Long, lapses: Int = 0) =
        Flashcard(id = id, deckId = 1, source = "w$id", target = "t$id", sourceLang = "en", targetLang = "de", lapses = lapses)

    private val day = 86_400_000L

    private val minute = 60_000L
    private val noon = 1_800_000_000_000L

    @Test fun fixedStepsStayAsDesigned() {
        val c = card(1)
        assertEquals(noon + minute, Srs.review(c, Rating.Again, noon).dueAt)
        assertEquals(noon + 6 * minute, Srs.review(c, Rating.Hard, noon).dueAt)
        assertEquals(noon + 10 * minute, Srs.review(c, Rating.Good, noon).dueAt)
        assertEquals(noon + 3 * day, Srs.review(c, Rating.Easy, noon).dueAt)
    }

    @Test fun againCountsALapseAndLowersTheLevel() {
        val known = card(1).copy(level = 3, intervalDays = 9, reps = 3)
        for (grow in listOf(false, true)) {
            val after = Srs.review(known, Rating.Again, now = noon, grow = grow)
            assertEquals(1, after.lapses)
            assertEquals(0, after.intervalDays)
            assertEquals(2, after.level)
            assertEquals(noon + minute, after.dueAt)
        }
    }

    @Test fun growingIntervalsDoubleWithGoodAndStopAtSixMonths() {
        var c = Srs.review(card(1), Rating.Good, now = noon, grow = true)
        assertEquals(noon + 10 * minute, c.dueAt)
        c = Srs.review(c, Rating.Good, now = noon + 20 * minute, grow = true)
        assertEquals(1, c.intervalDays)
        val gaps = ArrayList<Int>()
        var t = noon + day
        repeat(10) {
            c = Srs.review(c, Rating.Good, now = t, grow = true)
            gaps += c.intervalDays
            t += c.intervalDays * day
        }
        assertEquals(listOf(2, 4, 8, 16, 32, 64, 128, 180, 180, 180), gaps)
        assertEquals(Srs.MAX_LEVEL, c.level)
    }

    @Test fun easyIsLongerThanGoodAndHardKeepsTheGap() {
        val c = card(1).copy(level = 3, intervalDays = 8, reps = 4)
        val hard = Srs.review(c, Rating.Hard, now = noon, grow = true).intervalDays
        val good = Srs.review(c, Rating.Good, now = noon, grow = true).intervalDays
        val easy = Srs.review(c, Rating.Easy, now = noon, grow = true).intervalDays
        assertEquals(8, hard)
        assertTrue(good > hard)
        assertTrue(easy > good)
    }

    @Test fun cardsComeBackAtTheStartOfADayNotAtTheSameClockTime() {
        val due = Srs.review(card(1).copy(level = 2, intervalDays = 1, reps = 2), Rating.Good, now = noon, grow = true).dueAt
        assertEquals(Srs.nextDayStart(noon, 1), due)
        assertTrue(due > noon + day / 2)
    }

    @Test fun practisingAheadOfTimeDoesNotPushCardsAway() {
        val waiting = card(1).copy(level = 3, intervalDays = 8, reps = 4, dueAt = noon + 5 * day)
        for (rating in listOf(Rating.Hard, Rating.Good, Rating.Easy)) {
            val after = Srs.review(waiting, rating, now = noon, grow = true)
            assertEquals(waiting.dueAt, after.dueAt)
            assertEquals(8, after.intervalDays)
            assertEquals(3, after.level)
            assertEquals(5, after.reps)
        }
        // forgetting it still counts
        val wrong = Srs.review(waiting, Rating.Again, now = noon, grow = true)
        assertEquals(noon + minute, wrong.dueAt)
        assertEquals(1, wrong.lapses)
        // with fixed steps everything stays as it always was
        assertEquals(noon + 10 * minute, Srs.review(waiting, Rating.Good, now = noon).dueAt)
    }

    @Test fun pausedCardsAreNeverPartOfASession() {
        val paused = card(2).copy(dueAt = Srs.PAUSED)
        val cards = listOf(card(1), paused, card(3), card(4, lapses = 9), paused.copy(id = 5, lapses = 4))
        assertEquals(listOf(1L, 3L, 4L), selectCards(cards, 0, 0).map { it.id })
        // the range counts like the list the person sees, paused cards included
        assertEquals(listOf(3L, 4L), selectCards(cards, 2, 4).map { it.id })
        assertEquals(listOf(4L), selectCards(cards, -1, 0).map { it.id })
        assertTrue(paused.paused)
        assertTrue(card(1, lapses = Srs.STUBBORN).stubborn)
    }

    @Test fun rangeSelectionIsOneBasedAndInclusive() {
        val cards = (1L..30L).map { card(it) }.shuffled()
        assertEquals(30, selectCards(cards, 0, 0).size)
        assertEquals((1L..10L).toList(), selectCards(cards, 1, 10).map { it.id })
        assertEquals((11L..20L).toList(), selectCards(cards, 11, 20).map { it.id })
        assertEquals(listOf(30L), selectCards(cards, 30, 30).map { it.id })
    }

    @Test fun difficultCardsAreTheOnesWithLapses() {
        val cards = listOf(card(1), card(2, lapses = 1), card(3, lapses = 4))
        assertEquals(listOf(3L, 2L), selectCards(cards, -1, 0).map { it.id })
    }

    @Test fun typedAnswersTolerateTyposAndArticles() {
        assertEquals(AnswerResult.Correct, checkAnswer("Haus", "das Haus"))
        assertEquals(AnswerResult.Close, checkAnswer("Hous", "Haus"))
        assertEquals(AnswerResult.Wrong, checkAnswer("Baum", "Haus"))
    }

    @Test fun backupSurvivesARoundTrip() {
        val deck = Deck(id = 1, name = "Englisch", sourceLang = "en", targetLang = "de")
        val json = Backup.toJson(listOf(deck), listOf(card(1, lapses = 2).copy(level = 3)))
        val parsed = Backup.parse(json)
        assertNotNull(parsed)
        val c = parsed!!.single().cards.single()
        assertEquals("w1", c.source)
        assertEquals(3, c.level)
        assertEquals(2, c.lapses)
    }
}
