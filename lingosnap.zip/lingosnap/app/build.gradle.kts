plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.lingosnap"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.lingosnap"
        minSdk = 26
        targetSdk = 36
        // GitHub Actions passes the run number, so every build is a valid in-place update.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0.$versionCode"
    }

    // Fixed keystore checked into the project: every build has the SAME signature,
    // so Android installs new APKs over the old app without uninstalling.
    signingConfigs {
        create("lingosnap") {
            storeFile = file("lingosnap.jks")
            storePassword = "lingosnap123"
            keyAlias = "lingosnap"
            keyPassword = "lingosnap123"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("lingosnap")
        }
    }

    // lintVital would otherwise run (and may fail) during assembleRelease
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation(platform("androidx.compose:compose-bom:2025.10.01"))
    // Material 3 Expressive APIs (MaterialExpressiveTheme, LoadingIndicator, wavy progress) live in 1.4+
    implementation("androidx.compose.material3:material3:1.4.0")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.navigation:navigation-compose:2.9.5")
    implementation("androidx.exifinterface:exifinterface:1.4.1")

    // Local storage
    implementation("androidx.room:room-runtime:2.8.1")
    implementation("androidx.room:room-ktx:2.8.1")
    ksp("androidx.room:room-compiler:2.8.1")

    // Encrypted API-key storage
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Gemini REST calls
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // reads the text layer of PDFs (much faster and cheaper than sending page images)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
}
