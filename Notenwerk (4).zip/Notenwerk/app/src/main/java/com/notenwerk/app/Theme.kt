@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.notenwerk.app

import android.os.Build
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightScheme: ColorScheme = lightColorScheme(
    primary = Color(0xFF2F6A00),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFB0F67E),
    onPrimaryContainer = Color(0xFF0B2000),
    secondary = Color(0xFF56624A),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD9E7C8),
    onSecondaryContainer = Color(0xFF131F0B),
    tertiary = Color(0xFF386664),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFBBECE8),
    onTertiaryContainer = Color(0xFF00201F),
    background = Color(0xFFF8FAF0),
    onBackground = Color(0xFF191D16),
    surface = Color(0xFFF8FAF0),
    onSurface = Color(0xFF191D16),
    surfaceVariant = Color(0xFFE0E4D5),
    onSurfaceVariant = Color(0xFF44483D),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF2F5E9),
    surfaceContainer = Color(0xFFECEFE3),
    surfaceContainerHigh = Color(0xFFE6E9DE),
    surfaceContainerHighest = Color(0xFFE1E4D8),
    outline = Color(0xFF74796C),
)

private val DarkScheme: ColorScheme = darkColorScheme(
    primary = Color(0xFF95D963),
    onPrimary = Color(0xFF123800),
    primaryContainer = Color(0xFF225100),
    onPrimaryContainer = Color(0xFFB0F67E),
    secondary = Color(0xFFBDCBAD),
    onSecondary = Color(0xFF283420),
    secondaryContainer = Color(0xFF3E4A35),
    onSecondaryContainer = Color(0xFFD9E7C8),
    tertiary = Color(0xFFA0CFCC),
    onTertiary = Color(0xFF003736),
    tertiaryContainer = Color(0xFF1F4E4C),
    onTertiaryContainer = Color(0xFFBBECE8),
    background = Color(0xFF10140E),
    onBackground = Color(0xFFE1E4D8),
    surface = Color(0xFF10140E),
    onSurface = Color(0xFFE1E4D8),
    surfaceVariant = Color(0xFF44483D),
    onSurfaceVariant = Color(0xFFC4C8BA),
    surfaceContainerLowest = Color(0xFF0B0F09),
    surfaceContainerLow = Color(0xFF191D16),
    surfaceContainer = Color(0xFF1D211A),
    surfaceContainerHigh = Color(0xFF272B24),
    surfaceContainerHighest = Color(0xFF32362E),
    outline = Color(0xFF8E9285),
)

@Composable
fun NotenTheme(dark: Boolean, dynamic: Boolean, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> DarkScheme
        else -> LightScheme
    }
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        content = content,
    )
}
