package com.notenwerk.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.roundToInt

sealed interface Route {
    val depth: Int

    data object Home : Route {
        override val depth = 0
    }

    data class AddSubject(val sem: Int) : Route {
        override val depth = 1
    }

    data class SubjectDetail(val id: String, val sem: Int) : Route {
        override val depth = 1
    }

    /** kind: 0 = schriftlich, 1 = mündlich, 2 = Note festlegen */
    data class Entry(val subjectId: String, val sem: Int, val kind: Int, val gradeId: String?) : Route {
        override val depth = 2
    }
}

data class Grade(
    val id: String,
    val subjectId: String,
    val sem: Int,
    val kind: Int,
    val value: Double,
    val tendency: Int,
    val weight: Int,
)

data class Subject(
    val id: String,
    val name: String,
    val sems: Set<Int>,
    val writtenPct: Int = 20,
    val examPct: Int = 40,
    val finals: Map<Int, Double> = emptyMap(),
    val iconKey: String? = null,
)

fun badgeText(avg: Double, meanTendency: Double = 0.0): String {
    val r = avg.roundToInt().coerceIn(1, 6)
    val f = avg - r
    val t = when {
        f <= -0.17 -> 1
        f >= 0.17 -> -1
        else -> meanTendency.roundToInt()
    }
    return r.toString() + when (t) {
        1 -> "+"
        -1 -> "-"
        else -> ""
    }
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("notenwerk", Context.MODE_PRIVATE)

    val subjects = mutableStateListOf<Subject>()
    val grades = mutableStateListOf<Grade>()
    val stack = mutableStateListOf<Route>()

    var tab by mutableIntStateOf(0)

    /** 0 = System, 1 = Hell, 2 = Dunkel */
    var themeMode by mutableIntStateOf(prefs.getInt("theme", 0))
        private set
    var dynamicColor by mutableStateOf(prefs.getBoolean("dynamic", true))
        private set
    var tendencyDefault by mutableStateOf(prefs.getBoolean("tendencyDefault", true))
        private set
    var tendencyCounts by mutableStateOf(prefs.getBoolean("tendencyCounts", false))
        private set
    var decimals by mutableIntStateOf(prefs.getInt("decimals", 1))
        private set
    var bundesland by mutableStateOf(prefs.getString("bundesland", "") ?: "")
        private set
    var onboarded by mutableStateOf(prefs.getBoolean("onboarded", false))
        private set

    init {
        load()
        val saved = prefs.getString("lang", "de") ?: "de"
        if (!I18n.apply(app, saved)) I18n.apply(app, "de")
    }

    val current: Route get() = stack.lastOrNull() ?: Route.Home

    fun push(r: Route) {
        stack.add(r)
    }

    fun pop() {
        if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
    }

    // ---------- Einstellungen ----------
    fun updateThemeMode(v: Int) {
        themeMode = v; prefs.edit().putInt("theme", v).apply()
    }

    fun updateDecimals(v: Int) {
        decimals = v.coerceIn(0, 3); prefs.edit().putInt("decimals", decimals).apply()
    }

    fun updateBundesland(code: String) {
        bundesland = code; prefs.edit().putString("bundesland", code).apply()
    }

    fun finishOnboarding() {
        onboarded = true; prefs.edit().putBoolean("onboarded", true).apply()
    }

    /** Wendet eine installierte Sprache an und merkt sie sich. */
    fun updateLanguage(code: String): Boolean {
        val ok = I18n.apply(getApplication<Application>(), code)
        if (ok) prefs.edit().putString("lang", code).apply()
        return ok
    }

    /** Setzt die Gruppen-Gewichtung aller Fächer auf den Richtwert des Bundeslands. */
    fun applyWeightingToAll() {
        val w = weightingOf(bundesland)
        for (i in subjects.indices) subjects[i] = subjects[i].copy(writtenPct = w.written, examPct = w.exam)
        save()
    }

    fun setDynamic(v: Boolean) {
        dynamicColor = v; prefs.edit().putBoolean("dynamic", v).apply()
    }

    fun updateTendencyDefault(v: Boolean) {
        tendencyDefault = v; prefs.edit().putBoolean("tendencyDefault", v).apply()
    }

    fun updateTendencyCounts(v: Boolean) {
        tendencyCounts = v; prefs.edit().putBoolean("tendencyCounts", v).apply()
    }

    // ---------- Berechnung ----------
    private fun eff(g: Grade): Double =
        if (tendencyCounts) g.value - g.tendency * 0.33 else g.value

    fun effective(g: Grade): Double = eff(g).coerceIn(1.0, 6.0)

    private fun weighted(list: List<Grade>): Double? {
        if (list.isEmpty()) return null
        val w = list.sumOf { it.weight }.toDouble()
        return list.sumOf { eff(it) * it.weight } / w
    }

    fun gradesOf(subjectId: String, sem: Int, kind: Int): List<Grade> =
        grades.filter { it.subjectId == subjectId && it.sem == sem && it.kind == kind }

    fun avg(s: Subject, sem: Int): Double? {
        s.finals[sem]?.let { return it }
        // Gruppen: Klassenarbeiten (3), schriftlich (0), mündlich (1)
        val oral = (100 - s.writtenPct - s.examPct).coerceAtLeast(0)
        val parts = listOf(3 to s.examPct, 0 to s.writtenPct, 1 to oral)
        var num = 0.0
        var den = 0.0
        var plainSum = 0.0
        var plainN = 0
        for ((kind, pct) in parts) {
            val a = weighted(gradesOf(s.id, sem, kind)) ?: continue
            plainSum += a
            plainN++
            if (pct > 0) {
                num += a * pct
                den += pct
            }
        }
        val res = when {
            den > 0 -> num / den
            plainN > 0 -> plainSum / plainN
            else -> null
        }
        return res?.coerceIn(1.0, 6.0)
    }

    fun badge(s: Subject, sem: Int): String? {
        val a = avg(s, sem) ?: return null
        val own = if (s.finals.containsKey(sem)) emptyList()
        else grades.filter { it.subjectId == s.id && it.sem == sem }
        val mean = if (own.isEmpty()) 0.0 else own.map { it.tendency }.average()
        return badgeText(a, mean)
    }

    fun semAvg(sem: Int): Double? {
        val list = subjects.filter { sem in it.sems }.mapNotNull { avg(it, sem) }
        return if (list.isEmpty()) null else list.average()
    }

    fun yearAvg(s: Subject): Double? {
        val list = s.sems.sorted().mapNotNull { avg(s, it) }
        return if (list.isEmpty()) null else list.average()
    }

    fun overallYear(): Double? {
        val list = subjects.mapNotNull { yearAvg(it) }
        return if (list.isEmpty()) null else list.average()
    }

    // ---------- Änderungen ----------
    fun addSubject(name: String, sems: Set<Int>, iconKey: String? = null) {
        val n = name.trim()
        if (n.isEmpty() || sems.isEmpty()) return
        val idx = subjects.indexOfFirst { it.name.equals(n, ignoreCase = true) }
        if (idx >= 0) {
            val old = subjects[idx]
            subjects[idx] = old.copy(sems = old.sems + sems, iconKey = iconKey ?: old.iconKey)
        } else {
            val w = weightingOf(bundesland)
            subjects.add(Subject(UUID.randomUUID().toString(), n, sems, w.written, w.exam, emptyMap(), iconKey))
        }
        save()
    }

    fun setIcon(id: String, key: String?) {
        val i = subjects.indexOfFirst { it.id == id }
        if (i < 0) return
        subjects[i] = subjects[i].copy(iconKey = key)
        save()
    }

    fun renameSubject(id: String, name: String) {
        val n = name.trim()
        val i = subjects.indexOfFirst { it.id == id }
        if (i < 0 || n.isEmpty()) return
        subjects[i] = subjects[i].copy(name = n)
        save()
    }

    fun setGroups(id: String, written: Int, exam: Int) {
        val i = subjects.indexOfFirst { it.id == id }
        if (i < 0) return
        val e = exam.coerceIn(0, 100)
        val w = written.coerceIn(0, 100 - e)
        subjects[i] = subjects[i].copy(writtenPct = w, examPct = e)
        save()
    }

    fun deleteSubject(id: String) {
        subjects.removeAll { it.id == id }
        grades.removeAll { it.subjectId == id }
        save()
    }

    fun saveGrade(g: Grade) {
        val i = grades.indexOfFirst { it.id == g.id }
        if (i >= 0) grades[i] = g else grades.add(g)
        save()
    }

    fun deleteGrade(id: String) {
        grades.removeAll { it.id == id }
        save()
    }

    fun setFinal(subjectId: String, sem: Int, value: Double?) {
        val i = subjects.indexOfFirst { it.id == subjectId }
        if (i < 0) return
        val s = subjects[i]
        subjects[i] = s.copy(
            finals = if (value == null) s.finals - sem else s.finals + (sem to value)
        )
        save()
    }

    fun resetAll() {
        subjects.clear()
        grades.clear()
        stack.clear()
        save()
    }

    // ---------- Speichern / Laden ----------
    private fun save() {
        val sa = JSONArray()
        for (s in subjects) {
            val fin = JSONObject()
            for ((k, v) in s.finals) fin.put(k.toString(), v)
            sa.put(
                JSONObject()
                    .put("id", s.id)
                    .put("name", s.name)
                    .put("sems", JSONArray(s.sems.toList()))
                    .put("w", s.writtenPct)
                    .put("x", s.examPct)
                    .put("finals", fin)
                    .put("ic", s.iconKey ?: "")
            )
        }
        val ga = JSONArray()
        for (g in grades) {
            ga.put(
                JSONObject()
                    .put("id", g.id)
                    .put("s", g.subjectId)
                    .put("sem", g.sem)
                    .put("k", g.kind)
                    .put("v", g.value)
                    .put("t", g.tendency)
                    .put("w", g.weight)
            )
        }
        prefs.edit().putString("subjects", sa.toString()).putString("grades", ga.toString()).apply()
    }

    private fun load() {
        try {
            val sa = JSONArray(prefs.getString("subjects", "[]"))
            for (i in 0 until sa.length()) {
                val o = sa.getJSONObject(i)
                val semsArr = o.getJSONArray("sems")
                val sems = (0 until semsArr.length()).map { semsArr.getInt(it) }.toSet()
                val finObj = o.optJSONObject("finals") ?: JSONObject()
                val fin = HashMap<Int, Double>()
                for (k in finObj.keys()) fin[k.toInt()] = finObj.getDouble(k)
                subjects.add(Subject(o.getString("id"), o.getString("name"), sems, o.optInt("w", 40), o.optInt("x", 0), fin, o.optString("ic", "").ifEmpty { null }))
            }
            val ga = JSONArray(prefs.getString("grades", "[]"))
            for (i in 0 until ga.length()) {
                val o = ga.getJSONObject(i)
                grades.add(
                    Grade(
                        o.getString("id"), o.getString("s"), o.getInt("sem"), o.getInt("k"),
                        o.getDouble("v"), o.optInt("t", 0), o.optInt("w", 1)
                    )
                )
            }
        } catch (_: Exception) {
            subjects.clear(); grades.clear()
        }
    }
}
