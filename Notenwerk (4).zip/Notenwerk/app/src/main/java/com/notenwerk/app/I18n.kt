package com.notenwerk.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class Lang(val code: String, val name: String)

/** Deutsch ist eingebaut, alle anderen Sprachen werden erst bei Bedarf heruntergeladen. */
val languages = listOf(
    Lang("de", "Deutsch"),
    Lang("en", "English"),
    Lang("fr", "Français"),
    Lang("es", "Español"),
    Lang("it", "Italiano"),
    Lang("tr", "Türkçe"),
    Lang("pl", "Polski"),
)

object I18n {
    /** Deutscher Text -> Übersetzung. Leer = Deutsch. */
    var map by mutableStateOf<Map<String, String>>(emptyMap())
    var code by mutableStateOf("de")

    val locale: Locale get() = Locale.forLanguageTag(code)

    private fun file(ctx: Context, c: String) = File(ctx.filesDir, "lang-$c.json")

    fun installed(ctx: Context, c: String): Boolean = c == "de" || file(ctx, c).exists()

    /** Wendet eine bereits heruntergeladene Sprache an. */
    fun apply(ctx: Context, c: String): Boolean {
        if (c == "de") {
            map = emptyMap(); code = "de"; return true
        }
        val f = file(ctx, c)
        if (!f.exists()) return false
        return try {
            val o = JSONObject(f.readText())
            val m = HashMap<String, String>(o.length())
            for (k in o.keys()) m[k] = o.getString(k)
            map = m
            code = c
            true
        } catch (_: Exception) {
            f.delete()
            false
        }
    }

    /** Lädt das Sprachpaket aus dem GitHub-Release. Blockierend, daher nur im Hintergrund aufrufen. */
    fun download(ctx: Context, c: String): Boolean {
        return try {
            if (BuildConfig.REPO.isEmpty()) return false
            val url = URL("https://github.com/${BuildConfig.REPO}/releases/latest/download/lang-$c.json")
            val con = url.openConnection() as HttpURLConnection
            con.connectTimeout = 15000
            con.readTimeout = 20000
            con.instanceFollowRedirects = true
            if (con.responseCode != 200) return false
            val text = con.inputStream.bufferedReader().use { it.readText() }
            JSONObject(text) // prüfen, ob gültig
            val tmp = File(ctx.filesDir, "lang-$c.tmp")
            tmp.writeText(text)
            val dst = file(ctx, c)
            if (dst.exists()) dst.delete()
            tmp.renameTo(dst)
        } catch (_: Exception) {
            false
        }
    }
}

/** Übersetzt einen deutschen Text. Fehlt die Übersetzung, bleibt der deutsche Text stehen. */
fun t(s: String): String = I18n.map[s] ?: s

/** Wie t(), mit Platzhaltern {0}, {1} … */
fun tf(s: String, vararg a: Any): String {
    var r = t(s)
    a.forEachIndexed { i, v -> r = r.replace("{$i}", v.toString()) }
    return r
}
