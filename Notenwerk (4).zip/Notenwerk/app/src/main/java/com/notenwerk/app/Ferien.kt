@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.notenwerk.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit

// ======================================================================= Daten

class Bundesland(val code: String, val name: String)

val bundeslaender = listOf(
    Bundesland("BW", "Baden-Württemberg"),
    Bundesland("BY", "Bayern"),
    Bundesland("BE", "Berlin"),
    Bundesland("BB", "Brandenburg"),
    Bundesland("HB", "Bremen"),
    Bundesland("HH", "Hamburg"),
    Bundesland("HE", "Hessen"),
    Bundesland("MV", "Mecklenburg-Vorpommern"),
    Bundesland("NI", "Niedersachsen"),
    Bundesland("NW", "Nordrhein-Westfalen"),
    Bundesland("RP", "Rheinland-Pfalz"),
    Bundesland("SL", "Saarland"),
    Bundesland("SN", "Sachsen"),
    Bundesland("ST", "Sachsen-Anhalt"),
    Bundesland("SH", "Schleswig-Holstein"),
    Bundesland("TH", "Thüringen"),
)

fun bundeslandName(code: String): String = bundeslaender.firstOrNull { it.code == code }?.name ?: ""

class Holiday(val type: Char, val start: LocalDate, val end: LocalDate)

fun holidayName(type: Char): String = when (type) {
    'W' -> t("Winterferien")
    'O' -> t("Osterferien")
    'P' -> t("Pfingstferien")
    'S' -> t("Sommerferien")
    'H' -> t("Herbstferien")
    else -> t("Weihnachtsferien")
}

fun holidayColor(type: Char): Color = when (type) {
    'W' -> Color(0xFF1E88E5)
    'O' -> Color(0xFF43A047)
    'P' -> Color(0xFF8E24AA)
    'S' -> Color(0xFFEF6C00)
    'H' -> Color(0xFF8D6E63)
    else -> Color(0xFFC62828)
}

/** Format: Art (W Winter, O Ostern, P Pfingsten, S Sommer, H Herbst, X Weihnachten) + JJMMTT-JJMMTT */
private val ferienRaw: Map<String, String> = mapOf(
    "BW" to "O260330-260411;P260526-260605;S260730-260912;H261026-261030;X261223-270109;O270330-270403;P270518-270529;S270729-270911;H271102-271106;X271223-280108;O280418-280422;P280606-280617;S280727-280909",
    "BY" to "W260216-260220;O260330-260410;P260526-260605;S260803-260914;H261102-261106;X261224-270108;W270208-270212;O270322-270402;P270518-270528;S270802-270913;H271102-271105;X271224-280107;W280228-280303;O280410-280421;P280606-280616;S280731-280911",
    "BE" to "W260202-260207;O260330-260410;P260526-260526;S260709-260822;H261019-261031;X261223-270102;W270201-270206;O270322-270402;P270518-270519;S270701-270814;H271011-271023;X271222-271231;W280131-280205;O280410-280422;P280601-280602;S280701-280812",
    "BB" to "W260202-260207;O260330-260410;S260709-260822;H261019-261030;X261223-270102;W270201-270206;O270322-270403;S270701-270814;H271011-271023;X271223-271231;W280131-280205;O280410-280422;S280629-280812",
    "HB" to "W260202-260203;O260323-260407;P260526-260526;S260702-260812;H261012-261024;X261223-270109;W270201-270202;O270322-270403;P270518-270518;S270708-270818;H271018-271030;X271223-280108;W280131-280201;O280410-280422;P280606-280606;S280720-280830",
    "HH" to "W260130-260130;O260302-260313;P260511-260515;S260709-260819;H261019-261030;X261221-270101;W270129-270129;O270301-270312;P270507-270514;S270701-270811;H271011-271022;X271220-271231;W280128-280128;O280306-280317;P280522-280526;S280703-280811",
    "HE" to "O260330-260410;S260629-260807;H261005-261017;X261223-270112;O270322-270402;S270628-270806;H271004-271016;X271223-280111;O280403-280414;S280703-280811",
    "MV" to "W260209-260220;O260330-260408;P260522-260526;S260713-260822;H261015-261024;X261221-270102;W270208-270219;O270324-270402;P270514-270518;S270705-270814;H271014-271023;X271222-280104;W280205-280217;O280412-280421;P280602-280606;S280626-280805",
    "NI" to "W260202-260203;O260323-260407;P260526-260526;S260702-260812;H261012-261024;X261223-270109;W270201-270202;O270322-270403;P270518-270518;S270708-270818;H271016-271030;X271223-280108;W280131-280201;O280410-280422;P280606-280606;S280720-280830",
    "NW" to "O260330-260411;P260526-260526;S260720-260901;H261017-261031;X261223-270106;O270322-270403;P270518-270518;S270719-270831;H271023-271106;X271224-280108;O280410-280422;S280710-280822",
    "RP" to "O260330-260410;S260629-260807;H261005-261016;X261223-270108;O270322-270402;S270628-270806;H271004-271015;X271223-280107;O280410-280421;S280703-280811",
    "SL" to "W260216-260217;O260330-260408;S260706-260814;H261012-261023;X261221-270102;W270208-270209;O270329-270409;S270712-270820;H271010-271021;X271221-280101;W280212-280213;O280408-280417;S280709-280816",
    "SN" to "W260209-260221;O260403-260410;S260704-260814;H261012-261024;X261223-270102;W270208-270219;O270326-270402;P270515-270518;S270710-270820;H271011-271023;X271223-280101;W280214-280226;O280414-280422;S280722-280901",
    "ST" to "W260131-260206;O260330-260404;P260526-260529;S260704-260814;H261019-261030;X261221-270102;O270322-270327;P270515-270522;S270710-270820;H271018-271023;X271220-271231",
    "SH" to "O260326-260410;S260704-260815;H261012-261024;X261221-270106;O270330-270410;S270703-270814;H271011-271023;X271223-280108;O280403-280415;S280624-280804",
    "TH" to "W260216-260221;O260407-260417;S260704-260814;H261012-261024;X261223-270102;W270201-270206;O270322-270403;S270710-270820;H271009-271023;X271223-271231;W280207-280212;O280403-280415;S280722-280901",
)

private fun d6(s: String): LocalDate =
    LocalDate.of(2000 + s.substring(0, 2).toInt(), s.substring(2, 4).toInt(), s.substring(4, 6).toInt())

fun holidaysOf(code: String): List<Holiday> {
    val raw = ferienRaw[code] ?: return emptyList()
    return raw.split(';').filter { it.length >= 14 }.map {
        Holiday(it[0], d6(it.substring(1, 7)), d6(it.substring(8, 14)))
    }.sortedBy { it.start }
}

/** Richtwerte: Klassenarbeiten %, schriftlich %, mündlich = Rest. */
class Weighting(val exam: Int, val written: Int, val note: String) {
    val oral: Int get() = 100 - exam - written
}

private const val NOTE_STD = "Richtwert. Verbindlich legt deine Schule bzw. die Fachkonferenz die Gewichtung fest."

fun weightingOf(code: String): Weighting = when (code) {
    "BY" -> Weighting(67, 0, "Richtwert für Hauptfächer: Schulaufgaben zählen etwa doppelt so viel wie Kurzarbeiten und mündliche Note. Verbindlich legt deine Schule fest.")
    else -> Weighting(50, 0, NOTE_STD)
}

// ======================================================================= Auswahl & Start

@Composable
fun BundeslandList(selected: String, onPick: (String) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        items(bundeslaender, key = { it.code }) { b ->
            val sel = b.code == selected
            val shape = RoundedCornerShape(20.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .bouncy(shape, if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer) { onPick(b.code) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(MaterialShapes.Cookie6Sided.toShape())
                        .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        b.code,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
                Spacer(Modifier.width(16.dp))
                Text(b.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (sel) Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

/** Erster Start: Bundesland wählen. */
@Composable
fun StartScreen(vm: AppVM) {
    var pick by rememberSaveable { mutableStateOf(vm.bundesland) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Box(
            Modifier
                .size(72.dp)
                .clip(MaterialShapes.Cookie9Sided.toShape())
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.EmojiEvents, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(t("Willkommen bei Notenwerk"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            t("In welchem Bundesland gehst du zur Schule? Danach passen sich Ferienkalender und Notengewichtung an."),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        BundeslandList(pick, { pick = it }, Modifier.weight(1f))
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { vm.updateBundesland(pick); vm.finishOnboarding() },
            enabled = pick.isNotEmpty(),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        ) { Text(t("Weiter")) }
        TextButton(onClick = { vm.finishOnboarding() }, modifier = Modifier.fillMaxWidth()) { Text(t("Überspringen")) }
    }
}

// ======================================================================= Ferien-Tab

private fun monthIndex(ym: YearMonth) = ym.year * 12 + ym.monthValue - 1
private fun fromIndex(i: Int) = YearMonth.of(i / 12, i % 12 + 1)
private val MIN_IDX = 2026 * 12 + 1   // Februar 2026
private val MAX_IDX = 2028 * 12 + 11  // Dezember 2028

@Composable
fun FerienPage(vm: AppVM, pad: PaddingValues) {
    val today = remember { LocalDate.now() }
    val hol = remember(vm.bundesland) { holidaysOf(vm.bundesland) }
    var idx by rememberSaveable { mutableIntStateOf(monthIndex(YearMonth.from(today)).coerceIn(MIN_IDX, MAX_IDX)) }
    val loc = I18n.locale
    val m = MaterialTheme.motionScheme
    val spatial = m.defaultSpatialSpec<IntOffset>()
    val effects = m.defaultEffectsSpec<Float>()
    val dm = remember(loc) { DateTimeFormatter.ofPattern("d. MMM", loc) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = listPadding(pad),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "title") { TitleBar(t("Ferien")) }

        if (vm.bundesland.isEmpty()) {
            item(key = "none") {
                ContainerCard(t("Bundesland"), Icons.Filled.EmojiEvents) {
                    Text(t("Wähle in den Einstellungen dein Bundesland, dann siehst du hier deine Ferien."))
                }
            }
            return@LazyColumn
        }

        // Aktuell / als Nächstes
        item(key = "next") {
            val current = hol.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
            val upcoming = hol.filter { it.start.isAfter(today) }.take(3)
            ContainerCard(bundeslandName(vm.bundesland), Icons.Filled.EmojiEvents) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (current != null) {
                        val left = ChronoUnit.DAYS.between(today, current.end) + 1
                        HolidayLine(current, dm, tf("noch {0} Tage", left), true)
                    }
                    upcoming.forEach {
                        val days = ChronoUnit.DAYS.between(today, it.start)
                        HolidayLine(it, dm, tf("in {0} Tagen", days), false)
                    }
                    if (current == null && upcoming.isEmpty()) Text(t("Keine weiteren Termine hinterlegt."))
                }
            }
        }

        // Kalender
        item(key = "calendar") {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AnimatedContent(
                    targetState = idx,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (slideInHorizontally(spatial) { it / 3 * dir } + fadeIn(effects)) togetherWith
                                (slideOutHorizontally(spatial) { -it / 3 * dir } + fadeOut(effects))
                    },
                    label = "month",
                ) { i ->
                    MonthGrid(fromIndex(i), hol, today, loc,
                        onPrev = { if (idx > MIN_IDX) idx-- },
                        onNext = { if (idx < MAX_IDX) idx++ },
                        canPrev = i > MIN_IDX, canNext = i < MAX_IDX)
                }
            }
        }

        // Legende
        item(key = "legend") {
            val types = "WOPSHX".toList()
            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(horizontal = 8.dp)) {
                types.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        row.forEach { ty ->
                            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier
                                        .size(14.dp)
                                        .clip(CircleShape)
                                        .background(holidayColor(ty))
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(holidayName(ty), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                Text(
                    t("Angaben ohne Gewähr. Maßgeblich sind die Termine deines Kultusministeriums."),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun HolidayLine(h: Holiday, f: DateTimeFormatter, trailing: String, active: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(40.dp)
                .clip(MaterialShapes.Cookie6Sided.toShape())
                .background(holidayColor(h.type)),
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(holidayName(h.type), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            val range = if (h.start == h.end) h.start.format(f) else h.start.format(f) + " – " + h.end.format(f)
            Text(range, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            trailing,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun MonthGrid(
    ym: YearMonth,
    hol: List<Holiday>,
    today: LocalDate,
    loc: java.util.Locale,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    canPrev: Boolean,
    canNext: Boolean,
) {
    val title = remember(ym, loc) { ym.atDay(1).format(DateTimeFormatter.ofPattern("LLLL yyyy", loc)) }
    val first = ym.atDay(1)
    val offset = first.dayOfWeek.value - 1
    val cells = offset + ym.lengthOfMonth()
    val rows = (cells + 6) / 7

    fun holidayAt(d: LocalDate): Holiday? = hol.firstOrNull { !d.isBefore(it.start) && !d.isAfter(it.end) }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalIconButton(onClick = onPrev, enabled = canPrev) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null)
            }
            Text(
                title.replaceFirstChar { it.uppercase() },
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
            )
            FilledTonalIconButton(onClick = onNext, enabled = canNext) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
            }
        }
        Row {
            for (i in 1..7) {
                Text(
                    DayOfWeek.of(i).getDisplayName(TextStyle.SHORT, loc).take(2),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until 7) {
                    val n = r * 7 + c - offset + 1
                    if (n < 1 || n > ym.lengthOfMonth()) {
                        Spacer(Modifier.weight(1f))
                    } else {
                        val d = ym.atDay(n)
                        val h = holidayAt(d)
                        val prevIn = h != null && c > 0 && holidayAt(d.minusDays(1))?.let { it === h } == true
                        val nextIn = h != null && c < 6 && holidayAt(d.plusDays(1))?.let { it === h } == true
                        val shape = RoundedCornerShape(
                            topStart = if (prevIn) 0.dp else 20.dp, bottomStart = if (prevIn) 0.dp else 20.dp,
                            topEnd = if (nextIn) 0.dp else 20.dp, bottomEnd = if (nextIn) 0.dp else 20.dp,
                        )
                        val isToday = d == today
                        Box(
                            Modifier
                                .weight(1f)
                                .height(42.dp)
                                .clip(if (h != null) shape else CircleShape)
                                .background(if (h != null) holidayColor(h.type) else Color.Transparent)
                                .then(
                                    if (isToday) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, if (h != null) shape else CircleShape)
                                    else Modifier
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                "$n",
                                color = when {
                                    h != null -> Color.White
                                    c >= 5 -> MaterialTheme.colorScheme.onSurfaceVariant
                                    else -> MaterialTheme.colorScheme.onSurface
                                },
                                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                            )
                        }
                    }
                }
            }
        }
    }
}
