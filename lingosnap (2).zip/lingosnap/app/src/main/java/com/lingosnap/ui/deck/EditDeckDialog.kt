package com.lingosnap.ui.deck

import com.lingosnap.util.tr

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lingosnap.container
import com.lingosnap.data.model.Deck
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.create.LanguageField
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/** Change name, languages or subject of an existing deck. */
@Composable
fun EditDeckDialog(deck: Deck, onDismiss: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(deck.name) }
    var source by remember { mutableStateOf(deck.sourceLang) }
    var target by remember { mutableStateOf(deck.targetLang) }
    var subject by remember { mutableStateOf(deck.description) }
    var busy by remember { mutableStateOf(false) }

    com.lingosnap.ui.components.FormSheet(
        title = tr("Deck bearbeiten"),
        onDismiss = onDismiss,
        confirmLabel = tr("Speichern"),
        confirmEnabled = name.isNotBlank(),
        busy = busy,
        onConfirm = {
            busy = true
            scope.launch {
                repo.updateDeck(deck, name, source, target, subject)
                onDismiss()
            }
        },
    ) {
        AppTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(tr("Name des Decks")) }, singleLine = true)
        if (deck.isLanguage) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LanguageField(tr("Ich lerne"), source, Modifier.weight(1f), allowAuto = true) { source = it }
                IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                    Icon(Icons.Rounded.SwapHoriz, tr("Tauschen"))
                }
                LanguageField(tr("Meine Sprache"), target, Modifier.weight(1f)) { target = it }
            }
            Text(
                tr("Die Sprachen gelten für alle Karten dieses Decks (Vorlesen und Anzeige)."),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        } else {
            AppTextField(
                subject, { subject = it }, Modifier.fillMaxWidth(),
                label = { Text(tr("Worum geht es? (hilft der KI)")) }, minLines = 2,
            )
        }
    }
}
