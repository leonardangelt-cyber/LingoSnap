@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.lingosnap.ui.create

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.components.IconBadge
import com.lingosnap.ui.components.SheetHandle
import com.lingosnap.util.tr
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * New deck in two small steps: (1) the "+" button fans out two pills – Vokabeln / Karteikarten – over a dimmed screen,
 * (2) a short sheet asks only for the name (plus languages or subject). Then: add words later or right now.
 */
@Composable
fun NewDeckPills(visible: Boolean, onPick: (languageDeck: Boolean) -> Unit, onDismiss: () -> Unit) {
    if (!visible) return
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val cs = MaterialTheme.colorScheme
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Box(
            Modifier.fillMaxSize()
                .background(cs.surface.copy(alpha = 0.92f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
                .navigationBarsPadding().padding(16.dp),
        ) {
            Column(
                Modifier.align(Alignment.BottomEnd),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                listOf(
                    Triple(tr("Karteikarten"), Icons.Rounded.Style, false),
                    Triple(tr("Vokabeln"), Icons.Rounded.Translate, true),
                ).forEachIndexed { i, (label, icon, lang) ->
                    AnimatedVisibility(
                        visible = shown,
                        enter = fadeIn(tween(180, delayMillis = i * 60)) +
                            slideInVertically(tween(260, delayMillis = i * 60)) { it / 2 } +
                            scaleIn(tween(260, delayMillis = i * 60), initialScale = 0.8f),
                        exit = fadeOut(),
                    ) {
                        Surface(
                            onClick = { onPick(lang) },
                            shape = CircleShape,
                            color = cs.secondaryContainer,
                            contentColor = cs.onSecondaryContainer,
                            shadowElevation = 3.dp,
                        ) {
                            Row(Modifier.heightIn(min = 56.dp).padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(icon, null, Modifier.size(24.dp))
                                Spacer(Modifier.width(12.dp))
                                Text(label, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
                FloatingActionButton(
                    onClick = onDismiss,
                    containerColor = cs.primaryContainer,
                    contentColor = cs.onPrimaryContainer,
                ) { Icon(Icons.Rounded.Close, tr("Schließen")) }
            }
        }
    }
}

/** The short naming sheet. [onCreated] gets the new deck's id and whether the user wants to add words right now. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewDeckSheet(languageDeck: Boolean, existingSubjects: List<String>, onCreated: (Long, Boolean) -> Unit, onDismiss: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "en")
    }
    var busy by remember { mutableStateOf(false) }

    fun create(now: Boolean) {
        if (busy) return
        busy = true
        scope.launch {
            val finalName = name.trim().ifBlank { DEFAULT_DECK_NAME }
            val id = if (languageDeck) repo.createDeck(finalName, null, source, target, "")
            else repo.createDeck(finalName, null, "", "", subject.trim(), kind = "cards")
            onCreated(id, now)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerLow,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
        dragHandle = { SheetHandle() },
    ) {
        Column(
            Modifier.fillMaxWidth().imePadding().navigationBarsPadding().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(if (languageDeck) Icons.Rounded.Translate else Icons.Rounded.Style, container = cs.primaryContainer, content = cs.onPrimaryContainer)
                Spacer(Modifier.width(14.dp))
                Text(if (languageDeck) tr("Neues Vokabel-Deck") else tr("Neues Karteikarten-Deck"), style = MaterialTheme.typography.titleLarge)
            }
            AppTextField(
                value = name, onValueChange = { name = it },
                label = { Text(tr("Name des Decks einfügen")) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            if (languageDeck) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LanguageField(tr("Ich lerne"), source, Modifier.weight(1f), allowAuto = true) { source = it }
                    IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                        Icon(Icons.Rounded.SwapHoriz, tr("Tauschen"))
                    }
                    LanguageField(tr("Meine Sprache"), target, Modifier.weight(1f)) { target = it }
                }
            } else {
                AppTextField(
                    value = subject, onValueChange = { subject = it },
                    label = { Text(tr("Fach (optional)")) },
                    placeholder = { Text(tr("z. B. Biologie")) },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                if (existingSubjects.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        existingSubjects.forEach { s ->
                            AssistChip(onClick = { subject = s }, label = { Text(s) })
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(
                    onClick = { create(false) }, enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                ) { Text(if (languageDeck) tr("Später Vokabeln hinzufügen") else tr("Später Karten hinzufügen"), maxLines = 2) }
                Button(
                    onClick = { create(true) }, enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                ) { Text(if (languageDeck) tr("Jetzt Vokabeln hinzufügen") else tr("Jetzt Karten hinzufügen"), maxLines = 2) }
            }
        }
    }
}
