package com.lingosnap.ui.create

import com.lingosnap.util.tr

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.lingosnap.ui.components.AppTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.lingosnap.ui.components.OptionSheet
import androidx.compose.material.icons.rounded.ExpandMore
import com.lingosnap.ui.components.SegmentedItem
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.Surface
import androidx.compose.material3.RadioButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Style
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.SupportedLanguages
import com.lingosnap.data.model.languageName
import com.lingosnap.ui.components.LargeScreen
import com.lingosnap.ui.theme.bold
import kotlinx.coroutines.launch

/**
 * One page: kind of deck, optional name, languages – and the way to fill it. Every start button creates the deck and
 * jumps straight into that way (photo, AI, typing), so there is no extra menu in between. No name: the AI picks one
 * once the first cards are there.
 */
@Composable
fun NewDeckScreen(onCreated: (id: Long, method: Int) -> Unit, onBack: () -> Unit) {
    val repo = LocalContext.current.container.repository
    val scope = rememberCoroutineScope()
    var languageDeck by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("auto") }
    var target by rememberSaveable {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (SupportedLanguages.any { it.tag == sys }) sys else "en")
    }
    var busy by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    fun create(method: Int) {
        if (busy) return
        busy = true
        scope.launch {
            val finalName = name.trim().ifBlank { DEFAULT_DECK_NAME }
            val id = if (languageDeck) repo.createDeck(finalName, null, source, target, "")
            else repo.createDeck(finalName, null, "", "", subject, kind = "cards")
            onCreated(id, method)
        }
    }

    LargeScreen(
        title = tr("Neues Deck"),
        onBack = onBack,
        bottomBar = {
            Surface(color = cs.surfaceContainer) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(tr("Womit möchtest du starten?"), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    Button(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                        enabled = !busy,
                        onClick = { create(1) },
                    ) { Text(tr("Foto oder Datei scannen")) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        androidx.compose.material3.FilledTonalButton(
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            enabled = !busy,
                            onClick = { create(2) },
                        ) { Text(tr("Mit KI erzeugen")) }
                        androidx.compose.material3.FilledTonalButton(
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            enabled = !busy,
                            onClick = { create(0) },
                        ) { Text(tr("Eintippen")) }
                    }
                    androidx.compose.material3.TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !busy,
                        onClick = { create(-2) },
                    ) { Text(tr("Leeres Deck erstellen")) }
                }
            }
        },
    ) { inner ->
        Column(
            Modifier.padding(inner).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(tr("Was möchtest du lernen?"), style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = languageDeck, onClick = { languageDeck = true },
                    label = { Text(tr("Sprache lernen")) },
                    leadingIcon = { Icon(Icons.Rounded.Translate, null) },
                )
                FilterChip(
                    selected = !languageDeck, onClick = { languageDeck = false },
                    label = { Text(tr("Karteikarten")) },
                    leadingIcon = { Icon(Icons.Rounded.Style, null) },
                )
            }
            Text(
                if (languageDeck) tr("Vokabeln mit Wort, Übersetzung, Beispielsatz und Vorlesen")
                else tr("Frage und Antwort zu jedem anderen Thema, auch mit Bildern"),
                style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
            )
            AppTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(tr("Name des Decks (optional)")) },
                placeholder = { Text(tr("Leer lassen: die KI findet einen Namen")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            if (languageDeck) {
                Text(tr("Sprachen"), style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LanguageField(tr("Ich lerne"), source, Modifier.weight(1f), allowAuto = true) { source = it }
                    IconButton(enabled = source != "auto", onClick = { val t = source; source = target; target = t }) {
                        Icon(Icons.Rounded.SwapHoriz, tr("Tauschen"))
                    }
                    LanguageField(tr("Meine Sprache"), target, Modifier.weight(1f)) { target = it }
                }
                Surface(shape = MaterialTheme.shapes.large, color = cs.secondaryContainer, contentColor = cs.onSecondaryContainer) {
                    Text(
                        tr("Bei „Automatisch“ erkennt die KI die Sprache jedes Worts selbst und übersetzt fehlende Übersetzungen in deine Zielsprache."),
                        Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            } else {
                AppTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text(tr("Worum geht es? (hilft der KI)")) },
                    placeholder = { Text(tr("z. B. Biologie Klasse 9, Zellaufbau")) },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
internal fun LanguageField(label: String, value: String, modifier: Modifier = Modifier, allowAuto: Boolean = false, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        AppTextField(
            value = if (value == "auto") tr("Automatisch") else languageName(value),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable { open = true })
    }
    if (open) {
        OptionSheet(
            title = label,
            options = (if (allowAuto) listOf("auto" to tr("Automatisch")) else emptyList()) + SupportedLanguages.map { it.tag to it.label },
            selected = value,
            onPick = { onPick(it); open = false },
            onDismiss = { open = false },
        )
    }
}
