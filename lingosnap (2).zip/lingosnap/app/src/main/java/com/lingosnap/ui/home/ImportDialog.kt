package com.lingosnap.ui.home

import com.lingosnap.util.tr

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lingosnap.container
import com.lingosnap.ui.components.AppChip
import com.lingosnap.ui.components.AppTextField
import com.lingosnap.ui.create.LanguageField
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.ParsedImport
import kotlinx.coroutines.launch

/** Shows what was found in the file and, if the file does not say, asks for deck type and languages. */
@Composable
fun ImportDialog(parsed: ParsedImport, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val repo = ctx.container.repository
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val single = parsed.decks.size == 1
    var name by remember { mutableStateOf(parsed.decks.first().name) }
    var languageDeck by remember { mutableStateOf(true) }
    var source by remember { mutableStateOf("es") }
    var target by remember {
        val sys = java.util.Locale.getDefault().language
        mutableStateOf(if (com.lingosnap.data.model.SupportedLanguages.any { it.tag == sys }) sys else "en")
    }
    var busy by remember { mutableStateOf(false) }
    val cardCount = parsed.decks.sumOf { it.cards.size }

    com.lingosnap.ui.components.FormSheet(
        title = tr("Importieren"),
        subtitle = (if (single) tr("1 Deck") else tr("{0} Decks", parsed.decks.size)) + tr(" mit {0} Karten gefunden.", cardCount),
        onDismiss = onDismiss,
        confirmLabel = tr("Importieren"),
        confirmEnabled = !single || name.isNotBlank(),
        busy = busy,
        onConfirm = {
            busy = true
            scope.launch {
                val n = repo.importDecks(
                    parsed.decks,
                    fallbackKind = if (languageDeck) "language" else "cards",
                    fallbackSource = source, fallbackTarget = target,
                    names = if (single) mapOf(0 to name) else emptyMap(),
                )
                Toast.makeText(ctx, tr("{0} Karten importiert", n), Toast.LENGTH_SHORT).show()
                onDismiss()
            }
        },
    ) {
        if (!single) {
            parsed.decks.forEach { Text("• ${it.name} (${it.cards.size})", style = MaterialTheme.typography.bodyMedium) }
        } else {
            AppTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(tr("Name des Decks")) }, singleLine = true)
        }
        if (!parsed.hasMeta) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppChip(languageDeck, { languageDeck = true }, tr("Sprache lernen"))
                AppChip(!languageDeck, { languageDeck = false }, tr("Karteikarten"))
            }
            if (languageDeck) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LanguageField(tr("Ich lerne"), source, Modifier.weight(1f)) { source = it }
                    IconButton(onClick = { val t = source; source = target; target = t }) { Icon(Icons.Rounded.SwapHoriz, tr("Tauschen")) }
                    LanguageField(tr("Meine Sprache"), target, Modifier.weight(1f)) { target = it }
                }
            }
        }
    }
}
