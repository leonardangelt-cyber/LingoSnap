package com.lingosnap.ui.study

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lingosnap.container
import com.lingosnap.data.model.Flashcard
import com.lingosnap.data.model.languageNameEn
import com.lingosnap.ui.mascot.Axolotl
import com.lingosnap.ui.mascot.Mood
import com.lingosnap.ui.theme.bold
import com.lingosnap.util.tr
import kotlinx.coroutines.launch

/**
 * Chat with the mascot Axi. With a [card] the questions are about that card (differences, examples, usage);
 * without one it is a free chat about learning and the app.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatSheet(card: Flashcard?, onDismiss: () -> Unit) {
    val gemini = LocalContext.current.container.gemini
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val language = card?.sourceLang?.isNotBlank() == true
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scroll = rememberScrollState()

    LaunchedEffect(messages.size, loading) { scroll.animateScrollTo(scroll.maxValue) }

    fun ask(q: String) {
        if (loading || q.isBlank()) return
        val history = messages.toList()
        messages += true to q.trim()
        input = ""; loading = true; error = null
        scope.launch {
            val r = if (card != null) gemini.chatAbout(card.source, card.target, if (language) languageNameEn(card.sourceLang) else "", history, q.trim())
            else gemini.chatMascot(history, q.trim())
            r.onSuccess { messages += false to it }.onFailure { error = it.message ?: tr("Die KI hat nicht geantwortet") }
            loading = false
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerLow,
        shape = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
    ) {
        Column(Modifier.navigationBarsPadding().imePadding().padding(bottom = 12.dp)) {
            // header: Axi + what we talk about
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(cs.secondaryContainer)) {
                    Axolotl(Modifier.size(64.dp).padding(4.dp), mood = if (loading) Mood.Thinking else Mood.Idle)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Axi", style = MaterialTheme.typography.titleLarge.bold())
                    Text(
                        if (card != null) tr("Fragen zu dieser Karte") else tr("Frag mich zum Lernen oder zur App"),
                        style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
                    )
                }
            }
            if (card != null) Surface(
                Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth(),
                shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerHigh,
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Style, null, Modifier.size(20.dp), tint = cs.primary)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(card.source, style = MaterialTheme.typography.titleMedium.bold(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(card.target, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            // conversation
            Column(
                Modifier.heightIn(min = 120.dp, max = 340.dp).verticalScroll(scroll).padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (messages.isEmpty()) Bubble(false, if (card != null) tr("Hallo! Was möchtest du über diese Karte wissen?") else tr("Hallo, ich bin Axi! Ich helfe dir beim Lernen und zeige dir die App."))
                messages.forEach { (user, text) -> Bubble(user, text) }
                if (loading) TypingBubble()
                error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
            }
            // quick questions
            if (messages.isEmpty()) {
                val ideas: List<Pair<ImageVector, String>> = when {
                    card == null -> listOf(
                        Icons.Rounded.Lightbulb to tr("Wie lerne ich am besten?"),
                        Icons.Rounded.HelpOutline to tr("Was kann die App?"),
                        Icons.Rounded.FormatListBulleted to tr("Wie lege ich ein Deck an?"),
                    )
                    language -> listOf(
                        Icons.Rounded.CompareArrows to tr("Wie unterscheidet es sich von ähnlichen Wörtern?"),
                        Icons.Rounded.FormatListBulleted to tr("Gib mir drei weitere Beispiele"),
                        Icons.Rounded.HelpOutline to tr("Wann benutze ich es nicht?"),
                    )
                    else -> listOf(
                        Icons.Rounded.Lightbulb to tr("Erkläre es mir einfacher"),
                        Icons.Rounded.FormatListBulleted to tr("Gib mir ein Beispiel aus dem Alltag"),
                        Icons.Rounded.CompareArrows to tr("Was verwechselt man damit oft?"),
                    )
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ideas.forEach { (icon, text) ->
                        AssistChip(
                            onClick = { ask(text) }, label = { Text(text) },
                            leadingIcon = { Icon(icon, null, Modifier.size(AssistChipDefaults.IconSize), tint = cs.primary) },
                            shape = CircleShape,
                        )
                    }
                }
            }
            // input pill
            Surface(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth(),
                shape = CircleShape, color = cs.surfaceContainerHighest,
            ) {
                Row(Modifier.padding(start = 20.dp, end = 6.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        if (input.isEmpty()) Text(if (card != null) tr("Frage zu dieser Karte") else tr("Schreib Axi etwas"), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
                        BasicTextField(
                            input, { input = it }, Modifier.fillMaxWidth(),
                            textStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface),
                            cursorBrush = SolidColor(cs.primary),
                            maxLines = 4,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { ask(input) }),
                        )
                    }
                    FilledIconButton(onClick = { ask(input) }, enabled = input.isNotBlank() && !loading, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Rounded.Send, tr("Senden"))
                    }
                }
            }
        }
    }
}

@Composable
private fun Bubble(user: Boolean, text: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
        if (!user) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(cs.secondaryContainer)) { Axolotl(Modifier.size(32.dp).padding(2.dp)) }
            Spacer(Modifier.width(8.dp))
        }
        Surface(
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (user) 20.dp else 6.dp, bottomEnd = if (user) 6.dp else 20.dp),
            color = if (user) cs.primary else cs.surfaceContainerHigh,
            contentColor = if (user) cs.onPrimary else cs.onSurface,
            modifier = Modifier.widthIn(max = 300.dp),
        ) { Text(text, Modifier.padding(horizontal = 16.dp, vertical = 12.dp), style = MaterialTheme.typography.bodyLarge) }
    }
}

@Composable
private fun TypingBubble() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "typing")
    Row(verticalAlignment = Alignment.Bottom) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(cs.secondaryContainer)) { Axolotl(Modifier.size(32.dp).padding(2.dp), mood = Mood.Thinking) }
        Spacer(Modifier.width(8.dp))
        Surface(shape = RoundedCornerShape(20.dp), color = cs.surfaceContainerHigh) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (i in 0..2) {
                    val y by t.animateFloat(0f, -6f, infiniteRepeatable(tween(420, delayMillis = i * 140), RepeatMode.Reverse), label = "dot$i")
                    Box(Modifier.offset(y = y.dp).size(8.dp).clip(CircleShape).background(cs.onSurfaceVariant))
                }
            }
        }
    }
}
