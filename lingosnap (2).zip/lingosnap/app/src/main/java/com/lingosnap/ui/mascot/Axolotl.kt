package com.lingosnap.ui.mascot

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** How Axi feels: drives eyes, mouth and posture. */
enum class Mood { Idle, Happy, Thinking, Talking, Sad }

private val Pink = Color(0xFFF7A8C4)
private val PinkLight = Color(0xFFFFE0EA)
private val Head = Color(0xFFFFC4D8)
private val Gill = Color(0xFFEE5A91)
private val GillTip = Color(0xFFFF86AE)
private val Cheek = Color(0x66FF6F9F)
private val Ink = Color(0xFF2B1B2A)
private val Mouth = Color(0xFF8E2A55)
private val Tongue = Color(0xFFFF7FA6)

/**
 * Axi, the app's mascot: an axolotl (critically endangered in the wild – it only lives in the lakes near Mexico City).
 * Drawn completely in code, so it can be animated: it floats, wiggles its gills and tail, blinks, looks around and
 * changes face with its [mood]. [look] is a direction (roughly -1..1) the eyes follow.
 */
@Composable
fun Axolotl(modifier: Modifier = Modifier, mood: Mood = Mood.Idle, look: Offset = Offset.Zero) {
    val loop = rememberInfiniteTransition(label = "axi")
    // one slow clock (6 s); everything that moves is a whole number of cycles of it, so the loop is seamless
    val t by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "axiClock")
    val talk by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(260, easing = LinearEasing), RepeatMode.Reverse), label = "axiTalk")
    val blink = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(2200, 5200))
            blink.animateTo(1f, tween(70))
            blink.animateTo(0f, tween(120))
        }
    }
    val targetLook = if (mood == Mood.Thinking) Offset(0.7f, -0.8f) else look
    val lookX by animateFloatAsState(targetLook.x.coerceIn(-1f, 1f), tween(220), label = "lookX")
    val lookY by animateFloatAsState(targetLook.y.coerceIn(-1f, 1f), tween(220), label = "lookY")
    val tilt by animateFloatAsState(if (mood == Mood.Thinking) 7f else if (mood == Mood.Sad) -4f else 0f, tween(400), label = "tilt")
    val gillSpeed = if (mood == Mood.Happy || mood == Mood.Talking) 2f else 1f

    Canvas(modifier.aspectRatio(1f)) {
        val k = size.minDimension / 200f
        val tau = (2 * PI).toFloat()
        val bob = sin(t * tau) * 4f
        scale(k, k, Offset.Zero) {
            translate(0f, bob + 6f) {
                rotate(tilt + sin(t * tau) * 1.2f, Offset(100f, 120f)) {
                    drawAxi(t, tau, gillSpeed, blink.value, mood, lookX, lookY, talk)
                }
            }
        }
    }
}

private fun DrawScope.drawAxi(t: Float, tau: Float, gillSpeed: Float, blink: Float, mood: Mood, lookX: Float, lookY: Float, talk: Float) {
    // tail, wagging
    rotate(sin(t * tau * 2f) * 9f, Offset(132f, 160f)) {
        drawOval(Pink, Offset(126f, 148f), Size(58f, 24f))
        drawOval(Gill.copy(alpha = 0.55f), Offset(138f, 156f), Size(40f, 8f))
    }
    // body and belly
    drawOval(Pink, Offset(52f, 126f), Size(96f, 60f))
    drawOval(PinkLight, Offset(70f, 146f), Size(60f, 34f))
    // little feet
    drawOval(Pink, Offset(50f, 168f), Size(28f, 18f))
    drawOval(Pink, Offset(122f, 168f), Size(28f, 18f))
    // gills (behind the head): three feathery stalks on each side
    for (side in intArrayOf(-1, 1)) {
        for (i in 0..2) {
            val baseX = 100f + side * 50f
            val baseY = 82f + i * 13f
            val sway = sin(t * tau * 3f * gillSpeed + i * 0.9f + (if (side < 0) 0f else 0.6f)) * 8f
            val ang = Math.toRadians((-38.0 + i * 24.0) + sway)
            val len = 40f - i * 3f
            val end = Offset(baseX + side * cos(ang).toFloat() * len, baseY + sin(ang).toFloat() * len)
            drawLine(Gill, Offset(baseX, baseY), end, strokeWidth = 9f, cap = StrokeCap.Round)
            // small side filaments
            val mid = Offset((baseX + end.x) / 2f, (baseY + end.y) / 2f)
            drawLine(GillTip, mid, Offset(mid.x + side * 6f, mid.y - 9f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawCircle(GillTip, 6f, end)
        }
    }
    // head
    drawOval(Head, Offset(36f, 46f), Size(128f, 106f))
    drawOval(Color.White.copy(alpha = 0.22f), Offset(58f, 54f), Size(54f, 22f))
    // cheeks
    drawCircle(Cheek, 11f, Offset(62f, 118f))
    drawCircle(Cheek, 11f, Offset(138f, 118f))
    // eyes
    val eyeY = if (mood == Mood.Sad) 102f else 98f
    for (cx in floatArrayOf(78f, 122f)) {
        when {
            mood == Mood.Happy -> {
                // happy closed eyes: little arches
                val p = Path().apply {
                    moveTo(cx - 8f, eyeY + 3f)
                    quadraticBezierTo(cx, eyeY - 9f, cx + 8f, eyeY + 3f)
                }
                drawPath(p, Ink, style = Stroke(width = 4f, cap = StrokeCap.Round))
            }
            else -> {
                val open = 1f - blink * 0.92f
                val h = 17f * open
                val ex = cx + lookX * 3f
                val ey = eyeY + lookY * 3f
                drawOval(Ink, Offset(ex - 7.5f, ey - h / 2f), Size(15f, h))
                if (open > 0.5f) {
                    drawCircle(Color.White, 2.6f, Offset(ex + 2.4f, ey - h / 4f))
                    drawCircle(Color.White.copy(alpha = 0.8f), 1.3f, Offset(ex - 2.4f, ey + h / 5f))
                }
            }
        }
    }
    // mouth
    when (mood) {
        Mood.Talking -> {
            val open = 2f + 8f * talk
            drawOval(Mouth, Offset(100f - 8f, 124f - open / 2f), Size(16f, open))
            if (open > 7f) drawOval(Tongue, Offset(100f - 5f, 124f + open / 2f - 4f), Size(10f, 4f))
        }
        Mood.Happy -> {
            val p = Path().apply {
                moveTo(86f, 118f)
                quadraticBezierTo(100f, 146f, 114f, 118f)
                close()
            }
            drawPath(p, Mouth)
            drawOval(Tongue, Offset(94f, 128f), Size(12f, 7f))
        }
        Mood.Sad -> {
            val p = Path().apply {
                moveTo(89f, 128f)
                quadraticBezierTo(100f, 119f, 111f, 128f)
            }
            drawPath(p, Mouth, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
        }
        Mood.Thinking -> {
            drawOval(Mouth, Offset(96f, 122f), Size(9f, 7f))
        }
        else -> {
            val p = Path().apply {
                moveTo(88f, 120f)
                quadraticBezierTo(100f, 132f, 112f, 120f)
            }
            drawPath(p, Mouth, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
        }
    }
}
